package dev.shaurmalib.anim.fabric;

import dev.shaurmalib.anim.emote.EmoteMessage;
import dev.shaurmalib.anim.mc.emote.ServerEmotes;
import dev.shaurmalib.anim.net.AnimMessage;
import dev.shaurmalib.anim.net.AnimNetwork;
import dev.shaurmalib.fabric.WireCodec;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;

public final class FabricAnimBootstrap implements ModInitializer {
    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(Animation.TYPE,
            WireCodec.of(AnimMessage::read, AnimMessage::write, Animation::message, Animation::new));
        PayloadTypeRegistry.playC2S().register(Emote.TYPE,
            WireCodec.of(EmoteMessage::read, EmoteMessage::write, Emote::message, Emote::new));

        AnimNetwork.set((entity, message, includeSelf) -> {
            if (!(entity instanceof class_1297 e) || e.method_37908().field_9236) return;
            var payload = new Animation(message);
            for (class_3222 player : PlayerLookup.tracking(e)) send(player, payload);
            if (includeSelf && e instanceof class_3222 self) send(self, payload);
        });
        ServerPlayNetworking.registerGlobalReceiver(Emote.TYPE,
            (payload, context) -> ServerEmotes.handle(context.player(), payload.message()));
        ServerTickEvents.END_SERVER_TICK.register(ServerEmotes::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> ServerEmotes.onLogout(handler.method_32311().method_5667()));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> ServerEmotes.onServerStopped());
    }

    private static void send(class_3222 player, Animation payload) {
        if (ServerPlayNetworking.canSend(player, Animation.TYPE)) ServerPlayNetworking.send(player, payload);
    }

    record Animation(AnimMessage message) implements class_8710 {
        static final class_9154<Animation> TYPE = new class_9154<>(class_2960.method_60655("shaurma_lib", "anim"));

        @Override
        public class_9154<Animation> method_56479() { return TYPE; }
    }

    record Emote(EmoteMessage message) implements class_8710 {
        static final class_9154<Emote> TYPE = new class_9154<>(class_2960.method_60655("shaurma_lib", "emote"));

        @Override
        public class_9154<Emote> method_56479() { return TYPE; }
    }
}
