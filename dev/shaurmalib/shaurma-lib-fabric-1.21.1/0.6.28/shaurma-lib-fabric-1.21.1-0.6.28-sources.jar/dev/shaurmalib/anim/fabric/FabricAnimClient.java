package dev.shaurmalib.anim.fabric;

import dev.shaurmalib.anim.ShaurmaAnim;
import dev.shaurmalib.anim.emote.EmoteNetwork;
import dev.shaurmalib.anim.mc.AnimReloader;
import dev.shaurmalib.anim.mc.FirstPersonCompat;
import dev.shaurmalib.anim.mc.emote.EmoteClient;
import dev.shaurmalib.anim.mc.McAnim;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3300;

/** Реєструє ресурси, клавішу емоцій і клієнтські обробники анімацій. */
public final class FabricAnimClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        AnimReloader reloader = new AnimReloader();
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            @Override public class_2960 getFabricId() { return class_2960.method_60655("shaurma_lib", "anim_clips"); }
            @Override public void method_14491(class_3300 manager) { reloader.method_14491(manager); }
        });
        FirstPersonCompat.detect(FabricLoader.getInstance()::isModLoaded);
        KeyBindingHelper.registerKeyBinding(EmoteClient.KEY);
        EmoteNetwork.set(m -> {
            if (ClientPlayNetworking.canSend(FabricAnimBootstrap.Emote.TYPE)) {
                ClientPlayNetworking.send(new FabricAnimBootstrap.Emote(m));
            }
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            McAnim.clientTick();
            EmoteClient.tick();
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> McAnim.onDisconnect());
        ClientPlayNetworking.registerGlobalReceiver(FabricAnimBootstrap.Animation.TYPE,
            (payload, context) -> ShaurmaAnim.handle(payload.message()));
    }
}
