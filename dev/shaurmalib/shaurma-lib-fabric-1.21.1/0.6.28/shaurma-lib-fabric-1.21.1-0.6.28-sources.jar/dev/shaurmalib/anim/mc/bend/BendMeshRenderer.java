package dev.shaurmalib.anim.mc.bend;

import dev.shaurmalib.anim.bend.BendMath;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.List;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;

/**
 * Малює кубоїди зігнутої частини замість ванільного {@code ModelPart.compile}. Два згини на одній сітці:
 * <ol>
 *   <li><b>середина</b> (лікоть/коліно; для тулуба — груди, {@link BendablePart#shaurma$bendUpper()}):
 *       кільця по дузі ({@link BendMath}), нижній сегмент — жорстко за дугою;</li>
 *   <li><b>корінь</b> (кульша, {@link BendablePart#shaurma$rootBend()}): верхній торець вирівняний по тулубу
 *       й стоїть на шарнірі, кінцівка виходить із нього короткою дугою — нога «приклеєна» до низу тулуба.</li>
 * </ol>
 * Зона кожної вершини визначається за її положенням У СПОКОЇ, тож згини складаються без перетину зон.
 * Нормалі — на вершину (повернуті разом з кільцем): згин затіняється плавно. Формат вершин ванільний.
 *
 * Лише потік рендеру: робочі об'єкти статичні, без алокацій у кадрі.
 */
public final class BendMeshRenderer {

    private BendMeshRenderer() {}

    private static final BendMath MATH = new BendMath();
    private static final BendMath ROOT = new BendMath();
    private static final BendMath TAIL = new BendMath();
    private static final float[] P = new float[3], N = new float[3], N2 = new float[3];
    private static final Vector4f V4 = new Vector4f();
    private static final Vector3f V3 = new Vector3f();
    private static final float ROOT_EPS = 1e-4f;

    public static void render(List<class_630.class_628> cubes, BendablePart bend, class_4587.class_4665 pose, class_4588 vc,
                              int light, int overlay, int color) {
        Matrix4f m = pose.method_23761();
        Matrix3f nm = pose.method_23762();
        boolean bent = bend.shaurma$hasBend();
        float rx = bend.shaurma$bendX(), ry = bend.shaurma$bendY(), rz = bend.shaurma$bendZ();
        boolean upper = bend.shaurma$bendUpper();
        float[] rootQ = bend.shaurma$rootBend();
        float[] tailQ = bend.shaurma$tailBend();
        for (class_630.class_628 cube : cubes) {
            BendTemplate t = BendTemplate.of(cube);
            if (t == null) {
                cube.method_32089(pose, vc, light, overlay, color);
                continue;
            }
            boolean mid = bent && (upper
                ? MATH.setUpper(rx, ry, rz, t.hx, t.hy, t.hz, t.halfX, t.halfZ, t.halfLen)
                : MATH.set(rx, ry, rz, t.hx, t.hy, t.hz, t.halfX, t.halfZ, t.halfLen));
            float top = t.hy - t.halfLen;
            boolean root = false;
            if (rootQ != null) {
                // дуга кульші не заходить у зону коліна
                float limit = mid ? (MATH.slabStart() - top) * 0.5f - 0.05f : BendMath.ROOT_MAX_A;
                root = ROOT.setRoot(rootQ, t.hx, top, t.hz, t.halfX, t.halfZ, limit);
            }
            float bottom = t.hy + t.halfLen;
            boolean tail = false;
            if (tailQ != null) {
                // дуга таза не заходить у зону грудей
                float limit = mid ? (bottom - MATH.slabEnd()) * 0.5f - 0.05f : 2f;
                tail = TAIL.setTail(tailQ, t.hx, bottom, t.hz, t.halfX, t.halfZ, limit);
            }
            float tailStart = tail ? TAIL.slabStart() : bottom;
            if (!mid && !root && !tail) {
                cube.method_32089(pose, vc, light, overlay, color);
                continue;
            }
            float rootEnd = root ? ROOT.slabEnd() : top;
            float[] shift = ROOT.rootShift();
            for (int q = 0; q < t.quads; q++) {
                float nx = t.normal[q * 3], ny = t.normal[q * 3 + 1], nz = t.normal[q * 3 + 2];
                for (int k = 0; k < 4; k++) {
                    int i = q * 4 + k;
                    float x = t.pos[i * 3], y = t.pos[i * 3 + 1], z = t.pos[i * 3 + 2];
                    float u = t.uv[i * 2], v = t.uv[i * 2 + 1];
                    byte region = t.region[i];
                    float f = t.frac[i];
                    // положення у спокої
                    float restY = switch (region) {
                        case BendTemplate.RING -> mid ? MATH.slabY(f) : t.hy;
                        case BendTemplate.ROOT_RING -> root ? ROOT.slabY(f) : top;
                        case BendTemplate.TAIL_RING -> tail ? TAIL.slabY(f) : bottom;
                        default -> y;
                    };
                    if (region == BendTemplate.RING || region == BendTemplate.ROOT_RING || region == BendTemplate.TAIL_RING) {
                        float dy = restY - t.hy;
                        u += t.duv[i * 2] * dy;
                        v += t.duv[i * 2 + 1] * dy;
                    }
                    // 1) середній згин
                    if (region == BendTemplate.TAIL_RING) {
                        // нижня половина: для кінцівки — жорстко за коліном, для тулуба (груди) — на місці
                        if (mid && !upper) {
                            MATH.lower(x, restY, z, P);
                            MATH.lowerNormal(nx, ny, nz, N);
                        } else {
                            P[0] = x; P[1] = restY; P[2] = z;
                            N[0] = nx; N[1] = ny; N[2] = nz;
                        }
                    } else if (!mid || region == BendTemplate.UPPER || region == BendTemplate.ROOT_RING) {
                        P[0] = x; P[1] = restY; P[2] = z;
                        N[0] = nx; N[1] = ny; N[2] = nz;
                        if (mid && upper) { MATH.unlower(P); MATH.unlowerNormal(N); }
                    } else if (region == BendTemplate.RING) {
                        MATH.ring(f, x, z, nx, ny, nz, P, N);
                        if (upper) { MATH.unlower(P); MATH.unlowerNormal(N); }
                    } else if (upper) {
                        // тулуб: низ стоїть на місці (unlower ∘ lower = тотожність)
                        P[0] = x; P[1] = y; P[2] = z;
                        N[0] = nx; N[1] = ny; N[2] = nz;
                    } else {
                        MATH.lower(x, y, z, P);
                        MATH.lowerNormal(nx, ny, nz, N);
                    }
                    // 1б) таз (лише для частини, де низ стоїть: тулуб) — за положенням у спокої
                    if (tail && (!mid || upper) && restY > tailStart + ROOT_EPS) {
                        if (region == BendTemplate.TAIL_RING && restY < bottom - ROOT_EPS) {
                            TAIL.ring(f, x, z, N[0], N[1], N[2], P, N2);
                            N[0] = N2[0]; N[1] = N2[1]; N[2] = N2[2];
                        } else if (restY >= bottom - ROOT_EPS) {
                            TAIL.lower(x, restY, z, P);
                            TAIL.lowerNormal(N[0], N[1], N[2], N2);
                            N[0] = N2[0]; N[1] = N2[1]; N[2] = N2[2];
                        }
                    }
                    // 2) кульша: торець і дуга — за положенням у спокої; усе — зсув на шарнір
                    if (root) {
                        if (restY <= top + ROOT_EPS) {
                            ROOT.unlower(P);
                            ROOT.unlowerNormal(N);
                        } else if (region == BendTemplate.ROOT_RING && restY < rootEnd) {
                            ROOT.ring(f, x, z, N[0], N[1], N[2], P, N2);
                            ROOT.unlower(P);
                            ROOT.unlowerNormal(N2);
                            N[0] = N2[0]; N[1] = N2[1]; N[2] = N2[2];
                        }
                        P[0] += shift[0]; P[1] += shift[1]; P[2] += shift[2];
                    }
                    nm.transform(V3.set(N[0], N[1], N[2]));
                    m.transform(V4.set(P[0] / 16f, P[1] / 16f, P[2] / 16f, 1f));
                    vc.method_23919(V4.x(), V4.y(), V4.z(), color, u, v, overlay, light, V3.x(), V3.y(), V3.z());
                }
            }
        }
    }
}
