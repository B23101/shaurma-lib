package dev.shaurmalib.anim.mc.bend;

import dev.shaurmalib.anim.bend.BendMath;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;

/**
 * Сітка кубоїда для плавного згину. Будується один раз на кубоїд і кешується на ньому: кожна бічна грань,
 * що перетинає шарнір, ріжеться на {@code SEGMENTS + 2} квадів — верх, {@link BendMath#SEGMENTS} кілець
 * зони згину, низ. Торці (верх/низ кубоїда) лишаються цілими.
 *
 * Положення кілець по Y у спокої залежить від кута (зона згину ширшає/вужчає), тому кільцева вершина
 * зберігає не Y, а частку {@code f} зони, свої X/Z (бічне ребро вертикальне) і UV на висоті шарніра з
 * нахилом {@code duv/dy} — щокадру UV береться в точці {@code slabY(f)}, текстура скіна не рветься.
 *
 * Геометрію беремо, записуючи ванільний {@code Cube.compile} з одиничною матрицею, — без доступу до
 * {@code ModelPart.Polygon/Vertex}. Заодно працює з будь-якою геометрією, яку кубоїд реально малює
 * (прибрані грані, inflate). Усе у просторі частини, пікселі.
 */
public final class BendTemplate {

    public static final byte UPPER = -1, RING = 0, LOWER = 1, ROOT_RING = 2, TAIL_RING = 3;

    /** Кілець дуги біля нижнього торця (таз тулуба). Без неї вони стягнуті в торець. */
    public static final int TAIL_SEGMENTS = 6;

    /** Кілець кореневої дуги (кульша) біля верхнього торця. Без кореневого згину вони стягнуті в торець. */
    public static final int ROOT_SEGMENTS = 6;

    /** Шарнір кубоїда. */
    public final float hx, hy, hz;
    /**
     * Півтовщина і півдовжина БЕЗ inflate (рукав/штани мають ту саму дугу, що й шкіра під ними —
     * інакше шари розійдуться на згині).
     */
    public final float halfX, halfZ, halfLen;
    public final int quads;
    /** На вершину: x, y, z (для кільцевих Y не використовується). */
    final float[] pos;
    /** На вершину: u, v (для кільцевих — на висоті шарніра). */
    final float[] uv;
    /** На кільцеву вершину: du/dy, dv/dy уздовж її бічного ребра. */
    final float[] duv;
    /** На кільцеву вершину: частка зони згину (RING) або кореневої дуги (ROOT_RING), 0..1. */
    final float[] frac;
    /** На вершину: {@link #UPPER}, {@link #RING}, {@link #LOWER}. */
    final byte[] region;
    /** На квад: нормаль у просторі частини. */
    final float[] normal;

    private BendTemplate(class_630.class_628 cube, float hx, float hy, float hz, List<float[]> verts, List<float[]> normals) {
        this.hx = hx; this.hy = hy; this.hz = hz;
        this.halfX = (cube.field_3648 - cube.field_3645) * 0.5f;
        this.halfZ = (cube.field_3646 - cube.field_3643) * 0.5f;
        this.halfLen = (cube.field_3647 - cube.field_3644) * 0.5f;
        this.quads = normals.size();
        int n = quads * 4;
        pos = new float[n * 3];
        uv = new float[n * 2];
        duv = new float[n * 2];
        frac = new float[n];
        region = new byte[n];
        normal = new float[quads * 3];
        for (int i = 0; i < n; i++) {
            float[] v = verts.get(i);
            pos[i * 3] = v[0]; pos[i * 3 + 1] = v[1]; pos[i * 3 + 2] = v[2];
            uv[i * 2] = v[3]; uv[i * 2 + 1] = v[4];
            region[i] = (byte) v[5];
            duv[i * 2] = v[6]; duv[i * 2 + 1] = v[7];
            frac[i] = v[8];
        }
        for (int q = 0; q < quads; q++) {
            float[] nv = normals.get(q);
            normal[q * 3] = nv[0]; normal[q * 3 + 1] = nv[1]; normal[q * 3 + 2] = nv[2];
        }
    }

    /** Шаблон із кешу кубоїда (або збудувати). {@code null} — кубоїд нестандартний, малювати ванільно. */
    public static BendTemplate of(class_630.class_628 cube) {
        BendableCube bc = (BendableCube) cube;
        BendTemplate t = bc.shaurma$bendTemplate();
        if (t == null && !bc.shaurma$bendTemplateFailed()) {
            t = build(cube);
            if (t == null) bc.shaurma$markBendTemplateFailed();
            else bc.shaurma$setBendTemplate(t);
        }
        return t;
    }

    static BendTemplate build(class_630.class_628 cube) {
        Recorder rec = new Recorder();
        cube.method_32089(new class_4587().method_23760(), rec, 0, 0, 0xFFFFFFFF);
        if (rec.verts.isEmpty() || rec.verts.size() % 4 != 0) return null;

        float[] h = new float[3];
        BendMath.cubeHinge(cube.field_3645, cube.field_3644, cube.field_3643, cube.field_3648, cube.field_3647, cube.field_3646, h);
        float hy = h[1];
        int segs = BendMath.SEGMENTS;
        List<float[]> verts = new ArrayList<>();
        List<float[]> normals = new ArrayList<>();
        for (int p = 0; p < rec.verts.size(); p += 4) {
            float[][] c = new float[4][];
            for (int i = 0; i < 4; i++) c[i] = rigid(rec.verts.get(p + i), hy);
            float[] n = rec.normals.get(p);
            int a = -1;
            if (crosses(c[0], c[1], hy) && crosses(c[2], c[3], hy)) a = 0;
            else if (crosses(c[1], c[2], hy) && crosses(c[3], c[0], hy)) a = 1;
            if (a < 0) {
                // торець: увесь квад по один бік шарніра
                addQuad(verts, normals, n, c[0], c[1], c[2], c[3]);
                continue;
            }
            float[] v0 = c[a], v1 = c[a + 1], v2 = c[(a + 2) & 3], v3 = c[(a + 3) & 3];
            // кільця від верхнього торця вниз: коренева дуга (кульша), потім зона згину (коліно);
            // якщо v0 унизу — той самий список у зворотному порядку
            boolean down = v0[1] < hy;
            List<float[]> levels = new ArrayList<>(); // {region, f}
            for (int k = 0; k <= ROOT_SEGMENTS; k++) levels.add(new float[] { ROOT_RING, (float) k / ROOT_SEGMENTS });
            for (int k = 0; k <= segs; k++) levels.add(new float[] { RING, (float) k / segs });
            for (int k = 0; k <= TAIL_SEGMENTS; k++) levels.add(new float[] { TAIL_RING, (float) k / TAIL_SEGMENTS });
            if (!down) java.util.Collections.reverse(levels);
            float[] prev01 = v0, prev23 = v3;
            for (float[] lv : levels) {
                float[] r01 = ring(v0, v1, hy, lv[1], (byte) lv[0]), r23 = ring(v3, v2, hy, lv[1], (byte) lv[0]);
                // порядок обходу як в оригіналі: v0→v1→v2→v3
                addQuad(verts, normals, n, prev01, r01, r23, prev23);
                prev01 = r01; prev23 = r23;
            }
            addQuad(verts, normals, n, prev01, v1, v2, prev23);
        }
        return new BendTemplate(cube, h[0], h[1], h[2], verts, normals);
    }

    /** {x, y, z, u, v} → {x, y, z, u, v, region, 0, 0, 0}. */
    private static float[] rigid(float[] v, float hy) {
        return new float[] { v[0], v[1], v[2], v[3], v[4], v[1] < hy ? UPPER : LOWER, 0, 0, 0 };
    }

    private static boolean crosses(float[] a, float[] b, float hy) {
        return (a[1] - hy) * (b[1] - hy) < 0;
    }

    /** Кільцева вершина на ребрі a→b: X/Z і UV на висоті шарніра, нахил UV по Y, частка f. */
    private static float[] ring(float[] a, float[] b, float hy, float f, byte region) {
        float dy = b[1] - a[1];
        float t = (hy - a[1]) / dy;
        return new float[] {
            a[0] + (b[0] - a[0]) * t, hy, a[2] + (b[2] - a[2]) * t,
            a[3] + (b[3] - a[3]) * t, a[4] + (b[4] - a[4]) * t, region,
            (b[3] - a[3]) / dy, (b[4] - a[4]) / dy, f };
    }

    private static void addQuad(List<float[]> verts, List<float[]> normals, float[] n,
                                float[] a, float[] b, float[] c, float[] d) {
        verts.add(a); verts.add(b); verts.add(c); verts.add(d);
        normals.add(n);
    }

    /** Записує вершини ванільного {@code Cube.compile} (позиція назад у пікселі). */
    private static final class Recorder implements class_4588 {
        final List<float[]> verts = new ArrayList<>();
        final List<float[]> normals = new ArrayList<>();

        @Override
        public void method_23919(float x, float y, float z, int color, float u, float v,
                           int overlay, int light, float nx, float ny, float nz) {
            verts.add(new float[] { x * 16f, y * 16f, z * 16f, u, v });
            normals.add(new float[] { nx, ny, nz });
        }

        // Ванільний Cube.compile кличе лише пакетний addVertex(...) вище; решта — заглушки інтерфейсу.
        @Override public class_4588 method_22912(float x, float y, float z) { return this; }
        @Override public class_4588 method_1336(int r, int g, int b, int a) { return this; }
        @Override public class_4588 method_22913(float u, float v) { return this; }
        @Override public class_4588 method_60796(int u, int v) { return this; }
        @Override public class_4588 method_22921(int u, int v) { return this; }
        @Override public class_4588 method_22914(float x, float y, float z) { return this; }
    }
}
