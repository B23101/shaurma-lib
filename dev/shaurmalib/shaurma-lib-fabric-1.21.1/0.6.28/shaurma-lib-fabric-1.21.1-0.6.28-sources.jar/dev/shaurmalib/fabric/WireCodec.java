package dev.shaurmalib.fabric;

import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import io.netty.handler.codec.DecoderException;
import io.netty.handler.codec.EncoderException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.function.Function;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public final class WireCodec {
    private WireCodec() {}

    public static <M, P> class_9139<class_9129, P> of(
            Reader<M> reader, Writer<M> writer, Function<P, M> message, Function<M, P> payload) {
        return class_9139.method_56437((buf, value) -> {
            try (var out = new ByteBufOutputStream(buf)) {
                writer.write(message.apply(value), out);
            } catch (IOException e) {
                throw new EncoderException(e);
            }
        }, buf -> {
            try (var in = new ByteBufInputStream(buf)) {
                return payload.apply(reader.read(in));
            } catch (IOException e) {
                throw new DecoderException(e);
            }
        });
    }

    @FunctionalInterface
    public interface Reader<M> {
        M read(DataInput in) throws IOException;
    }

    @FunctionalInterface
    public interface Writer<M> {
        void write(M message, DataOutput out) throws IOException;
    }
}
