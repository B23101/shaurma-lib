package dev.shaurmalib.scene.eval;

import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.anim.clip.BoneTrack;
import dev.shaurmalib.anim.clip.Channel;
import dev.shaurmalib.anim.molang.MolangContext;
import dev.shaurmalib.anim.rig.BoneMask;
import dev.shaurmalib.scene.doc.Channels;
import dev.shaurmalib.scene.doc.Clip;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.doc.Track;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Поза актора в момент t: шари знизу вгору, як у NLA Blender / шари рушія анімацій:
 * <ol>
 *   <li>спокій (0, 0, 0 / масштаб 1);</li>
 *   <li>{@code idle} — зациклений кліп під усім (у BBS — «idle» форми);</li>
 *   <li>треки анімацій актора знизу вгору: кожен активний кліп — {@code lerp(нижче, кліп, вага·fade·маска)}
 *       або {@code += кліп·вага} для адитивного; кістка без треку в кліпі прозора;</li>
 *   <li>ключі пози з редактора ({@link SceneObject#bones}) — ЗСУВ поверх усього (поставив позу — idle
 *       під нею продовжує «дихати»).</li>
 * </ol>
 */
public final class ActorPoser {

    private final MolangContext molang = new MolangContext();
    private final Map<SceneRig, Map<String, BoneMask>> masks = new HashMap<>();
    private final float[] tmp = new float[3];

    public void pose(SceneObject actor, SceneDoc.Variant v, double t, ClipSource src, SceneFrame.Actor out) {
        out.pose.clear();
        out.layers.clear();
        SceneRig rig = src.rig(actor);
        if (actor.idle != null) {
            AnimationClip idle = src.clip(actor.idle);
            if (idle != null && idle.length() > 0) {
                double it = (t * actor.idleSpeed) % idle.length();
                apply(idle, it, 1, null, false, rig, out.pose);
                out.layers.add(new SceneFrame.Layer(actor.idle, it, 1, null, false));
            }
        }
        boolean solo = false;
        List<Track> tracks = v.animationTracks(actor.id);
        for (Track tr : tracks) solo |= tr.solo;
        for (Track tr : tracks) {
            if (tr.muted || (solo && !tr.solo)) continue;
            for (Clip c : tr.clips) {
                if (c.muted || !c.covers(t)) continue;
                AnimationClip ac = src.clip(c.ref);
                if (ac == null) continue;
                double len = ac.length() > 0 ? ac.length() : c.sourceLength;
                double st = (t - c.start) * c.speed + c.in;
                if (len > 0) {
                    switch (c.end) {
                        case STOP -> { if (st > len) continue; }
                        case HOLD -> st = Math.min(st, len);
                        case LOOP -> {
                            double span = Math.max(1e-4, len - Math.min(c.in, len * 0.999));
                            if (st > len) st = c.in + ((st - c.in) % span);
                        }
                    }
                }
                double w = c.weight * c.fadeWeight(t);
                if (w <= 1e-4) continue;
                apply(ac, st, w, c.mask, c.additive, rig, out.pose);
                out.layers.add(new SceneFrame.Layer(c.ref, st, w, c.mask, c.additive));
            }
        }
        for (Map.Entry<String, Channels> e : actor.bones.entrySet()) {
            Channels ch = e.getValue();
            if (ch.isEmpty()) continue;
            float[] p = out.pose.computeIfAbsent(e.getKey(), k -> rest());
            for (int i = 0; i < 6; i++) p[i] += (float) ch.sample(Channels.BONE[i], t, 0);
            for (int i = 6; i < 9; i++) p[i] *= (float) ch.sample(Channels.BONE[i], t, 1);
        }
    }

    private void apply(AnimationClip clip, double time, double w, String mask, boolean additive, SceneRig rig, Map<String, float[]> pose) {
        molang.set("query.anim_time", time).set("query.life_time", time);
        BoneMask m = mask == null || rig == null ? null : masks.computeIfAbsent(rig, r -> new HashMap<>()).computeIfAbsent(mask, s -> rig.rig.mask(s));
        for (String bone : clip.bones()) {
            BoneTrack tr = clip.track(bone);
            if (tr == null) continue;
            double bw = w;
            if (m != null) {
                int idx = rig.rig.indexOf(bone);
                if (idx >= 0) bw *= m.weight(idx);
            }
            if (bw <= 1e-4) continue;
            float[] p = pose.computeIfAbsent(bone, k -> rest());
            channel(tr.rotation(), (float) time, bw, additive, p, 0, false);
            channel(tr.position(), (float) time, bw, additive, p, 3, false);
            channel(tr.scale(), (float) time, bw, additive, p, 6, true);
        }
    }

    private void channel(Channel ch, float t, double w, boolean additive, float[] p, int off, boolean scale) {
        if (ch == null || ch.isEmpty() || !ch.sample(t, molang, tmp)) return;
        for (int i = 0; i < 3; i++) {
            float v = tmp[i];
            if (additive) p[off + i] += (float) ((scale ? v - 1 : v) * w);
            else p[off + i] += (float) ((v - p[off + i]) * w);
        }
    }

    public static float[] rest() { return new float[] { 0, 0, 0, 0, 0, 0, 1, 1, 1 }; }
}
