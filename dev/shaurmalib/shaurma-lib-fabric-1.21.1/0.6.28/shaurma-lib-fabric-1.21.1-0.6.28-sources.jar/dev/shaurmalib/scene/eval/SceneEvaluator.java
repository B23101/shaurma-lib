package dev.shaurmalib.scene.eval;

import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.doc.Channels;
import dev.shaurmalib.scene.doc.Clip;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.doc.Track;
import dev.shaurmalib.scene.doc.Transition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Обчислює {@link SceneFrame} для варіанта сцени в момент часу контенту t. Детермінований (окрім
 * «тримати останній напрям» look-at): клієнт, сервер і редактор при тих самих даних бачать одне й те саме.
 *
 * <h3>Камера</h3>
 * Камери — об'єкти зі своїми ключами в ЧАСІ СЦЕНИ (як у Blender), а треки CAMERA — монтаж: який з них
 * у кадрі. На однаковому t вищий трек перекриває нижчий. Межа кліпів:
 * <ul>
 *   <li>CUT — миттєво;</li>
 *   <li>BLEND — камера інтерполює трансформ і FOV від попередньої до нової за {@code duration} від старту кліпу;</li>
 *   <li>ефекти (FADE/DIP/FLASH/GLITCH/SHUTTER/WIPE/ZOOM_PUNCH/CROSSFADE/WHIP_PAN) — вікно {@code duration}
 *       з центром на межі, склейка рівно посередині під піком ефекту.</li>
 * </ul>
 */
public final class SceneEvaluator {

    private final SceneDoc doc;
    private final SceneDoc.Variant variant;
    private SceneBindings bindings;
    private ClipSource clips = ClipSource.NONE;
    /** Редактор: сховані актори теж у кадрі (ghost), для пунктирного малювання. */
    private boolean editor;
    private final ActorPoser poser = new ActorPoser();
    private final Map<String, float[]> lastLook = new HashMap<>();
    private final Map<String, SceneFrame.Actor> poseCache = new HashMap<>();
    private double poseCacheT = Double.NaN;

    public SceneEvaluator(SceneDoc doc, SceneDoc.Variant variant, SceneBindings bindings) {
        this.doc = doc;
        this.variant = variant;
        this.bindings = bindings == null ? new SceneBindings() : bindings;
    }

    public SceneEvaluator clips(ClipSource c) { this.clips = c == null ? ClipSource.NONE : c; return this; }

    public SceneEvaluator editor(boolean e) { this.editor = e; return this; }

    public SceneEvaluator bindings(SceneBindings b) { this.bindings = b == null ? new SceneBindings() : b; return this; }

    public SceneDoc doc() { return doc; }

    public SceneDoc.Variant variant() { return variant; }

    public SceneBindings bindings() { return bindings; }

    public ClipSource clips() { return clips; }

    // ═════════════════════════ кадр ═════════════════════════

    public SceneFrame eval(double t, SceneFrame out) {
        evalRaw(t, out);
        SceneDoc.Variant v = variant;
        if (!v.loop || v.loopBlend <= 1e-3) return out;
        // безшовний цикл: останні loopBlend секунд циклу змішуються з кадром на період раніше — на межі
        // кадр дорівнює початку циклу, тож стрибка нема навіть без однакових ключів
        double in = v.loopStart(), end = v.loopEnd(), len = end - in;
        double blend = Math.min(v.loopBlend, len * 0.5);
        if (len <= 0.1 || t <= end - blend || t > end + 1e-9) return out;
        double w = (t - (end - blend)) / blend;
        w = w * w * (3 - 2 * w);
        if (blendFrame == null) blendFrame = new SceneFrame();
        evalRaw(t - len, blendFrame);
        mix(out, blendFrame, w);
        return out;
    }

    private SceneFrame blendFrame;

    /** {@code a = lerp(a, b, w)} для камери, акторів (трансформ і поза) і світел з однаковими id. */
    private static void mix(SceneFrame a, SceneFrame b, double w) {
        if (a.hasCamera && b.hasCamera) a.camera.lerp(new SceneFrame.Cam().set(a.camera), b.camera, w);
        for (SceneFrame.Actor x : a.actors) {
            SceneFrame.Actor y = b.actor(x.object.id);
            if (y == null) continue;
            x.x += (y.x - x.x) * w; x.y += (y.y - x.y) * w; x.z += (y.z - x.z) * w;
            x.yaw += (float) (SceneFrame.Cam.wrap(y.yaw - x.yaw) * w);
            x.pitch += (float) ((y.pitch - x.pitch) * w);
            x.roll += (float) ((y.roll - x.roll) * w);
            x.scale += (float) ((y.scale - x.scale) * w);
            for (Map.Entry<String, float[]> e : y.pose.entrySet()) {
                float[] p = x.pose.computeIfAbsent(e.getKey(), k -> ActorPoser.rest());
                float[] q = e.getValue();
                for (int i = 0; i < 9; i++) p[i] += (float) ((q[i] - p[i]) * w);
            }
            for (Map.Entry<String, float[]> e : x.pose.entrySet()) {
                if (y.pose.containsKey(e.getKey())) continue;
                float[] p = e.getValue(), r = ActorPoser.rest();
                for (int i = 0; i < 9; i++) p[i] += (float) ((r[i] - p[i]) * w);
            }
        }
        for (SceneFrame.Light x : a.lights) {
            SceneFrame.Light y = null;
            for (SceneFrame.Light l : b.lights) if (l.object == x.object) { y = l; break; }
            if (y == null) continue;
            x.x += (y.x - x.x) * w; x.y += (y.y - x.y) * w; x.z += (y.z - x.z) * w;
            x.dx += (y.dx - x.dx) * w; x.dy += (y.dy - x.dy) * w; x.dz += (y.dz - x.dz) * w;
            double n = Math.sqrt(x.dx * x.dx + x.dy * x.dy + x.dz * x.dz);
            if (n > 1e-6) { x.dx /= n; x.dy /= n; x.dz /= n; }
            x.r += (float) ((y.r - x.r) * w); x.g += (float) ((y.g - x.g) * w); x.b += (float) ((y.b - x.b) * w);
            x.intensity += (float) ((y.intensity - x.intensity) * w);
            x.range += (float) ((y.range - x.range) * w);
        }
    }

    private void evalRaw(double t, SceneFrame out) {
        out.clear();
        out.time = t;
        poseCache.clear();
        poseCacheT = t;
        SceneDoc.Variant v = variant;
        out.speed = speedAt(t);
        out.letterbox = v.letterbox;
        out.hideEntities = v.hideEntities;
        out.hideParticles = v.hideParticles;
        out.hideWeather = v.hideWeather;
        if (!v.loop) {
            double fi = v.fadeIn > 0 && t < v.fadeIn ? 1 - t / v.fadeIn : 0;
            double end = v.length;
            double fo = v.fadeOut > 0 && t > end - v.fadeOut ? (t - (end - v.fadeOut)) / v.fadeOut : 0;
            out.fade = clamp01(Math.max(fi, fo));
        }
        for (SceneObject o : v.objects) {
            if (o.kind != SceneObject.Kind.ACTOR && o.kind != SceneObject.Kind.PROP) continue;
            SceneFrame.Actor a = actor(o, t);
            if (a.visible || editor) out.actors.add(a);
        }
        out.look = v.look;
        lights(t, out);
        camera(t, out);
        media(t, out);
        motion(t, out);
    }

    // ═════════════════════════ світло ═════════════════════════

    private void lights(double t, SceneFrame out) {
        for (SceneObject o : variant.objects) {
            if (o.kind != SceneObject.Kind.LIGHT) continue;
            if (o.channels.sample(Channels.VISIBLE, t, 1) < 0.5) continue;
            out.lights.add(light(o, t));
        }
    }

    /** Світло-об'єкт у момент t (позиція з батьком, напрям з yaw/pitch, колір і сила з ключів). */
    public SceneFrame.Light light(SceneObject o, double t) {
        SceneFrame.Light l = new SceneFrame.Light();
        double[] xf = transform(o, t, new double[7], 0);
        l.object = o;
        l.type = o.lightType;
        l.x = xf[0]; l.y = xf[1]; l.z = xf[2];
        double yaw = Math.toRadians(xf[3]), pitch = Math.toRadians(xf[4]);
        l.dx = -Math.sin(yaw) * Math.cos(pitch);
        l.dy = -Math.sin(pitch);
        l.dz = Math.cos(yaw) * Math.cos(pitch);
        Channels ch = o.channels;
        l.r = (float) clamp01(ch.sample(Channels.LIGHT_R, t, ((o.lightColor >> 16) & 255) / 255.0));
        l.g = (float) clamp01(ch.sample(Channels.LIGHT_G, t, ((o.lightColor >> 8) & 255) / 255.0));
        l.b = (float) clamp01(ch.sample(Channels.LIGHT_B, t, (o.lightColor & 255) / 255.0));
        l.intensity = (float) Math.max(0, ch.sample(Channels.INTENSITY, t, o.lightIntensity));
        l.range = (float) Math.max(0.5, ch.sample(Channels.RANGE, t, o.lightRange));
        l.spotAngle = o.spotAngle;
        l.spotBlend = o.spotBlend;
        l.shadows = o.castShadows;
        l.softness = o.shadowSoftness;
        l.specular = o.lightSpecular;
        l.spotInner = o.spotInner;
        l.target = o.lightTarget.ordinal();
        l.beam = (float) Math.max(0, ch.sample("beam", t, o.beam));
        l.vlDensity = o.vlDensity;
        l.anisotropy = o.anisotropy;
        l.cookie = o.cookie;
        l.cookieRotation = o.cookieRotation;
        l.cookieScale = o.cookieScale;
        l.cookieInvert = o.cookieInvert;
        return l;
    }

    /**
     * Ефекти руху камери з бібліотеки «Ефекти → Рух»: кліпи EFFECT з id {@code shaurma_lib:cam_*} не малюють 2D,
     * а трусять/крутять/наїжджають камерою кадру (сила — канал intensity, з fade in/out кліпу).
     */
    private void motion(double t, SceneFrame out) {
        if (!out.hasCamera) return;
        for (SceneFrame.Effect e : out.effects) {
            if (e.id == null || !e.id.startsWith("shaurma_lib:cam_")) continue;
            double k = e.intensity, local = t - e.clip.start;
            switch (e.id) {
                case "shaurma_lib:cam_shake" -> {
                    out.camera.yaw += (float) (4 * k * noise(t, 14, 0));
                    out.camera.pitch += (float) (3 * k * noise(t, 12, 2));
                    out.camera.roll += (float) (1.5 * k * noise(t, 9, 4));
                }
                case "shaurma_lib:cam_handheld" -> {
                    out.camera.yaw += (float) (1.6 * k * noise(t, 0.9, 0));
                    out.camera.pitch += (float) (1.1 * k * noise(t, 0.8, 2));
                    out.camera.roll += (float) (0.8 * k * noise(t, 0.6, 4));
                }
                case "shaurma_lib:cam_earthquake" -> {
                    out.camera.y += 0.12 * k * noise(t, 25, 1);
                    out.camera.x += 0.08 * k * noise(t, 21, 3);
                    out.camera.pitch += (float) (2 * k * noise(t, 18, 5));
                }
                case "shaurma_lib:cam_zoom_in" -> out.camera.fov = (float) Math.max(5, out.camera.fov * (1 - 0.35 * k * clamp01(local / Math.max(0.05, e.clip.length))));
                case "shaurma_lib:cam_zoom_pulse" -> out.camera.fov = (float) Math.max(5, out.camera.fov * (1 - 0.12 * k * Math.pow(Math.max(0, Math.sin(local * Math.PI * 2 * e.clip.param("bpm", 120) / 60)), 8)));
                case "shaurma_lib:cam_dutch" -> out.camera.roll += (float) (18 * k);
                case "shaurma_lib:cam_spin" -> out.camera.roll += (float) (k * local * e.clip.param("deg_per_sec", 45));
                case "shaurma_lib:cam_drunk" -> {
                    out.camera.roll += (float) (8 * k * Math.sin(local * 1.3));
                    out.camera.yaw += (float) (5 * k * Math.sin(local * 0.7 + 1));
                    out.camera.fov = (float) (out.camera.fov * (1 + 0.06 * k * Math.sin(local * 2.1)));
                }
                case "shaurma_lib:cam_heartbeat" -> {
                    double beat = local * e.clip.param("bpm", 70) / 60, ph = beat - Math.floor(beat);
                    double p = Math.exp(-ph * 18) + 0.6 * Math.exp(-Math.abs(ph - 0.22) * 18);
                    out.camera.fov = (float) (out.camera.fov * (1 - 0.06 * k * p));
                }
                default -> { }
            }
        }
    }

    /** Швидкість часу в t (треки TIME; вищий перекриває). */
    public double speedAt(double t) {
        double speed = 1;
        for (Track tr : active(Track.Type.TIME)) {
            Clip c = tr.clipAt(t);
            if (c == null) continue;
            double target = Math.max(0.01, c.value(Channels.SPEED, t, c.param(Channels.SPEED, 0.5)));
            double f = c.fadeWeight(t);
            speed = 1 + (target - 1) * f;
        }
        return speed;
    }

    // ═════════════════════════ актори ═════════════════════════

    public SceneFrame.Actor actor(SceneObject o, double t) {
        if (t == poseCacheT) {
            SceneFrame.Actor c = poseCache.get(o.id);
            if (c != null) return c;
        }
        SceneFrame.Actor a = new SceneFrame.Actor();
        a.object = o;
        double[] xf = transform(o, t, new double[7], 0);
        a.x = xf[0]; a.y = xf[1]; a.z = xf[2];
        a.yaw = (float) xf[3]; a.pitch = (float) xf[4]; a.roll = (float) xf[5]; a.scale = (float) xf[6];
        boolean visible = o.channels.sample(Channels.VISIBLE, t, 1) >= 0.5;
        if (o.slot != null) {
            a.binding = bindings.get(o.slot, o.slotIndex);
            if (a.binding == null && o.hideIfUnbound) visible = false;
        }
        a.visible = visible;
        a.ghost = !visible;
        poser.pose(o, variant, t, clips, a);
        motion(o, t, a);
        if (t == poseCacheT) poseCache.put(o.id, a);
        return a;
    }

    /**
     * Рух актора-гравця (як у BBS, де кроки беруться зі швидкості запису): фаза кроку — пройдений шлях,
     * сила — поточна швидкість (ванільна формула {@code cos(pos·0.6662)·1.4·amount}); голова — канали
     * head_yaw/head_pitch відносно тіла; присід — канал sneak. Кліпи анімацій на кінцівках приглушують ходьбу.
     */
    private void motion(SceneObject o, double t, SceneFrame.Actor a) {
        if (o.modelType != SceneObject.ModelType.PLAYER) return;
        double hy = o.channels.sample(Channels.HEAD_YAW, t, 0), hp = o.channels.sample(Channels.HEAD_PITCH, t, 0);
        if (hy != 0 || hp != 0) {
            float[] h = a.pose.computeIfAbsent("head", k -> ActorPoser.rest());
            h[0] += (float) hp;
            h[1] += (float) hy;
        }
        if (o.channels.sample(Channels.SNEAK, t, 0) >= 0.5) {
            a.pose.computeIfAbsent("torso", k -> ActorPoser.rest())[0] += 28.6f;
            for (String arm : new String[] { "right_arm", "left_arm" }) a.pose.computeIfAbsent(arm, k -> ActorPoser.rest())[0] += 23f;
            a.pose.computeIfAbsent("head", k -> ActorPoser.rest())[4] -= 4.2f;
        }
        if (!o.autoWalk || !(o.channels.has(Channels.X) || o.channels.has(Channels.Z))) return;
        // шлях і швидкість у «тіках» ванілі (крок 0.05 с), детерміновано від початку
        double step = 0.05, pos = 0, amount = 0;
        double[] prev = transform(o, 0, new double[7], 0), cur = new double[7];
        int n = (int) Math.min(4000, Math.ceil(t / step));
        for (int i = 1; i <= n; i++) {
            double tt = Math.min(t, i * step);
            transform(o, tt, cur, 0);
            double d = Math.hypot(cur[0] - prev[0], cur[2] - prev[2]) * (step / Math.max(1e-6, tt - (i - 1) * step));
            double speed = Math.min(1, d * 4);
            amount += (speed - amount) * 0.4;
            pos += amount;
            double[] sw = prev; prev = cur; cur = sw;
        }
        if (amount < 0.01) return;
        double weight = 1;
        for (SceneFrame.Layer l : a.layers) if (o.idle == null || !o.idle.equals(l.clip())) weight -= l.weight();
        weight = Math.max(0, weight);
        if (weight <= 0) return;
        float leg = (float) Math.toDegrees(Math.cos(pos * 0.6662) * 1.4 * amount * weight);
        float arm = (float) Math.toDegrees(Math.cos(pos * 0.6662 + Math.PI) * amount * weight);
        a.pose.computeIfAbsent("right_leg", k -> ActorPoser.rest())[0] += leg;
        a.pose.computeIfAbsent("left_leg", k -> ActorPoser.rest())[0] -= leg;
        a.pose.computeIfAbsent("right_arm", k -> ActorPoser.rest())[0] += arm;
        a.pose.computeIfAbsent("left_arm", k -> ActorPoser.rest())[0] -= arm;
    }

    /**
     * Світовий трансформ об'єкта {x, y, z, yaw, pitch, roll, scale}. Батько — об'єкт або його кістка:
     * дитина бере точку кістки/батька і обертається разом з ним.
     */
    public double[] transform(SceneObject o, double t, double[] out, int depth) {
        Channels ch = o.channels;
        double x = ch.sample(Channels.X, t, o.x), y = ch.sample(Channels.Y, t, o.y), z = ch.sample(Channels.Z, t, o.z);
        double yaw = ch.sample(Channels.YAW, t, o.yaw), pitch = ch.sample(Channels.PITCH, t, o.pitch), roll = ch.sample(Channels.ROLL, t, o.roll);
        double scale = ch.sample(Channels.SCALE, t, o.scale);
        SceneObject parent = depth < 16 ? variant.object(o.parent) : null;
        if (parent != null && parent != o) {
            double[] p = transform(parent, t, new double[7], depth + 1);
            double ax = p[0], ay = p[1], az = p[2];
            if (o.parentBone != null && (parent.kind == SceneObject.Kind.ACTOR || parent.kind == SceneObject.Kind.PROP)) {
                SceneRig rig = clips.rig(parent);
                if (rig != null) {
                    SceneFrame.Actor pa = actor(parent, t);
                    float[] local = new float[3];
                    if (rig.bonePivot(o.parentBone, pa.pose, local)) {
                        double[] w = new double[3];
                        SceneRig.toWorld(pa, local, w);
                        ax = w[0]; ay = w[1]; az = w[2];
                    }
                }
            }
            double r = Math.toRadians(-p[3]);
            double cs = Math.cos(r), sn = Math.sin(r);
            double lx = x * cs + z * sn, lz = -x * sn + z * cs;
            x = ax + lx * p[6];
            y = ay + y * p[6];
            z = az + lz * p[6];
            yaw += p[3];
            pitch += p[4];
            roll += p[5];
            scale *= p[6];
        }
        out[0] = x; out[1] = y; out[2] = z; out[3] = yaw; out[4] = pitch; out[5] = roll; out[6] = scale;
        return out;
    }

    // ═════════════════════════ камера ═════════════════════════

    private void camera(double t, SceneFrame out) {
        List<Track> tracks = active(Track.Type.CAMERA);
        Clip cur = null;
        for (Track tr : tracks) {
            Clip c = tr.clipAt(t);
            if (c != null) cur = c;
        }
        double at = t;
        if (cur == null) {
            // між кліпами / після останнього: камера лишається там, де закінчився попередній кліп
            // (до першого — де він почнеться), а не стрибає «кудись» на вид редактора чи гравця
            Clip before = null, after = null;
            for (Track tr : tracks) for (Clip c : tr.clips) {
                if (c.muted || variant.object(c.ref) == null) continue;
                if (c.end() <= t + 1e-9) { if (before == null || c.end() > before.end()) before = c; }
                else if (c.start >= t && (after == null || c.start < after.start)) after = c;
            }
            cur = before != null ? before : after;
            if (cur == null) return;
            at = cur == before ? Math.max(cur.start, cur.end() - 1e-6) : cur.start;
        }
        SceneObject cam = variant.object(cur.ref);
        if (cam == null) return;
        cameraOf(cam, at, cur, out.camera);
        out.hasCamera = true;
        out.cameraId = cam.id;

        // переходи на межах кліпів
        for (Track tr : tracks) {
            for (Clip c : tr.clips) {
                Transition tn = c.transition;
                if (c.muted || tn == null || tn.type == Transition.Type.CUT || tn.duration <= 0) continue;
                double d = tn.duration;
                if (tn.type == Transition.Type.BLEND) {
                    if (c != cur || t >= c.start + d) continue;
                    Clip prev = clipBefore(tracks, c);
                    SceneObject pc = prev == null ? null : variant.object(prev.ref);
                    if (pc == null) continue;
                    double f = tn.easing == null ? (t - c.start) / d : tn.easing.apply((t - c.start) / d);
                    SceneFrame.Cam a = cameraOf(pc, t, prev, new SceneFrame.Cam());
                    SceneFrame.Cam b = new SceneFrame.Cam().set(out.camera);
                    out.camera.lerp(a, b, clamp01(f));
                } else {
                    double w0 = c.start - d / 2, w1 = c.start + d / 2;
                    if (t < w0 || t >= w1) continue;
                    out.fx = tn.type;
                    out.fxU = (t - w0) / d;
                    out.fxColor = tn.color;
                    if (tn.type == Transition.Type.ZOOM_PUNCH) out.camera.fov *= zoomPunch(out.fxU);
                    if (tn.type == Transition.Type.WHIP_PAN) out.camera.yaw += whip(out.fxU);
                    double bump = 1 - Math.abs(2 * out.fxU - 1);
                    if (tn.type == Transition.Type.SPIN) out.camera.roll += (float) (out.fxU < 0.5 ? 180 * Math.pow(out.fxU * 2, 3) : -180 * Math.pow(2 - out.fxU * 2, 3));
                    if (tn.type == Transition.Type.ZOOM_OUT) out.camera.fov = (float) Math.min(140, out.camera.fov * (1 + 0.7 * bump * bump));
                    if (tn.type == Transition.Type.SHAKE) {
                        out.camera.yaw += (float) (9 * bump * noise(t, 22, 0));
                        out.camera.pitch += (float) (7 * bump * noise(t, 19, 3));
                        out.camera.roll += (float) (5 * bump * noise(t, 17, 5));
                    }
                }
            }
        }
    }

    /**
     * Поза камери-об'єкта в t. Інерція (drag, як BBS Drag): камера експоненційно наздоганяє «сиру» позу —
     * детерміновано, перераховуючи останні 1.5 с, тож перемотка дає той самий кадр.
     */
    public SceneFrame.Cam cameraOf(SceneObject cam, double t, Clip clip, SceneFrame.Cam out) {
        if (cam.drag <= 0.001) return cameraRaw(cam, t, clip, out);
        double step = 0.05, from = Math.max(0, t - 1.5);
        SceneFrame.Cam s = cameraRaw(cam, from, clip, new SceneFrame.Cam()), raw = new SceneFrame.Cam();
        double k = 1 - Math.pow(cam.drag, 1.0);
        for (double tt = from + step; tt < t + step * 0.5; tt += step) {
            cameraRaw(cam, Math.min(t, tt), clip, raw);
            s.lerp(new SceneFrame.Cam().set(s), raw, k);
        }
        return out.set(s);
    }

    private SceneFrame.Cam cameraRaw(SceneObject cam, double t, Clip clip, SceneFrame.Cam out) {
        double[] xf = transform(cam, t, new double[7], 0);
        out.x = xf[0]; out.y = xf[1]; out.z = xf[2];
        out.yaw = (float) xf[3]; out.pitch = (float) xf[4]; out.roll = (float) xf[5];
        out.fov = (float) cam.channels.sample(Channels.FOV, t, cam.fov);
        if (!cam.path.isEmpty()) {
            double f;
            if (cam.channels.has(Channels.PATH)) f = cam.channels.sample(Channels.PATH, t, 0);
            else if (clip != null) f = (t - clip.start) / Math.max(1e-6, clip.length);
            else f = 0;
            path(cam, clamp01(f), out);
        }
        if (cam.orbitTarget != null) {
            double[] tg = target(cam.orbitTarget, t);
            if (tg != null) {
                double oy = Math.toRadians(cam.channels.sample(Channels.ORBIT_YAW, t, cam.yaw));
                double op = Math.toRadians(cam.channels.sample(Channels.ORBIT_PITCH, t, 15));
                double od = cam.channels.sample(Channels.ORBIT_DIST, t, 4);
                // камера стоїть «позаду» напрямку orbit_yaw і дивиться на ціль
                double fx = -Math.sin(oy) * Math.cos(op), fy = -Math.sin(op), fz = Math.cos(oy) * Math.cos(op);
                out.x = tg[0] - fx * od; out.y = tg[1] + cam.lookOffsetY - fy * od; out.z = tg[2] - fz * od;
                out.yaw = (float) Math.toDegrees(oy);
                out.pitch = (float) Math.toDegrees(op);
            }
        }
        if (cam.lookAt != null) {
            double[] target = target(cam.lookAt, t);
            float[] look = lastLook.get(cam.id);
            if (target != null) {
                double dx = target[0] - out.x, dy = target[1] + cam.lookOffsetY - out.y, dz = target[2] - out.z;
                double h = Math.sqrt(dx * dx + dz * dz);
                if (h > 1e-6 || Math.abs(dy) > 1e-6) {
                    look = new float[] { (float) Math.toDegrees(Math.atan2(-dx, dz)), (float) -Math.toDegrees(Math.atan2(dy, h)) };
                    lastLook.put(cam.id, look);
                }
            } else if (!cam.lookHoldOnLoss) look = null;
            if (look != null) { out.yaw = look[0]; out.pitch = look[1]; }
        }
        if (cam.dollyZoom) {
            String ref = cam.lookAt != null ? cam.lookAt : cam.orbitTarget;
            double[] tg = ref == null ? null : target(ref, t);
            if (tg != null) {
                double dx = tg[0] - out.x, dy = tg[1] - out.y, dz = tg[2] - out.z, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
                double ref0 = Math.tan(Math.toRadians(Math.max(1, cam.fov) / 2)), now = Math.tan(Math.toRadians(Math.max(1, out.fov) / 2));
                double nd = d * ref0 / now;          // ціль займає той самий кут: відстань ∝ 1/tan(fov/2)
                if (d > 1e-4) { out.x = tg[0] - dx / d * nd; out.y = tg[1] - dy / d * nd; out.z = tg[2] - dz / d * nd; }
            }
        }
        double shake = cam.channels.sample(Channels.SHAKE, t, 0) + cam.breath;
        if (shake > 0) {
            out.yaw += (float) (shake * noise(t, 1.00, 0.0));
            out.pitch += (float) (shake * noise(t, 0.85, 2.1));
            out.roll += (float) (shake * 0.45 * noise(t, 0.60, 4.3));
            double drift = shake * 0.012;
            out.x += drift * noise(t, 0.45, 6.1);
            out.y += drift * 0.6 * noise(t, 0.55, 8.7);
            out.z += drift * noise(t, 0.40, 1.9);
        }
        out.pitch = Math.max(-90f, Math.min(90f, out.pitch));
        return out;
    }

    /** Catmull-Rom по точках шляху (рівномірний параметр), кути — по найкоротшій дузі. */
    private static void path(SceneObject cam, double f, SceneFrame.Cam out) {
        List<SceneObject.PathPoint> p = cam.path;
        int n = p.size();
        if (n == 1) {
            SceneObject.PathPoint a = p.get(0);
            out.x = a.x; out.y = a.y; out.z = a.z; out.yaw = a.yaw; out.pitch = a.pitch; out.roll = a.roll; out.fov = a.fov;
            return;
        }
        double s = f * (n - 1);
        int i = Math.min(n - 2, (int) Math.floor(s));
        double u = s - i;
        SceneObject.PathPoint p0 = p.get(Math.max(0, i - 1)), p1 = p.get(i), p2 = p.get(i + 1), p3 = p.get(Math.min(n - 1, i + 2));
        out.x = cr(u, p0.x, p1.x, p2.x, p3.x);
        out.y = cr(u, p0.y, p1.y, p2.y, p3.y);
        out.z = cr(u, p0.z, p1.z, p2.z, p3.z);
        if (cam.pathOrient) {
            double e = 1e-3;
            double u2 = Math.min(1, u + e), u1 = Math.max(0, u - e);
            double dx = cr(u2, p0.x, p1.x, p2.x, p3.x) - cr(u1, p0.x, p1.x, p2.x, p3.x);
            double dy = cr(u2, p0.y, p1.y, p2.y, p3.y) - cr(u1, p0.y, p1.y, p2.y, p3.y);
            double dz = cr(u2, p0.z, p1.z, p2.z, p3.z) - cr(u1, p0.z, p1.z, p2.z, p3.z);
            double h = Math.sqrt(dx * dx + dz * dz);
            out.yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            out.pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        } else {
            double y1 = p1.yaw, y2 = y1 + SceneFrame.Cam.wrap(p2.yaw - p1.yaw);
            double y0 = y1 - SceneFrame.Cam.wrap(p1.yaw - p0.yaw), y3 = y2 + SceneFrame.Cam.wrap(p3.yaw - p2.yaw);
            out.yaw = (float) cr(u, y0, y1, y2, y3);
            out.pitch = (float) cr(u, p0.pitch, p1.pitch, p2.pitch, p3.pitch);
        }
        out.roll = (float) cr(u, p0.roll, p1.roll, p2.roll, p3.roll);
        out.fov = (float) cr(u, p0.fov, p1.fov, p2.fov, p3.fov);
    }

    private static double cr(double t, double p0, double p1, double p2, double p3) {
        double t2 = t * t, t3 = t2 * t;
        return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
    }

    /**
     * Світова точка цілі: {@code obj:<id>}, {@code obj:<id>:<кістка>}, {@code slot:<ім'я>[#i]}.
     * @return null — ціль недоступна (тоді політика lookHoldOnLoss)
     */
    public double[] target(String ref, double t) {
        if (ref == null) return null;
        if (ref.startsWith("obj:")) {
            String rest = ref.substring(4);
            int c = rest.indexOf(':');
            String id = c < 0 ? rest : rest.substring(0, c), bone = c < 0 ? null : rest.substring(c + 1);
            SceneObject o = variant.object(id);
            if (o == null) return null;
            if (o.kind == SceneObject.Kind.ACTOR || o.kind == SceneObject.Kind.PROP) {
                SceneFrame.Actor a = actor(o, t);
                if (!a.visible && !editor) return null;
                SceneRig rig = clips.rig(o);
                float[] local = new float[3];
                if (rig != null && bone != null && rig.bonePivot(bone, a.pose, local)) {
                    double[] w = new double[3];
                    SceneRig.toWorld(a, local, w);
                    return w;
                }
                return new double[] { a.x, a.y + (o.modelType == SceneObject.ModelType.PLAYER ? 1.5 * a.scale : 0), a.z };
            }
            double[] xf = transform(o, t, new double[7], 0);
            return new double[] { xf[0], xf[1], xf[2] };
        }
        if (ref.startsWith("slot:")) {
            String s = ref.substring(5);
            int idx = 0, h = s.indexOf('#');
            if (h >= 0) { try { idx = Integer.parseInt(s.substring(h + 1)); } catch (NumberFormatException ignored) { } s = s.substring(0, h); }
            for (SceneObject o : variant.objects) {
                if (s.equals(o.slot) && o.slotIndex == idx && o.kind != SceneObject.Kind.CAMERA) return target("obj:" + o.id, t);
            }
            SceneBindings.Binding b = bindings.get(s, idx);
            return b != null && b.hasPos ? new double[] { b.x, b.y + 1.5, b.z } : null;
        }
        return null;
    }

    private Clip clipBefore(List<Track> tracks, Clip c) {
        double t = c.start - 1e-4;
        Clip best = null;
        for (Track tr : tracks) {
            Clip x = tr.clipAt(t);
            if (x != null && x != c) best = x;
        }
        return best;
    }

    // ═════════════════════════ звук, оверлеї, ефекти ═════════════════════════

    private void media(double t, SceneFrame out) {
        for (Track tr : active(Track.Type.AUDIO)) {
            for (Clip c : tr.clips) {
                if (c.muted || !c.covers(t) || c.ref == null) continue;
                SceneFrame.Audio a = new SceneFrame.Audio();
                a.track = tr;
                a.clip = c;
                a.ref = c.ref;
                double st = (t - c.start) * c.speed + c.in;
                if (c.end == Clip.End.LOOP && c.sourceLength > 0) {
                    double span = Math.max(1e-3, c.sourceLength - Math.min(c.in, c.sourceLength * 0.999));
                    if (st >= c.sourceLength) st = c.in + ((st - c.in) % span);
                    a.loop = true;
                } else if (c.sourceLength > 0 && st >= c.sourceLength) continue;
                a.sourceTime = st;
                a.gain = c.value(Channels.GAIN, t, 1) * c.fadeWeight(t) * tr.gain;
                a.pitch = c.param("pitch", 1);
                SceneObject src = variant.object(tr.target);
                if (src != null) {
                    double[] xf = transform(src, t, new double[7], 0);
                    a.position = new double[] { xf[0], xf[1], xf[2] };
                }
                out.audio.add(a);
            }
        }
        for (Track tr : active(Track.Type.OVERLAY)) {
            for (Clip c : tr.clips) {
                if (c.muted || !c.covers(t) || c.ref == null) continue;
                SceneFrame.Overlay o = new SceneFrame.Overlay();
                o.clip = c;
                o.id = c.ref;
                o.local = t - c.start;
                o.length = c.length;
                o.opacity = c.value(Channels.OPACITY, t, 1);
                o.x = c.value("x", t, 0.5);
                o.y = c.value("y", t, 0.5);
                o.scale = c.value("scale", t, 1);
                double ein = c.param("enter_time", 0.3), eout = c.param("exit_time", 0.3);
                o.enter = ein <= 0 ? 1 : clamp01(o.local / ein);
                o.exit = eout <= 0 ? 1 : clamp01((c.length - o.local) / eout);
                o.enterType = c.param("enter", "fade");
                o.exitType = c.param("exit", "fade");
                o.params = c.params;
                out.overlays.add(o);
            }
        }
        for (Track tr : active(Track.Type.EFFECT)) {
            for (Clip c : tr.clips) {
                if (c.muted || !c.covers(t) || c.ref == null) continue;
                SceneFrame.Effect e = new SceneFrame.Effect();
                e.clip = c;
                e.id = c.ref;
                e.intensity = c.value(Channels.INTENSITY, t, 1) * c.fadeWeight(t);
                e.params = c.params;
                out.effects.add(e);
            }
        }
    }

    /** Треки типу з урахуванням mute/solo, знизу вгору. */
    public List<Track> active(Track.Type type) {
        List<Track> all = variant.tracks(type);
        boolean solo = false;
        for (Track t : all) solo |= t.solo;
        List<Track> out = new ArrayList<>(all.size());
        for (Track t : all) if (!t.muted && (!solo || t.solo)) out.add(t);
        return out;
    }

    // ═════════════════════════ утиліти ═════════════════════════

    /** Множник FOV «наїзду» (мафія): до склейки стискає кадр, після — вилітає з широкого кута. */
    static float zoomPunch(double u) {
        if (u < 0.5) { double k = u / 0.5; return (float) (1 - 0.5 * k * k * k); }
        double k = (u - 0.5) / 0.5, f = 1 - k;
        return (float) (1 + 0.55 * f * f * f);
    }

    /** Зсув yaw для whip-pan: різкий розворот до склейки й «доїзд» після. */
    static float whip(double u) {
        if (u < 0.5) { double k = u / 0.5; return (float) (70 * k * k); }
        double k = 1 - (u - 0.5) / 0.5;
        return (float) (-70 * k * k);
    }

    /** Плавний шум ≈[-1, 1]: три синусоїди з несумірними частотами (як «рука оператора» мафії). */
    static double noise(double s, double speed, double phase) {
        double x = s * speed;
        return Math.sin(x * 1.7 + phase) * 0.55 + Math.sin(x * 2.9 + phase * 1.7 + 1.3) * 0.30 + Math.sin(x * 5.3 + phase * 0.6 + 2.2) * 0.15;
    }

    static double clamp01(double v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
}
