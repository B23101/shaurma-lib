package dev.shaurmalib.scene.api;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Опис сцени, який реєструє ГОЛОВНИЙ мод: id, призначення, слоти (що мод передає при запуску),
 * дозволені мітки, підказки варіантів. Бібліотека за цим описом відкриває редактор і перевіряє документ —
 * сама нових сцен не вигадує.
 *
 * <pre>{@code
 * SceneRegistry.register(SceneDefinition.builder("maniac:victory_maniac", "Перемога маніяка")
 *     .slot(Slot.player("maniac", "Маніяк"))
 *     .slot(Slot.players("victims", "Жертви на гачках", 10))
 *     .labels("victory_hook", "hook_target").boneLabels("player_skin")
 *     .variantHint("1-3", 1, 3).variantHint("4+", 4, 0)
 *     .build());
 * }</pre>
 */
public final class SceneDefinition {

    public enum SlotKind {
        /** Один гравець (скін, нік, UUID). */
        PLAYER,
        /** Список гравців: актори з {@code slot_index} 0..max-1. */
        PLAYERS,
        /** Будь-яка сутність (позиція для look-at, прив'язки). */
        ENTITY,
        /** Число/рядок (значення для оверлеїв, параметрів кліпів). */
        VALUE
    }

    public record Slot(String name, String title, SlotKind kind, int max, String description) {
        public static Slot player(String name, String title) { return new Slot(name, title, SlotKind.PLAYER, 1, ""); }
        public static Slot players(String name, String title, int max) { return new Slot(name, title, SlotKind.PLAYERS, max, ""); }
        public static Slot entity(String name, String title) { return new Slot(name, title, SlotKind.ENTITY, 1, ""); }
        public static Slot value(String name, String title) { return new Slot(name, title, SlotKind.VALUE, 1, ""); }
        public Slot describe(String d) { return new Slot(name, title, kind, max, d); }
    }

    public record VariantHint(String id, int minPlayers, int maxPlayers) {}

    /** Як сцена використовується (впливає на типові налаштування нового документа). */
    public enum Usage {
        /** Кінематографічна вставка для гравців (камера забирає керування). */
        CUTSCENE,
        /** Лише камери (без акторів), напр. проліт по карті під час завантаження. */
        CAMERA_ONLY,
        /** Статична зациклена сценка у меню (превʼю кіта): без світу, без ліміту. */
        LOOP_PREVIEW,
        /**
         * Анімована сцена у віконці меню: справжня локація світу, власна камера, світло, тіні й корекція,
         * рендериться окремо від камери гравця в картку/кнопку ({@code MenuScene} у mc-шарі). Зациклена.
         */
        MENU_SCENE
    }

    /**
     * Вимога режиму до сцени меню — редактор показує чек-лист «що треба розмістити» і чи виконано.
     *
     * @param kind  що перевіряти
     * @param key   мітка / слот / число (залежно від kind)
     * @param title людська назва («Персонаж у кадрі», «Зброя кіта»)
     * @param min   мінімальна кількість (для LABEL/SLOT/LIGHTS) або межа (MAX_LENGTH, секунди)
     */
    public record Requirement(ReqKind kind, String key, String title, double min) {
        /** Об'єкт з міткою (наприклад {@code kit_item}). */
        public static Requirement label(String label, String title) { return new Requirement(ReqKind.LABEL, label, title, 1); }
        /** Актор, прив'язаний до слота. */
        public static Requirement slot(String slot, String title) { return new Requirement(ReqKind.SLOT, slot, title, 1); }
        /** Об'єкт з міткою має бути в кадрі весь цикл і не заходити в безпечні зони. */
        public static Requirement inFrame(String label, String title) { return new Requirement(ReqKind.IN_FRAME, label, title, 1); }
        /** Щонайменше n світел. */
        public static Requirement lights(int n) { return new Requirement(ReqKind.LIGHTS, null, "Світло сцени (≥ " + n + ")", n); }
        /** Хоч одне світло з тінями. */
        public static Requirement shadows() { return new Requirement(ReqKind.SHADOW_LIGHT, null, "Світло з тінями", 1); }
        /** Безшовний цикл. */
        public static Requirement seamless() { return new Requirement(ReqKind.SEAMLESS_LOOP, null, "Безшовний цикл", 0); }
        /** Цикл не довший за n секунд. */
        public static Requirement maxLength(double seconds) { return new Requirement(ReqKind.MAX_LENGTH, null, "Цикл ≤ " + seconds + " с", seconds); }
    }

    public enum ReqKind { LABEL, SLOT, IN_FRAME, LIGHTS, SHADOW_LIGHT, SEAMLESS_LOOP, MAX_LENGTH }

    public final String id;
    public final String title;
    public final String description;
    public final Usage usage;
    public final List<Slot> slots;
    public final List<String> labels;
    public final List<String> boneLabels;
    public final List<VariantHint> variantHints;
    /** Моделі з ресурсів мода, доступні в Asset Browser (id як у кліпів ShaurmaAnim). */
    public final List<String> resourceModels;
    public final List<String> overlays;
    public final List<String> effects;
    /** Назви подій (міток), які мод розуміє — підказки в редакторі. */
    public final List<String> events;
    /** Слот, кількість гравців у якому вибирає варіант. */
    public final String countSlot;
    /** Кадр сцени меню (співвідношення сторін, збільшення під курсором, безпечні зони, радіус сцени); null — не меню. */
    public final dev.shaurmalib.scene.doc.MenuFrame menu;
    /** Що режим вимагає розмістити на сцені меню (чек-лист редактора). */
    public final List<Requirement> requirements;
    /**
     * Початковий вміст, поки сцену не змонтовано (сервер): режим будує документ зі своїх конфігів —
     * точок камер, роликів, розмітки — і редактор відкривається з ними, а не з порожнечі. null — порожньо.
     */
    public final java.util.function.Function<String, dev.shaurmalib.scene.doc.SceneDoc> seeder;

    private SceneDefinition(Builder b) {
        id = b.id;
        title = b.title;
        description = b.description;
        usage = b.usage;
        slots = List.copyOf(b.slots.values());
        labels = List.copyOf(b.labels);
        boneLabels = List.copyOf(b.boneLabels);
        variantHints = List.copyOf(b.hints);
        resourceModels = List.copyOf(b.models);
        overlays = List.copyOf(b.overlays);
        effects = List.copyOf(b.effects);
        events = List.copyOf(b.events);
        countSlot = b.countSlot;
        seeder = b.seeder;
        menu = b.menu;
        requirements = List.copyOf(b.requirements);
    }

    public Slot slot(String name) {
        for (Slot s : slots) if (s.name.equals(name)) return s;
        return null;
    }

    public static Builder builder(String id, String title) { return new Builder(id, title); }

    public static final class Builder {
        private final String id, title;
        private String description = "";
        private Usage usage = Usage.CUTSCENE;
        private final Map<String, Slot> slots = new LinkedHashMap<>();
        private final List<String> labels = new ArrayList<>(), boneLabels = new ArrayList<>(), models = new ArrayList<>(),
            overlays = new ArrayList<>(), effects = new ArrayList<>(), events = new ArrayList<>();
        private final List<VariantHint> hints = new ArrayList<>();
        private String countSlot;
        private java.util.function.Function<String, dev.shaurmalib.scene.doc.SceneDoc> seeder;
        private dev.shaurmalib.scene.doc.MenuFrame menu;
        private final List<Requirement> requirements = new ArrayList<>();

        private Builder(String id, String title) {
            if (id == null || !id.matches("[a-z0-9_.-]+:[a-z0-9_./-]+")) throw new IllegalArgumentException("id сцени: ns:path, отримано " + id);
            this.id = id;
            this.title = title;
        }

        public Builder description(String d) { this.description = d; return this; }
        public Builder usage(Usage u) { this.usage = u; return this; }
        public Builder slot(Slot s) { slots.put(s.name(), s); return this; }
        public Builder labels(String... l) { Collections.addAll(labels, l); return this; }
        public Builder boneLabels(String... l) { Collections.addAll(boneLabels, l); return this; }
        public Builder variantHint(String id, int min, int max) { hints.add(new VariantHint(id, min, max)); return this; }
        public Builder models(String... ids) { Collections.addAll(models, ids); return this; }
        public Builder overlays(String... ids) { Collections.addAll(overlays, ids); return this; }
        public Builder effects(String... ids) { Collections.addAll(effects, ids); return this; }
        public Builder events(String... names) { Collections.addAll(events, names); return this; }
        /** Кількість гравців у цьому слоті вибирає варіант (типово — перший слот PLAYERS). */
        public Builder countSlot(String slot) { this.countSlot = slot; return this; }
        /** Початковий вміст зі старих конфігів режиму (див. {@link SceneDefinition#seeder}). */
        public Builder seed(java.util.function.Function<String, dev.shaurmalib.scene.doc.SceneDoc> s) { this.seeder = s; return this; }

        /** Сцена для віконця меню: кадр (напр. {@code MenuFrame.card(3, 4).safeBottom(0.2f)}); ставить usage MENU_SCENE. */
        public Builder menu(dev.shaurmalib.scene.doc.MenuFrame frame) { this.menu = frame; this.usage = Usage.MENU_SCENE; return this; }
        /** Вимоги до вмісту сцени (чек-лист у редакторі). */
        public Builder require(Requirement... r) { Collections.addAll(requirements, r); return this; }

        public SceneDefinition build() {
            if (countSlot == null) for (Slot s : slots.values()) if (s.kind() == SlotKind.PLAYERS) { countSlot = s.name(); break; }
            return new SceneDefinition(this);
        }
    }
}
