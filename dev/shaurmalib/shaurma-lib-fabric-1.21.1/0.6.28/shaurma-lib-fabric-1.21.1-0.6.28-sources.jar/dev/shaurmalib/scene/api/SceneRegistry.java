package dev.shaurmalib.scene.api;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Реєстр сцен, які оголосив головний мод. Редактор відкриває ЛИШЕ зареєстровані сцени. Реєструвати —
 * у спільному setup (і на клієнті, і на сервері), до старту сервера.
 *
 * <p>Тут же — глобальні слухачі подій сцен (мітки таймлайну, кінець сцени), щоб режим реагував
 * на «laugh_start» чи кінець сцени без власної мережі.
 */
public final class SceneRegistry {

    private SceneRegistry() {}

    private static final Map<String, SceneDefinition> SCENES = Collections.synchronizedMap(new LinkedHashMap<>());
    private static final List<SceneListener> LISTENERS = new CopyOnWriteArrayList<>();

    public static SceneDefinition register(SceneDefinition def) {
        SCENES.put(def.id, def);
        return def;
    }

    public static SceneDefinition get(String id) { return id == null ? null : SCENES.get(id); }

    public static boolean has(String id) { return SCENES.containsKey(id); }

    public static Collection<SceneDefinition> all() {
        synchronized (SCENES) { return new ArrayList<>(SCENES.values()); }
    }

    public static void listen(SceneListener l) { LISTENERS.add(l); }

    public static void unlisten(SceneListener l) { LISTENERS.remove(l); }

    public static List<SceneListener> listeners() { return LISTENERS; }

    /** Події програвання (на сервері й на клієнті — див. {@link SceneSession#serverSide()}). */
    public interface SceneListener {
        /** Мітка таймлайну перетнута. */
        default void onMarker(SceneSession session, String marker, Map<String, Object> payload) {}
        /** Сцена почалась (після preroll). */
        default void onStart(SceneSession session) {}
        /** Сцена скінчилась або зупинена ({@code interrupted}). */
        default void onEnd(SceneSession session, boolean interrupted) {}
    }

    /** Мінімальний опис сесії для слухачів (без типів гри). */
    public interface SceneSession {
        long id();
        String sceneId();
        String variant();
        SceneBindings bindings();
        /** Час контенту, секунди. */
        double time();
        boolean serverSide();
    }
}
