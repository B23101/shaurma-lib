package dev.shaurmalib.scene.doc;

import dev.shaurmalib.anim.math.Easing;

import java.util.Locale;

/**
 * Перехід на межі двох кліпів. Не всі переходи взаємозамінні:
 * <ul>
 *   <li>{@link Type#BLEND} — інтерполяція трансформу/FOV камери (камера ЇДЕ з кадру A в кадр B);</li>
 *   <li>решта — композитинг поверх кадру: склейка відбувається рівно посередині, ефект її ховає
 *       (технологія мафії: dip, flash, glitch, shutter, wipe, zoom-punch, crossfade);</li>
 *   <li>{@link Type#CUT} — миттєва зміна активної камери.</li>
 * </ul>
 */
public final class Transition {

    public enum Type {
        CUT(0), BLEND(1000), FADE_BLACK(800), DIP_COLOR(700), FLASH(380), GLITCH(420), SHUTTER(480),
        WIPE(520), ZOOM_PUNCH(460), CROSSFADE(900), WHIP_PAN(350),
        // ── нові (бібліотека «Переходи»): композитинг поверх кадру й рух камери ──
        WIPE_UP(520), WIPE_DIAGONAL(560), IRIS(700), BLINDS(620), SPLIT_DOOR(560), PIXEL_BLOCKS(600),
        RGB_SPLIT(420), FILM_BURN(800), LIGHT_LEAK(900), SPIN(520), ZOOM_OUT(520), SHAKE(450),
        PUSH_LEFT(600), PUSH_UP(600), BLUR_DIP(700), INK(800);

        public final int defaultMs;

        Type(int ms) { this.defaultMs = ms; }

        /** Чи це інтерполяція камери (а не ефект поверх кадру). */
        public boolean isCameraBlend() { return this == BLEND; }

        public static Type parse(String s, Type def) {
            if (s == null) return def;
            String n = s.trim().toUpperCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
            for (Type t : values()) if (t.name().equals(n) || t.name().replace("_", "").equals(n.replace("_", ""))) return t;
            return def;
        }
    }

    public Type type = Type.CUT;
    /** Тривалість, секунди. */
    public double duration;
    public Easing easing = Easing.parse("easeInOutCubic");
    /** Колір для DIP_COLOR / FLASH, 0xRRGGBB. */
    public int color = 0x000000;

    public Transition() {}

    public Transition(Type type, double duration) {
        this.type = type;
        this.duration = duration;
    }

    public static Transition of(Type type) { return new Transition(type, type.defaultMs / 1000.0); }

    public Transition copy() {
        Transition t = new Transition(type, duration);
        t.easing = easing;
        t.color = color;
        return t;
    }
}
