package dev.shaurmalib.scene.eval;

import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.api.SceneRegistry;
import dev.shaurmalib.scene.doc.Marker;
import dev.shaurmalib.scene.doc.SceneDoc;

import java.util.Map;

/**
 * Годинник однієї сесії сцени: preroll (чорний екран, поки вантажаться чанки), потім час контенту
 * росте як {@code dt · speed(t)} (сповільнення з треків TIME), перетнуті мітки → події, кінець → onEnd.
 * Зациклена сцена ({@link SceneDoc.Variant#loop}) крутиться без кінця. Однаковий на клієнті й сервері.
 */
public final class ScenePlayback implements SceneRegistry.SceneSession {

    /** Подія мітки для власника сесії (рендер, звук). */
    public interface MarkerSink { void marker(Marker m); }

    private final long id;
    private final SceneDoc doc;
    private final SceneDoc.Variant variant;
    private final SceneBindings bindings;
    private final SceneEvaluator evaluator;
    private final boolean server;
    private double time, wall, preroll;
    private boolean started, ended, interrupted;
    private MarkerSink sink;
    private boolean paused;

    public ScenePlayback(long id, SceneDoc doc, SceneDoc.Variant variant, SceneBindings bindings, double startAt, double preroll, boolean server) {
        this.id = id;
        this.doc = doc;
        this.variant = variant;
        this.bindings = bindings == null ? new SceneBindings() : bindings;
        this.evaluator = new SceneEvaluator(doc, variant, this.bindings);
        this.time = Math.max(0, startAt);
        this.preroll = Math.max(0, preroll);
        this.server = server;
    }

    public ScenePlayback sink(MarkerSink s) { this.sink = s; return this; }

    public SceneEvaluator evaluator() { return evaluator; }

    public SceneDoc doc() { return doc; }

    public SceneDoc.Variant variantDoc() { return variant; }

    @Override public long id() { return id; }
    @Override public String sceneId() { return doc.id; }
    @Override public String variant() { return variant.id; }
    @Override public SceneBindings bindings() { return bindings; }
    @Override public double time() { return time; }
    @Override public boolean serverSide() { return server; }

    public boolean inPreroll() { return preroll > 0; }

    public double prerollLeft() { return preroll; }

    public boolean ended() { return ended; }

    public boolean wasInterrupted() { return interrupted; }

    public double wallTime() { return wall; }

    public void paused(boolean p) { this.paused = p; }

    /** Просунути годинник на dt секунд реального часу. */
    public void advance(double dt) {
        if (ended || paused || dt <= 0) return;
        wall += dt;
        if (preroll > 0) {
            preroll -= dt;
            if (preroll > 0) return;
            dt = -preroll;
            preroll = 0;
        }
        if (!started) {
            started = true;
            for (SceneRegistry.SceneListener l : SceneRegistry.listeners()) safe(() -> l.onStart(this));
        }
        double prev = time;
        // інтегруємо швидкість дрібними кроками, щоб рампа сповільнення не «перескакувала»
        double left = dt;
        while (left > 1e-9) {
            double step = Math.min(left, 0.025);
            time += step * evaluator.speedAt(time);
            left -= step;
        }
        double len = variant.length;
        if (variant.loop && len > 0) {
            // вступ 0..loopIn грає раз, далі цикл loopIn..loopOut
            double in = variant.loopStart(), end = variant.loopEnd(), span = end - in;
            if (span > 1e-4 && time >= end) {
                fireMarkers(prev, end);
                time = in + ((time - end) % span);
                fireMarkers(in - 1e-9, time);
                return;
            }
            fireMarkers(prev, time);
            return;
        }
        fireMarkers(prev, Math.min(time, len));
        if (!variant.loop && time >= len) {
            time = len;
            finish(false);
        }
    }

    /** Перемотати (редактор/синхронізація з сервером) без подій міток. */
    public void seek(double t) { this.time = Math.max(0, t); }

    public void stop() { if (!ended) finish(true); }

    private void finish(boolean interrupted) {
        ended = true;
        this.interrupted = interrupted;
        for (SceneRegistry.SceneListener l : SceneRegistry.listeners()) safe(() -> l.onEnd(this, interrupted));
    }

    private void fireMarkers(double from, double to) {
        for (Marker m : variant.markers) {
            if (!m.event || m.time <= from || m.time > to) continue;
            if (sink != null) safe(() -> sink.marker(m));
            Map<String, Object> payload = m.payload;
            for (SceneRegistry.SceneListener l : SceneRegistry.listeners()) safe(() -> l.onMarker(this, m.name, payload));
        }
    }

    private static void safe(Runnable r) {
        try { r.run(); } catch (RuntimeException e) { System.err.println("[shaurma_scene] слухач сцени впав: " + e); }
    }
}
