package dev.shaurmalib.scene.api;

import dev.shaurmalib.scene.doc.Channels;
import dev.shaurmalib.scene.doc.Clip;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.doc.Track;
import dev.shaurmalib.scene.doc.Transition;

/** Програмно змонтовані камери, які використовують той самий таймлайн, що й редактор сцен. */
public final class SceneCameraPaths {
    private SceneCameraPaths() {}

    /** Координати центра верхньої грані п'єдесталу. Слот player стежить за гравцем. */
    public static SceneDoc pedestalOrbit(double x, double y, double z, float yaw, double seconds) {
        if (!Double.isFinite(seconds) || seconds <= 0) throw new IllegalArgumentException("seconds must be positive and finite");
        SceneDoc doc = new SceneDoc("shaurma_lib:pedestal_orbit");
        SceneDoc.Variant variant = doc.variant(null);
        variant.length = seconds;
        variant.fadeIn = Math.min(0.3, seconds * 0.12);
        variant.fadeOut = 0;
        variant.letterbox = 0.075;

        var pedestal = new SceneObject("pedestal", "Pedestal", SceneObject.Kind.EMPTY);
        pedestal.x = x;
        pedestal.y = y;
        pedestal.z = z;
        var orbit = camera("orbit", 52);
        orbit.channels.getOrCreate(Channels.ORBIT_YAW).set(0, yaw - 45);
        orbit.channels.getOrCreate(Channels.ORBIT_YAW).set(seconds * 0.76, yaw + 75);
        orbit.channels.getOrCreate(Channels.ORBIT_PITCH).set(0, -4);
        orbit.channels.getOrCreate(Channels.ORBIT_PITCH).set(seconds * 0.76, 24);
        orbit.channels.getOrCreate(Channels.ORBIT_DIST).set(0, 3.6);
        orbit.channels.getOrCreate(Channels.ORBIT_DIST).set(seconds * 0.76, 4.8);
        var wide = camera("wide", 68);
        wide.yaw = yaw + 100;
        wide.channels.getOrCreate(Channels.ORBIT_PITCH).set(0, 28);
        wide.channels.getOrCreate(Channels.ORBIT_DIST).set(0, 6.2);
        variant.objects.add(pedestal);
        variant.objects.add(orbit);
        variant.objects.add(wide);

        double cut = seconds * 0.76;
        var track = new Track("camera", "Camera", Track.Type.CAMERA);
        track.clips.add(new Clip("orbit", 0, cut, orbit.id));
        var finalShot = new Clip("wide", cut, seconds - cut, wide.id);
        finalShot.transition = new Transition(Transition.Type.DIP_COLOR, Math.min(0.32, seconds * 0.16));
        finalShot.transition.color = 0xF8D998;
        track.clips.add(finalShot);
        variant.tracks.add(track);
        return doc;
    }

    private static SceneObject camera(String id, float fov) {
        var camera = new SceneObject(id, id, SceneObject.Kind.CAMERA);
        camera.orbitTarget = "obj:pedestal";
        camera.lookAt = "slot:player";
        camera.fov = fov;
        return camera;
    }
}
