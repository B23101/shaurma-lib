package dev.shaurmalib.scene.mc.client;

import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.api.SceneCameraPaths;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.eval.ScenePlayback;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_638;
import net.minecraft.class_746;

/** Відтворення камер таймлайну у вже завантаженій частині світу. Викликати з клієнтського потоку. */
public final class SceneCameraPlayback {
    private static Session active;
    private static long nextId;

    private SceneCameraPlayback() {}

    /** Запускає сцену довкола п'єдесталу. Повертає сесію для скасування через stop(). */
    public static ScenePlayback playPedestalOrbit(class_2338 pedestal, double seconds) {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null) throw new IllegalStateException("A local player is required");
        class_243 center = class_243.method_24955(pedestal).method_1031(0, 1, 0);
        SceneDoc doc = SceneCameraPaths.pedestalOrbit(center.field_1352, center.field_1351, center.field_1350, player.method_36454(), seconds);
        var binding = SceneBindings.Binding.player(player.method_5667(), player.method_7334().getName());
        return play(doc, null, new SceneBindings().bind("player", binding));
    }

    /** Координати документа — світові. UUID у слотах відстежують позиції гравців у поточному світі. */
    public static ScenePlayback play(SceneDoc doc, String variantId, SceneBindings bindings) {
        class_310 mc = class_310.method_1551();
        if (!mc.method_18854()) throw new IllegalStateException("Play scenes on the client thread");
        if (mc.field_1687 == null || mc.field_1724 == null) throw new IllegalStateException("A client world is required");
        SceneDoc.Variant variant = doc.variant(variantId);
        if (variant == null || !Double.isFinite(variant.length) || variant.length <= 0) {
            throw new IllegalArgumentException("A scene variant with a positive finite length is required");
        }
        if (variant.dimension != null && !variant.dimension.equals(mc.field_1687.method_27983().method_29177().toString())) {
            throw new IllegalArgumentException("The scene camera must be in the current dimension");
        }
        var playback = new ScenePlayback(++nextId, doc, variant, bindings, 0, 0, false);
        var previous = active;
        active = new Session(playback, mc.field_1687, mc.field_1724);
        if (previous != null) previous.playback.stop();
        return playback;
    }

    public static void tick(class_310 mc) { current(mc); }

    /** Застосовується один раз за кадр після vanilla Camera.setup(). */
    public static SceneFrame.Cam sample(float partial, SceneFrame.Cam vanilla) {
        class_310 mc = class_310.method_1551();
        Session session = current(mc);
        if (session == null) return null;

        long now = System.nanoTime();
        double dt = session.lastFrame == 0 ? 0 : Math.min(0.25, (now - session.lastFrame) * 1e-9);
        session.lastFrame = now;
        if (!mc.method_1493()) session.playback.advance(dt);
        if (session != active || session.playback.ended()) {
            current(mc);
            return null;
        }

        for (var bindings : session.playback.bindings().map().values()) {
            for (var binding : bindings) {
                if (binding.uuid == null) continue;
                var subject = session.level.method_18470(binding.uuid);
                if (subject != null) {
                    class_243 pos = subject.method_30950(partial);
                    binding.at(pos.field_1352, pos.field_1351, pos.field_1350);
                }
            }
        }
        double time = session.playback.time();
        session.playback.evaluator().eval(time, session.frame);
        if (!session.frame.hasCamera) return null;
        SceneDoc.Variant variant = session.playback.variantDoc();
        double tail = Math.min(0.45, variant.length * 0.20);
        double fraction = variant.loop ? 1 : Math.clamp((variant.length - time) / tail, 0, 1);
        session.cameraWeight = smooth(fraction);
        session.pose.lerp(vanilla, session.frame.camera, session.cameraWeight);
        return session.pose;
    }

    public static boolean hasCamera() {
        Session session = current(class_310.method_1551());
        return session != null && session.frame.hasCamera;
    }

    public static float roll() { return hasCamera() ? active.pose.roll : 0; }

    public static double fov(double vanilla) {
        return hasCamera() ? vanilla + (active.frame.camera.fov - vanilla) * active.cameraWeight : vanilla;
    }

    public static boolean hideHud() { return hasCamera() && active.playback.variantDoc().cinematic; }

    public static void renderHud(class_332 graphics) {
        if (!hasCamera()) return;
        SceneFrame frame = active.frame;
        int width = graphics.method_51421();
        int height = graphics.method_51443();
        if (frame.fx != null) {
            double phase = frame.fxU;
            double bump = smooth(1 - Math.abs(2 * phase - 1));
            switch (frame.fx) {
                case FADE_BLACK -> tint(graphics, width, height, 0, bump);
                case DIP_COLOR -> tint(graphics, width, height, frame.fxColor, bump);
                case FLASH -> tint(graphics, width, height, frame.fxColor == 0 ? 0xFFF4E0 : frame.fxColor, bump);
                default -> { }
            }
        }
        int bar = (int) Math.round(height * Math.clamp(frame.letterbox, 0, 0.5) * active.cameraWeight);
        if (bar > 0) {
            graphics.method_25294(0, 0, width, bar, 0xFF000000);
            graphics.method_25294(0, height - bar, width, height, 0xFF000000);
        }
        tint(graphics, width, height, 0, frame.fade);
    }

    private static void tint(class_332 graphics, int width, int height, int color, double opacity) {
        int alpha = (int) Math.round(255 * Math.clamp(opacity, 0, 1));
        if (alpha != 0) graphics.method_25294(0, 0, width, height, (alpha << 24) | (color & 0xFFFFFF));
    }

    private static double smooth(double t) { return t * t * (3 - 2 * t); }

    private static Session current(class_310 mc) {
        Session session = active;
        if (session == null) return null;
        if (session.playback.ended() || mc.field_1687 != session.level || mc.field_1724 != session.player || !session.player.method_5805()) {
            active = null;
            session.playback.stop();
            return null;
        }
        return session;
    }

    private static final class Session {
        private final ScenePlayback playback;
        private final class_638 level;
        private final class_746 player;
        private final SceneFrame frame = new SceneFrame();
        private final SceneFrame.Cam pose = new SceneFrame.Cam();
        private long lastFrame;
        private double cameraWeight;

        private Session(ScenePlayback playback, class_638 level, class_746 player) {
            this.playback = playback;
            this.level = level;
            this.player = player;
        }
    }
}
