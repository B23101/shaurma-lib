package dev.shaurmalib.scene.doc;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Набір іменованих кривих об'єкта/кліпу/кістки. Канал створюється на першому ключі; поки його нема,
 * значення береться з {@link #defaultOf}. Імена стандартні (як data path у Blender):
 * {@code x y z yaw pitch roll scale fov visible shake focus path}, для кісток {@code rx ry rz px py pz sx sy sz}.
 */
public final class Channels {

    public static final String X = "x", Y = "y", Z = "z", YAW = "yaw", PITCH = "pitch", ROLL = "roll",
        SCALE = "scale", FOV = "fov", VISIBLE = "visible", SHAKE = "shake", PATH = "path", OPACITY = "opacity",
        INTENSITY = "intensity", GAIN = "gain", SPEED = "speed",
        /** Голова відносно тіла (як у записі BBS: headYaw − bodyYaw) і нахил погляду, градуси. */
        HEAD_YAW = "head_yaw", HEAD_PITCH = "head_pitch", SNEAK = "sneak",
        /** Орбіта камери навколо цілі: кут, нахил, відстань. */
        ORBIT_YAW = "orbit_yaw", ORBIT_PITCH = "orbit_pitch", ORBIT_DIST = "orbit_dist",
        /** Світло: колір (0..1 на канал) і дальність, блоки. */
        LIGHT_R = "light_r", LIGHT_G = "light_g", LIGHT_B = "light_b", RANGE = "range";
    public static final String[] TRANSFORM = { X, Y, Z, YAW, PITCH, ROLL };
    public static final String[] BONE = { "rx", "ry", "rz", "px", "py", "pz", "sx", "sy", "sz" };

    private final Map<String, KeyChannel> map = new LinkedHashMap<>();

    public Map<String, KeyChannel> map() { return map; }

    public KeyChannel get(String name) { return map.get(name); }

    public KeyChannel getOrCreate(String name) {
        return map.computeIfAbsent(name, n -> {
            KeyChannel c = new KeyChannel(defaultOf(n));
            c.stepped = VISIBLE.equals(n) || SNEAK.equals(n);
            return c;
        });
    }

    public boolean has(String name) {
        KeyChannel c = map.get(name);
        return c != null && !c.isEmpty();
    }

    /** Значення каналу в час t; нема ключів — fallback. */
    public double sample(String name, double t, double fallback) {
        KeyChannel c = map.get(name);
        return c == null || c.isEmpty() ? fallback : c.sample(t);
    }

    public boolean isEmpty() {
        for (KeyChannel c : map.values()) if (!c.isEmpty()) return false;
        return true;
    }

    public void shift(double dt) { for (KeyChannel c : map.values()) c.shift(dt); }

    public Channels copy() {
        Channels c = new Channels();
        for (Map.Entry<String, KeyChannel> e : map.entrySet()) c.map.put(e.getKey(), e.getValue().copy());
        return c;
    }

    public static double defaultOf(String name) {
        return switch (name) {
            case SCALE, VISIBLE, OPACITY, INTENSITY, GAIN, SPEED, "sx", "sy", "sz" -> 1;
            case FOV -> 70;
            case ORBIT_DIST -> 4;
            case ORBIT_PITCH -> 15;
            default -> 0;
        };
    }
}
