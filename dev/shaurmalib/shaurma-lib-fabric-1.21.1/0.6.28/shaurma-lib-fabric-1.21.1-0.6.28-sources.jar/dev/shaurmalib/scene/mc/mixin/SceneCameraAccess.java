package dev.shaurmalib.scene.mc.mixin;

import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4184.class)
public interface SceneCameraAccess {
    @Invoker("setPosition") void shaurma$setScenePosition(class_243 position);
    @Invoker("setRotation") void shaurma$setSceneRotation(float yaw, float pitch);
    @Accessor("detached") void shaurma$setSceneDetached(boolean detached);
}
