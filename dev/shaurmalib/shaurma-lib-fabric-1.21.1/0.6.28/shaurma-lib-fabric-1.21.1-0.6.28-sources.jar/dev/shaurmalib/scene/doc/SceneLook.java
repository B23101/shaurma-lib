package dev.shaurmalib.scene.doc;

/**
 * «Вигляд» сцени для рендеру у віконці меню (як World + Color Management + Compositor у Blender):
 * середовище (небо, світло неба й ламп світу, заповнення, туман), корекція кольору (експозиція, тонмапінг,
 * контраст, насиченість, температура, lift/gamma/gain, спліт-тонування, bloom, віньєтка, зерно, різкість)
 * і якість. Числа, які варто анімувати, мають канали {@link #channels} (ключі як у будь-якого об'єкта).
 *
 * <p>Кольори — RGB {@code 0xRRGGBB} у sRGB, як їх бачить художник; рендер переводить у лінійний простір.
 */
public final class SceneLook {

    /** Тло за світом. */
    public enum Sky {
        /** Колір неба світу в цю мить (день/ніч). */
        WORLD,
        /** Градієнт зеніт → горизонт → земля. */
        GRADIENT,
        /** Суцільний колір {@link #skyTop}. */
        COLOR,
        /** Прозоре тло — під сценою видно меню. */
        NONE
    }

    /** Тонмапінг HDR → екран. */
    public enum Tonemap {
        /** Обрізання (як ваніль). */
        NONE,
        /** ACES (кіно, насичено). */
        ACES,
        /** Filmic (м'яко, як Blender Filmic). */
        FILMIC,
        /** AgX (нейтрально, світлі кольори не «вигоряють» у жовте). */
        AGX
    }

    public enum Quality { AUTO, LOW, MEDIUM, HIGH, ULTRA }

    // ── канали (ключі) ──
    public static final String EXPOSURE = "exposure", CONTRAST = "contrast", SATURATION = "saturation", TEMPERATURE = "temperature",
        TINT = "tint", BLOOM = "bloom", VIGNETTE = "vignette", SKY_LIGHT = "sky_light", BLOCK_LIGHT = "block_light",
        AMBIENT = "ambient", FOG_END = "fog_end", SKY_INTENSITY = "sky_intensity";
    public static final String[] KEYABLE = { EXPOSURE, CONTRAST, SATURATION, TEMPERATURE, TINT, BLOOM, VIGNETTE, SKY_LIGHT, BLOCK_LIGHT, AMBIENT, FOG_END, SKY_INTENSITY };

    // ── середовище ──
    public Sky sky = Sky.GRADIENT;
    public int skyTop = 0x1F3355, skyHorizon = 0xB8916A, ground = 0x1C1814;
    public float skyIntensity = 1f;
    /** Світло неба (там, куди падає небо, — рівень sky light блоку), колір і сила. */
    public int skyLightColor = 0xB9CCF2;
    public float skyLight = 0.85f;
    /** Світло ламп світу (факели, світлокамінь — рівень block light), без ванільного мерехтіння. */
    public int blockLightColor = 0xFFB061;
    public float blockLight = 1.3f;
    /** Заповнення: мінімальне світло всюди. */
    public int ambientColor = 0x2A2F3E;
    public float ambient = 0.16f;
    /** Туман від камери, блоки; fogEnd ≤ 0 — за радіусом сцени. Колір -1 — колір горизонту. */
    public float fogStart = 0, fogEnd = 0;
    public int fogColor = -1;
    /** Прибрати ванільне затінення граней (світло сцени саме дає об'єм за нормалями). */
    public boolean unshade = true;
    /** Відблиски від світел, 0..1. */
    public float specular = 0.25f;
    /** Живі сутності світу на сцені (NPC лобі, стійки для броні). Актори сцени є завжди. */
    public boolean worldEntities;

    // ── корекція ──
    public Tonemap tonemap = Tonemap.AGX;
    /** Експозиція, стопи (EV). */
    public float exposure;
    public float contrast = 1f, saturation = 1f;
    /** Температура (−1 холодно … +1 тепло) і відтінок (−1 зелений … +1 пурпурний). */
    public float temperature, tint;
    public float lift, gamma = 1f, gain = 1f;
    /** Спліт-тонування: тіні й світлі ділянки у свій колір. */
    public int splitShadows = 0x2C5AA0, splitHighlights = 0xFFB46A;
    public float splitAmount;
    public float bloom = 0.22f, bloomThreshold = 1.0f, bloomRadius = 1f;
    public float vignette = 0.28f, vignetteSoftness = 0.55f;
    public float grain, sharpen = 0.12f;

    // ── авто-світло блоків (як Auto block-lights у IRL-editor) ──
    /** Блоки, що світяться (факели, ліхтарі, лава, світлокамінь…), самі стають кольоровими лампами сцени. */
    public boolean autoLights;
    /** Лише «відкриті» блоки (хоч одна грань у повітря) — закопані в землю не світять. */
    public boolean autoLightCulling = true;
    /** Множники сили й дальності для всіх авто-світел; скільки найближчих брати. */
    public float autoLightIntensity = 1f, autoLightReach = 1f;
    public int autoLightMax = 24;

    // ── об'ємне світло (глобальне) ──
    /** Загальна сила променів, кроків трасування, найбільша дальність (блоки). */
    public float vlIntensity = 1f;
    public int vlSteps = 32;
    public float vlMaxDist = 64f;
    /** Тіні в променях (світло перекривається блоками). */
    public boolean vlShadows = true;
    /** Свічення біля самого джерела: підсилення й радіус (блоки). */
    public float vlTipBoost = 1.5f, vlTipRadius = 1.5f;
    /** «Дим»: шум щільності — сила 0..1, розмір клубів (блоки), швидкість дрейфу. */
    public float vlNoiseAmount = 0.6f, vlNoiseScale = 2f, vlNoiseSpeed = 0.25f;
    public boolean vlNoise = true;

    // ── контур від світла (outline / rim) ──
    public boolean outline;
    /** 0 — усе, 1 — сутності, 2 — блоки. */
    public int outlineTarget = 1;
    public float outlineStrength = 0.65f, outlinePower = 2.2f, outlineBack = 1f, outlineFront, outlineGlow;
    /** Тун-смуги світла (0 — вимкнено), м'якість переходу. */
    public int toonBands;
    public float toonSmooth = 0.15f;
    /** Розмір джерела для м'якості тіней за замовчуванням (як shadowSoftness у IRL). */
    public float shadowSoftness = 1f;

    // ── якість ──
    public Quality quality = Quality.AUTO;
    /** Кадрів на секунду: картка в спокої і під курсором (решту часу показується останній кадр). */
    public int fpsIdle = 30, fpsHover = 60;

    public final Channels channels = new Channels();

    /** Значення з ключами в момент t (каналу нема — база). */
    public double get(String ch, double t, double base) { return channels.sample(ch, t, base); }

    /** Базове значення каналу (без ключів). */
    public double base(String ch) {
        return switch (ch) {
            case EXPOSURE -> exposure;
            case CONTRAST -> contrast;
            case SATURATION -> saturation;
            case TEMPERATURE -> temperature;
            case TINT -> tint;
            case BLOOM -> bloom;
            case VIGNETTE -> vignette;
            case SKY_LIGHT -> skyLight;
            case BLOCK_LIGHT -> blockLight;
            case AMBIENT -> ambient;
            case FOG_END -> fogEnd;
            case SKY_INTENSITY -> skyIntensity;
            default -> 0;
        };
    }

    public void setBase(String ch, double v) {
        float f = (float) v;
        switch (ch) {
            case EXPOSURE -> exposure = f;
            case CONTRAST -> contrast = f;
            case SATURATION -> saturation = f;
            case TEMPERATURE -> temperature = f;
            case TINT -> tint = f;
            case BLOOM -> bloom = f;
            case VIGNETTE -> vignette = f;
            case SKY_LIGHT -> skyLight = f;
            case BLOCK_LIGHT -> blockLight = f;
            case AMBIENT -> ambient = f;
            case FOG_END -> fogEnd = f;
            case SKY_INTENSITY -> skyIntensity = f;
            default -> { }
        }
    }

    /** Значення в t з урахуванням ключів. */
    public double at(String ch, double t) { return get(ch, t, base(ch)); }

    public SceneLook copy() {
        SceneLook l = new SceneLook();
        l.copyFrom(this);
        return l;
    }

    public void copyFrom(SceneLook o) {
        sky = o.sky; skyTop = o.skyTop; skyHorizon = o.skyHorizon; ground = o.ground; skyIntensity = o.skyIntensity;
        skyLightColor = o.skyLightColor; skyLight = o.skyLight; blockLightColor = o.blockLightColor; blockLight = o.blockLight;
        ambientColor = o.ambientColor; ambient = o.ambient; fogStart = o.fogStart; fogEnd = o.fogEnd; fogColor = o.fogColor;
        unshade = o.unshade; specular = o.specular; worldEntities = o.worldEntities;
        tonemap = o.tonemap; exposure = o.exposure; contrast = o.contrast; saturation = o.saturation; temperature = o.temperature;
        tint = o.tint; lift = o.lift; gamma = o.gamma; gain = o.gain; splitShadows = o.splitShadows; splitHighlights = o.splitHighlights;
        splitAmount = o.splitAmount; bloom = o.bloom; bloomThreshold = o.bloomThreshold; bloomRadius = o.bloomRadius;
        vignette = o.vignette; vignetteSoftness = o.vignetteSoftness; grain = o.grain; sharpen = o.sharpen;
        quality = o.quality; fpsIdle = o.fpsIdle; fpsHover = o.fpsHover;
        autoLights = o.autoLights; autoLightCulling = o.autoLightCulling; autoLightIntensity = o.autoLightIntensity;
        autoLightReach = o.autoLightReach; autoLightMax = o.autoLightMax;
        vlIntensity = o.vlIntensity; vlSteps = o.vlSteps; vlMaxDist = o.vlMaxDist; vlShadows = o.vlShadows;
        vlTipBoost = o.vlTipBoost; vlTipRadius = o.vlTipRadius; vlNoise = o.vlNoise; vlNoiseAmount = o.vlNoiseAmount;
        vlNoiseScale = o.vlNoiseScale; vlNoiseSpeed = o.vlNoiseSpeed;
        outline = o.outline; outlineTarget = o.outlineTarget; outlineStrength = o.outlineStrength; outlinePower = o.outlinePower;
        outlineBack = o.outlineBack; outlineFront = o.outlineFront; outlineGlow = o.outlineGlow;
        toonBands = o.toonBands; toonSmooth = o.toonSmooth; shadowSoftness = o.shadowSoftness;
        channels.map().clear();
        for (var e : o.channels.map().entrySet()) channels.map().put(e.getKey(), e.getValue().copy());
    }

    // ═════════════════════════ пресети ═════════════════════════

    /** Стиль променів (як Clean/Dusty/Smoky у IRL-editor). */
    public static final String[] BEAM_STYLES = { "Чисті", "Пил", "Дим" };

    public void beamStyle(int i) {
        switch (i) {
            case 0 -> { vlNoise = false; vlNoiseAmount = 0.3f; vlTipBoost = 1f; }
            case 1 -> { vlNoise = true; vlNoiseAmount = 0.45f; vlNoiseScale = 1.2f; vlNoiseSpeed = 0.25f; vlTipBoost = 1.5f; }
            default -> { vlNoise = true; vlNoiseAmount = 0.85f; vlNoiseScale = 3.5f; vlNoiseSpeed = 0.5f; vlTipBoost = 2f; }
        }
    }

    public static final String[] PRESETS = { "Нейтральний", "Кіно · теплий", "Золота година", "Нічний неон", "Хорор", "Нуар", "Яскравий день" };

    /** Пресет вигляду (ключі не чіпає). */
    public void preset(String name) {
        SceneLook d = new SceneLook();
        Channels keep = channels.copy();
        copyFrom(d);
        channels.map().putAll(keep.map());
        switch (name) {
            case "Кіно · теплий" -> {
                tonemap = Tonemap.AGX; contrast = 1.12f; saturation = 1.1f; temperature = 0.18f;
                splitAmount = 0.22f; bloom = 0.3f; vignette = 0.35f;
            }
            case "Золота година" -> {
                skyTop = 0x3A5C8C; skyHorizon = 0xFFA45C; skyLightColor = 0xFFC48A; skyLight = 0.6f;
                temperature = 0.3f; bloom = 0.45f; bloomThreshold = 0.8f; contrast = 1.08f; saturation = 1.15f; vignette = 0.3f;
            }
            case "Нічний неон" -> {
                skyTop = 0x07091A; skyHorizon = 0x2A1645; ground = 0x050508; skyLightColor = 0x4B5CA8; skyLight = 0.18f;
                ambientColor = 0x1A1033; ambient = 0.08f; blockLight = 0.9f; tonemap = Tonemap.ACES; exposure = 0.3f;
                bloom = 0.65f; bloomThreshold = 0.7f; saturation = 1.25f; splitShadows = 0x2A3CFF; splitHighlights = 0xFF3CC8;
                splitAmount = 0.3f; vignette = 0.45f;
            }
            case "Хорор" -> {
                skyTop = 0x0B0D10; skyHorizon = 0x2B2A28; ground = 0x070606; skyLightColor = 0x7D8AA0; skyLight = 0.12f;
                ambientColor = 0x14161C; ambient = 0.05f; blockLight = 1.1f; blockLightColor = 0xFF8A3C;
                tonemap = Tonemap.AGX; contrast = 1.25f; saturation = 0.72f; temperature = -0.12f; splitShadows = 0x1E4A5A;
                splitHighlights = 0xC8503C; splitAmount = 0.25f; vignette = 0.6f; vignetteSoftness = 0.45f; grain = 0.12f; fogEnd = 28;
            }
            case "Нуар" -> {
                saturation = 0f; contrast = 1.4f; tonemap = Tonemap.FILMIC; vignette = 0.55f; grain = 0.18f; bloom = 0.15f;
            }
            case "Яскравий день" -> {
                sky = Sky.WORLD; skyLight = 0.85f; ambient = 0.2f; tonemap = Tonemap.AGX; saturation = 1.12f; contrast = 1.05f;
                vignette = 0.15f; bloom = 0.15f;
            }
            default -> { }
        }
    }
}
