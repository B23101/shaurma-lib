package dev.shaurmalib.scene.doc;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Кліп на треку — як у монтажній програмі: start/length на таймлайні, in — зсув у джерелі, speed,
 * режим кінця, blend in/out. Що саме кліп «грає», визначає тип треку ({@link Track.Type}) і {@link #ref}:
 * <ul>
 *   <li>CAMERA — id об'єкта-камери; {@link #transition} — перехід з попереднього кліпу;</li>
 *   <li>ANIMATION — id кліпу анімації ({@code ns:clip}, {@code asset:<id>/<name>});</li>
 *   <li>AUDIO — asset id звуку (wav/ogg/mp3) або звук гри {@code minecraft:...};</li>
 *   <li>OVERLAY — id оверлея мода; EFFECT — id ефекту/шейдера; TIME — сповільнення (канал speed).</li>
 * </ul>
 * Параметри без ключів — {@link #params}, з ключами — {@link #channels} (час каналів — ЛОКАЛЬНИЙ, від старту кліпу).
 */
public final class Clip {

    /** Що робити кліпу анімації після кінця джерела. */
    public enum End {
        /** Зупинитись (шар зникає). */
        STOP,
        /** Зациклити в межах довжини кліпу на таймлайні. */
        LOOP,
        /** Заморозити на останньому кадрі до кінця кліпу. */
        HOLD
    }

    public String id;
    public String name;
    public double start;
    public double length = 1;
    /** Зсув у джерелі (trim початку), секунди джерела. */
    public double in;
    public double speed = 1;
    public End end = End.HOLD;
    public double blendIn, blendOut;
    public String ref;
    public boolean muted;
    public Transition transition;
    /** ANIMATION: маска кісток ({@code upper_body}, {@code full-legs}…), вага, адитивність. */
    public String mask;
    public double weight = 1;
    public boolean additive;
    public final Map<String, Object> params = new LinkedHashMap<>();
    public final Channels channels = new Channels();
    /** Довжина джерела (секунди), якщо відома — таймлайн малює межу/повтори. 0 — невідомо. */
    public double sourceLength;
    public transient boolean selected;

    public Clip() {}

    public Clip(String id, double start, double length, String ref) {
        this.id = id;
        this.start = start;
        this.length = length;
        this.ref = ref;
    }

    public double end() { return start + length; }

    public boolean covers(double t) { return t >= start && t < start + length; }

    /** Час у джерелі для часу сцени t (з урахуванням in, speed, режиму кінця). Від'ємне — ще не почався. */
    public double sourceTime(double t) {
        double local = (t - start) * speed + in;
        if (sourceLength > 0) {
            switch (end) {
                case LOOP -> {
                    double span = Math.max(1e-6, sourceLength - Math.min(in, sourceLength * 0.999));
                    if (local > sourceLength) local = in + ((local - in) % span);
                }
                case HOLD -> local = Math.min(local, sourceLength);
                case STOP -> { }
            }
        }
        return local;
    }

    /** Вага fade in/out у час t (0..1). */
    public double fadeWeight(double t) {
        double w = 1;
        double a = t - start, b = start + length - t;
        if (blendIn > 0 && a < blendIn) w = Math.min(w, Math.max(0, a / blendIn));
        if (blendOut > 0 && b < blendOut) w = Math.min(w, Math.max(0, b / blendOut));
        return w;
    }

    public double param(String key, double def) {
        Object o = params.get(key);
        if (o instanceof Number n) return n.doubleValue();
        if (o instanceof String s) { try { return Double.parseDouble(s); } catch (NumberFormatException ignored) { } }
        if (o instanceof Boolean b) return b ? 1 : 0;
        return def;
    }

    public String param(String key, String def) {
        Object o = params.get(key);
        return o == null ? def : o.toString();
    }

    public boolean flag(String key, boolean def) {
        Object o = params.get(key);
        if (o instanceof Boolean b) return b;
        if (o instanceof Number n) return n.doubleValue() != 0;
        if (o instanceof String s) return Boolean.parseBoolean(s);
        return def;
    }

    /** Канал кліпу в момент t (локальний час), або param, або def. */
    public double value(String channel, double t, double def) {
        return channels.sample(channel, t - start, param(channel, def));
    }

    public Clip copy(String newId) {
        Clip c = new Clip(newId, start, length, ref);
        c.name = name; c.in = in; c.speed = speed; c.end = end; c.blendIn = blendIn; c.blendOut = blendOut;
        c.muted = muted; c.transition = transition == null ? null : transition.copy();
        c.mask = mask; c.weight = weight; c.additive = additive; c.sourceLength = sourceLength;
        c.params.putAll(params);
        for (Map.Entry<String, KeyChannel> e : channels.map().entrySet()) c.channels.map().put(e.getKey(), e.getValue().copy());
        return c;
    }
}
