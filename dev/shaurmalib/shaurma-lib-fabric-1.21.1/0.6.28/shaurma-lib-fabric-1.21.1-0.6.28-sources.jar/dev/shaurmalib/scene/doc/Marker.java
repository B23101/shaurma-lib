package dev.shaurmalib.scene.doc;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Мітка таймлайну: іменована подія на кадрі ({@code laugh_start}, {@code overlay_show}, {@code camera_cut}).
 * Коли програвання її перетинає, сервер і клієнт отримують подію з {@link #payload} — головний мод
 * вирішує, що з нею робити (звук, частинки, ігрова логіка). Скриптів у документі немає: лише назви.
 */
public final class Marker {
    public String id;
    public String name;
    public double time;
    public int color = 0xF2B84B;
    /** Подія для мода (false — просто закладка для монтажу). */
    public boolean event = true;
    /** Слот, до якого стосується подія (необов'язково). */
    public String slot;
    public final Map<String, Object> payload = new LinkedHashMap<>();

    public Marker() {}

    public Marker(String id, String name, double time) {
        this.id = id;
        this.name = name;
        this.time = time;
    }
}
