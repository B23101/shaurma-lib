package dev.shaurmalib.scene.eval;

import dev.shaurmalib.anim.math.Mat4;
import dev.shaurmalib.anim.mesh.GeoMesh;
import dev.shaurmalib.anim.rig.Rig;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Ієрархія кісток актора у «просторі сітки» (блоки, X дзеркальний до Blockbench, Y вгору, перед −Z —
 * конвенція GeckoLib/{@link GeoMesh}). Потрібна, щоб без гри знайти світову точку кістки: прикріпити
 * проп до руки, навести камеру на голову. Математика — та сама, що в {@link dev.shaurmalib.anim.mesh.PropBaker}.
 *
 * <p>Світ актора: {@code T(pos) · Ry(180−yaw) · Rx(pitch) · Rz(roll) · S(scale)} — рендер у mc-шарі
 * робить рівно ці операції, тож точки збігаються з картинкою.
 */
public final class SceneRig {

    public final Rig rig;
    final List<String> names = new ArrayList<>();
    final List<Integer> parents = new ArrayList<>();
    /** Півот (блоки, простір сітки) і базове обертання (радіани, вже в конвенції сітки). */
    final List<float[]> pivots = new ArrayList<>();
    final List<float[]> rest = new ArrayList<>();
    private final Map<String, Integer> index = new HashMap<>();

    private SceneRig(Rig rig) { this.rig = rig; }

    public int size() { return names.size(); }

    public String bone(int i) { return names.get(i); }

    public int parent(int i) { return parents.get(i); }

    public int indexOf(String bone) {
        if (bone == null) return -1;
        Integer i = index.get(bone.toLowerCase(java.util.Locale.ROOT));
        return i == null ? -1 : i;
    }

    public List<String> bones() { return names; }

    private void add(String name, int parent, float[] pivot, float[] restRot) {
        index.put(name.toLowerCase(java.util.Locale.ROOT), names.size());
        names.add(name);
        parents.add(parent);
        pivots.add(pivot);
        rest.add(restRot);
    }

    /** Риг ванільного гравця (кістки Rig.PLAYER, півоти в пікселях). */
    public static SceneRig player() {
        Rig r = Rig.PLAYER;
        SceneRig s = new SceneRig(r);
        for (int i = 0; i < r.size(); i++) {
            float[] p = r.pivot(i);
            s.add(r.bone(i), r.parent(i), new float[] { p[0] / 16f, p[1] / 16f, p[2] / 16f }, new float[3]);
        }
        return s;
    }

    public static SceneRig of(String name, GeoMesh mesh) {
        List<String> names = new ArrayList<>(), parents = new ArrayList<>();
        List<float[]> piv = new ArrayList<>();
        for (GeoMesh.MeshBone b : mesh.bones) {
            names.add(b.name);
            parents.add(b.parentName);
            piv.add(new float[] { -b.pivotX * 16f, b.pivotY * 16f, b.pivotZ * 16f });
        }
        SceneRig s = new SceneRig(Rig.fromHierarchy(name, names, parents, piv));
        Map<String, Integer> idx = new HashMap<>();
        for (int i = 0; i < mesh.bones.size(); i++) idx.put(mesh.bones.get(i).name, i);
        for (GeoMesh.MeshBone b : mesh.bones) {
            Integer p = b.parentName == null ? null : idx.get(b.parentName);
            s.add(b.name, p == null ? -1 : p, new float[] { b.pivotX, b.pivotY, b.pivotZ }, new float[] { b.rotX, b.rotY, b.rotZ });
        }
        return s;
    }

    /**
     * Матриця кістки в просторі сітки з урахуванням пози ({@code bone → rx..sz}, градуси/пікселі).
     * @return null, якщо кістки нема
     */
    public Mat4 boneMatrix(String bone, Map<String, float[]> pose) {
        int i = indexOf(bone);
        if (i < 0) return null;
        List<Integer> chain = new ArrayList<>();
        for (int c = i, guard = 0; c >= 0 && guard < 256; c = parents.get(c), guard++) chain.add(0, c);
        Mat4 m = new Mat4();
        for (int c : chain) {
            float[] pv = pivots.get(c), rr = rest.get(c);
            float[] p = pose == null ? null : pose.get(names.get(c));
            float rx = rr[0], ry = rr[1], rz = rr[2];
            if (p != null) {
                m.translate(-p[3] / 16f, p[4] / 16f, p[5] / 16f);
                rx += (float) Math.toRadians(-p[0]);
                ry += (float) Math.toRadians(-p[1]);
                rz += (float) Math.toRadians(p[2]);
            }
            m.translate(pv[0], pv[1], pv[2]);
            m.rotateZ(rz).rotateY(ry).rotateX(rx);
            if (p != null) m.scale(p[6], p[7], p[8]);
            m.translate(-pv[0], -pv[1], -pv[2]);
        }
        return m;
    }

    /** Точка півота кістки в просторі сітки (блоки). */
    public boolean bonePivot(String bone, Map<String, float[]> pose, float[] out) {
        Mat4 m = boneMatrix(bone, pose);
        if (m == null) return false;
        float[] pv = pivots.get(indexOf(bone));
        m.transformPoint(pv[0], pv[1], pv[2], out);
        return true;
    }

    /** Простір сітки → світ для актора з даним трансформом. */
    public static void toWorld(SceneFrame.Actor a, float[] local, double[] out) {
        Mat4 m = actorMatrix(a.yaw, a.pitch, a.roll, a.scale);
        float[] tmp = new float[3];
        m.transformPoint(local[0], local[1], local[2], tmp);
        out[0] = a.x + tmp[0];
        out[1] = a.y + tmp[1];
        out[2] = a.z + tmp[2];
    }

    public static Mat4 actorMatrix(float yaw, float pitch, float roll, float scale) {
        return new Mat4().rotateY((float) Math.toRadians(180 - yaw)).rotateX((float) Math.toRadians(pitch))
            .rotateZ((float) Math.toRadians(roll)).scale(scale, scale, scale);
    }
}
