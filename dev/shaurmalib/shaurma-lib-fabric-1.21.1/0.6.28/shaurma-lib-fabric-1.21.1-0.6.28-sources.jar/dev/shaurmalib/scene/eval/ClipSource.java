package dev.shaurmalib.scene.eval;

import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.scene.doc.SceneObject;

/**
 * Звідки рушій сцени бере кліпи анімацій і риги акторів. На клієнті — бібліотека ShaurmaAnim
 * (ресурси модів, {@code ns:clip}) + анімації з .bbmodel-ассетів світу ({@code asset:<id>/<назва>});
 * на сервері досить ригів/кліпів для look-at і довжин (або {@link #NONE}).
 */
public interface ClipSource {

    AnimationClip clip(String id);

    /** Риг актора (null — невідомий: маски не діють, кістки для прив'язок не шукаються). */
    SceneRig rig(SceneObject actor);

    ClipSource NONE = new ClipSource() {
        @Override public AnimationClip clip(String id) { return null; }
        @Override public SceneRig rig(SceneObject actor) {
            return actor.modelType == SceneObject.ModelType.PLAYER ? PLAYER_RIG : null;
        }
    };

    SceneRig PLAYER_RIG = SceneRig.player();
}
