package dev.shaurmalib.scene.doc;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Об'єкт сцени: камера, актор (персонаж з ригом), проп (модель без «персонажності») або порожня точка.
 * КОЖЕН актор — окрема сутність зі своїм ригом, кістками, стеком анімацій і мітками (не один спільний
 * провідник), тож дві моделі однієї сцени анімуються незалежно.
 *
 * <p>Трансформ — канали {@link #channels} у СВІТОВИХ координатах (або відносно {@link #parent}); база
 * без ключів — {@link #x}…{@link #roll}. Поза кісток — {@link #bones}: поверх кліпів анімацій
 * (як «pose» у BBS: можна поставити позу й лишити під нею idle).
 */
public final class SceneObject {

    public enum Kind { CAMERA, ACTOR, PROP, EMPTY,
        /** Джерело світла сцени меню ({@link LightType}): колір, сила, дальність, тіні — рендер сцени в меню. */
        LIGHT }

    /** Тип світла (як у Blender): точкове, прожектор, сонце (паралельні промені). */
    public enum LightType { POINT, SPOT, SUN }

    /** Звідки модель актора/пропа. */
    public enum ModelType {
        /** Ванільна модель гравця (wide/slim за скіном), риг {@code player}. */
        PLAYER,
        /** .bbmodel / .geo.json з папки світу (asset id). */
        ASSET,
        /** Модель з ресурсів мода, id як у кліпів ShaurmaAnim ({@code ns:шлях}). */
        RESOURCE,
        NONE
    }

    /** Звідки скін (текстура). Політику для слотів визначає режим, редактор лише записує вибір. */
    public enum SkinMode {
        /** Текстура моделі як є (або стандартний скін для PLAYER). */
        DEFAULT,
        /** Скін гравця, прив'язаного до слота об'єкта (winner, maniac…). */
        SLOT,
        /** Скін конкретного профілю (нік/UUID) у {@link #skinValue}. */
        PROFILE,
        /** Текстура-ассет світу ({@link #skinValue} = asset id). */
        TEXTURE,
        /** Віддзеркалення гравця, який ДИВИТЬСЯ сцену. */
        VIEWER
    }

    public String id;
    public String name;
    public Kind kind;

    // ── ієрархія ──
    /** Батьківський об'єкт (null — світ). */
    public String parent;
    /** Кістка батька, до якої прикріплено (гачок до руки). */
    public String parentBone;

    // ── база трансформу (без ключів) ──
    public double x, y, z;
    public float yaw, pitch, roll;
    public float scale = 1f;

    public final Channels channels = new Channels();
    /** Поза кісток: кістка → канали rx..sz (градуси/пікселі, як у Blockbench). */
    public final Map<String, Channels> bones = new LinkedHashMap<>();

    // ── модель / скін ──
    public ModelType modelType = ModelType.NONE;
    public String model;
    /** Текстура ассет-моделі (asset id) або ресурсна ({@code ns:textures/...png}). */
    public String texture;
    public SkinMode skinMode = SkinMode.DEFAULT;
    public String skinValue;
    /** Явно slim-руки (null — авто за скіном). */
    public Boolean slim;
    /** Базова «жива» анімація під усім (idle), id кліпу. */
    public String idle;
    public float idleSpeed = 1f;
    /**
     * Ходьба з руху (як у BBS: кроки виводяться зі швидкості запису, а не з ключів кінцівок): актор, що
     * переміщується ключами/записом, сам махає ногами й руками, сила — від швидкості.
     */
    public boolean autoWalk = true;

    // ── мітки ──
    /** Слот режиму (winner, maniac, victims…). Для списків — {@link #slotIndex}. */
    public String slot;
    public int slotIndex;
    /** Що робити, якщо слот не прив'язаний: сховати (типово) чи лишити як у редакторі. */
    public boolean hideIfUnbound = true;
    /** Семантичні мітки об'єкта (victory_player, hook_target…), читає режим. */
    public final Set<String> labels = new LinkedHashSet<>();
    /** Мітки кісток: кістка → мітка (body → player_skin: під-кістки малюються скіном гравця). */
    public final Map<String, String> boneLabels = new LinkedHashMap<>();
    /** Сховані кістки (з дітьми). */
    public final Set<String> hiddenBones = new LinkedHashSet<>();

    // ── камера ──
    public float fov = 70f;
    public float near = 0.05f;
    /** Ціль погляду: {@code obj:<id>}, {@code obj:<id>:<bone>}, {@code slot:<name>[#i]} або null. */
    public String lookAt;
    public double lookOffsetY;
    /** Що робити, якщо ціль зникла: HOLD — тримати останній напрям, OFF — вимкнути look-at. */
    public boolean lookHoldOnLoss = true;
    /** Шлях камери (spline): канал {@link Channels#PATH} 0..1 — де на шляху камера. */
    public final List<PathPoint> path = new ArrayList<>();
    /** Орієнтація по дотичній шляху (інакше — з точок / ключів). */
    public boolean pathOrient;
    /** Базове «дихання» камери в градусах (як «рука оператора» мафії). */
    public float breath = 0.10f;
    /** Орбіта (BBS Orbit): камера кружляє навколо цілі за каналами orbit_yaw/pitch/dist і дивиться на неї. */
    public String orbitTarget;
    /** Інерція (BBS Drag): 0 — жорстко, 0.9 — камера м'яко «наздоганяє» рух, як оператор зі стедікамом. */
    public float drag;
    /** Dolly zoom (вертиго): зі зміною FOV камера їде так, що ціль лишається того ж розміру. */
    public boolean dollyZoom;

    // ── світло (Kind.LIGHT) ──
    public LightType lightType = LightType.POINT;
    /** Колір світла RGB; ключі — канали {@link Channels#LIGHT_R}/G/B (0..1). */
    public int lightColor = 0xFFE2B8;
    /** Сила (множник, 1 — «лампа»); ключі — канал {@link Channels#INTENSITY}. */
    public float lightIntensity = 2f;
    /** Дальність, блоки (точкове/прожектор); ключі — канал {@link Channels#RANGE}. */
    public float lightRange = 10f;
    /** Кут конуса прожектора (повний), градуси, і м'якість краю 0..1. */
    public float spotAngle = 50f, spotBlend = 0.35f;
    /** Кидає тіні (сонце й прожектор; на сцену — до двох таких світел). */
    public boolean castShadows;
    /** Розмиття краю тіні (1 — типово, 0 — різка, 4 — дуже м'яка). */
    public float shadowSoftness = 1f;
    /** Відблиск (specular) від світла, 0..2. */
    public float lightSpecular = 1f;
    /** Внутрішній конус прожектора (повний кут, градуси; ≤ spotAngle). ≤0 — з {@link #spotBlend}. */
    public float spotInner = -1f;
    /** На що світить: усе, лише сутності/актори, лише блоки (як entitiesOnly/blocksOnly у IRL). */
    public enum LightTarget { ALL, ENTITIES, BLOCKS }
    public LightTarget lightTarget = LightTarget.ALL;
    /**
     * Об'ємне світло (промені в повітрі, як у IRLights): сила променя 0..5 (0 — вимкнено), щільність середовища
     * 0.005..0.5 і анізотропія розсіювання Хеньї-Грінштейна −0.95..0.95 (&gt;0 — промінь яскравіший проти світла).
     */
    public float beam, vlDensity = 0.05f, anisotropy = 0.4f;
    /**
     * Кукі (гобо) прожектора: маска-картинка, що проєктується світлом (ассет-текстура світу або {@code ns:шлях.png}),
     * поворот (градуси), масштаб і інверсія.
     */
    public String cookie;
    public float cookieRotation, cookieScale = 1f;
    public boolean cookieInvert;

    // ── редактор ──
    public int color = 0x4A9EFF;
    public boolean locked;
    /** Сховано лише в редакторі (око в Outliner). */
    public boolean editorHidden;

    public SceneObject() {}

    public SceneObject(String id, String name, Kind kind) {
        this.id = id;
        this.name = name;
        this.kind = kind;
    }

    public boolean isCamera() { return kind == Kind.CAMERA; }

    public boolean isLight() { return kind == Kind.LIGHT; }

    public boolean hasModel() { return (kind == Kind.ACTOR || kind == Kind.PROP) && modelType != ModelType.NONE; }

    public Channels bone(String bone) { return bones.computeIfAbsent(bone, b -> new Channels()); }

    /** Точка шляху камери. */
    public static final class PathPoint {
        public double x, y, z;
        public float yaw, pitch, roll, fov = 70f;

        public PathPoint() {}

        public PathPoint(double x, double y, double z, float yaw, float pitch, float roll, float fov) {
            this.x = x; this.y = y; this.z = z; this.yaw = yaw; this.pitch = pitch; this.roll = roll; this.fov = fov;
        }

        public PathPoint copy() { return new PathPoint(x, y, z, yaw, pitch, roll, fov); }
    }
}
