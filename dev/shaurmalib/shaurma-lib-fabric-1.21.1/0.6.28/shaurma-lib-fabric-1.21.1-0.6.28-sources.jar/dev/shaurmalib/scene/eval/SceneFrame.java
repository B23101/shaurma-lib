package dev.shaurmalib.scene.eval;

import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.doc.Clip;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.doc.Track;
import dev.shaurmalib.scene.doc.Transition;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Результат {@link SceneEvaluator} на один момент часу — усе, що треба намалювати й програти:
 * камера, ефект склейки, актори з позами, звуки, оверлеї, ефекти, швидкість часу. Чиста структура:
 * рендер (клієнт), якір чанків (сервер) і превʼю редактора читають ОДИН і той самий кадр.
 */
public final class SceneFrame {

    public double time;
    /** Множник швидкості часу (Time Remapping), 1 — норма. */
    public double speed = 1;

    public boolean hasCamera;
    public String cameraId;
    public final Cam camera = new Cam();

    /** Ефект склейки поверх кадру (null — нема) і його фаза 0..1 (склейка на 0.5). */
    public Transition.Type fx;
    public double fxU;
    public int fxColor;
    /** Затемнення входу/виходу, 0..1. */
    public double fade;
    public double letterbox;
    /** «Лише світ»: що сховати зі світу, поки грає цей кадр. */
    public boolean hideEntities, hideParticles, hideWeather;

    public final List<Actor> actors = new ArrayList<>();
    public final List<Audio> audio = new ArrayList<>();
    public final List<Overlay> overlays = new ArrayList<>();
    public final List<Effect> effects = new ArrayList<>();
    /** Світла сцени (рендер меню). */
    public final List<Light> lights = new ArrayList<>();
    /** Вигляд варіанта (небо, корекція…); значення з ключами — {@code look.at(канал, time)}. */
    public dev.shaurmalib.scene.doc.SceneLook look;

    public void clear() {
        time = 0; speed = 1; hasCamera = false; cameraId = null; fx = null; fxU = 0; fxColor = 0; fade = 0; letterbox = 0;
        hideEntities = hideParticles = hideWeather = false;
        actors.clear(); audio.clear(); overlays.clear(); effects.clear(); lights.clear();
        look = null;
    }

    public Actor actor(String id) {
        for (Actor a : actors) if (a.object.id.equals(id)) return a;
        return null;
    }

    /** Поза камери. Кути — як у Minecraft (yaw 0 = південь, pitch вниз +). */
    public static final class Cam {
        public double x, y, z;
        public float yaw, pitch, roll, fov = 70f;

        public Cam set(Cam o) {
            x = o.x; y = o.y; z = o.z; yaw = o.yaw; pitch = o.pitch; roll = o.roll; fov = o.fov;
            return this;
        }

        public Cam lerp(Cam a, Cam b, double f) {
            x = a.x + (b.x - a.x) * f;
            y = a.y + (b.y - a.y) * f;
            z = a.z + (b.z - a.z) * f;
            yaw = (float) (a.yaw + wrap(b.yaw - a.yaw) * f);
            pitch = (float) (a.pitch + (b.pitch - a.pitch) * f);
            roll = (float) (a.roll + (b.roll - a.roll) * f);
            fov = (float) (a.fov + (b.fov - a.fov) * f);
            return this;
        }

        static double wrap(double d) {
            d %= 360;
            if (d > 180) d -= 360;
            if (d < -180) d += 360;
            return d;
        }
    }

    /** Актор у кадрі: світовий трансформ, шари анімацій і підсумкова поза кісток. */
    public static final class Actor {
        public SceneObject object;
        public boolean visible;
        /** Сховано правилом (слот без гравця / канал visible): редактор малює пунктиром. */
        public boolean ghost;
        public double x, y, z;
        public float yaw, pitch, roll, scale = 1f;
        /** Кістка → {rx, ry, rz, px, py, pz, sx, sy, sz} (градуси/пікселі, як у Blockbench). */
        public final Map<String, float[]> pose = new HashMap<>();
        public final List<Layer> layers = new ArrayList<>();
        /** Прив'язка слота (гравець зі скіном), null — нема. */
        public SceneBindings.Binding binding;
    }

    /** Світло в кадрі: світова позиція, напрям (для прожектора й сонця), лінійний колір × сила. */
    public static final class Light {
        public SceneObject object;
        public SceneObject.LightType type;
        public double x, y, z;
        /** Одиничний напрям променів (куди світить). */
        public double dx, dy = -1, dz;
        /** Колір 0..1 (sRGB, як у редакторі) і сила. */
        public float r = 1, g = 1, b = 1, intensity = 1;
        public float range = 10, spotAngle = 50, spotBlend = 0.35f, softness = 1, specular = 1;
        public boolean shadows;
        /** Косинуси внутрішнього конуса (повний cosInner береться з spotInner або spotBlend). */
        public float spotInner = -1;
        /** 0 — усе, 1 — сутності, 2 — блоки. */
        public int target;
        public float beam, vlDensity = 0.05f, anisotropy = 0.4f;
        public String cookie;
        public float cookieRotation, cookieScale = 1;
        public boolean cookieInvert;
        /** Авто-світло блоку (не об'єкт документа). */
        public boolean auto;

        public Light copy() {
            Light l = new Light();
            l.object = object; l.type = type; l.x = x; l.y = y; l.z = z; l.dx = dx; l.dy = dy; l.dz = dz;
            l.r = r; l.g = g; l.b = b; l.intensity = intensity; l.range = range; l.spotAngle = spotAngle;
            l.spotBlend = spotBlend; l.softness = softness; l.specular = specular; l.shadows = shadows;
            l.spotInner = spotInner; l.target = target; l.beam = beam; l.vlDensity = vlDensity; l.anisotropy = anisotropy;
            l.cookie = cookie; l.cookieRotation = cookieRotation; l.cookieScale = cookieScale; l.cookieInvert = cookieInvert; l.auto = auto;
            return l;
        }
    }

    /** Активний кліп анімації актора (для діагностики й шкали в редакторі). */
    public record Layer(String clip, double time, double weight, String mask, boolean additive) {}

    public static final class Audio {
        public Track track;
        public Clip clip;
        public String ref;
        /** Позиція в джерелі, секунди. */
        public double sourceTime;
        public double gain = 1, pitch = 1;
        /** Просторове джерело (null — «в голові»). */
        public double[] position;
        public boolean loop;
    }

    public static final class Overlay {
        public Clip clip;
        public String id;
        /** Секунди від початку кліпу і його довжина. */
        public double local, length;
        public double opacity = 1, x, y, scale = 1;
        /** Фаза появи/зникнення 0..1 (1 — повністю на екрані). */
        public double enter = 1, exit = 1;
        public String enterType = "fade", exitType = "fade";
        public Map<String, Object> params;
    }

    public static final class Effect {
        public Clip clip;
        public String id;
        public double intensity;
        public Map<String, Object> params;
    }
}
