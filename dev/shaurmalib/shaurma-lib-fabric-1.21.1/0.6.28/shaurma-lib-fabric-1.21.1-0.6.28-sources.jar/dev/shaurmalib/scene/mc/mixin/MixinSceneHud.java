package dev.shaurmalib.scene.mc.mixin;

import dev.shaurmalib.scene.mc.client.SceneCameraPlayback;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
abstract class MixinSceneHud {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void shaurma$sceneHideHud(class_332 graphics, class_9779 ticks, CallbackInfo ci) {
        if (!SceneCameraPlayback.hideHud()) return;
        SceneCameraPlayback.renderHud(graphics);
        ci.cancel();
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void shaurma$sceneOverlay(class_332 graphics, class_9779 ticks, CallbackInfo ci) {
        SceneCameraPlayback.renderHud(graphics);
    }
}
