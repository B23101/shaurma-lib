package dev.shaurmalib.scene.mc.mixin;

import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.mc.client.SceneCameraPlayback;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_757.class)
abstract class MixinSceneRenderer {
    @Shadow public abstract class_4184 getMainCamera();

    @Inject(method = "renderLevel", at = @At(value = "INVOKE",
        target = "Lnet/minecraft/client/Camera;setup(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/entity/Entity;ZZF)V",
        shift = At.Shift.AFTER))
    private void shaurma$scenePose(class_9779 ticks, CallbackInfo ci) {
        class_4184 camera = getMainCamera();
        class_243 position = camera.method_19326();
        var vanilla = new SceneFrame.Cam();
        vanilla.x = position.field_1352;
        vanilla.y = position.field_1351;
        vanilla.z = position.field_1350;
        vanilla.yaw = camera.method_19330();
        vanilla.pitch = camera.method_19329();
        var pose = SceneCameraPlayback.sample(ticks.method_60637(true), vanilla);
        if (pose == null) return;

        var access = (SceneCameraAccess) camera;
        access.shaurma$setSceneRotation(pose.yaw, pose.pitch);
        access.shaurma$setScenePosition(new class_243(pose.x, pose.y, pose.z));
        access.shaurma$setSceneDetached(true);
    }

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void shaurma$sceneFov(class_4184 camera, float partial, boolean useFovSetting, CallbackInfoReturnable<Double> cir) {
        if (camera == getMainCamera() && SceneCameraPlayback.hasCamera()) {
            cir.setReturnValue(SceneCameraPlayback.fov(cir.getReturnValueD()));
        }
    }

    @Inject(method = "bobHurt", at = @At("HEAD"), cancellable = true, order = 900)
    private void shaurma$sceneRoll(class_4587 pose, float partial, CallbackInfo ci) {
        if (!SceneCameraPlayback.hasCamera()) return;
        pose.method_22907(class_7833.field_40718.rotationDegrees(SceneCameraPlayback.roll()));
        ci.cancel();
    }

    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
    private void shaurma$sceneNoBob(class_4587 pose, float partial, CallbackInfo ci) {
        if (SceneCameraPlayback.hasCamera()) ci.cancel();
    }

    @Inject(method = "renderItemInHand", at = @At("HEAD"), cancellable = true)
    private void shaurma$sceneHideHand(class_4184 camera, float partial, Matrix4f projection, CallbackInfo ci) {
        if (camera == getMainCamera() && SceneCameraPlayback.hasCamera()) ci.cancel();
    }
}
