package dev.shaurmalib.scene.doc;

/**
 * Кадр анімованої сцени в меню: «розширення екрана» камери (співвідношення сторін віконця), наскільки
 * картка збільшується під курсором, безпечні зони під підписи/ціну, де нічого важливого стояти не повинно,
 * і «сцена» — ділянка світу навколо центру, яку рендер вантажить і малює (усе поза нею — небо й туман).
 *
 * <p>Режим оголошує кадр у {@code SceneDefinition.menu(...)}; документ може мати власний (тоді в редакторі
 * видно розбіжність). Розміри — частки кадру 0..1.
 */
public final class MenuFrame {

    /** Готові формати: назва, ширина : висота. */
    public record Preset(String name, int w, int h) {}

    public static final Preset[] PRESETS = {
        new Preset("Кнопка · квадрат", 1, 1),
        new Preset("Картка · 3:4", 3, 4),
        new Preset("Портрет · 9:16", 9, 16),
        new Preset("Широка · 16:9", 16, 9),
        new Preset("Банер · 21:9", 21, 9),
        new Preset("Плитка · 4:3", 4, 3),
    };

    public int aspectW = 16, aspectH = 9;
    /** Масштаб картки під курсором (1 — без збільшення). */
    public float hoverZoom = 1.06f;
    /** Наїзд камери під курсором: FOV множиться на (1 − це). */
    public float hoverDolly = 0.06f;
    /** Безпечні зони (частки кадру): там малює меню — назва, ціна, кнопка. */
    public float safeTop, safeBottom, safeLeft, safeRight;
    /** Центр сцени у світі (null — середина об'єктів сцени) і радіус у блоках. */
    public double[] stageCenter;
    public double stageRadius = 24;
    /** Найменша ширина картки в GUI-пікселях, під яку варто монтувати (підказка редактора; 0 — без). */
    public int minWidth;

    public MenuFrame() {}

    public MenuFrame(int w, int h) { aspect(w, h); }

    public static MenuFrame button() { return new MenuFrame(1, 1); }

    public static MenuFrame card(int w, int h) { return new MenuFrame(w, h); }

    public static MenuFrame wide() { return new MenuFrame(16, 9); }

    public MenuFrame aspect(int w, int h) {
        aspectW = Math.max(1, w);
        aspectH = Math.max(1, h);
        return this;
    }

    public MenuFrame hoverZoom(float z) { hoverZoom = Math.max(1f, Math.min(1.5f, z)); return this; }

    public MenuFrame hoverDolly(float d) { hoverDolly = Math.max(0f, Math.min(0.4f, d)); return this; }

    public MenuFrame safe(float top, float bottom, float left, float right) {
        safeTop = clamp(top); safeBottom = clamp(bottom); safeLeft = clamp(left); safeRight = clamp(right);
        return this;
    }

    public MenuFrame safeBottom(float f) { safeBottom = clamp(f); return this; }

    public MenuFrame safeTop(float f) { safeTop = clamp(f); return this; }

    public MenuFrame stage(double x, double y, double z, double radius) {
        stageCenter = new double[] { x, y, z };
        stageRadius = Math.max(4, Math.min(96, radius));
        return this;
    }

    public MenuFrame stageRadius(double r) { stageRadius = Math.max(4, Math.min(96, r)); return this; }

    public MenuFrame minWidth(int w) { minWidth = Math.max(0, w); return this; }

    public double aspect() { return aspectW / (double) aspectH; }

    /** Назва формату, якщо збігається з пресетом. */
    public String label() {
        for (Preset p : PRESETS) if (p.w * aspectH == p.h * aspectW) return p.name;
        return aspectW + ":" + aspectH;
    }

    public boolean sameAspect(MenuFrame o) { return o != null && (long) aspectW * o.aspectH == (long) aspectH * o.aspectW; }

    public MenuFrame copy() {
        MenuFrame f = new MenuFrame(aspectW, aspectH);
        f.hoverZoom = hoverZoom; f.hoverDolly = hoverDolly;
        f.safeTop = safeTop; f.safeBottom = safeBottom; f.safeLeft = safeLeft; f.safeRight = safeRight;
        f.stageCenter = stageCenter == null ? null : stageCenter.clone();
        f.stageRadius = stageRadius;
        f.minWidth = minWidth;
        return f;
    }

    private static float clamp(float f) { return Math.max(0, Math.min(0.45f, f)); }
}
