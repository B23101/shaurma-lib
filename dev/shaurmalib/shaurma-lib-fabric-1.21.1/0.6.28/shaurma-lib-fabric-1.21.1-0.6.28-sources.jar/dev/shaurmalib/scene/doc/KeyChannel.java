package dev.shaurmalib.scene.doc;

import dev.shaurmalib.anim.math.Easing;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Одна крива значення в часі (як F-Curve у Blender): ключі з інтерполяцією Constant / Linear / Bezier,
 * ручками Auto / Auto Clamped / Vector / Free / Aligned і easing-пресетами. Час — секунди сцени.
 *
 * <p>Ручки зберігаються ВІДНОСНО ключа (dt, dv). Для Auto/Auto Clamped/Vector вони перераховуються
 * {@link #recalcHandles()} після кожної зміни, тож Graph Editor завжди малює те, що реально семплюється.
 */
public final class KeyChannel {

    public enum Interp { CONSTANT, LINEAR, BEZIER }

    public enum HandleMode { AUTO, AUTO_CLAMPED, VECTOR, FREE, ALIGNED }

    public static final class Key {
        public double t, v;
        /** Інтерполяція СЕГМЕНТА від цього ключа до наступного (як у Blender). */
        public Interp interp = Interp.BEZIER;
        /** Easing поверх Linear/Bezier (null = без). */
        public Easing easing;
        public HandleMode handle = HandleMode.AUTO_CLAMPED;
        /** Ліва/права ручка відносно ключа: dt ≤ 0 зліва, ≥ 0 справа. */
        public double lt = -0.1, lv, rt = 0.1, rv;
        /** Вибір у редакторі (не зберігається). */
        public transient boolean selected;

        public Key() {}

        public Key(double t, double v) { this.t = t; this.v = v; }

        public Key copy() {
            Key k = new Key(t, v);
            k.interp = interp; k.easing = easing; k.handle = handle;
            k.lt = lt; k.lv = lv; k.rt = rt; k.rv = rv;
            return k;
        }
    }

    private final List<Key> keys = new ArrayList<>();
    /** Значення, коли ключів нема. */
    public double defaultValue;
    /** Ступінчастий канал (видимість, ввімк/вимк): завжди Constant. */
    public boolean stepped;
    /**
     * Цикл (модифікатор Cycles у Blender): поза першим/останнім ключем крива повторюється з періодом
     * {@code last − first}, а авто-ручки на краях рахуються через шов — рух безшовно продовжується.
     */
    public boolean cyclic;

    public KeyChannel() {}

    public KeyChannel(double defaultValue) { this.defaultValue = defaultValue; }

    public List<Key> keys() { return keys; }

    public boolean isEmpty() { return keys.isEmpty(); }

    public int size() { return keys.size(); }

    public Key get(int i) { return keys.get(i); }

    /** Ставить ключ у час t (замінює значення, якщо ключ уже є в межах півкадру). */
    public Key set(double t, double v) { return set(t, v, 1.0 / 240); }

    public Key set(double t, double v, double eps) {
        for (Key k : keys) {
            if (Math.abs(k.t - t) <= eps) { k.v = v; recalcHandles(); return k; }
        }
        Key k = new Key(t, v);
        if (stepped) k.interp = Interp.CONSTANT;
        else if (!keys.isEmpty()) {
            Key near = nearest(t);
            k.interp = near.interp;
            k.handle = near.handle;
        }
        keys.add(k);
        sort();
        return k;
    }

    public void add(Key k) { keys.add(k); sort(); }

    public boolean remove(Key k) {
        boolean r = keys.remove(k);
        if (r) recalcHandles();
        return r;
    }

    public Key keyAt(double t, double eps) {
        for (Key k : keys) if (Math.abs(k.t - t) <= eps) return k;
        return null;
    }

    public Key nearest(double t) {
        Key best = null;
        double bd = Double.MAX_VALUE;
        for (Key k : keys) {
            double d = Math.abs(k.t - t);
            if (d < bd) { bd = d; best = k; }
        }
        return best;
    }

    public void sort() {
        keys.sort(Comparator.comparingDouble(k -> k.t));
        recalcHandles();
    }

    public double firstTime() { return keys.isEmpty() ? 0 : keys.get(0).t; }

    public double lastTime() { return keys.isEmpty() ? 0 : keys.get(keys.size() - 1).t; }

    /** Зсув усіх ключів (рух кліпу разом з його ключами). */
    public void shift(double dt) {
        for (Key k : keys) k.t += dt;
    }

    /** Масштаб часу навколо pivot (S у Dope Sheet). */
    public void scaleTime(double pivot, double factor) {
        for (Key k : keys) {
            k.t = pivot + (k.t - pivot) * factor;
            k.lt *= factor;
            k.rt *= factor;
        }
        sort();
    }

    public KeyChannel copy() {
        KeyChannel c = new KeyChannel(defaultValue);
        c.stepped = stepped;
        c.cyclic = cyclic;
        for (Key k : keys) c.keys.add(k.copy());
        return c;
    }

    // ── Семплювання ──────────────────────────────────────────────────────

    public double sample(double t) {
        int n = keys.size();
        if (n == 0) return defaultValue;
        Key first = keys.get(0);
        Key last = keys.get(n - 1);
        if (cyclic && n >= 2 && (t < first.t || t > last.t)) {
            double period = last.t - first.t;
            if (period > 1e-6) {
                double u = (t - first.t) % period;
                if (u < 0) u += period;
                t = first.t + u;
            }
        }
        if (n == 1 || t <= first.t) return first.v;
        if (t >= last.t) return last.v;
        int lo = 0, hi = n - 1;
        while (hi - lo > 1) {
            int mid = (lo + hi) >>> 1;
            if (keys.get(mid).t <= t) lo = mid; else hi = mid;
        }
        return segment(keys.get(lo), keys.get(hi), t);
    }

    private double segment(Key a, Key b, double t) {
        double span = b.t - a.t;
        if (span <= 1e-9) return b.v;
        if (stepped || a.interp == Interp.CONSTANT) return a.v;
        double u = (t - a.t) / span;
        if (a.easing != null) u = a.easing.apply(u);
        if (a.interp == Interp.LINEAR) return a.v + (b.v - a.v) * u;
        // Bezier: P0=(a.t,a.v) P1=a+right handle P2=b+left handle P3=(b.t,b.v); x(s)=t → s → y(s)
        double x0 = a.t, x1 = a.t + clampDt(a.rt, span), x2 = b.t + clampDt(b.lt, -span), x3 = b.t;
        double y0 = a.v, y1 = a.v + a.rv * scaleFor(a.rt, span), y2 = b.v + b.lv * scaleFor(b.lt, -span), y3 = b.v;
        double tx = a.easing != null ? a.t + u * span : t;
        double s = solveBezier(x0, x1, x2, x3, tx);
        return bez(y0, y1, y2, y3, s);
    }

    /** Ручка не може вилізти за сусідній ключ — інакше крива петляє в часі (Blender так само обрізає). */
    private static double clampDt(double dt, double span) {
        if (span > 0) return Math.max(0, Math.min(dt, span));
        return Math.min(0, Math.max(dt, span));
    }

    private static double scaleFor(double dt, double span) {
        double c = clampDt(dt, span);
        return Math.abs(dt) < 1e-9 ? 0 : c / dt;
    }

    private static double bez(double p0, double p1, double p2, double p3, double s) {
        double m = 1 - s;
        return m * m * m * p0 + 3 * m * m * s * p1 + 3 * m * s * s * p2 + s * s * s * p3;
    }

    private static double solveBezier(double x0, double x1, double x2, double x3, double x) {
        double lo = 0, hi = 1, s = (x - x0) / Math.max(1e-9, x3 - x0);
        for (int i = 0; i < 8; i++) {   // Ньютон
            double fx = bez(x0, x1, x2, x3, s) - x;
            if (Math.abs(fx) < 1e-7) return s;
            double m = 1 - s;
            double d = 3 * m * m * (x1 - x0) + 6 * m * s * (x2 - x1) + 3 * s * s * (x3 - x2);
            if (Math.abs(d) < 1e-9) break;
            double ns = s - fx / d;
            if (ns < 0 || ns > 1) break;
            s = ns;
        }
        for (int i = 0; i < 40; i++) {  // бісекція як запасний варіант
            s = (lo + hi) * 0.5;
            double fx = bez(x0, x1, x2, x3, s) - x;
            if (Math.abs(fx) < 1e-7) break;
            if (fx > 0) hi = s; else lo = s;
        }
        return s;
    }

    /** Перерахунок автоматичних ручок (Auto, Auto Clamped, Vector) за сусідами — як BKE_nurb_handle_calc. */
    public void recalcHandles() {
        int n = keys.size();
        for (int i = 0; i < n; i++) {
            Key k = keys.get(i);
            Key p = i > 0 ? keys.get(i - 1) : null, nx = i + 1 < n ? keys.get(i + 1) : null;
            if (cyclic && n >= 3) {
                // сусіди через шов: перед першим — передостанній (зсунутий на −період), після останнього — другий
                double period = keys.get(n - 1).t - keys.get(0).t;
                if (period > 1e-6) {
                    if (p == null) { Key q = keys.get(n - 2); p = new Key(q.t - period, q.v); }
                    if (nx == null) { Key q = keys.get(1); nx = new Key(q.t + period, q.v); }
                }
            }
            double dl = p == null ? 0.1 : (k.t - p.t) / 3.0;
            double dr = nx == null ? 0.1 : (nx.t - k.t) / 3.0;
            switch (k.handle) {
                case VECTOR -> {
                    k.lt = -dl; k.lv = p == null ? 0 : (p.v - k.v) / 3.0;
                    k.rt = dr; k.rv = nx == null ? 0 : (nx.v - k.v) / 3.0;
                }
                case AUTO, AUTO_CLAMPED -> {
                    double slope;
                    if (p == null && nx == null) slope = 0;
                    else if (p == null) slope = 0;
                    else if (nx == null) slope = 0;
                    else {
                        slope = (nx.v - p.v) / Math.max(1e-9, nx.t - p.t);
                        if (k.handle == HandleMode.AUTO_CLAMPED
                            && ((k.v >= p.v && k.v >= nx.v) || (k.v <= p.v && k.v <= nx.v))) slope = 0;
                    }
                    k.lt = -dl; k.lv = -slope * dl;
                    k.rt = dr; k.rv = slope * dr;
                }
                case ALIGNED -> {
                    double len = Math.hypot(k.lt, k.lv);
                    double rl = Math.hypot(k.rt, k.rv);
                    if (rl > 1e-9 && len > 1e-9) { k.lt = -k.rt / rl * len; k.lv = -k.rv / rl * len; }
                }
                case FREE -> { }
            }
        }
    }
}
