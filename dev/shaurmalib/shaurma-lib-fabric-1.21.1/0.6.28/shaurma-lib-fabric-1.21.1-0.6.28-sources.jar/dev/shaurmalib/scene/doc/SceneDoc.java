package dev.shaurmalib.scene.doc;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Документ сцени ({@code scene.json} у папці світу). Сцену СТВОРЮЄ і РЕЄСТРУЄ головний мод
 * ({@code SceneRegistry.register}); документ — лише її змонтований вміст: камери, актори, треки,
 * мітки, варіанти й маніфест ассетів. Шляхи ассетів — відносні, ідентичність — sha256.
 */
public final class SceneDoc {

    public static final int SCHEMA = 1;

    public int schema = SCHEMA;
    public String id;
    public int revision;
    public double fps = 20;
    /** Хто й коли зберіг востаннє (для конфліктів ревізій). */
    public String editedBy;
    public long editedAt;
    public final Map<String, Variant> variants = new LinkedHashMap<>();
    public final Map<String, Asset> assets = new LinkedHashMap<>();
    /**
     * Точка редагування: звідки редактор відкривається (x, y, z, yaw, pitch) і в якому вимірі. Сервер одразу
     * переносить туди якір камери — редагувати можна з будь-якого місця світу (лобі, завантаження), чанки сцени
     * вже завантажені. null — від гравця.
     */
    public double[] home;
    public String homeDim;

    public SceneDoc() {}

    public SceneDoc(String id) {
        this.id = id;
        variants.put("default", new Variant("default", "Основний"));
    }

    public Variant variant(String id) {
        Variant v = id == null ? null : variants.get(id);
        if (v == null && !variants.isEmpty()) v = variants.values().iterator().next();
        return v;
    }

    /** Варіант для кількості гравців (перший, чий діапазон підходить; інакше перший). */
    public Variant variantFor(int players) {
        for (Variant v : variants.values()) {
            if ((v.minPlayers <= 0 || players >= v.minPlayers) && (v.maxPlayers <= 0 || players <= v.maxPlayers)) return v;
        }
        return variant(null);
    }

    public boolean isEmpty() {
        for (Variant v : variants.values()) if (!v.objects.isEmpty() || !v.tracks.isEmpty()) return false;
        return true;
    }

    public static String newId() { return UUID.randomUUID().toString().substring(0, 8); }

    /** Один варіант сцени: власний таймлайн з об'єктами (наприклад, для 1–3 і для 4–10 гравців). */
    public static final class Variant {
        public String id;
        public String name;
        public int minPlayers, maxPlayers;
        /** Довжина таймлайну, секунди (у часі контенту, до сповільнень). */
        public double length = 10;
        /** Довжина сама йде за вмістом (кінець останнього кліпу / ключа / мітки) — як послідовність у монтажці. */
        public boolean autoLength;
        /** Зациклити (статична сценка, напр. превʼю кіта): грає без кінця. */
        public boolean loop;
        /** Чорні кіно-смуги, частка висоти екрана (0 — без). */
        public double letterbox = 0.11;
        /** Затемнення на вході/виході, секунди. */
        public double fadeIn = 0.6, fadeOut = 0.8;
        /** Вимір сцени ({@code minecraft:overworld}); null — вимір глядача. */
        public String dimension;
        /** Сховати HUD і руку, заблокувати керування (кінематографічний режим). */
        public boolean cinematic = true;
        /**
         * «Лише світ» — поки сцена грає (і у виді з камери в редакторі), глядач бачить тільки блоки:
         * без сутностей і гравців (актори сцени лишаються), без партіклів, без дощу/снігу. Для фонів меню й лобі.
         */
        public boolean hideEntities, hideParticles, hideWeather;

        public boolean worldOnly() { return hideEntities && hideParticles && hideWeather; }

        public void worldOnly(boolean on) { hideEntities = hideParticles = hideWeather = on; }
        public final List<SceneObject> objects = new ArrayList<>();
        public final List<Track> tracks = new ArrayList<>();
        public final List<Marker> markers = new ArrayList<>();
        /** Робоча зона редактора (loop range), секунди; ≤0 — уся сцена. */
        public double workIn, workOut;
        /**
         * Межі циклу ({@link #loop}): сцена грає від 0 до loopOut один раз (вступ), далі крутиться loopIn..loopOut.
         * loopOut ≤ loopIn — до кінця. {@link #loopBlend} &gt; 0 — останні секунди циклу плавно змішуються з його
         * початком (поза, камера, світло), тож шву не видно навіть без ідеально однакових ключів.
         */
        public double loopIn, loopOut, loopBlend;
        /** Вигляд для рендеру в меню: середовище, корекція, якість. */
        public final SceneLook look = new SceneLook();
        /** Власний кадр меню (null — як оголосив режим). */
        public MenuFrame menu;

        /** Початок циклу, секунди. */
        public double loopStart() { return Math.max(0, Math.min(loopIn, loopEnd() - 0.05)); }

        /** Кінець циклу, секунди. */
        public double loopEnd() { return loopOut > loopIn + 0.05 ? Math.min(loopOut, length) : length; }

        public Variant() {}

        public Variant(String id, String name) {
            this.id = id;
            this.name = name;
        }

        public SceneObject object(String id) {
            if (id == null) return null;
            for (SceneObject o : objects) if (id.equals(o.id)) return o;
            return null;
        }

        public Track track(String id) {
            for (Track t : tracks) if (t.id.equals(id)) return t;
            return null;
        }

        public List<Track> tracks(Track.Type type) {
            List<Track> out = new ArrayList<>();
            for (Track t : tracks) if (t.type == type) out.add(t);
            return out;
        }

        /** Треки анімацій актора, знизу вгору. */
        public List<Track> animationTracks(String actorId) {
            List<Track> out = new ArrayList<>();
            for (Track t : tracks) if (t.type == Track.Type.ANIMATION && actorId.equals(t.target)) out.add(t);
            return out;
        }

        public double contentEnd() {
            double e = length;
            for (Track t : tracks) e = Math.max(e, t.end());
            return e;
        }
    }

    /** Ассет світу: модель, текстура, звук. Файл лежить у {@code assets/<sha256>.<ext>}. */
    public static final class Asset {
        public enum Type { MODEL, TEXTURE, AUDIO, OTHER }

        public String id;
        public String name;
        public Type type;
        public String sha256;
        public String ext;
        public long size;
        /** Довжина звуку (секунди) / ширина-висота текстури — для таймлайну і превʼю. */
        public double duration;
        public int width, height;
        public final List<String> tags = new ArrayList<>();

        public String fileName() { return sha256 + "." + ext; }
    }
}
