package dev.shaurmalib.scene.api;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Значення слотів на час запуску сцени: хто winner, хто maniac, список жертв, числа для оверлеїв.
 * Режим заповнює це у своєму коді й передає в {@code SceneServer.play}; актори з міткою слота
 * беруть звідси скін/нік/позицію, а актори без значення ховаються (правило приховання).
 */
public final class SceneBindings {

    /** Прив'язка: гравець/сутність (uuid, нік, скін) або значення. */
    public static final class Binding {
        public UUID uuid;
        public String name;
        /** Текстура скіна (property «textures» профілю) — клієнт намалює навіть далекого/офлайн гравця. */
        public String skinTexture, skinSignature;
        /** Slim-руки (null — визначить клієнт). */
        public Boolean slim;
        /** Позиція сутності на момент запуску (для look-at, коли сутність не відстежується). */
        public double x, y, z;
        public boolean hasPos;
        public String value;

        public static Binding player(UUID uuid, String name) {
            Binding b = new Binding();
            b.uuid = uuid;
            b.name = name;
            return b;
        }

        public static Binding value(String v) {
            Binding b = new Binding();
            b.value = v;
            return b;
        }

        public Binding skin(String texture, String signature) { this.skinTexture = texture; this.skinSignature = signature; return this; }

        public Binding at(double x, double y, double z) { this.x = x; this.y = y; this.z = z; this.hasPos = true; return this; }

        public Binding slim(Boolean s) { this.slim = s; return this; }
    }

    private final Map<String, List<Binding>> slots = new LinkedHashMap<>();

    public SceneBindings bind(String slot, Binding b) {
        slots.computeIfAbsent(slot, k -> new ArrayList<>()).add(b);
        return this;
    }

    public SceneBindings bindAll(String slot, List<Binding> list) {
        slots.computeIfAbsent(slot, k -> new ArrayList<>()).addAll(list);
        return this;
    }

    public Binding get(String slot, int index) {
        List<Binding> l = slots.get(slot);
        return l == null || index < 0 || index >= l.size() ? null : l.get(index);
    }

    public List<Binding> all(String slot) { return slots.getOrDefault(slot, List.of()); }

    public int count(String slot) { return all(slot).size(); }

    public Map<String, List<Binding>> map() { return slots; }

    public boolean isEmpty() { return slots.isEmpty(); }

    // ── дріт ──

    public void write(DataOutput out) throws IOException {
        out.writeShort(slots.size());
        for (Map.Entry<String, List<Binding>> e : slots.entrySet()) {
            out.writeUTF(e.getKey());
            out.writeShort(e.getValue().size());
            for (Binding b : e.getValue()) {
                int flags = (b.uuid != null ? 1 : 0) | (b.name != null ? 2 : 0) | (b.skinTexture != null ? 4 : 0)
                    | (b.skinSignature != null ? 8 : 0) | (b.slim != null ? 16 : 0) | (b.hasPos ? 32 : 0) | (b.value != null ? 64 : 0);
                out.writeByte(flags);
                if (b.uuid != null) { out.writeLong(b.uuid.getMostSignificantBits()); out.writeLong(b.uuid.getLeastSignificantBits()); }
                if (b.name != null) out.writeUTF(b.name);
                if (b.skinTexture != null) writeLong(out, b.skinTexture);
                if (b.skinSignature != null) writeLong(out, b.skinSignature);
                if (b.slim != null) out.writeBoolean(b.slim);
                if (b.hasPos) { out.writeDouble(b.x); out.writeDouble(b.y); out.writeDouble(b.z); }
                if (b.value != null) out.writeUTF(b.value);
            }
        }
    }

    public static SceneBindings read(DataInput in) throws IOException {
        SceneBindings s = new SceneBindings();
        int n = in.readUnsignedShort();
        if (n > 64) throw new IOException("забагато слотів: " + n);
        for (int i = 0; i < n; i++) {
            String slot = in.readUTF();
            int m = in.readUnsignedShort();
            if (m > 256) throw new IOException("забагато прив'язок: " + m);
            for (int j = 0; j < m; j++) {
                int f = in.readUnsignedByte();
                Binding b = new Binding();
                if ((f & 1) != 0) b.uuid = new UUID(in.readLong(), in.readLong());
                if ((f & 2) != 0) b.name = in.readUTF();
                if ((f & 4) != 0) b.skinTexture = readLong(in);
                if ((f & 8) != 0) b.skinSignature = readLong(in);
                if ((f & 16) != 0) b.slim = in.readBoolean();
                if ((f & 32) != 0) { b.x = in.readDouble(); b.y = in.readDouble(); b.z = in.readDouble(); b.hasPos = true; }
                if ((f & 64) != 0) b.value = in.readUTF();
                s.bind(slot, b);
            }
        }
        return s;
    }

    /** writeUTF обмежений 64 КБ; підписи й текстури скінів пишемо з довжиною int. */
    private static void writeLong(DataOutput out, String s) throws IOException {
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        out.writeInt(b.length);
        out.write(b);
    }

    private static String readLong(DataInput in) throws IOException {
        int n = in.readInt();
        if (n < 0 || n > 1 << 16) throw new IOException("задовгий рядок прив'язки: " + n);
        byte[] b = new byte[n];
        in.readFully(b);
        return new String(b, StandardCharsets.UTF_8);
    }
}
