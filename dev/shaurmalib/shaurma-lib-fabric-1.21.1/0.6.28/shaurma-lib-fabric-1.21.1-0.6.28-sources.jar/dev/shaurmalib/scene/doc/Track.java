package dev.shaurmalib.scene.doc;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Трек таймлайну. Камери, ефекти, оверлеї, звук — окремі треки (як окремі доріжки монтажу), що
 * накладаються згори вниз: на тих самих типах вищий трек (більший індекс у списку) перекриває нижчий.
 * Треки анімацій прив'язані до актора ({@link #target}) і працюють як шари: нижній — база.
 */
public final class Track {

    public enum Type {
        CAMERA(true), ANIMATION(true), AUDIO(true), OVERLAY(true), EFFECT(true), TIME(false);

        /** Чи кліпи можуть перекриватися (blending) у межах одного треку. */
        public final boolean overlap;

        Type(boolean overlap) { this.overlap = overlap; }
    }

    public String id;
    public String name;
    public Type type;
    /** ANIMATION: id актора. AUDIO: id об'єкта-джерела для просторового звуку (null — без простору). */
    public String target;
    public boolean muted, solo, locked, hidden;
    /** Гучність треку (мікшер, як фейдер доріжки в монтажці): множиться на гучність кліпів. 1 — 0 дБ. */
    public double gain = 1;
    /** Згорнуто в редакторі. */
    public boolean collapsed;
    public final List<Clip> clips = new ArrayList<>();

    public Track() {}

    public Track(String id, String name, Type type) {
        this.id = id;
        this.name = name;
        this.type = type;
    }

    public void sort() { clips.sort(Comparator.comparingDouble(c -> c.start)); }

    public Clip clipAt(double t) {
        Clip best = null;
        for (Clip c : clips) if (!c.muted && c.covers(t)) best = c;   // пізніший (вищий на треку) виграє
        return best;
    }

    public Clip find(String clipId) {
        for (Clip c : clips) if (c.id.equals(clipId)) return c;
        return null;
    }

    public double end() {
        double e = 0;
        for (Clip c : clips) e = Math.max(e, c.end());
        return e;
    }
}
