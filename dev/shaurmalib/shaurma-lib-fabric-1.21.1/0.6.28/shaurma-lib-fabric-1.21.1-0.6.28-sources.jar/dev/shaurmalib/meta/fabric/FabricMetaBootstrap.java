package dev.shaurmalib.meta.fabric;

import dev.shaurmalib.fabric.WireCodec;
import dev.shaurmalib.meta.mc.McMeta;
import dev.shaurmalib.meta.net.MetaMessage;
import dev.shaurmalib.meta.net.MetaNetwork;
import dev.shaurmalib.meta.server.MetaServer;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import java.util.UUID;

public final class FabricMetaBootstrap implements ModInitializer {
    @Override
    public void onInitialize() {
        var codec = WireCodec.of(MetaMessage::read, MetaMessage::write, MetaPayload::message, MetaPayload::new);
        PayloadTypeRegistry.playS2C().register(MetaPayload.TYPE, codec);
        PayloadTypeRegistry.playC2S().register(MetaPayload.TYPE, codec);

        ServerLifecycleEvents.SERVER_STARTED.register(McMeta::onServerStarted);
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> McMeta.onServerStopped());
        ServerPlayConnectionEvents.JOIN.register((h, sender, server) -> server.execute(() -> McMeta.onJoin(h.method_32311())));
        ServerPlayConnectionEvents.DISCONNECT.register((h, server) -> McMeta.onLeave(h.method_32311()));
        CommandRegistrationCallback.EVENT.register((d, ctx, env) -> d.register(McMeta.command()));
        ServerPlayNetworking.registerGlobalReceiver(MetaPayload.TYPE, (payload, context) -> {
            MetaMessage message = payload.message();
            MetaServer server = MetaServer.get();
            if (server != null && message.op().toServer()) server.handle(context.player().method_5667(), message);
        });
        MetaNetwork.set(new MetaNetwork() {
            @Override public void toPlayer(UUID id, MetaMessage message) {
                var server = McMeta.server();
                if (server == null) return;
                class_3222 player = server.method_3760().method_14602(id);
                if (player != null) send(player, new MetaPayload(message));
            }

            @Override public void toAll(MetaMessage message) {
                var server = McMeta.server();
                if (server == null) return;
                var payload = new MetaPayload(message);
                for (class_3222 player : server.method_3760().method_14571()) send(player, payload);
            }

            @Override public void toNear(UUID near, double x, double y, double z, double r, MetaMessage message) {
                var payload = new MetaPayload(message);
                for (class_3222 player : McMeta.near(near, x, y, z, r)) send(player, payload);
            }

            @Override public void toServer(MetaMessage message) { FabricMetaClient.send(message); }
        });
    }

    private static void send(class_3222 player, MetaPayload payload) {
        if (ServerPlayNetworking.canSend(player, MetaPayload.TYPE)) ServerPlayNetworking.send(player, payload);
    }

    record MetaPayload(MetaMessage message) implements class_8710 {
        static final class_9154<MetaPayload> TYPE = new class_9154<>(class_2960.method_60655("shaurma_lib", "meta"));

        @Override
        public class_9154<MetaPayload> method_56479() { return TYPE; }
    }
}
