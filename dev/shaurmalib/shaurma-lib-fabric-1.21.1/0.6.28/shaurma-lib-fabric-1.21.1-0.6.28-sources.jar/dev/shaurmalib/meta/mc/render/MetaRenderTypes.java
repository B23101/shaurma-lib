package dev.shaurmalib.meta.mc.render;

import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4668;

public final class MetaRenderTypes extends class_1921 {
    public static final class_1921 GLOW = new MetaRenderTypes("shaurma_meta_glow", 256, false,
        field_29429, field_21367, field_21344, field_21350);
    public static final class_1921 PLUS = new MetaRenderTypes("shaurma_meta_plus", 1024, true,
        field_29442, field_21370, field_21345, field_21349);

    private MetaRenderTypes(String name, int bufferSize, boolean sort, class_5942 shader,
                            class_4685 transparency, class_4671 cull, class_4686 mask) {
        this(name, bufferSize, sort, new class_4668[] {
            field_21378, shader, transparency, field_21348, cull, field_21384, field_21386,
            field_21352, field_21358, field_21379, mask, field_21360, field_44815
        });
    }

    private MetaRenderTypes(String name, int bufferSize, boolean sort, class_4668[] states) {
        super(name, class_290.field_1576, class_293.class_5596.field_27382, bufferSize, false, sort,
            () -> { for (var state : states) state.method_23516(); },
            () -> { for (var state : states) state.method_23518(); });
    }
}
