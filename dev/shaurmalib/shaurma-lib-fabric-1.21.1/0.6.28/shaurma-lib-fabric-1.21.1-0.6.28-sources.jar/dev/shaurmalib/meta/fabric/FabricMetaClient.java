package dev.shaurmalib.meta.fabric;

import dev.shaurmalib.meta.MetaModes;
import dev.shaurmalib.meta.client.MetaClient;
import dev.shaurmalib.meta.mc.McMetaClient;
import dev.shaurmalib.meta.mc.render.CosmeticRenderer;
import dev.shaurmalib.meta.net.MetaMessage;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1007;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import java.util.HashSet;
import java.util.Set;

/** Fabric-клей мета-двигуна (клієнт): дзеркало {@code ForgeMetaClient}. */
public final class FabricMetaClient implements ClientModInitializer {

    private static final Set<class_1792> TINTED = new HashSet<>();

    @Override
    public void onInitializeClient() {
        McMetaClient.init();
        ClientPlayNetworking.registerGlobalReceiver(FabricMetaBootstrap.MetaPayload.TYPE, (payload, context) -> {
            MetaMessage message = payload.message();
            if (!message.op().toServer()) MetaClient.handle(message);
        });
        HudRenderCallback.EVENT.register((graphics, ticks) -> McMetaClient.onHud(graphics, ticks.method_60637(false)));
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            if (ctx.consumers() == null) return;
            McMetaClient.onWorld(ctx.matrixStack(), ctx.consumers(), ctx.camera().method_19326(), ctx.tickCounter().method_60637(false));
        });
        ClientTickEvents.END_CLIENT_TICK.register(c -> { registerTints(); McMetaClient.onTick(); });
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> McMetaClient.onDisconnect());
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, context) -> {
            if (renderer instanceof class_1007 r) helper.register(new CosmeticRenderer.Layer(r));
        });
    }

    /**
     * Відтінок предметів-моделей косметики. На Fabric порядок entrypoint-ів модів не гарантований, тож
     * реєструємо ліниво, коли режим уже зареєстрував каталог (реєстр ColorProvider приймає й пізню реєстрацію).
     */
    private static void registerTints() {
        for (var mode : MetaModes.all()) {
            for (String id : mode.cosmetics.models()) {
                class_2960 rl = class_2960.method_12829(id);
                class_1792 it = rl == null ? class_1802.field_8162 : class_7923.field_41178.method_10223(rl);
                if (it == class_1802.field_8162 || !TINTED.add(it)) continue;
                ColorProviderRegistry.ITEM.register((stack, tint) -> 0xFF000000 | CosmeticRenderer.tint(stack), it);
            }
        }
    }

    static void send(MetaMessage m) {
        if (class_310.method_1551().method_1562() != null && ClientPlayNetworking.canSend(FabricMetaBootstrap.MetaPayload.TYPE)) {
            ClientPlayNetworking.send(new FabricMetaBootstrap.MetaPayload(m));
        }
    }
}
