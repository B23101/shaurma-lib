package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.pose.BoneTransform;
import dev.shaurmalib.anim.pose.Pose;
import dev.shaurmalib.anim.rig.Rig;
import net.minecraft.class_1306;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5603;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import org.joml.Quaternionf;

/**
 * Переклад пози рушія ↔ ванільна {@link class_572}.
 *
 * <h2>Простори (перевірено проти GeckoLib і Blockbench)</h2>
 * Кліп зберігає значення як у Blockbench. Сцена Blockbench має Y вгору; {@code ModelPart} — Y вниз і
 * дзеркальний X, тобто сцена, повернута на 180° навколо Z. Звідси для ванільної моделі:
 * <pre>
 *   обертання (x, y, z)°  →  xRot, yRot, zRot += rad(x, y, z)      (порядок ZYX, як у ModelPart)
 *   зсув      (x, y, z)px →  x += x;  y −= y;  z += z
 * </pre>
 * Півоти ригу Blockbench (Y вгору від ступнів) ↔ ванільні: точка сцени (x,y,z) = ModelPart (−x, 24−y, z).
 * Якір предмета в руці (кістка {@code right_item}, півот (6,12,−2)) збігається з ванільним
 * {@code ItemInHandLayer} точно: (−1, 10, −2) у просторі руки — тому предмет у кліпі стоїть там, де в Blockbench.
 */
public final class PlayerModelBridge {

    private PlayerModelBridge() {}

    private static final Rig R = Rig.PLAYER;
    static final int HEAD = R.indexOf("head"), TORSO = R.indexOf("torso"), RIGHT_ARM = R.indexOf("right_arm"),
        LEFT_ARM = R.indexOf("left_arm"), RIGHT_LEG = R.indexOf("right_leg"), LEFT_LEG = R.indexOf("left_leg"),
        ROOT = R.indexOf("body"), RIGHT_ITEM = R.indexOf("right_item"), LEFT_ITEM = R.indexOf("left_item");

    /** Півот кореня (стегна) у просторі ModelPart, пікселі. */
    private static final float ROOT_PIVOT_Y = 24f - 12f;

    static class_630 part(class_572<?> m, int bone) {
        if (bone == HEAD) return m.field_3398;
        if (bone == TORSO) return m.field_3391;
        if (bone == RIGHT_ARM) return m.field_3401;
        if (bone == LEFT_ARM) return m.field_27433;
        if (bone == RIGHT_LEG) return m.field_3392;
        if (bone == LEFT_LEG) return m.field_3397;
        return null;
    }

    private static final int[] PARTS = { HEAD, TORSO, RIGHT_ARM, LEFT_ARM, RIGHT_LEG, LEFT_LEG };

    /** Ванільна поза моделі → поза рушія (база під кліпами). */
    public static void capture(class_572<?> m, Pose base) {
        base.reset();
        for (int bone : PARTS) {
            class_630 p = part(m, bone);
            class_5603 rest = p.method_41921();
            BoneTransform b = base.bone(bone);
            b.rx = (p.field_3654 - rest.field_27705) * class_3532.field_29848;
            b.ry = (p.field_3675 - rest.field_27706) * class_3532.field_29848;
            b.rz = (p.field_3674 - rest.field_27707) * class_3532.field_29848;
            b.px = p.field_3657 - rest.field_27702;
            b.py = -(p.field_3656 - rest.field_27703);
            b.pz = p.field_3655 - rest.field_27704;
            b.sx = p.field_37938;
            b.sy = p.field_37939;
            b.sz = p.field_37940;
        }
    }

    /** Пише в модель ЛИШЕ кістки, які змінив рушій. @return чи щось змінено. */
    public static boolean apply(class_572<?> m, Pose pose) {
        boolean any = false;
        for (int bone : PARTS) {
            if (!pose.touched(bone)) continue;
            write(part(m, bone), pose.bone(bone));
            any = true;
        }
        if (any && m instanceof class_591<?> pm) syncOverlays(pm);
        else if (any) m.field_3394.method_17138(m.field_3398);
        return any;
    }

    /** Лише руки (перша особа). */
    public static void applyArms(class_572<?> m, Pose pose) {
        if (pose.touched(RIGHT_ARM)) write(m.field_3401, pose.bone(RIGHT_ARM));
        if (pose.touched(LEFT_ARM)) write(m.field_27433, pose.bone(LEFT_ARM));
        if (m instanceof class_591<?> pm) syncOverlays(pm);
    }

    private static void write(class_630 p, BoneTransform b) {
        class_5603 rest = p.method_41921();
        p.field_3654 = rest.field_27705 + b.rx * class_3532.field_29847;
        p.field_3675 = rest.field_27706 + b.ry * class_3532.field_29847;
        p.field_3674 = rest.field_27707 + b.rz * class_3532.field_29847;
        p.field_3657 = rest.field_27702 + b.px;
        p.field_3656 = rest.field_27703 - b.py;
        p.field_3655 = rest.field_27704 + b.pz;
        p.field_37938 = b.sx;
        p.field_37939 = b.sy;
        p.field_37940 = b.sz;
    }

    static void syncOverlays(class_591<?> m) {
        m.field_3394.method_17138(m.field_3398);
        m.field_3483.method_17138(m.field_3391);
        m.field_3484.method_17138(m.field_27433);
        m.field_3486.method_17138(m.field_3401);
        m.field_3482.method_17138(m.field_3397);
        m.field_3479.method_17138(m.field_3392);
    }

    /** Повертає частини в позу спокою (на початку setupAnim, якщо попередній кадр їх зсував). */
    public static void reset(class_572<?> m) {
        for (int bone : PARTS) part(m, bone).method_41923();
        m.field_3394.method_41923();
        if (m instanceof class_591<?> pm) {
            pm.field_3483.method_41923();
            pm.field_3484.method_41923();
            pm.field_3486.method_41923();
            pm.field_3482.method_41923();
            pm.field_3479.method_41923();
        }
    }

    /** Корінь {@code body} (усе тіло: лягти, нахилитись, бути піднятим) — у просторі моделі перед частинами. */
    public static void applyRoot(class_4587 ps, Pose pose) {
        if (pose == null || ROOT < 0 || !pose.touched(ROOT)) return;
        BoneTransform b = pose.bone(ROOT);
        ps.method_46416(b.px / 16f, -b.py / 16f, b.pz / 16f);
        ps.method_46416(0, ROOT_PIVOT_Y / 16f, 0);
        if (b.rx != 0 || b.ry != 0 || b.rz != 0) {
            ps.method_22907(new Quaternionf().rotationZYX(b.rz * class_3532.field_29847, b.ry * class_3532.field_29847, b.rx * class_3532.field_29847));
        }
        if (b.sx != 1 || b.sy != 1 || b.sz != 1) ps.method_22905(safe(b.sx), safe(b.sy), safe(b.sz));
        ps.method_46416(0, -ROOT_PIVOT_Y / 16f, 0);
    }

    /**
     * Кістка предмета, викликати там, де ванільний {@code ItemInHandLayer} уже поставив стек у якір
     * (після {@code XP(-90)·YP(180)·translate}). Перетворення задане в осях руки, тож обертаємо назад,
     * застосовуємо і повертаємо ванільну орієнтацію: {@code R⁻¹·B·R}.
     */
    public static void applyItemBone(class_4587 ps, Pose pose, class_1306 arm) {
        int bone = arm == class_1306.field_6183 ? RIGHT_ITEM : LEFT_ITEM;
        if (pose == null || !pose.touched(bone)) return;
        BoneTransform b = pose.bone(bone);
        ps.method_22907(class_7833.field_40716.rotationDegrees(-180f));
        ps.method_22907(class_7833.field_40714.rotationDegrees(90f));
        applyLocal(ps, b);
        ps.method_22907(class_7833.field_40714.rotationDegrees(-90f));
        ps.method_22907(class_7833.field_40716.rotationDegrees(180f));
    }

    /** Трансформ кістки в осях ModelPart навколо поточного початку стеку. */
    static void applyLocal(class_4587 ps, BoneTransform b) {
        ps.method_46416(b.px / 16f, -b.py / 16f, b.pz / 16f);
        if (b.rx != 0 || b.ry != 0 || b.rz != 0) {
            ps.method_22907(new Quaternionf().rotationZYX(b.rz * class_3532.field_29847, b.ry * class_3532.field_29847, b.rx * class_3532.field_29847));
        }
        if (b.sx != 1 || b.sy != 1 || b.sz != 1) ps.method_22905(safe(b.sx), safe(b.sy), safe(b.sz));
    }

    /** Якір предмета в руці, простір ModelPart (пікселі). */
    static float[] itemAnchor(class_1306 arm) {
        return arm == class_1306.field_6183 ? new float[] { -1, 10, -2 } : new float[] { 1, 10, -2 };
    }

    static float safe(float s) { return Math.abs(s) < 1e-4f ? 1e-4f : s; }
}
