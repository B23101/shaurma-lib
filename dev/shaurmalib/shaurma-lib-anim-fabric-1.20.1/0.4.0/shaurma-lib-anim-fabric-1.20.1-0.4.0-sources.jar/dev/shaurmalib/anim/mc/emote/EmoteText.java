package dev.shaurmalib.anim.mc.emote;

import dev.shaurmalib.anim.emote.Emote;
import net.minecraft.class_2561;

/** Тексти емоцій: переклад, якщо мод його дав, інакше назва з реєстру. */
final class EmoteText {

    private EmoteText() {}

    /** {@code emote.<ns>.<шлях>} — напр. {@code emote.maniacmod.wave}. */
    static class_2561 name(Emote e) {
        return class_2561.method_48321("emote." + e.id().replace(':', '.').replace('/', '.'), e.name());
    }

    static class_2561 category(String c) {
        return class_2561.method_48321("emote.category." + c, c);
    }

    static class_2561 ui(String key, String fallback) {
        return class_2561.method_48321("shaurma_lib.emote." + key, fallback);
    }
}
