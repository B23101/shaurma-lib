package dev.shaurmalib.anim.mc.mixin;

import dev.shaurmalib.anim.mc.PropLayer;
import net.minecraft.class_1007;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Шар пропсів на кожен рендерер гравця (широкий і тонкий скін) — без подій лоадера. */
@Mixin(class_1007.class)
public abstract class MixinPlayerRendererAnim extends class_922<class_742, class_591<class_742>> {

    private MixinPlayerRendererAnim(class_5617.class_5618 ctx, class_591<class_742> model, float shadow) {
        super(ctx, model, shadow);
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void shaurma$anim$addPropLayer(class_5617.class_5618 ctx, boolean slim, CallbackInfo ci) {
        this.method_4046(new PropLayer(this));
    }
}
