package dev.shaurmalib.anim.mc.mixin;

import dev.shaurmalib.anim.mc.FirstPersonRenderer;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_746;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Перша особа: кліп з {@code first_person: model/hide} підміняє ванільні руки. Ваніль-рівень — однаково для всіх лоадерів. */
@Mixin(class_759.class)
public abstract class MixinItemInHandRendererAnim {

    @Inject(method = "renderHandsWithItems", at = @At("HEAD"), cancellable = true)
    private void shaurma$anim$firstPerson(float partial, class_4587 ps, class_4597.class_4598 buffers,
                                          class_746 player, int light, CallbackInfo ci) {
        if (FirstPersonRenderer.render(partial, ps, buffers, player, light)) ci.cancel();
    }
}
