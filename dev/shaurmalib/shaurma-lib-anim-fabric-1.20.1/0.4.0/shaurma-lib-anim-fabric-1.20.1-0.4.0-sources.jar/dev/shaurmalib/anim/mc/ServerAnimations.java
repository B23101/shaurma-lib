package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.net.AnimMessage;
import dev.shaurmalib.anim.net.AnimNetwork;
import dev.shaurmalib.anim.runtime.Slot;
import net.minecraft.class_1297;

/**
 * Серверний API: запустити анімацію так, щоб її побачили ВСІ, хто бачить сутність (і вона сама).
 * Сервер нічого не семплить — лише шле id кліпа; кліпи живуть у ресурсах клієнта.
 *
 * <pre>
 * ServerAnimations.play(player, "maniacmod:medkit_use");
 * ServerAnimations.play(player, AnimMessage.PlayRequestSpec.of("maniacmod:scissors_cut").slot(Slot.ACTION));
 * </pre>
 */
public final class ServerAnimations {

    private ServerAnimations() {}

    public static void play(class_1297 entity, String clipId) {
        play(entity, AnimMessage.PlayRequestSpec.of(clipId).restart(true));
    }

    public static void play(class_1297 entity, AnimMessage.PlayRequestSpec spec) {
        AnimNetwork.get().sendToTracking(entity, AnimMessage.play(entity.method_5667(), spec), true);
    }

    public static void stop(class_1297 entity, String clipId) {
        AnimNetwork.get().sendToTracking(entity, AnimMessage.stopClip(entity.method_5667(), clipId, Float.NaN), true);
    }

    public static void stop(class_1297 entity, Slot slot) {
        AnimNetwork.get().sendToTracking(entity, AnimMessage.stopSlot(entity.method_5667(), slot, Float.NaN), true);
    }

    public static void stopAll(class_1297 entity) {
        AnimNetwork.get().sendToTracking(entity, AnimMessage.stopAll(entity.method_5667(), 0.2f), true);
    }
}
