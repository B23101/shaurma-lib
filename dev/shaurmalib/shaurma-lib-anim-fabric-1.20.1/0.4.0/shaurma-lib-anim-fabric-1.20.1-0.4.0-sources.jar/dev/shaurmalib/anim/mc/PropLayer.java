package dev.shaurmalib.anim.mc;

import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_591;
import net.minecraft.class_742;

/** Шар рендера гравця, що малює пропси активних кліпів (після моделі, у тій самій позі). */
public final class PropLayer extends class_3887<class_742, class_591<class_742>> {

    public PropLayer(class_3883<class_742, class_591<class_742>> parent) {
        super(parent);
    }

    @Override
    public void render(class_4587 ps, class_4597 buffers, int light, class_742 player,
                       float limbSwing, float limbSwingAmount, float partial, float age, float headYaw, float headPitch) {
        if (player != McAnim.renderingEntity || player.method_5767()) return;
        PropRenderer.renderProps(ps, buffers, light, player, method_17165(), McAnim.framePose(player));
    }
}
