package dev.shaurmalib.anim.mc.mixin;

import dev.shaurmalib.anim.mc.McAnimHooks;
import net.minecraft.class_1309;
import net.minecraft.class_572;
import net.minecraft.class_591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Ванільна поза → база, шари рушія поверх. Пріоритет 900: інші моди з TAIL-ін'єкціями (з дефолтом 1000)
 * отримують модель уже з анімацією рушія і можуть її доповнити, а не навпаки.
 */
@Mixin(value = class_591.class, priority = 900)
public abstract class MixinPlayerModelAnim {

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("HEAD"))
    private void shaurma$anim$reset(class_1309 entity, float limbSwing, float limbSwingAmount, float age,
                                    float headYaw, float headPitch, CallbackInfo ci) {
        McAnimHooks.beforeSetupAnim((class_572<?>) (Object) this);
    }

    @Inject(method = "setupAnim(Lnet/minecraft/world/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void shaurma$anim$apply(class_1309 entity, float limbSwing, float limbSwingAmount, float age,
                                    float headYaw, float headPitch, CallbackInfo ci) {
        McAnimHooks.afterSetupAnim((class_572<?>) (Object) this, entity);
    }
}
