package dev.shaurmalib.anim.mc.mixin;

import dev.shaurmalib.anim.mc.McAnimHooks;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Корінь тіла рушія + межі «зараз малюється ця сутність». */
@Mixin(class_922.class)
public abstract class MixinLivingEntityRendererAnim<T extends class_1309, M extends class_583<T>> {

    @Shadow protected M model;

    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/EntityModel;prepareMobModel(Lnet/minecraft/world/entity/Entity;FFF)V"))
    private void shaurma$anim$begin(T entity, float yaw, float partialTick, class_4587 poseStack, class_4597 buffers,
                                    int light, CallbackInfo ci) {
        McAnimHooks.beginRender(entity, partialTick, poseStack, this.model);
    }

    @Inject(method = "render(Lnet/minecraft/world/entity/LivingEntity;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At("RETURN"))
    private void shaurma$anim$end(T entity, float yaw, float partialTick, class_4587 poseStack, class_4597 buffers,
                                  int light, CallbackInfo ci) {
        McAnimHooks.endRender();
    }
}
