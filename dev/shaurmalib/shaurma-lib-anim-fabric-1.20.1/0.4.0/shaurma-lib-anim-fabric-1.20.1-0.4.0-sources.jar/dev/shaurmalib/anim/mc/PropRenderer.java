package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.ShaurmaAnim;
import dev.shaurmalib.anim.clip.BoneTrack;
import dev.shaurmalib.anim.clip.PropSpec;
import dev.shaurmalib.anim.mesh.GeoMesh;
import dev.shaurmalib.anim.mesh.PropBaker;
import dev.shaurmalib.anim.pose.BoneTransform;
import dev.shaurmalib.anim.pose.Pose;
import dev.shaurmalib.anim.rig.Rig;
import dev.shaurmalib.anim.runtime.Animator;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_572;
import net.minecraft.class_630;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_7923;
import net.minecraft.class_811;

/**
 * Малює пропси кліпа (модель з Blockbench з власною текстурою, або предмет гри) на кістках
 * ванільної моделі гуманоїда. Кістки самого пропса (кришка аптечки, лезо ножиць) анімуються
 * треками того ж кліпа — у Blockbench це просто групи всередині групи пропса.
 */
public final class PropRenderer {

    private PropRenderer() {}

    private static final Map<String, class_1799> ITEM_CACHE = new HashMap<>();

    public static void renderProps(class_4587 ps, class_4597 buffers, int light, class_1309 entity,
                                   class_572<?> model, Pose pose) {
        if (pose == null || pose.props().isEmpty()) return;
        Animator animator = ShaurmaAnim.find(entity.method_5667());
        if (animator == null) return;
        for (Pose.ActiveProp prop : pose.props()) {
            try {
                renderProp(ps, buffers, light, entity, model, pose, animator, prop);
            } catch (RuntimeException ignored) {
                // кривий пропс не має валити рендер гравця
            }
        }
    }

    private static void renderProp(class_4587 ps, class_4597 buffers, int light, class_1309 entity,
                                   class_572<?> model, Pose pose, Animator animator, Pose.ActiveProp prop) {
        PropSpec spec = prop.spec();
        String parent = spec.parentBone() == null ? "right_arm" : spec.parentBone();
        int parentIdx = Rig.PLAYER.indexOf(parent);
        if (parentIdx < 0) return;

        ps.method_22903();
        if (parentIdx == PlayerModelBridge.RIGHT_ITEM || parentIdx == PlayerModelBridge.LEFT_ITEM) {
            class_1306 arm = parentIdx == PlayerModelBridge.RIGHT_ITEM ? class_1306.field_6183 : class_1306.field_6182;
            model.method_2803(arm, ps);
            float[] a = PlayerModelBridge.itemAnchor(arm);
            ps.method_46416(a[0] / 16f, a[1] / 16f, a[2] / 16f);
            if (pose.touched(parentIdx)) PlayerModelBridge.applyLocal(ps, pose.bone(parentIdx));
        } else if (parentIdx == PlayerModelBridge.ROOT) {
            ps.method_46416(0, 12f / 16f, 0);
        } else {
            class_630 part = PlayerModelBridge.part(model, parentIdx);
            if (part == null) { ps.method_22909(); return; }
            part.method_22703(ps);
        }

        float t = prop.clipTime();
        float[] scratch = new float[3];
        if (spec.item() != null) {
            // предмет гри: власна кістка пропса (ім'я = id пропса) може його зсувати
            BoneTransform b = new BoneTransform();
            boolean any = false;
            if (animator.samplePropBone(prop.clip(), spec.id(), BoneTrack.ChannelType.POSITION, t, scratch)) {
                b.px = scratch[0]; b.py = scratch[1]; b.pz = scratch[2]; any = true;
            }
            if (animator.samplePropBone(prop.clip(), spec.id(), BoneTrack.ChannelType.ROTATION, t, scratch)) {
                b.rx = scratch[0]; b.ry = scratch[1]; b.rz = scratch[2]; any = true;
            }
            if (any) PlayerModelBridge.applyLocal(ps, b);
            ps.method_22907(class_7833.field_40714.rotationDegrees(-90f));
            ps.method_22907(class_7833.field_40716.rotationDegrees(180f));
            class_310.method_1551().method_1480().method_23177(entity, item(spec.item()),
                class_811.field_4320, false, ps, buffers, entity.method_37908(), light,
                class_4608.field_21444, entity.method_5628());
        } else {
            GeoMesh mesh = ShaurmaAnim.clips().mesh(spec.model());
            class_2960 tex = spec.texture() == null ? null : class_2960.method_12829(spec.texture());
            if (mesh != null && tex != null) {
                ps.method_22907(class_7833.field_40718.rotationDegrees(180f)); // сцена Blockbench → простір ModelPart
                class_1921 type = spec.emissive() ? class_1921.method_23026(tex) : class_1921.method_23578(tex);
                class_4588 vc = buffers.getBuffer(type);
                Matrix4f m4 = ps.method_23760().method_23761();
                Matrix3f m3 = ps.method_23760().method_23762();
                int lit = spec.emissive() ? class_765.field_32767 : light;
                PropBaker.bake(mesh, Rig.PLAYER.pivot(parentIdx),
                    (bone, type2, out) -> animator.samplePropBone(prop.clip(), bone, type2, t, out),
                    (pos, uv, nx, ny, nz) -> {
                        for (int v = 0; v < 4; v++) {
                            vc.method_22918(m4, pos[v * 3], pos[v * 3 + 1], pos[v * 3 + 2])
                                .method_22915(1f, 1f, 1f, 1f)
                                .method_22913(uv[v * 2], uv[v * 2 + 1])
                                .method_22922(class_4608.field_21444)
                                .method_22916(lit)
                                .method_23763(m3, nx, ny, nz)
                                .method_1344();
                        }
                    });
            }
        }
        ps.method_22909();
    }

    private static class_1799 item(String id) {
        return ITEM_CACHE.computeIfAbsent(id, k -> {
            class_2960 rl = class_2960.method_12829(k);
            class_1792 it = rl == null ? class_1802.field_8162 : class_7923.field_41178.method_10223(rl);
            return new class_1799(it);
        });
    }
}
