package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.ShaurmaAnim;
import dev.shaurmalib.anim.io.AnimResourceLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.util.Map;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_4013;

/**
 * Перезавантажує бібліотеку кліпів з ресурс-паків (старт клієнта і F3+T). Ванільний інтерфейс —
 * лоадер лише реєструє екземпляр (Forge: RegisterClientReloadListenersEvent; Fabric: ResourceManagerHelper).
 */
public final class AnimReloader implements class_4013 {

    private static final Logger LOG = LoggerFactory.getLogger("ShaurmaAnim");
    private static final String[] ROOTS = { "shaurma_anim", "player_animation", "player_animations", "animations" };

    @Override
    public void method_14491(class_3300 rm) {
        AnimResourceLoader loader = new AnimResourceLoader(w -> LOG.warn("[ShaurmaAnim] {}", w));
        for (String root : ROOTS) {
            Map<class_2960, class_3298> found = rm.method_14488(root, rl -> rl.method_12832().endsWith(".json"));
            for (Map.Entry<class_2960, class_3298> e : found.entrySet()) {
                class_2960 rl = e.getKey();
                try (Reader r = e.getValue().method_43039()) {
                    StringBuilder sb = new StringBuilder();
                    char[] buf = new char[8192];
                    int n;
                    while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
                    loader.accept(rl.method_12836(), rl.method_12832(), sb.toString());
                } catch (IOException ex) {
                    LOG.warn("[ShaurmaAnim] не прочитано {}: {}", rl, ex.toString());
                }
            }
        }
        ShaurmaAnim.clips().replaceAll(loader.clips(), loader.meshes());
        LOG.info("[ShaurmaAnim] завантажено {} кліпів і {} моделей пропсів з {} файлів",
            loader.clips().size(), loader.meshes().size(), loader.files());
    }
}
