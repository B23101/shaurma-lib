package dev.shaurmalib.meta.mc;

import com.mojang.authlib.properties.Property;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import dev.shaurmalib.meta.MetaMode;
import dev.shaurmalib.meta.MetaModes;
import dev.shaurmalib.meta.economy.Reward;
import dev.shaurmalib.meta.server.MetaPlatform;
import dev.shaurmalib.meta.server.MetaServer;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

/**
 * Серверний клей мета-двигуна для 1.20.1 (однаковий для Forge і Fabric): платформа для {@link MetaServer},
 * вхід/вихід гравців, адмін-команда {@code /meta}. Лоадер лише викликає ці методи зі своїх подій.
 */
public final class McMeta {

    private static MinecraftServer server;

    private McMeta() {}

    public static MinecraftServer server() { return server; }

    /** Старт сервера: запускає рушій для режиму, що зареєстрований першим. */
    public static void onServerStarted(MinecraftServer s) {
        server = s;
        MetaMode mode = MetaModes.server();
        if (mode == null) return;
        MetaServer.start(mode, new MetaPlatform() {
            @Override public Path dataDir() { return s.method_27050(class_5218.field_24188).resolve("data").resolve("shaurma_meta"); }
            @Override public Collection<UUID> online() {
                List<UUID> out = new ArrayList<>();
                for (class_3222 p : s.method_3760().method_14571()) out.add(p.method_5667());
                return out;
            }
            @Override public boolean isAdmin(UUID id) {
                class_3222 p = s.method_3760().method_14602(id);
                return p != null && p.method_5687(2);
            }
            @Override public void tell(UUID id, String text, boolean actionBar) {
                class_3222 p = s.method_3760().method_14602(id);
                if (p != null) p.method_7353(class_2561.method_43470(text), actionBar);
            }
        });
    }

    public static void onServerStopped() {
        MetaServer.stop();
        server = null;
    }

    public static void onJoin(class_3222 p) {
        MetaServer s = MetaServer.get();
        if (s == null) return;
        String skin = "";
        for (Property prop : p.method_7334().getProperties().get("textures")) { skin = prop.getValue(); break; }
        s.onJoin(p.method_5667(), p.method_7334().getName(), skin);
    }

    public static void onLeave(class_3222 p) {
        MetaServer s = MetaServer.get();
        if (s != null) s.onLeave(p.method_5667());
    }

    /** Гравці, яким слати подію біля точки (той самий світ, що й {@code near}; без нього — усі світи). */
    public static List<class_3222> near(UUID nearId, double x, double y, double z, double r) {
        List<class_3222> out = new ArrayList<>();
        if (server == null) return out;
        class_3222 anchor = nearId == null ? null : server.method_3760().method_14602(nearId);
        for (class_3222 p : server.method_3760().method_14571()) {
            if (anchor != null && p.method_37908() != anchor.method_37908()) continue;
            if (p.method_5649(x, y, z) <= r * r) out.add(p);
        }
        return out;
    }

    // ══ /meta ═══════════════════════════════════════════════════════════

    public static LiteralArgumentBuilder<class_2168> command() {
        return class_2170.method_9247("meta").requires(s -> s.method_9259(2))
                .then(class_2170.method_9247("give").then(class_2170.method_9244("player", class_2186.method_9305())
                        .then(class_2170.method_9247("coins").then(class_2170.method_9244("amount", IntegerArgumentType.integer(1))
                                .executes(c -> give(c.getSource(), class_2186.method_9315(c, "player"),
                                        Reward.coins(MetaServer.get().mode.currency.id(), IntegerArgumentType.getInteger(c, "amount"))))
                                .then(class_2170.method_9244("currency", StringArgumentType.word())
                                        .executes(c -> give(c.getSource(), class_2186.method_9315(c, "player"),
                                                Reward.coins(StringArgumentType.getString(c, "currency"), IntegerArgumentType.getInteger(c, "amount")))))))
                        .then(class_2170.method_9247("cosmetic").then(class_2170.method_9244("id", StringArgumentType.word())
                                .suggests((c, b) -> {
                                    MetaServer s = MetaServer.get();
                                    if (s != null) s.mode.cosmetics.all().forEach(d -> b.suggest(d.id()));
                                    return b.buildFuture();
                                })
                                .executes(c -> give(c.getSource(), class_2186.method_9315(c, "player"),
                                        Reward.cosmetic(StringArgumentType.getString(c, "id"))))))
                        .then(class_2170.method_9247("material").then(class_2170.method_9244("id", StringArgumentType.word())
                                .suggests((c, b) -> {
                                    MetaServer s = MetaServer.get();
                                    if (s != null) s.mode.materials.keySet().forEach(b::suggest);
                                    return b.buildFuture();
                                })
                                .then(class_2170.method_9244("amount", IntegerArgumentType.integer(1))
                                        .executes(c -> give(c.getSource(), class_2186.method_9315(c, "player"),
                                                Reward.material(StringArgumentType.getString(c, "id"), IntegerArgumentType.getInteger(c, "amount")))))))
                        .then(class_2170.method_9247("points").then(class_2170.method_9244("amount", IntegerArgumentType.integer(1))
                                .executes(c -> give(c.getSource(), class_2186.method_9315(c, "player"),
                                        Reward.points(IntegerArgumentType.getInteger(c, "amount"))))))
                        .then(class_2170.method_9247("xp").then(class_2170.method_9244("amount", IntegerArgumentType.integer(1))
                                .executes(c -> {
                                    class_3222 t = class_2186.method_9315(c, "player");
                                    int amount = IntegerArgumentType.getInteger(c, "amount");
                                    MetaServer.get().edit(t.method_5667(), p -> p.addXp("admin", amount));
                                    c.getSource().method_9226(() -> class_2561.method_43470("XP +" + amount + " → " + t.method_7334().getName()), true);
                                    return 1;
                                })))))
                .then(class_2170.method_9247("open").then(class_2170.method_9244("screen", StringArgumentType.word())
                        .suggests((c, b) -> { for (String s : List.of("profile", "wardrobe", "shop", "craft", "track", "upgrades", "leaderboard")) b.suggest(s); return b.buildFuture(); })
                        .executes(c -> {
                            MetaServer.get().open(c.getSource().method_9207().method_5667(), StringArgumentType.getString(c, "screen"));
                            return 1;
                        })))
                .then(class_2170.method_9247("reset").then(class_2170.method_9244("player", class_2186.method_9305())
                        .executes(c -> {
                            class_3222 t = class_2186.method_9315(c, "player");
                            MetaServer s = MetaServer.get();
                            s.edit(t.method_5667(), p -> {
                                p.xp.clear(); p.stats.view().keySet().stream().toList().forEach(k -> p.stats.set(k, 0));
                                p.wallet.view().keySet().stream().toList().forEach(k -> p.wallet.set(k, 0));
                                p.materials.clear(); p.owned.clear(); p.unseen.clear(); p.claimed.clear();
                                p.upgradePoints = 0; p.upgrades.clear();
                                p.wardrobe = new dev.shaurmalib.meta.cosmetics.Wardrobe();
                            });
                            s.onLeave(t.method_5667());
                            onJoin(t);
                            c.getSource().method_9226(() -> class_2561.method_43470("Профіль скинуто: " + t.method_7334().getName()), true);
                            return 1;
                        })));
    }

    private static int give(class_2168 src, class_3222 target, Reward r) {
        MetaServer s = MetaServer.get();
        if (s == null) { src.method_9213(class_2561.method_43470("Мета-двигун не запущено")); return 0; }
        if (r.type() == Reward.Type.COSMETIC && s.mode.cosmetics.get(r.id()) == null) {
            src.method_9213(class_2561.method_43470("Нема такої косметики: " + r.id()));
            return 0;
        }
        s.grant(target.method_5667(), "Від адміністратора", r);
        src.method_9226(() -> class_2561.method_43470("Видано " + r.type() + " " + r.id() + " ×" + r.amount() + " → " + target.method_7334().getName()), true);
        return 1;
    }
}
