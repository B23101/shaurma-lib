package dev.shaurmalib.meta.mc.render;

import dev.shaurmalib.meta.client.MetaClient;
import dev.shaurmalib.meta.cosmetics.CosmeticDef;
import dev.shaurmalib.meta.cosmetics.CosmeticSlot;
import dev.shaurmalib.meta.cosmetics.Look;
import dev.shaurmalib.meta.cosmetics.Worn;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_591;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_7923;
import net.minecraft.class_811;
import net.minecraft.class_976;

/**
 * Рендер косметики (перенесено з мафії й узагальнено під будь-який каталог):
 * <ul>
 *   <li>капелюх і предмет на спині — шар моделі гравця ({@link Layer});</li>
 *   <li>улюбленець і аура — окремо у світі: улюбленець має власну позицію, що плавно «доганяє» точку біля
 *       голови (експоненційне згладжування, незалежне від FPS), відстає при бігу й нахиляється за рухом;</li>
 *   <li>у прев'ю гардероба — усе на манекені ({@link #preview}).</li>
 * </ul>
 * Колір предмета передається через NBT {@code CosmeticColor} — його читає відтінок, який лоадер реєструє
 * для всіх моделей каталогу.
 */
public final class CosmeticRenderer {

    public static final String COLOR_TAG = "CosmeticColor";

    private static final Map<UUID, PetState> PETS = new HashMap<>();
    private static final Map<UUID, Float> AURAS = new HashMap<>();
    private static final Map<Long, class_1799> STACKS = new HashMap<>();
    private static final Random RND = new Random();
    private static long auraNanos = System.nanoTime();

    /** Прев'ю гардероба: що малювати на манекені (null — звичайний рендер). */
    public static Look preview;
    public static boolean drawingPreview;
    public static float previewLift, previewLean, previewYaw, previewTilt;

    private static final class PetState {
        double x, y, z, lastX, lastZ;
        float yaw, roll, pitch, appear;
        long lastNanos;
    }

    private CosmeticRenderer() {}

    public static void reset() {
        PETS.clear();
        AURAS.clear();
        STACKS.clear();
        preview = null;
        drawingPreview = false;
    }

    static Look lookOf(class_742 p) {
        if (drawingPreview) return preview;
        return MetaClient.look(p.method_5667());
    }

    private static boolean hidden(class_742 p) {
        return p.method_7325() || p.method_5767() || !p.method_5805();
    }

    /** Чи щось на спині (тоді плащ варто сховати — міксин режиму може спитати це). */
    public static boolean wearsBackItem(class_742 p) {
        Look l = lookOf(p);
        return l != null && l.has(CosmeticSlot.BACK);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Тік: частинки аур
    // ══════════════════════════════════════════════════════════════════════

    public static void clientTick() {
        class_310 mc = class_310.method_1551();
        class_638 level = mc.field_1687;
        if (level == null) { PETS.clear(); AURAS.clear(); return; }
        PETS.keySet().removeIf(id -> level.method_18470(id) == null);
        AURAS.keySet().removeIf(id -> level.method_18470(id) == null);
        if (mc.field_1724 == null) return;
        for (class_742 p : level.method_18456()) {
            Look look = MetaClient.look(p.method_5667());
            Worn aura = look == null ? null : look.get(CosmeticSlot.AURA);
            if (aura == null || hidden(p) || p.method_5858(mc.field_1724) > 1024) continue;
            if (p == mc.field_1724 && mc.field_1690.method_31044().method_31034()) continue;
            AuraRenderer.particles(level, p.method_23317(), p.method_23318(), p.method_23321(), aura.color, aura.param(CosmeticSlot.AURA, "scale"), RND, auraType(aura));
        }
    }

    static int auraType(Worn w) {
        var mode = MetaClient.mode();
        CosmeticDef d = mode == null ? null : mode.cosmetics.get(w.item);
        return d == null ? 0 : d.auraType();
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Світ: улюбленці й аури (подія «після сутностей»)
    // ══════════════════════════════════════════════════════════════════════

    public static void renderWorld(class_4587 m, class_4597 buffers, class_243 cam, float partial) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) return;
        long now = System.nanoTime();
        for (class_742 p : mc.field_1687.method_18456()) {
            Look look = MetaClient.look(p.method_5667());
            boolean hide = hidden(p) || p.method_5707(cam) > 4096;
            Worn aura = look == null ? null : look.get(CosmeticSlot.AURA);
            if (aura != null && !hide) renderAura(mc, buffers, m, cam, p, aura, partial, now);
            else AURAS.remove(p.method_5667());
            Worn pet = look == null ? null : look.get(CosmeticSlot.PET);
            if (pet == null || hide) { PETS.remove(p.method_5667()); continue; }
            renderPet(mc, buffers, m, cam, p, pet, partial, now);
        }
        auraNanos = now;
    }

    private static void renderAura(class_310 mc, class_4597 buffers, class_4587 m, class_243 cam, class_742 p,
                                   Worn aura, float partial, long now) {
        float dt = class_3532.method_15363((now - auraNanos) / 1e9f, 0f, .1f);
        float appear = Math.min(1f, AURAS.getOrDefault(p.method_5667(), 0f) + dt * 1.1f);
        AURAS.put(p.method_5667(), appear);
        double px = class_3532.method_16436(partial, p.field_6014, p.method_23317()), py = class_3532.method_16436(partial, p.field_6036, p.method_23318()), pz = class_3532.method_16436(partial, p.field_5969, p.method_23321());
        double dx = px - cam.field_1352, dy = py - cam.field_1351, dz = pz - cam.field_1350;
        m.method_22903();
        m.method_22904(dx, dy, dz);
        AuraRenderer.draw(auraType(aura), m, buffers.getBuffer(MetaRenderTypes.GLOW), mc.field_1687.method_8510() + partial,
                aura.color, aura.param(CosmeticSlot.AURA, "scale"), appear, dx * dx + dy * dy + dz * dz < 576,
                p == mc.field_1724 && mc.field_1690.method_31044().method_31034());
        m.method_22909();
    }

    private static void renderPet(class_310 mc, class_4597 buffers, class_4587 m, class_243 cam, class_742 p,
                                  Worn pet, float partial, long now) {
        class_1792 item = item(pet.item);
        if (item == null) return;
        PetState s = PETS.get(p.method_5667());
        double px = class_3532.method_16436(partial, p.field_6014, p.method_23317()), py = class_3532.method_16436(partial, p.field_6036, p.method_23318()), pz = class_3532.method_16436(partial, p.field_5969, p.method_23321());
        float bodyYaw = class_3532.method_17821(partial, p.field_6220, p.field_6283);
        boolean fresh = s == null;
        if (fresh) {
            s = new PetState();
            s.yaw = bodyYaw;
            s.lastNanos = now;
            PETS.put(p.method_5667(), s);
        }
        float dt = class_3532.method_15363((now - s.lastNanos) / 1e9f, 0f, .1f);
        s.lastNanos = now;
        float bx = pet.param(CosmeticSlot.PET, "x"), by = pet.param(CosmeticSlot.PET, "y"), bz = pet.param(CosmeticSlot.PET, "z");
        float bob = pet.param(CosmeticSlot.PET, "bob"), speed = pet.param(CosmeticSlot.PET, "speed"), scale = pet.param(CosmeticSlot.PET, "scale");

        s.yaw += class_3532.method_15393(bodyYaw - s.yaw) * (1f - (float) Math.exp(-dt * 5.5f));
        double rad = Math.toRadians(s.yaw), cos = Math.cos(rad), sin = Math.sin(rad);
        double phase = (mc.field_1687.method_8510() + partial) * .075 * speed;
        double b = Math.sin(phase) * bob, drift = Math.sin(phase * .55 + 1.3) * bob * .35;
        double tx = px + (bx + drift) * cos - bz * sin, ty = py + by + b, tz = pz + (bx + drift) * sin + bz * cos;
        if (fresh || Math.abs(tx - s.x) + Math.abs(tz - s.z) + Math.abs(ty - s.y) > 24) {
            s.x = tx; s.y = ty; s.z = tz; s.lastX = tx; s.lastZ = tz;
        }
        float kh = 1f - (float) Math.exp(-dt * 9f), kv = 1f - (float) Math.exp(-dt * 14f);
        s.x += (tx - s.x) * kh;
        s.z += (tz - s.z) * kh;
        s.y += (ty - s.y) * kv;
        double vx = dt > 1e-4 ? (s.x - s.lastX) / dt : 0, vz = dt > 1e-4 ? (s.z - s.lastZ) / dt : 0;
        s.lastX = s.x;
        s.lastZ = s.z;
        double forward = vx * -sin + vz * cos, lateral = vx * cos + vz * sin;
        float wantPitch = (float) class_3532.method_15350(forward * 4.0, -14, 14);
        float wantRoll = (float) class_3532.method_15350(lateral * 4.0, -14, 14) + (float) (Math.sin(phase * .7) * 3.0);
        float kt = 1f - (float) Math.exp(-dt * 7f);
        s.pitch += (wantPitch - s.pitch) * kt;
        s.roll += (wantRoll - s.roll) * kt;
        s.appear = Math.min(1f, s.appear + dt * 2.6f);

        double dx = s.x - cam.field_1352, dy = s.y - cam.field_1351, dz = s.z - cam.field_1350;
        if (p == mc.field_1724 && dx * dx + dy * dy + dz * dz < .5) return;
        int light = mc.method_1561().method_23839(p, partial);
        light = class_765.method_23687(Math.max(class_765.method_24186(light), 11), class_765.method_24187(light));
        float sc = scale * easeOutBack(s.appear);
        m.method_22903();
        m.method_22904(dx, dy, dz);
        m.method_22907(class_7833.field_40716.rotationDegrees(180f - s.yaw));
        m.method_22907(class_7833.field_40718.rotationDegrees(s.roll));
        m.method_22907(class_7833.field_40714.rotationDegrees(-s.pitch));
        m.method_22905(sc, sc, sc);
        draw(m, buffers, light, p, item, pet.color, class_811.field_4315);
        m.method_22909();
    }

    /** Центр предмета на спині від центра тулуба (у блоках, +z — назад). */
    public static double backCenterZ(Worn back) {
        return .129 + back.param(CosmeticSlot.BACK, "z") + .375 * back.param(CosmeticSlot.BACK, "scale");
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Шар моделі гравця
    // ══════════════════════════════════════════════════════════════════════

    public static final class Layer extends class_3887<class_742, class_591<class_742>> {

        public Layer(class_3883<class_742, class_591<class_742>> parent) { super(parent); }

        @Override
        public void render(class_4587 m, class_4597 v, int light, class_742 p, float limbSwing,
                           float limbSwingAmount, float partial, float age, float headYaw, float headPitch) {
            boolean ui = drawingPreview;
            if (!ui && hidden(p)) return;
            Look look = lookOf(p);
            if (look == null || look.isEmpty()) return;

            Worn hat = look.get(CosmeticSlot.HEAD);
            class_1792 hatItem = hat == null ? null : item(hat.item);
            if (hatItem != null) {
                float sc = hat.param(CosmeticSlot.HEAD, "scale");
                m.method_22903();
                method_17165().field_3398.method_22703(m);
                m.method_46416(0, -hat.param(CosmeticSlot.HEAD, "y"), 0);
                class_976.method_32798(m, false);
                m.method_22905(sc, sc, sc);
                draw(m, v, light, p, hatItem, hat.color, class_811.field_4316);
                m.method_22909();
            }
            Worn back = look.get(CosmeticSlot.BACK);
            class_1792 backItem = back == null ? null : item(back.item);
            if (backItem != null) {
                // Простір тулуба перевернутий: +z — назад, y — вниз. (s,-s,-s) ставить предмет сторчма,
                // поворот на 180° кладе лямки до спини.
                float s = back.param(CosmeticSlot.BACK, "scale");
                m.method_22903();
                method_17165().field_3391.method_22703(m);
                m.method_22904(0, .375 - back.param(CosmeticSlot.BACK, "y"), backCenterZ(back));
                m.method_22905(s, -s, -s);
                m.method_22907(class_7833.field_40716.rotationDegrees(180f));
                draw(m, v, light, p, backItem, back.color, class_811.field_4315);
                m.method_22909();
            }
            for (CosmeticSlot extra : new CosmeticSlot[]{CosmeticSlot.BODY, CosmeticSlot.LEGS}) {
                Worn w = look.get(extra);
                class_1792 it = w == null ? null : item(w.item);
                if (it == null) continue;
                float s = w.param(extra, "scale");
                m.method_22903();
                (extra == CosmeticSlot.BODY ? method_17165().field_3391 : method_17165().field_3392).method_22703(m);
                m.method_22904(0, extra == CosmeticSlot.BODY ? .375 : .375, 0);
                m.method_22905(s, -s, -s);
                draw(m, v, light, p, it, w.color, class_811.field_4315);
                m.method_22909();
            }
            if (ui) previewExtras(m, v, p, look, partial);
        }
    }

    /** У прев'ю аура й улюбленець малюються прямо на манекені (у світі його нема). */
    private static void previewExtras(class_4587 m, class_4597 v, class_742 p, Look look, float partial) {
        Worn aura = look.get(CosmeticSlot.AURA);
        if (aura != null) {
            m.method_22903();
            m.method_22904(0, 1.501, 0);
            m.method_22905(-1f, -1f, 1f);
            m.method_22907(class_7833.field_40716.rotationDegrees(-(previewYaw + 180f)));
            m.method_22907(class_7833.field_40714.rotationDegrees((float) Math.toDegrees(previewTilt)));
            AuraRenderer.draw(auraType(aura), m, v.getBuffer(MetaRenderTypes.GLOW), p.field_6012 + partial, aura.color,
                    aura.param(CosmeticSlot.AURA, "scale"), 1f, true, false);
            m.method_22909();
        }
        Worn pet = look.get(CosmeticSlot.PET);
        class_1792 petItem = pet == null ? null : item(pet.item);
        if (petItem != null) {
            double phase = (p.field_6012 + partial) * .075 * pet.param(CosmeticSlot.PET, "speed");
            double bob = Math.sin(phase) * pet.param(CosmeticSlot.PET, "bob");
            float s = pet.param(CosmeticSlot.PET, "scale");
            m.method_22903();
            m.method_22904(pet.param(CosmeticSlot.PET, "x"), 1.501 - pet.param(CosmeticSlot.PET, "y") - bob - previewLift,
                    -pet.param(CosmeticSlot.PET, "z"));
            m.method_22907(class_7833.field_40718.rotationDegrees(-(float) Math.sin(phase * .7) * 3f));
            m.method_22907(class_7833.field_40714.rotationDegrees(previewLean));
            m.method_22905(-s, -s, s);
            draw(m, v, class_765.field_32767, p, petItem, pet.color, class_811.field_4315);
            m.method_22909();
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Предмети
    // ══════════════════════════════════════════════════════════════════════

    public static class_1792 item(String id) {
        var mode = MetaClient.mode();
        CosmeticDef d = mode == null ? null : mode.cosmetics.get(id);
        if (d == null || d.model().isEmpty()) return null;
        class_2960 rl = class_2960.method_12829(d.model());
        if (rl == null) return null;
        class_1792 it = class_7923.field_41178.method_10223(rl);
        return it == class_1802.field_8162 ? null : it;
    }

    public static class_1799 stack(class_1792 item, int color) {
        long key = ((long) System.identityHashCode(item) << 32) | (color & 0xFFFFFFL);
        return STACKS.computeIfAbsent(key, k -> {
            class_1799 st = new class_1799(item);
            st.method_7948().method_10569(COLOR_TAG, color & 0xFFFFFF);
            return st;
        });
    }

    /** Відтінок для реєстрації в лоадері: {@code (stack, tintIndex) -> колір}. */
    public static int tint(class_1799 stack) {
        return stack.method_7985() && stack.method_7969().method_10545(COLOR_TAG) ? stack.method_7969().method_10550(COLOR_TAG) : 0xFFFFFF;
    }

    static void draw(class_4587 m, class_4597 v, int light, class_742 p, class_1792 item, int color, class_811 ctx) {
        class_310.method_1551().method_1480().method_23177(p, stack(item, color), ctx, false, m, v, p.method_37908(), light,
                class_4608.field_21444, p.method_5628());
    }

    private static float easeOutBack(float t) {
        float c1 = 1.70158f, c3 = c1 + 1f, u = t - 1f;
        return 1f + c3 * u * u * u + c1 * u * u;
    }
}
