package dev.shaurmalib.meta.mc.render;

import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;

/**
 * Шари рендера мета-двигуна. Наслідуємо RenderType лише заради доступу до захищених станів.
 * <ul>
 *   <li>{@link #GLOW} — аури: адитивне світіння БЕЗ запису глибини (з глибиною півпрозорий стовп аури
 *       працював як невидима стіна й ховав усе, що малювалось після нього);</li>
 *   <li>{@link #PLUS} — плюсики хілу: непрозорі «світні» кубики з глибиною, без освітлення світу.</li>
 * </ul>
 */
public final class MetaRenderTypes extends class_1921 {

    public static final class_1921 GLOW = class_1921.method_24049("shaurma_meta_glow",
            class_290.field_1576, class_293.class_5596.field_27382, 256, false, false,
            class_4688.method_23598()
                    .method_34578(field_29429)
                    .method_23616(field_21350)
                    .method_23615(field_21367)
                    .method_23617(false));

    public static final class_1921 PLUS = class_1921.method_24049("shaurma_meta_plus",
            class_290.field_1576, class_293.class_5596.field_27382, 1024, false, true,
            class_4688.method_23598()
                    .method_34578(field_29442)
                    .method_23615(field_21370)
                    .method_23603(field_21345)
                    .method_23616(field_21349)
                    .method_23617(false));

    private MetaRenderTypes() {
        super("shaurma_meta_dummy", class_290.field_1576, class_293.class_5596.field_27382, 256, false, false, () -> { }, () -> { });
    }
}
