package dev.shaurmalib.meta.mc;

import dev.shaurmalib.meta.client.MetaClient;
import dev.shaurmalib.meta.fx.PlusBurst;
import dev.shaurmalib.meta.mc.hud.CompassHud;
import dev.shaurmalib.meta.mc.render.CosmeticRenderer;
import dev.shaurmalib.meta.mc.render.HealPlusRenderer;
import dev.shaurmalib.meta.mc.screen.MetaScreen;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

/**
 * Клієнтський клей мета-двигуна для 1.20.1: лоадер викликає ці методи зі своїх подій
 * (HUD, рендер світу після сутностей, тік, вихід із сервера).
 */
public final class McMetaClient {

    /** Колір плюсиків хілу за замовчуванням. */
    public static final int HEAL_GREEN = 0x4CFF6A;

    private McMetaClient() {}

    public static void init() {
        MetaClient.setUi(MetaScreens.INSTANCE);
    }

    public static void onHud(class_332 g, float partial) {
        CompassHud.render(g, partial);
        class_310 mc = class_310.method_1551();
        if (!(mc.field_1755 instanceof MetaScreen)) MetaScreens.renderToasts(g, g.method_51421(), g.method_51443());
    }

    public static void onWorld(class_4587 pose, class_4597 buffers, class_243 cam, float partial) {
        CosmeticRenderer.renderWorld(pose, buffers, cam, partial);
        HealPlusRenderer.render(pose, buffers, cam);
    }

    public static void onTick() { CosmeticRenderer.clientTick(); }

    public static void onDisconnect() {
        MetaClient.reset();
        CosmeticRenderer.reset();
    }

    /** Клієнтський сплеск плюсиків над сутністю (без пакета — для локальних ефектів). */
    public static void healBurst(class_1297 e, int count) {
        PlusBurst.spawn(e.method_23317(), e.method_23318() + e.method_17682() * .55, e.method_23321(), count, HEAL_GREEN, e.method_17681() * .9);
    }
}
