package dev.shaurmalib.meta.cosmetics;

import dev.shaurmalib.meta.io.J;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Гардероб гравця: окремий образ на кожен «варіант» режиму (мафія — «Гравець»; маніяк — «Виживий» і «Маніяк»)
 * плюс {@link #PRESETS} збережених образів. Який варіант зараз на гравці — вирішує сервер режиму
 * ({@code MetaServer#setVariant}), а не клієнт.
 */
public final class Wardrobe {

    public static final int PRESETS = 3;

    private final Map<String, Look> looks = new LinkedHashMap<>();
    private final Look[] presets = new Look[PRESETS];
    private final String[] presetNames = new String[PRESETS];

    public static final int NAME_MAX = 24;

    public Look look(String variant) { return looks.computeIfAbsent(variant, k -> new Look()); }

    public void setLook(String variant, Look look) { looks.put(variant, look == null ? new Look() : look); }

    public Look preset(int slot) { return slot >= 0 && slot < PRESETS ? presets[slot] : null; }

    public void setPreset(int slot, Look look) {
        if (slot < 0 || slot >= PRESETS) return;
        presets[slot] = look;
        if (look == null) presetNames[slot] = null;
    }

    /** Зберегти образ під вигаданою назвою. */
    public void setPreset(int slot, Look look, String name) {
        setPreset(slot, look);
        if (slot >= 0 && slot < PRESETS && look != null) presetNames[slot] = cleanName(name);
    }

    /** Назва образу; порожньо — без назви. */
    public String presetName(int slot) {
        return slot >= 0 && slot < PRESETS && presetNames[slot] != null ? presetNames[slot] : "";
    }

    /** Без керівних символів і крайніх пробілів, не довше {@link #NAME_MAX} (діє й на сервері, тож чужий клієнт не вставить сміття). */
    public static String cleanName(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length() && b.length() < NAME_MAX * 2; i++) {
            char c = s.charAt(i);
            if (c >= 32 && c != 127) b.append(c);
        }
        String t = b.toString().trim();
        return t.length() > NAME_MAX ? t.substring(0, NAME_MAX).trim() : t;
    }

    public Map<String, Look> looks() { return java.util.Collections.unmodifiableMap(looks); }

    public Wardrobe copy() {
        Wardrobe w = new Wardrobe();
        looks.forEach((k, v) -> w.looks.put(k, v.copy()));
        for (int i = 0; i < PRESETS; i++) { w.presets[i] = presets[i] == null ? null : presets[i].copy(); w.presetNames[i] = presetNames[i]; }
        return w;
    }

    public void validate(CosmeticCatalog catalog, java.util.function.Predicate<String> owned, List<String> variants) {
        validate(catalog, owned, variants, null);
    }

    public void validate(CosmeticCatalog catalog, java.util.function.Predicate<String> owned, List<String> variants,
                         java.util.function.BiPredicate<String, Integer> colorOwned) {
        looks.keySet().removeIf(k -> !variants.contains(k));
        for (Look l : looks.values()) l.validate(catalog, owned, colorOwned);
        for (Look p : presets) if (p != null) p.validate(catalog, null);
    }

    /** Прибрати з образів слоти, не дозволені варіанту (маніяк не носить тіло й ноги). */
    public void restrict(java.util.function.Function<String, ? extends java.util.Collection<CosmeticSlot>> allowed) {
        for (Map.Entry<String, Look> e : looks.entrySet()) {
            java.util.Collection<CosmeticSlot> ok = allowed.apply(e.getKey());
            for (CosmeticSlot s : CosmeticSlot.values()) if (!ok.contains(s)) e.getValue().remove(s);
        }
    }

    /** Зняти предмет з усіх образів (наприклад, якщо його прибрали з каталогу). */
    public void strip(String itemId) {
        for (Look l : looks.values()) l.view().entrySet().stream()
                .filter(e -> e.getValue().item.equals(itemId)).map(Map.Entry::getKey).toList().forEach(l::remove);
    }

    public Map<String, Object> toJson() {
        Map<String, Object> l = new LinkedHashMap<>();
        looks.forEach((k, v) -> l.put(k, v.toJson()));
        List<Object> p = new ArrayList<>();
        for (Look x : presets) p.add(x == null ? null : x.toJson());
        List<Object> names = new ArrayList<>();
        for (String n : presetNames) names.add(n == null ? "" : n);
        return J.o("looks", l, "presets", p, "presetNames", names);
    }

    public static Wardrobe fromJson(Map<String, Object> o) {
        Wardrobe w = new Wardrobe();
        for (Map.Entry<String, Object> e : J.obj(o, "looks").entrySet()) w.looks.put(e.getKey(), Look.fromJson(J.asObj(e.getValue())));
        List<Object> p = J.arr(o, "presets");
        for (int i = 0; i < Math.min(PRESETS, p.size()); i++) w.presets[i] = p.get(i) instanceof Map ? Look.fromJson(J.asObj(p.get(i))) : null;
        List<Object> names = J.arr(o, "presetNames");
        for (int i = 0; i < Math.min(PRESETS, names.size()); i++) {
            if (w.presets[i] != null && names.get(i) instanceof String n && !cleanName(n).isEmpty()) w.presetNames[i] = cleanName(n);
        }
        return w;
    }
}
