package dev.shaurmalib.meta.mc.screen;

import dev.shaurmalib.meta.client.MetaClient;
import dev.shaurmalib.meta.cosmetics.CosmeticDef;
import dev.shaurmalib.meta.cosmetics.CosmeticSlot;
import dev.shaurmalib.meta.cosmetics.Look;
import dev.shaurmalib.meta.cosmetics.ParamSpec;
import dev.shaurmalib.meta.cosmetics.Wardrobe;
import dev.shaurmalib.meta.cosmetics.Worn;
import dev.shaurmalib.meta.economy.Currency;
import dev.shaurmalib.meta.economy.Recipe;
import dev.shaurmalib.meta.economy.Reward;
import dev.shaurmalib.meta.economy.ShopOffer;
import dev.shaurmalib.meta.mc.MetaScreens;
import dev.shaurmalib.meta.mc.render.CosmeticRenderer;
import dev.shaurmalib.meta.mc.skin.MetaSkin;
import dev.shaurmalib.meta.mc.ui.MetaIcons;
import dev.shaurmalib.meta.mc.ui.MetaUi;
import dev.shaurmalib.meta.profile.MetaProfile;
import org.joml.Quaternionf;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.class_1664;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_745;

/**
 * Гардероб (перенесено з мафії й зроблено керованим даними — працює з каталогом будь-якого режиму).
 * Каталог ліворуч, примірка посередині, налаштування праворуч, пресети. Жодних повзунків — усе прямо на моделі:
 * <ul>
 *   <li>ЛКМ на вільному місці — обертання; ПКМ — пересунути модель; колесо поза предметом — масштаб;</li>
 *   <li>ЛКМ на предметі й тягнути — посадка (Shift — уперед/назад для улюбленця);</li>
 *   <li>колесо над предметом — розмір (Ctrl — розмах польоту, Alt — швидкість).</li>
 * </ul>
 * Невласні предмети видно із замком і ціною: купити, скрафтити або «на доріжці, рівень N».
 * Зміни зберігаються самі за 0.8 с (сервер ще раз перевіряє межі й володіння).
 *
 * <p><b>Анімації примірки</b> (усе — лише на головному манекені):
 * <ul>
 *   <li><i>Одягання</i> ({@link #startEquip}): приготування → персонаж злітає, обертаючись, а довкола крутиться аура-орбіта →
 *       зависає → падає, удар об підлогу (хвиля, струс, спалах) → оглядає себе (повороти тулуба, голова вниз).</li>
 *   <li><i>Падіння на місце</i>: обраний предмет висить над своїм місцем і падає з двома відскоками
 *       ({@code CosmeticRenderer.fallCurve}); улюбленець і рюкзак підлітають збоку, аура розростається.</li>
 *   <li><i>«Схопив»</i>: поки предмет тягнеш — він піднятий, трохи більший і гойдається за рухом руки; відпустив — лягає назад з відскоком.</li>
 *   <li>Манекен дихає вертикальним рухом ({@code Preview.breathOffset}); у польоті дихання вимкнене.</li>
 * </ul></p>
 */
public class WardrobeScreen extends MetaScreen {

    private static final int VX = 446, VY = 84, VW = 284, VH = 374;
    private static final int VCX = VX + VW / 2, VFY = 438;
    private static final float BASE = 122f;
    private static final int PRESETS_TAB = -1;

    private final Wardrobe wardrobe;
    private String variant;
    private class_745 mannequin;
    /** Індекс у CosmeticSlot.values() або {@link #PRESETS_TAB}. */
    private int cat = CosmeticSlot.HEAD.ordinal();
    private CosmeticDef selected;
    private int selectedPreset = -1;
    private float yaw = 160, panX, panY, zoom = 1, yawGoal = Float.NaN;
    private boolean moving, changed;
    private int drag;
    private float saveAt, jumpStart = -10f, curLift, curLean, catTime, selY;
    private int scroll;
    /** Відтінок, який приміряють, але ще не купили (-1 — нема), і колір, що був до примірки. */
    private int pendingColor = -1, prevColor;

    // Діалог назви образу
    private boolean naming, nameFresh;
    private int namingSlot;
    private final StringBuilder nameBuf = new StringBuilder();

    // ── Анімації примірки ────────────────────────────────────────────────
    private static final int N_SLOTS = CosmeticSlot.values().length;
    private static final float EQUIP_LEN = 3.2f, DROP_LEN = .85f;
    private static final float T_DIP = .22f, T_RISE = 1.45f, T_FALL = 1.80f, T_LAND = 2.10f, T_LOOK = 2.25f;
    private static final float FLY_H = .62f;
    /** Коли (у секундах екрана) предмет слота почав/почне падати; велике мінусове — не падає. */
    private final float[] dropStart = new float[N_SLOTS];
    private final float[] dropAmp = new float[N_SLOTS], dropOut = new float[N_SLOTS], dropPrevU = new float[N_SLOTS];
    private float equipStart = -10f, eLift, eYaw, eHeadYaw, eHeadPitch, ePrevLift, landShake, shockT = -10f;
    private int equipColor;
    private boolean landed;
    private float grab, dragVx;
    /** Куди дивиться фігура у вікні (для орбіти й хвилі): центр, ноги, розмір. */
    private float figCx, figFoot, figSize;

    private String presetTitle(int slot) {
        String n = wardrobe.presetName(slot);
        return n.isEmpty() ? "ОБРАЗ " + (slot + 1) : n;
    }

    private void startNaming(int slot) {
        naming = true;
        namingSlot = slot;
        nameBuf.setLength(0);
        String cur = wardrobe.presetName(slot);
        nameBuf.append(cur.isEmpty() ? "Образ " + (slot + 1) : cur);
        nameFresh = true;   // перша ж літера замінює пропозицію, а не дописується до неї
    }

    /** «Зберегти» з шапки: перший вільний слот, інакше вибраний образ, інакше перший. */
    private void quickSave() {
        int slot = -1;
        for (int i = 0; i < Wardrobe.PRESETS && slot < 0; i++) if (wardrobe.preset(i) == null) slot = i;
        if (slot < 0) slot = selectedPreset >= 0 ? selectedPreset : 0;
        click();
        startNaming(slot);
    }

    private void confirmNaming() {
        String name = Wardrobe.cleanName(nameBuf.toString());
        if (name.isEmpty()) name = "Образ " + (namingSlot + 1);
        wardrobe.setPreset(namingSlot, look().copy(), name);
        naming = false;
        dirty();
        click();
        say("Образ «" + name + "» збережено", false);
    }

    private void typeInto(String text) {
        if (nameFresh && !text.isEmpty()) { nameBuf.setLength(0); nameFresh = false; }
        for (int i = 0; i < text.length() && nameBuf.length() < Wardrobe.NAME_MAX; i++) {
            char c = text.charAt(i);
            if (c >= 32 && c != 127) nameBuf.append(c);
        }
    }

    private void drawNaming(class_332 g) {
        if (!naming) return;
        zone(0, 0, DW, DH, () -> { });   // перший у списку = останній у пріоритеті: ловить усе, що не кнопки діалогу
        g.method_25294(0, 0, DW, DH, MetaUi.a(0, .6f));
        int w = 300, h = 132, x = (DW - w) / 2, y = (DH - h) / 2;
        panel(g, x, y, w, h, true);
        MetaUi.text(g, field_22793, "ЗБЕРЕГТИ ОБРАЗ", x + 16, y + 14, MetaUi.solid(theme.text()), true);
        MetaUi.textS(g, field_22793, "Назва", x + 16, y + 36, .85f, MetaUi.solid(theme.dim()), false);
        MetaUi.textR(g, field_22793, nameBuf.length() + " / " + Wardrobe.NAME_MAX, x + w - 16, y + 36, MetaUi.solid(theme.dim()), false);
        panel(g, x + 16, y + 48, w - 32, 24, false);
        Look old = wardrobe.preset(namingSlot);
        MetaUi.textS(g, field_22793, "Слот " + (namingSlot + 1) + (old == null ? " · вільний" : " · замінить «" + MetaUi.fit(field_22793, presetTitle(namingSlot), 120) + "»"),
                x + 16, y + 76, .75f, MetaUi.solid(old == null ? theme.dim() : theme.gold()), false);
        boolean caret = ((int) (time * 2f) & 1) == 0;
        MetaUi.text(g, field_22793, nameBuf + (caret ? "_" : ""), x + 24, y + 56, MetaUi.solid(theme.text()), false);
        button(g, "nameOk", x + 16, y + 88, 132, 28, "ЗБЕРЕГТИ", MetaSkin.Kind.PRIMARY, this::confirmNaming);
        button(g, "nameNo", x + w - 148, y + 88, 132, 28, "СКАСУВАТИ", MetaSkin.Kind.NORMAL, () -> { naming = false; click(); });
    }

    private static final class Spark { float x, y, vx, vy, life, max, size, grav; int rgb; }
    private final List<Spark> sparks = new ArrayList<>();
    private final Random rnd = new Random();
    private float ambient, flash, auraMix;

    public WardrobeScreen(class_437 parent) {
        super("Гардероб", parent);
        MetaProfile p = me();
        wardrobe = p == null ? new Wardrobe() : p.wardrobe.copy();
        variant = mode == null ? "player" : mode.variants.get(0);
        selected = first(slot());
        java.util.Arrays.fill(dropStart, -10f);
        java.util.Arrays.fill(dropPrevU, 1f);
    }

    @Override protected String section() { return "wardrobe"; }

    private CosmeticSlot slot() { return cat == PRESETS_TAB ? null : CosmeticSlot.values()[cat]; }

    private Look look() { return wardrobe.look(variant); }

    /** Слоти, дозволені поточному варіанту (маніяк: без тіла й ніг). */
    private List<CosmeticSlot> allowed() { return mode == null ? List.of(CosmeticSlot.values()) : mode.slots(variant); }

    /** Після зміни варіанта: якщо відкрита вкладка недозволена — перейти на першу дозволену. */
    private void ensureSlot() {
        if (cat == PRESETS_TAB) return;
        List<CosmeticSlot> a = allowed();
        if (a.contains(slot())) return;
        cat = a.isEmpty() ? PRESETS_TAB : a.get(0).ordinal();
        selected = cat == PRESETS_TAB ? null : first(slot());
        selectedPreset = -1;
        catTime = time;
        scroll = 0;
    }

    private boolean owns(CosmeticDef d) { MetaProfile p = me(); return p != null && p.owns(d.id()); }

    private List<CosmeticDef> pieces(CosmeticSlot s) {
        List<CosmeticDef> out = new ArrayList<>();
        if (mode == null || s == null) return out;
        for (CosmeticDef d : mode.cosmetics.bySlot(s)) if (!d.hidden() || owns(d)) out.add(d);
        // власні — першими
        out.sort((a, b) -> Boolean.compare(owns(b), owns(a)));
        return out;
    }

    private CosmeticDef first(CosmeticSlot s) {
        List<CosmeticDef> l = pieces(s);
        return l.isEmpty() ? null : l.get(0);
    }

    private boolean worn(CosmeticDef d) { Worn w = look().get(d.slot()); return w != null && w.item.equals(d.id()); }

    private void wear(CosmeticDef d, boolean on) {
        if (on && !owns(d)) { say("Цей предмет ще не твій", true); return; }
        if (on) {
            Worn prev = look().get(d.slot());
            Worn w = new Worn(d.id(), d.defaultColor());
            if (prev != null) w.params.putAll(prev.params);   // посадка лишається при заміні предмета
            w.validate(d.slot());
            look().put(d.slot(), w);
            startEquip(d);
        } else look().remove(d.slot());
        dirty();
        burstItem(on ? accent : theme.dim(), on ? 56 : 24);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Анімації
    // ══════════════════════════════════════════════════════════════════════

    /** Предмет висить над своїм місцем (на висоті {@code amp}, зі зсувом {@code out}) і через {@code delay} с падає на нього. */
    private void startDrop(CosmeticSlot s, float delay, float amp, float out) {
        int i = s.ordinal();
        dropStart[i] = time + delay;
        dropAmp[i] = amp;
        dropOut[i] = out;
        dropPrevU[i] = -1f;
    }

    /** Одягання: повна сцена, якщо попередня закінчилась; інакше лише падіння нового предмета (не перезапускаємо політ). */
    private void startEquip(CosmeticDef d) {
        boolean running = time - equipStart < EQUIP_LEN - .3f;
        equipColor = d.rarity().color;
        CosmeticSlot s = d.slot();
        // падає, коли персонаж біля верхньої точки польоту (або одразу, якщо сцена вже йде)
        dropFor(s, running ? .05f : T_RISE - .55f);
        if (!running) {
            equipStart = time;
            landed = false;
        }
    }

    private void dropFor(CosmeticSlot s, float delay) {
        switch (s) {
            case HEAD -> startDrop(s, delay, 1.05f, 0f);          // капелюх падає зверху
            case BACK -> startDrop(s, delay, .55f, .95f);         // рюкзак підлітає ззаду
            case PET -> startDrop(s, delay, 1.10f, .95f);         // улюбленець — збоку й згори
            case AURA -> startDrop(s, delay, 0f, 0f);             // аура розростається з підлоги
            default -> startDrop(s, delay, .6f, 0f);
        }
    }

    /** Весь образ одягнули одразу (застосували збережений): та сама сцена, предмети падають усі разом. */
    private void startOutfit() {
        equipColor = accent;
        equipStart = time;
        landed = false;
        for (CosmeticSlot s : look().view().keySet()) dropFor(s, T_RISE - .55f);
    }

    private static float easeInOut(float t) { t = MetaUi.clamp01(t); return t * t * (3f - 2f * t); }

    /** Поза й ефекти сцени одягання на момент {@code time}. */
    private void updateEquip() {
        ePrevLift = eLift;
        eLift = eYaw = eHeadYaw = eHeadPitch = 0f;
        float t = time - equipStart;
        boolean on = t >= 0f && t < EQUIP_LEN;
        if (on) {
            if (t < T_DIP) {
                eLift = -.05f * (float) Math.sin(Math.PI * t / T_DIP);                 // присів перед стрибком
            } else if (t < T_FALL) {
                float up = MetaUi.outCubic((t - T_DIP) / (T_RISE - T_DIP));            // злітає, сповільнюючись
                eLift = FLY_H * up + (t > T_RISE ? .018f * (float) Math.sin((t - T_RISE) * 6.5f) : 0f);   // у верхній точці — легке погойдування
                eYaw = 720f * easeInOut((t - T_DIP) / (T_FALL - T_DIP));                // два повних оберти за політ
            } else if (t < T_LAND) {
                float k = (t - T_FALL) / (T_LAND - T_FALL);
                eLift = FLY_H * (1f - k * k);                                           // падає з прискоренням
            } else if (t < T_LAND + .2f) {
                eLift = -.06f * (float) Math.sin(Math.PI * (t - T_LAND) / .2f);         // амортизація
            }
            if (!landed && t >= T_LAND) {
                landed = true;
                landShake = 1f;
                shockT = time;
                flash = Math.min(1f, flash + .9f);
                burst(figCx, figFoot, equipColor, 46, true);
                burst(figCx, figFoot, 0xFFFFFF, 16, true);
            }
            if (t >= T_LOOK) {                                                          // оглядає себе
                float u = (t - T_LOOK) / (EQUIP_LEN - T_LOOK);
                float env = (float) Math.sin(Math.PI * Math.min(1f, u * 1.05f));
                eYaw = 38f * (float) Math.sin(Math.PI * 2.0 * u) * (1f - .35f * u);
                eHeadYaw = -eYaw * .8f;
                eHeadPitch = 24f * env;
            }
        }
        landShake = Math.max(0f, landShake - dt * 3.2f);
        // у польоті не дихає: плавно вимикаємо
        Preview.breathMul = 1f - MetaUi.clamp01(Math.abs(eLift) / .12f);
    }

    /** Падіння предметів, «схопив» і нахил від руки — у спільні масиви рендера косметики. */
    private void updateItemAnim() {
        CosmeticRenderer.clearAnim();
        for (int i = 0; i < N_SLOTS; i++) {
            float u = (time - dropStart[i]) / DROP_LEN;
            float lift = 0f, out = 0f;
            if (dropStart[i] > time) { lift = dropAmp[i]; out = dropOut[i]; }          // чекає над місцем
            else if (u < 1f) {
                float f = CosmeticRenderer.fallCurve(u);
                lift = dropAmp[i] * f;
                out = dropOut[i] * MetaUi.clamp01(1f - u * 1.25f) * f;
                if (dropPrevU[i] < .62f && u >= .62f && dropPrevU[i] >= 0f) impact(CosmeticSlot.values()[i]);
            }
            dropPrevU[i] = dropStart[i] > time ? -1f : u;
            CosmeticRenderer.animLift[i] = lift;
            CosmeticRenderer.animOut[i] = out;
        }
        int ai = CosmeticSlot.AURA.ordinal();
        CosmeticRenderer.animAuraGrow = dropStart[ai] > time ? 0f : MetaUi.outBack(MetaUi.clamp01((time - dropStart[ai]) / (DROP_LEN * 1.4f)));

        // «схопив»: предмет у руці піднятий і гойдається, поки його тягнуть
        grab += ((drag == 3 ? 1f : 0f) - grab) * Math.min(1f, dt * 14f);
        dragVx *= (float) Math.exp(-dt * 7f);
        CosmeticSlot s = slot();
        if (s != null) {
            CosmeticRenderer.animGrab[s.ordinal()] = grab;
            CosmeticRenderer.animRoll[s.ordinal()] = Math.max(-26f, Math.min(26f, -dragVx * 2.2f)) * grab;
        }
    }

    /** Предмет торкнувся місця: маленький спалах у точці посадки. */
    private void impact(CosmeticSlot s) {
        double[] sp = itemSpot(s);
        if (sp == null) return;
        burst(sp[0], sp[1], s == CosmeticSlot.AURA ? equipColor : theme.gold(), 12, true);
        flash = Math.min(1f, flash + .25f);
    }

    /** Скасувати примірку некупленого відтінку: повернути колір, що був. */
    private void clearPending() {
        if (pendingColor < 0) return;
        if (selected != null) {
            Worn w = look().get(selected.slot());
            if (w != null && (w.color & 0xFFFFFF) == (pendingColor & 0xFFFFFF)) w.color = prevColor;
        }
        pendingColor = -1;
    }

    private void dirty() { changed = true; saveAt = time + .8f; }

    private void save() {
        if (!changed) return;
        changed = false;
        MetaClient.saveWardrobe(wardrobe);
    }

    private void markSeen(CosmeticDef d) {
        MetaProfile p = me();
        if (d != null && p != null && p.unseen.contains(d.id())) MetaClient.seen(List.of(d.id()));
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        if (mannequin == null && field_22787 != null && field_22787.field_1724 != null && field_22787.field_1687 != null) {
            mannequin = new class_745(field_22787.field_1687, field_22787.field_1724.method_7334()) {
                @Override public boolean method_7348(class_1664 part) { return true; }
                @Override public boolean method_7325() { return false; }   // інакше манекен з UUID спостерігача — лише голова
                @Override public boolean method_7337() { return false; }
            };
        }
    }

    @Override
    public void method_25393() {
        // ходьба рахується в draw() (див. walkTick)
    }

    private float walkAcc;

    /** Ходьба/спокій рахується в 20 Гц і з кадру, і з tick(): не залежить від того, чи екран отримує tick. */
    private void walkTick() {
        mannequin.field_6012++;
        mannequin.field_42108.method_48568(moving ? .8f : 0f, .5f);
    }

    @Override
    public void method_25419() {
        clearPending();
        save();
        CosmeticRenderer.preview = null;
        CosmeticRenderer.drawingPreview = false;
        CosmeticRenderer.clearAnim();
        Preview.breathMul = 1f;
        super.method_25419();
    }

    @Override
    public void method_25432() {
        clearPending();
        save();
        CosmeticRenderer.clearAnim();
        Preview.breathMul = 1f;
        super.method_25432();
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Рендер
    // ══════════════════════════════════════════════════════════════════════

    @Override
    protected void draw(class_332 g) {
        CosmeticSlot s = slot();
        if (changed && time >= saveAt) save();
        if (!Float.isNaN(yawGoal)) {
            if (drag == 1) yawGoal = Float.NaN;
            else {
                float d = class_3532.method_15393(yawGoal - yaw);
                yaw += d * Math.min(1f, dt * 6f);
                if (Math.abs(d) < .5f) yawGoal = Float.NaN;
            }
        }
        float u = (time - jumpStart) / .55f;
        float jumpH = 0, lift = 0;
        if (u >= 0 && u <= 1) { jumpH = 4f * .45f * u * (1f - u); lift = -(4f * .45f * (1f - 2f * u) / .55f) * .05f; }
        updateEquip();
        updateItemAnim();
        jumpH += eLift;
        lift += Math.max(-.35f, Math.min(.35f, -(eLift - ePrevLift) / Math.max(dt, 1e-3f) * .05f));
        curLift = lift;
        curLean += ((moving ? 9f : 0f) - curLean) * Math.min(1f, dt * 8f);
        auraMix += ((s == CosmeticSlot.AURA ? 1f : 0f) - auraMix) * Math.min(1f, dt * 5f);
        if (mannequin != null) {
            walkAcc += Math.min(dt, .1f);
            while (walkAcc >= .05f) { walkAcc -= .05f; walkTick(); }
            Preview.idle(mannequin, time, moving, eHeadYaw, eHeadPitch);   // жива поза: зсув ваги, голова роззирається, дихання (tickCount веде tick())
        }
        updateFx();
        drawHeader(g);
        drawLeft(g);
        drawViewport(g, jumpH, lift);
        drawRight(g);
        drawHints(g);
        drawFx(g);
        drawNaming(g);
    }

    private void drawHeader(class_332 g) {
        header(g, "ГАРДЕРОБ", "КОСМЕТИКА");
        int x = 446;
        if (mode != null && mode.variants.size() > 1) {
            // багато маніяків — кнопки стискаються, щоб не налізти на «РУХ · ХОДЬБА»; довгу назву кнопка вписує сама
            int avail = 590 - x, n = mode.variants.size();
            for (String v : mode.variants) {
                String name = mode.variantNames.getOrDefault(v, v).toUpperCase();
                int w = Math.min(field_22793.method_1727(name) + 24, Math.max(44, avail / n - 6));
                boolean act = v.equals(variant);
                button(g, "var" + v, x, 54, w, 20, name, act, () -> { if (!act) { clearPending(); variant = v; ensureSlot(); click(); burstItem(accent, 30); } });
                x += w + 6;
            }
        }
        button(g, "move", Math.max(x + 6, 600), 54, 120, 20, moving ? "РУХ · ХОДЬБА" : "РУХ · СПОКІЙ", moving, () -> { moving = !moving; click(); });
        button(g, "saveLook", 726, 54, 94, 20, "ЗБЕРЕГТИ", MetaSkin.Kind.PRIMARY, this::quickSave);
        button(g, "resetView", 826, 54, 120, 20, "R · СКИНУТИ ВИД", false, () -> { resetView(); click(); });
    }

    private void resetView() { yaw = 160; panX = panY = 0; zoom = 1; }

    // ── ліва панель ─────────────────────────────────────────────────────
    private void drawLeft(class_332 g) {
        panel(g, 14, 84, 424, 374, false);
        CosmeticSlot[] slots = allowed().toArray(new CosmeticSlot[0]);
        int rows = slots.length + 1;
        for (int i = 0; i < rows; i++) {
            final int idx = i < slots.length ? slots[i].ordinal() : PRESETS_TAB;
            String title = i < slots.length ? slots[i].title.toUpperCase() : "ОБРАЗИ";
            String icon = i < slots.length ? iconOf(slots[i]) : "preset";
            boolean act = idx == cat;
            int y = 96 + i * 34;
            float hv = hv("cat" + i, zone(22, y, 84, 28, () -> {
                if (cat != idx) {
                    clearPending();
                    cat = idx;
                    selected = idx == PRESETS_TAB ? null : first(CosmeticSlot.values()[idx]);
                    markSeen(selected);
                    selectedPreset = -1;
                    catTime = time;
                    scroll = 0;
                    yawGoal = idx == CosmeticSlot.BACK.ordinal() ? 300f : 160f;
                    click();
                }
            }));
            skin.tab(g, field_22793, 22, y, 84, 28, title, icon, act, hv);
            if (i < slots.length && hasUnseen(slots[i])) MetaUi.disc(g, 101, y + 5, 2, MetaUi.solid(theme.gold()));
        }
        g.method_25294(112, 96, 113, 446, MetaUi.a(theme.border(), .9f));

        String title = cat == PRESETS_TAB ? "ОБРАЗИ" : slot().title.toUpperCase();
        if (cat == PRESETS_TAB) {
            skin.sectionTitle(g, field_22793, 122, 96, 306, title, null, time);
            for (int i = 0; i < Wardrobe.PRESETS; i++) presetCard(g, i, 122 + i * 104, 120);
            button(g, "clearAll", 122, 258, 306, 26, "ЗНЯТИ ВСЕ", MetaSkin.Kind.DANGER, () -> {
                click();
                look().clear();
                selected = null;
                dirty();
                say("Усе знято", false);
            });
            return;
        }
        List<CosmeticDef> list = pieces(slot());
        int owned = 0;
        for (CosmeticDef d : list) if (owns(d)) owned++;
        skin.sectionTitle(g, field_22793, 122, 96, 306, title, owned + " / " + list.size(), time);
        if (list.isEmpty()) {
            MetaUi.text(g, field_22793, "Предметів поки немає", 122, 124, MetaUi.solid(theme.dim()), false);
            MetaUi.textS(g, field_22793, "Слідкуй за магазином і пропуском сезону.", 122, 138, .8f, MetaUi.a(theme.dim(), .7f), false);
            return;
        }
        int perRow = 3, maxRows = 2;
        int pages = (list.size() + perRow * maxRows - 1) / (perRow * maxRows);
        scroll = Math.max(0, Math.min(scroll, pages - 1));
        int start = scroll * perRow * maxRows;
        for (int i = start; i < Math.min(list.size(), start + perRow * maxRows); i++) {
            int k = i - start;
            pieceCard(g, list.get(i), 122 + (k % perRow) * 104, 120 + (k / perRow) * 134, k);
        }
        if (pages > 1) {
            MetaUi.textC(g, field_22793, (scroll + 1) + " / " + pages, 275, 434, MetaUi.solid(theme.dim()), false);
            button(g, "pgPrev", 122, 428, 40, 20, "<", false, scroll > 0 ? () -> { scroll--; catTime = time; click(); } : null);
            button(g, "pgNext", 388, 428, 40, 20, ">", false, scroll < pages - 1 ? () -> { scroll++; catTime = time; click(); } : null);
        }
    }

    private boolean hasUnseen(CosmeticSlot s) {
        MetaProfile p = me();
        if (p == null || p.unseen.isEmpty() || mode == null) return false;
        for (CosmeticDef d : mode.cosmetics.bySlot(s)) if (p.unseen.contains(d.id())) return true;
        return false;
    }

    static String iconOf(CosmeticSlot s) {
        return switch (s) { case HEAD -> "head"; case BODY -> "body"; case LEGS -> "legs"; case BACK -> "back"; case PET -> "pet"; case AURA -> "aura"; };
    }

    private void pieceCard(class_332 g, CosmeticDef d, int bx, int by, int idx) {
        int w = 98, h = 128, ph = 88;
        boolean sel = d == selected, own = owns(d);
        float hv = hv("card" + d.id(), zone(bx, by, w, h, () -> {
            click();
            if (d != selected) clearPending();
            selected = d;
            markSeen(d);
            if (own && !worn(d)) wear(d, true);
            else burstItem(accent, 18);
        }));
        float appear = MetaUi.outBack(MetaUi.clamp01((time - catTime - .1f - idx * .07f) / .45f));
        if (appear <= .02f) return;
        int x = bx, y = by + Math.round((1f - appear) * 24f);
        int rc = d.rarity().color;
        skin.card(g, x, y, w, h, rc, sel, hv, time);
        skin.stage(g, x + 2, y + 2, w - 4, ph, rc, time, hv);
        boolean au = d.slot() == CosmeticSlot.AURA;
        Worn w1 = worn(d) ? look().get(d.slot()).copy() : new Worn(d.id(), d.defaultColor());
        w1.validate(d.slot());
        figure(g, x + w / 2, y + (au ? 64 : 84), (au ? 28 : 32) + 2 * hv,
                faceYaw(d.slot()) + (float) Math.sin(time * 1.1 + idx) * 20f + hv * 35f, new Look().only(d.slot(), w1),
                x + 2, y + 2, w - 4, ph, 0, 0, au);
        if (!own) {
            g.method_25294(x + 2, y + 2, x + w - 2, y + 2 + ph, MetaUi.a(0, .42f));
            MetaUi.lock(g, x + w / 2 - 3, y + 38, MetaUi.a(0xFFFFFF, .85f));
        }
        skin.tag(g, field_22793, x + 5, y + ph - 10, d.rarity().title, rc, true);
        int ny = y + ph + 6, lines = 0;
        for (String line : MetaUi.wrap(field_22793, d.name(), (int) ((w - 12) / .85f))) {
            if (lines++ >= 2) break;
            MetaUi.textS(g, field_22793, line, x + 6, ny, .85f, MetaUi.solid(theme.text()), false);
            ny += 9;
        }
        if (!own) {
            String price = priceText(d);
            if (!price.isEmpty()) MetaUi.textS(g, field_22793, price, x + 6, y + h - 10, .75f, MetaUi.solid(theme.gold()), false);
        }
        if (worn(d)) MetaUi.check(g, x + w - 13, y + 7, MetaUi.solid(theme.good()));
        MetaProfile p = me();
        if (p != null && p.unseen.contains(d.id())) skin.tag(g, field_22793, x + 5, y + 5, "НОВЕ", theme.gold(), true);
        skin.cardOverlay(g, x, y, w, h, rc, sel, hv, time);
    }

    private String priceText(CosmeticDef d) {
        if (mode == null) return "";
        ShopOffer o = mode.offerFor(d.id());
        if (o != null) return MetaUi.num(o.price()) + " " + currencyShort(o.currency());
        if (mode.recipeFor(d.id()) != null) return "МАЙСТЕРНЯ";
        Integer lvl = trackLevelOf(d);
        return lvl != null ? "ПРОПУСК · " + lvl : "";
    }

    private Integer trackLevelOf(CosmeticDef d) {
        for (Map.Entry<Integer, List<Reward>> e : mode.track.steps().entrySet()) {
            for (Reward r : e.getValue()) if (r.type() == Reward.Type.COSMETIC && r.id().equals(d.id())) return e.getKey();
        }
        return null;
    }

    private String currencyShort(String id) {
        Currency c = mode.currency(id);
        return c == null ? id : c.name();
    }

    private void presetCard(class_332 g, int slot, int x, int y) {
        int w = 98, h = 128, ph = 88;
        boolean sel = slot == selectedPreset;
        float hv = hv("slot" + slot, zone(x, y, w, h, () -> { click(); selectedPreset = slot; }));
        skin.card(g, x, y, w, h, theme.gold(), sel, hv, time);
        skin.stage(g, x + 2, y + 2, w - 4, ph, theme.gold(), time, hv);
        Look s = wardrobe.preset(slot);
        if (s != null) figure(g, x + w / 2, y + 84, 32, 150, s, x + 2, y + 2, w - 4, ph, 0, 0, false);
        else MetaUi.textC(g, field_22793, "порожньо", x + w / 2, y + 40, MetaUi.a(theme.dim(), .8f), false);
        MetaUi.text(g, field_22793, MetaUi.fit(field_22793, presetTitle(slot), w - 12), x + 6, y + ph + 7, MetaUi.solid(theme.text()), false);
        MetaUi.textS(g, field_22793, s != null ? "збережено" : "—", x + 6, y + ph + 20, .8f, s != null ? MetaUi.solid(theme.good()) : MetaUi.solid(theme.dim()), false);
        skin.cardOverlay(g, x, y, w, h, theme.gold(), sel, hv, time);
    }

    private static float faceYaw(CosmeticSlot s) { return s == CosmeticSlot.BACK ? 300f : 150f; }

    /** true лише під час малювання головного манекена у вікні примірки: тоді діють анімації предметів. */
    private boolean animatedFigure;

    /** Манекен із образом, обрізаний прямокутником (у дизайнових координатах). */
    private void figure(class_332 g, int cx, int fy, float size, float yawDeg, Look lk,
                        int clx, int cly, int clw, int clh, float lift, float lean, boolean tilt) {
        if (mannequin == null) return;
        g.method_44379((int) (ox + clx * ui), (int) (oy + cly * ui), (int) (ox + (clx + clw) * ui), (int) (oy + (cly + clh) * ui));
        CosmeticRenderer.preview = lk;
        CosmeticRenderer.drawingPreview = true;
        CosmeticRenderer.previewLift = lift;
        CosmeticRenderer.previewLean = lean;
        CosmeticRenderer.previewYaw = yawDeg;
        CosmeticRenderer.previewTilt = tilt ? .42f : 0f;
        CosmeticRenderer.previewAnimated = animatedFigure;
        try {
            // Спільний рендер превʼю: аура позаду моделі, сцена трохи нахилена, кільце вписане у вікно.
            Preview.render(g, cx, fy, size, yawDeg, mannequin, lk == null ? null : lk.get(CosmeticSlot.AURA), tilt, clw);
        } finally {
            CosmeticRenderer.drawingPreview = false;
            CosmeticRenderer.preview = null;
            CosmeticRenderer.previewLift = CosmeticRenderer.previewLean = CosmeticRenderer.previewTilt = 0;
            CosmeticRenderer.previewAnimated = false;
            g.method_44380();
        }
    }

    // ── центр: модель ───────────────────────────────────────────────────
    private double[] itemSpot(CosmeticSlot k) {
        if (mannequin == null || k == null) return null;
        Worn w = look().get(k);
        if (w == null) return null;
        float size = BASE * zoom;
        double ang = Math.toRadians(yaw), cx = VCX + panX, fy = VFY + panY;
        return switch (k) {
            case PET -> {
                double phase = (mannequin.field_6012 + (field_22787 == null ? 0 : field_22787.method_1488())) * .075 * w.param(k, "speed");
                double h = w.param(k, "y") + Math.sin(phase) * w.param(k, "bob") + curLift;
                yield new double[]{cx - size * (w.param(k, "x") * Math.cos(ang) + w.param(k, "z") * Math.sin(ang)), fy - size * h, size * w.param(k, "scale") * .62};
            }
            case BACK -> {
                double b = -CosmeticRenderer.backCenterZ(w);
                yield new double[]{cx - size * (b * Math.sin(ang)), fy - size * (1.126 + w.param(k, "y")), size * w.param(k, "scale") * .6};
            }
            case HEAD -> new double[]{cx, fy - size * (1.82 + w.param(k, "y")), size * .4 * w.param(k, "scale")};
            default -> null;
        };
    }

    private double[] spotUnderMouse() {
        double[] s = itemSpot(slot());
        if (s == null) return null;
        double dx = mx - s[0], dy = my - s[1];
        return dx * dx + dy * dy <= s[2] * s[2] ? s : null;
    }

    private void drawViewport(class_332 g, float jumpH, float lift) {
        float sm = MetaUi.clamp01((time - .2f) / .8f);
        skin.viewport(g, VX, VY, VW, VH, VCX + (int) panX, VFY + (int) panY, accent, time, sm * (1f - auraMix * .7f));
        float model = MetaUi.outBack(MetaUi.clamp01((time - .3f) / .9f));
        float size = BASE * zoom * (1f - .28f * auraMix);
        float shake = landShake * landShake * 4f;
        int fx = (int) (VCX + panX + Math.sin(time * 71f) * shake), fy = (int) (VFY + panY - size * jumpH + (1f - Math.min(1, model)) * 150f - 44f * auraMix + Math.cos(time * 83f) * shake);
        figCx = fx;
        figSize = size;
        figFoot = VFY + panY - 44f * auraMix;   // земля, не залежить від польоту
        drawEquipBack(g, jumpH);
        animatedFigure = true;
        try {
            figure(g, fx, fy, size, yaw + eYaw + (1f - Math.min(1, model)) * 320f, look(), VX + 2, VY + 2, VW - 4, VH - 4, lift, curLean, auraMix > .5f);
        } finally {
            animatedFigure = false;
        }
        drawEquipFront(g, jumpH);

        // підписи — ПІСЛЯ моделі, на затемненій смузі: пересунута модель не налазить на текст
        g.method_25296(VX + 2, VY + 2, VX + VW - 2, VY + 22, MetaUi.a(0xFF030304, .85f * sm), MetaUi.a(0xFF030304, 0f));
        MetaUi.text(g, field_22793, "ПРИМІРКА", VX + 10, VY + 8, MetaUi.a(theme.dim(), sm), false);
        if (mode != null && mode.variants.size() > 1) {
            String v = mode.variantNames.getOrDefault(variant, variant).toUpperCase();
            MetaUi.textR(g, field_22793, v, VX + VW - 10, VY + 8, MetaUi.a(theme.gold(), sm), false);
        }

        boolean inView = over(VX, VY, VW, VH);
        double[] spot = drag == 3 ? itemSpot(slot()) : inView && drag == 0 ? spotUnderMouse() : null;
        if (spot != null) {
            int r = (int) (spot[2] * .62);
            skin.focus(g, (int) spot[0] - r, (int) spot[1] - r, 2 * r, 2 * r, theme.gold(), time);
        }
        String tip = null;
        if (drag == 3) tip = "ЛКМ утримується · тягни";
        else if (drag == 0 && inView) tip = spot != null ? percentText() + " · колесо" : "ЛКМ · повернути";
        if (tip != null) {
            int tw = (int) (field_22793.method_1727(tip) * .85f), tx = VCX - tw / 2, ty = VY + VH - 18;   // фіксовано під моделлю, не за курсором
            skin.toast(g, tx - 4, ty - 3, tw + 8, 14, 1f, time);
            MetaUi.textS(g, field_22793, tip, tx, ty, .85f, MetaUi.solid(theme.gold()), false);
        }
    }

    private String percentText() {
        CosmeticSlot s = slot();
        Worn w = s == null ? null : look().get(s);
        if (w == null) return "";
        if (s == CosmeticSlot.PET && class_437.method_25441()) return "розмах " + s.param("bob").percent(w.param(s, "bob")) + "%";
        if (s == CosmeticSlot.PET && class_437.method_25443()) return "швидкість " + s.param("speed").percent(w.param(s, "speed")) + "%";
        return s.param("scale").percent(w.param(s, "scale")) + "%";
    }

    // ── права панель ────────────────────────────────────────────────────
    private void drawRight(class_332 g) {
        int x = 738, y = 84, w = 208, h = 374;
        if (cat == PRESETS_TAB) { drawPresetPanel(g, x, y, w, h); return; }
        panel(g, x, y, w, h, false);
        if (selected == null) {
            MetaUi.textC(g, field_22793, "Обери предмет", x + w / 2, y + h / 2 - 4, MetaUi.a(theme.dim(), .8f), false);
            return;
        }
        CosmeticDef d = selected;
        boolean own = owns(d), on = worn(d);
        if (on) {
            MetaUi.rrect(g, x + 14, y + 15, 6, 6, 2, MetaUi.solid(theme.good()));
            MetaUi.text(g, field_22793, "ОДЯГНЕНО", x + 26, y + 14, MetaUi.solid(theme.good()), false);
        } else skin.tag(g, field_22793, x + 14, y + 13, d.rarity().title.toUpperCase(), d.rarity().color, true);
        float hvX = hv("x", zone(x + w - 28, y + 8, 20, 20, () -> { selected = null; click(); }));
        MetaUi.cross(g, x + w - 21, y + 15, MetaUi.mix(MetaUi.solid(theme.dim()), 0xFFFFFFFF, hvX));
        MetaUi.textS(g, field_22793, MetaUi.fit(field_22793, d.name(), 140), x + 14, y + 34, 1.3f, MetaUi.solid(theme.text()), true);
        skin.divider(g, x + 14, y + 50, w - 28);

        int pvY = y + 58, pvH = 146;
        skin.stage(g, x + 12, pvY, w - 24, pvH, d.rarity().color, time, 0);
        boolean au = d.slot() == CosmeticSlot.AURA;
        Worn cur = on ? look().get(d.slot()) : new Worn(d.id(), d.defaultColor());
        figure(g, x + w / 2, pvY + (au ? 110 : 134), au ? 48 : 58, faceYaw(d.slot()) + (float) Math.sin(time * .8) * 18f,
                new Look().only(d.slot(), cur), x + 12, pvY, w - 24, pvH, curLift, curLean, au);

        if (own) {
            MetaProfile pr = me();
            MetaUi.text(g, field_22793, "КОЛІР", x + 14, y + 212, MetaUi.solid(theme.dim()), false);
            if (mode.colorPrice > 0) {
                MetaUi.textR(g, field_22793, MetaUi.num(mode.colorPrice) + " " + currencyShort(mode.currency.id()) + " / відтінок",
                        x + w - 14, y + 212, MetaUi.solid(theme.dim()), false);
            }
            int[] pal = d.palette().length == 0 ? new int[]{d.defaultColor(), 0xFFFFFF, 0xFF7A1A, 0xA77BFF, 0x55E5FF, 0x3DDC84} : d.palette();
            for (int i = 0; i < Math.min(6, pal.length); i++) {
                int rgb = pal[i], sx = x + 16 + i * 30, sy = y + 224;
                boolean haveColor = pr != null && pr.ownsColor(d, rgb);
                float hv = hv("col" + i, zone(sx, sy, 24, 22, () -> {
                    if (!worn(d)) wear(d, true);
                    Worn ww = look().get(d.slot());
                    if (ww == null) return;
                    if (pr == null || pr.ownsColor(d, rgb)) {
                        pendingColor = -1;
                        ww.color = rgb;
                        dirty();
                        burstItem(rgb, 40);
                    } else {
                        // не куплений відтінок: лише примірка, купівля — окремою кнопкою нижче
                        if (pendingColor < 0) prevColor = ww.color;
                        pendingColor = rgb;
                        ww.color = rgb;
                        burstItem(rgb, 24);
                    }
                    click();
                }));
                boolean isCur = on && (look().get(d.slot()).color & 0xFFFFFF) == rgb;
                MetaUi.rrect(g, sx, sy, 24, 22, 6, MetaUi.solid(MetaUi.bright(rgb, .6f)));
                MetaUi.rrect(g, sx + 1, sy + 1, 22, 20, 5, MetaUi.solid(rgb));
                if (!haveColor) {
                    MetaUi.rrect(g, sx + 1, sy + 1, 22, 20, 5, MetaUi.a(0, .38f));
                    MetaUi.lock(g, sx + 9, sy + 7, MetaUi.a(0xFFFFFF, .9f));
                }
                if (isCur || hv > .02f) skin.focus(g, sx - 3, sy - 3, 30, 28, isCur ? 0xFFFFFF : MetaUi.mix(0, 0xFFFFFF, hv), time);
            }
            boolean buying = pendingColor >= 0 && pr != null && !pr.ownsColor(d, pendingColor);
            if (buying) {
                boolean can = pr.wallet.canAfford(mode.currency.id(), mode.colorPrice);
                final int want = pendingColor;
                primary(g, "buyColor", x + 12, y + 254, w - 24, 28,
                        "КУПИТИ КОЛІР · " + MetaUi.num(mode.colorPrice) + " " + currencyShort(mode.currency.id()),
                        can ? () -> { click(); MetaClient.buyColor(d.id(), want); } : null);
                if (!can) MetaUi.textSC(g, field_22793, "Не вистачає " + currencyShort(mode.currency.id()), x + w / 2, y + 283, .8f, MetaUi.solid(theme.bad()), false);
            } else {
                button(g, "reset", x + 12, y + 258, w - 24, 24, "СКИНУТИ ПОСАДКУ", MetaSkin.Kind.DANGER, on ? () -> {
                    Worn ww = look().get(d.slot());
                    ww.params.clear();
                    ww.color = d.defaultColor();
                    ww.validate(d.slot());
                    pendingColor = -1;
                    dirty();
                    click();
                    say("Налаштування предмета скинуто", false);
                } : null);
            }
            primary(g, "wear", x + 12, y + 290, w - 24, 30, on ? "ЗНЯТИ" : "ОДЯГНУТИ", () -> { wear(d, !on); click(); });
        } else {
            int ly = y + 212;
            for (String line : MetaUi.wrap(field_22793, d.description(), (int) ((w - 24) / .8f))) {
                MetaUi.textS(g, field_22793, line, x + 12, ly, .8f, MetaUi.solid(theme.dim()), false);
                ly += 9;
                if (ly > y + 246) break;
            }
            ShopOffer offer = mode.offerFor(d.id());
            Recipe recipe = mode.recipeFor(d.id());
            Integer lvl = trackLevelOf(d);
            MetaProfile p = me();
            int by = y + 258;
            if (offer != null) {
                boolean can = p != null && p.wallet.canAfford(offer.currency(), offer.price());
                primary(g, "buy", x + 12, by, w - 24, 28, "КУПИТИ · " + MetaUi.num(offer.price()) + " " + currencyShort(offer.currency()),
                        can ? () -> { click(); MetaClient.buy(offer.id()); } : null);
                if (!can) MetaUi.textSC(g, field_22793, "Не вистачає " + currencyShort(offer.currency()), x + w / 2, by + 32, .8f, MetaUi.solid(theme.bad()), false);
                by += 44;
            }
            if (recipe != null) {
                button(g, "craft", x + 12, by, w - 24, 22, "ДО МАЙСТЕРНІ", false, () -> { click(); MetaScreens.open("craft", parent); });
                by += 28;
            }
            if (lvl != null) MetaUi.textSC(g, field_22793, "Нагорода пропуску · ступінь " + lvl, x + w / 2, by + 4, .8f, MetaUi.solid(theme.gold()), false);
        }
        String how = switch (d.slot()) {
            case PET -> "Тягни улюбленця на моделі. Shift — уперед/назад. Колесо — розмір.";
            case AURA -> "Аура під гравцем. Колесо над моделлю — розмір.";
            case BACK -> "Тягни вгору чи вниз; боком до моделі — відстань від спини.";
            default -> "Тягни предмет вгору або вниз. Колесо — розмір.";
        };
        int ly = y + 336;
        for (String line : MetaUi.wrap(field_22793, how, (int) ((w - 24) / .75f))) {
            if (ly > y + h - 9) break;
            MetaUi.textS(g, field_22793, line, x + 12, ly, .75f, MetaUi.solid(theme.dim()), false);
            ly += 8;
        }
    }

    private void drawPresetPanel(class_332 g, int x, int y, int w, int h) {
        panel(g, x, y, w, h, false);
        if (selectedPreset < 0) {
            MetaUi.textC(g, field_22793, "Обери образ", x + w / 2, y + h / 2 - 4, MetaUi.a(theme.dim(), .8f), false);
            return;
        }
        int slot = selectedPreset;
        MetaUi.textS(g, field_22793, MetaUi.fit(field_22793, presetTitle(slot), 150), x + 14, y + 16, 1.3f, MetaUi.solid(theme.text()), true);
        skin.divider(g, x + 14, y + 32, w - 28);
        Look s = wardrobe.preset(slot);
        skin.stage(g, x + 12, y + 58, w - 24, 146, theme.gold(), time, 0);
        if (s != null) figure(g, x + w / 2, y + 192, 58, 150 + (float) Math.sin(time * .8) * 18f, s, x + 12, y + 58, w - 24, 146, 0, 0, false);
        else MetaUi.textC(g, field_22793, "порожньо", x + w / 2, y + 128, MetaUi.a(theme.dim(), .8f), false);
        button(g, "slotLoad", x + 12, y + 222, w - 24, 24, "ЗАСТОСУВАТИ", false, s == null ? null : () -> {
            click();
            Look copy = s.copy();
            MetaProfile p = me();
            if (p != null) copy.validate(mode.cosmetics, p::owns);
            wardrobe.setLook(variant, copy);
            dirty();
            startOutfit();
            say("Образ застосовано", false);
        });
        primary(g, "slotSave", x + 12, y + 256, w - 24, 30, "ЗБЕРЕГТИ ОБРАЗ…", () -> { click(); startNaming(slot); });
    }

    private void drawHints(class_332 g) {
        String hint;
        if (drag == 3) hint = "Не відпускаючи кнопку, тягни предмет, а потім відпусти, щоб закріпити посадку.";
        else if (drag == 1) hint = "Відпусти кнопку — модель залишиться під цим кутом. R — скинути вид.";
        else if (selected != null && !owns(selected)) hint = "Предмет ще не твій: купи в магазині, скрафти в майстерні або отримай у пропуску сезону.";
        else if (selected != null && worn(selected)) hint = "Зажми ліву кнопку на предметі й тягни, щоб змінити посадку. Колесо над предметом — розмір.";
        else hint = "Натисни на картку, щоб одягнути. ЛКМ біля моделі — повернути її.";
        int y = 468;
        for (String line : MetaUi.wrap(field_22793, hint, 560)) { MetaUi.textC(g, field_22793, line, VCX, y, MetaUi.solid(theme.text()), false); y += 11; }
        MetaUi.textSC(g, field_22793, "ЛКМ — обертати · ПКМ — пересунути · колесо — масштаб · Пробіл — стрибок · R — скинути вид", 480, 524, .8f,
                MetaUi.a(theme.dim(), .8f), false);
        if (changed) MetaUi.text(g, field_22793, "• Зберігаю…", 18, 468, MetaUi.solid(theme.dim()), false);
    }

    // ── сцена одягання: орбіта аури, тінь, хвиля ──────────────────────────
    private float equipEnv() {
        float t = time - equipStart;
        if (t < 0f || t >= EQUIP_LEN) return 0f;
        // орбіта наростає з приготування, тримається в польоті й гасне до приземлення
        return MetaUi.clamp01((t - .05f) / .35f) * MetaUi.clamp01((T_LAND + .1f - t) / .45f);
    }

    /** Задня половина орбіти (за спиною) і підлога: тінь, що зменшується в польоті, та кільце-світіння. Малюється ДО моделі. */
    private void drawEquipBack(class_332 g, float jumpH) {
        float env = equipEnv();
        float lifted = MetaUi.clamp01(eLift / FLY_H);
        float cx = figCx, fl = figFoot + 4f, sz = figSize;
        g.method_44379((int) (ox + VX * ui), (int) (oy + VY * ui), (int) (ox + (VX + VW) * ui), (int) (oy + (VY + VH) * ui));
        if (env > .01f || lifted > .01f) {
            // тінь під ногами: у польоті менша й блідіша
            MetaUi.ellipse(g, (int) cx, (int) fl, (int) (sz * (.34f - .14f * lifted)), (int) (sz * (.07f - .03f * lifted)), MetaUi.a(0, .32f * (1f - .5f * lifted)));
            MetaUi.glowEllipse(g, (int) cx, (int) fl, (int) (sz * (.62f + .1f * env)), (int) (sz * .15f), equipColor, .30f * env);
        }
        if (env > .01f) orbit(g, env, false);
        // хвиля від приземлення
        float st = time - shockT;
        if (st >= 0f && st < .75f) {
            float k = st / .75f, a = (1f - k) * (1f - k);
            ringDots(g, cx, fl, sz * (.25f + .95f * MetaUi.outCubic(k)), sz * (.06f + .2f * MetaUi.outCubic(k)), equipColor, a * .9f, 56);
            ringDots(g, cx, fl, sz * (.15f + .70f * MetaUi.outCubic(k)), sz * (.04f + .14f * MetaUi.outCubic(k)), 0xFFFFFF, a * .6f, 40);
        }
        g.method_44380();
    }

    /** Передня половина орбіти — поверх моделі. */
    private void drawEquipFront(class_332 g, float jumpH) {
        float env = equipEnv();
        if (env <= .01f) return;
        g.method_44379((int) (ox + VX * ui), (int) (oy + VY * ui), (int) (ox + (VX + VW) * ui), (int) (oy + (VY + VH) * ui));
        orbit(g, env, true);
        g.method_44380();
    }

    /**
     * Три нахилені орбіти іскор навколо тулуба (знизу вгору, у різні боки), що летять разом із фігурою: аура «несе» персонажа.
     * Іскра ззаду (sin &lt; 0) малюється до моделі, спереду — після, тож створюється відчуття, що вона обертається ДОВКОЛА.
     */
    private void orbit(class_332 g, float env, boolean front) {
        float t = time;
        float cy0 = figFoot - figSize * jumpHeightBlocks();
        for (int ring = 0; ring < 3; ring++) {
            float h = figSize * (.35f + ring * .55f);
            float rx = figSize * (.50f - ring * .05f) * (.6f + .4f * env), ry = rx * .26f;
            float dir = ring % 2 == 0 ? 1f : -1f;
            int n = 12 + ring * 2;
            for (int j = 0; j < n; j++) {
                float a = t * 4.4f * dir + j * 6.2831853f / n + ring * 1.1f;
                float sn = (float) Math.sin(a);
                if ((sn >= 0f) != front) continue;
                float px = figCx + (float) Math.cos(a) * rx;
                float py = cy0 - h + sn * ry + (float) Math.sin(t * 3f + j) * 2f;
                int col = (j & 3) == 0 ? 0xFFFFFF : equipColor;
                float near = .55f + .45f * Math.abs(sn);
                for (int tr = 0; tr < 4; tr++) {   // хвіст
                    float ta = a - dir * tr * .13f;
                    int tx = (int) (figCx + Math.cos(ta) * rx), ty = (int) (cy0 - h + Math.sin(ta) * ry);
                    int sz = tr == 0 ? 3 : 2;
                    g.method_25294(tx, ty, tx + sz, ty + sz, MetaUi.a(col, env * near * (1f - tr * .26f)));
                }
                MetaUi.glowDisc(g, (int) px + 1, (int) py + 1, 4, equipColor, env * near * .5f);
            }
        }
    }

    private float jumpHeightBlocks() { return eLift; }

    private void ringDots(class_332 g, float cx, float cy, float rx, float ry, int rgb, float alpha, int n) {
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            int x = (int) (cx + Math.cos(a) * rx), y = (int) (cy + Math.sin(a) * ry);
            g.method_25294(x, y, x + 2, y + 1, MetaUi.a(rgb, alpha));
        }
    }

    // ── ефекти ──────────────────────────────────────────────────────────
    private void burst(double x, double y, int rgb, int n) { burst(x, y, rgb, n, false); }

    /** {@code force} — анімації одягання малюються навіть у скінах, що вимкнули «феєрверки» (вони — частина сцени, а не декор). */
    private void burst(double x, double y, int rgb, int n, boolean force) {
        if (!force && !skin.sparks()) return;
        for (int i = 0; i < n && sparks.size() < 500; i++) {
            Spark k = new Spark();
            double an = rnd.nextDouble() * Math.PI * 2, sp = 40 + rnd.nextDouble() * 140;
            k.x = (float) x; k.y = (float) y; k.vx = (float) (Math.cos(an) * sp); k.vy = (float) (Math.sin(an) * sp - 30);
            k.max = k.life = .6f + rnd.nextFloat() * .7f; k.size = 1 + rnd.nextInt(3); k.grav = 70; k.rgb = rgb;
            sparks.add(k);
        }
        flash = Math.min(1f, flash + .4f);
    }

    private void burstItem(int rgb, int n) {
        double[] sp = itemSpot(slot());
        if (sp == null) sp = new double[]{VCX + panX, VFY + panY - BASE * zoom, 0};
        burst(sp[0], sp[1], rgb, n);
    }

    private void updateFx() {
        if (skin.sparks()) {
            ambient += dt;
            while (ambient > .06f) {
                ambient -= .06f;
                if (sparks.size() > 300) break;
                Spark k = new Spark();
                k.x = VX + rnd.nextFloat() * VW; k.y = VFY + 20;
                k.vx = (rnd.nextFloat() - .5f) * 14; k.vy = -(14 + rnd.nextFloat() * 30);
                k.max = k.life = 2.5f + rnd.nextFloat() * 2f; k.size = 1 + rnd.nextInt(2);
                k.rgb = rnd.nextInt(3) == 0 ? theme.gold() : accent;
                sparks.add(k);
            }
        }
        for (int i = sparks.size() - 1; i >= 0; i--) {
            Spark k = sparks.get(i);
            k.life -= dt;
            if (k.life <= 0) { sparks.remove(i); continue; }
            k.vy += k.grav * dt;
            k.x += k.vx * dt + (k.grav == 0 ? (float) Math.sin(time * 2 + k.y * .05) * .25f : 0);
            k.y += k.vy * dt;
        }
        flash = Math.max(0f, flash - dt * 2.2f);
    }

    private void drawFx(class_332 g) {
        g.method_44379((int) (ox + VX * ui), (int) (oy + VY * ui), (int) (ox + (VX + VW) * ui), (int) (oy + (VY + VH) * ui));
        for (Spark k : sparks) {
            float a = Math.min(1f, k.life / k.max * (k.grav == 0 ? 1.6f : 1.2f));
            if (k.grav == 0) a *= Math.min(1f, (k.max - k.life) * 2f);
            int sz = Math.max(1, Math.round(k.size * (.5f + .5f * a)));
            g.method_25294((int) k.x, (int) k.y, (int) k.x + sz, (int) k.y + sz, MetaUi.a(k.rgb, a * .9f));
        }
        g.method_44380();
        if (flash > .01f) g.method_25296(VX, VY, VX + VW, VY + VH, MetaUi.a(0xFFFFFF, flash * .10f), 0x00FFFFFF);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Ввід
    // ══════════════════════════════════════════════════════════════════════

    @Override
    public boolean method_25402(double rx, double ry, int button) {
        updateMouse(rx, ry);
        if (button == 0) {
            for (int i = zones.size() - 1; i >= 0; i--) {
                Zone z = zones.get(i);
                if (over(z.x(), z.y(), z.w(), z.h())) { z.action().run(); return true; }
            }
        }
        if (over(VX, VY, VW, VH)) {
            if (button == 1) drag = 2;
            else if (button == 0) drag = spotUnderMouse() != null ? 3 : 1;
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25403(double rx, double ry, int button, double rdx, double rdy) {
        updateMouse(rx, ry);
        double dx = rdx / ui, dy = rdy / ui;
        if (drag == 1) { yaw += (float) dx * .9f; return true; }
        if (drag == 2) {
            panX = Math.max(-120, Math.min(120, panX + (float) dx));
            panY = Math.max(-80, Math.min(80, panY + (float) dy));
            return true;
        }
        if (drag == 3) {
            CosmeticSlot s = slot();
            Worn w = s == null ? null : look().get(s);
            if (w == null) return true;
            dragVx = dragVx * .6f + (float) dx / Math.max(dt, .008f) * .02f;   // інерція нахилу «предмета в руці»
            float size = BASE * zoom;
            double ang = Math.toRadians(yaw), cos = Math.cos(ang), sin = Math.sin(ang);
            Map<String, Float> before = Map.copyOf(w.params);
            switch (s) {
                case HEAD -> w.setParam(s, "y", w.param(s, "y") - (float) (dy / size));
                case BACK -> {
                    if (class_437.method_25442() && Math.abs(sin) < .5) w.setParam(s, "z", w.param(s, "z") - (float) (dy / size));
                    else {
                        w.setParam(s, "y", w.param(s, "y") - (float) (dy / size));
                        if (Math.abs(sin) >= .35) w.setParam(s, "z", w.param(s, "z") + (float) (dx / size * Math.signum(sin)));
                    }
                }
                case PET -> {
                    boolean side = Math.abs(cos) >= Math.abs(sin);
                    float sc = (float) Math.signum(side ? cos : sin);
                    float hh = (float) (-dx / size * sc);
                    String a = side ? "x" : "z", b = side ? "z" : "x";
                    if (class_437.method_25442()) {
                        float dd = (float) (side ? -dy / size * sc : dy / size * sc);
                        w.setParam(s, b, w.param(s, b) + dd);
                        w.setParam(s, a, w.param(s, a) + hh);
                    } else {
                        w.setParam(s, a, w.param(s, a) + hh);
                        w.setParam(s, "y", w.param(s, "y") - (float) (dy / size));
                    }
                }
                default -> { }
            }
            w.validate(s);
            if (w.params.equals(before) && (Math.abs(dx) + Math.abs(dy)) > 2) say("Досягнуто межі — далі не можна, щоб не заважати іншим", false);
            dirty();
            return true;
        }
        return super.method_25403(rx, ry, button, rdx, rdy);
    }

    @Override
    public boolean method_25406(double rx, double ry, int button) {
        if (drag != 0) {
            if (drag == 3) {
                burstItem(theme.gold(), 14);
                CosmeticSlot rs = slot();
                if (rs != null) {   // відпустив — предмет лягає назад з відскоком
                    float amp = rs == CosmeticSlot.AURA ? 0f : .12f;
                    startDrop(rs, 0f, amp, 0f);
                }
            }
            drag = 0;
            return true;
        }
        return super.method_25406(rx, ry, button);
    }

    @Override
    public boolean method_25401(double rx, double ry, double amount) {
        updateMouse(rx, ry);
        if (!over(VX, VY, VW, VH)) {
            if (over(116, 118, 318, 268)) { scroll += amount < 0 ? 1 : -1; catTime = time; return true; }
            return super.method_25401(rx, ry, amount);
        }
        CosmeticSlot s = slot();
        Worn w = s == null ? null : look().get(s);
        float k = 1f + (float) amount * .06f;
        if (s == CosmeticSlot.AURA && w != null) { w.setParam(s, "scale", w.param(s, "scale") * k); dirty(); return true; }
        if (w != null && spotUnderMouse() != null) {
            if (s == CosmeticSlot.PET && class_437.method_25441()) w.setParam(s, "bob", Math.max(.005f, w.param(s, "bob")) * k);
            else if (s == CosmeticSlot.PET && class_437.method_25443()) w.setParam(s, "speed", w.param(s, "speed") * k);
            else {
                ParamSpec sp = s.param("scale");
                if (sp != null) w.setParam(s, "scale", w.param(s, "scale") * k);
            }
            dirty();
        } else zoom = Math.max(.6f, Math.min(1.4f, zoom + (float) amount * .05f));
        return true;
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        if (naming) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { naming = false; return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { confirmNaming(); return true; }
            if (key == GLFW.GLFW_KEY_BACKSPACE && nameBuf.length() > 0) {
                if (nameFresh) { nameBuf.setLength(0); nameFresh = false; }
                else nameBuf.setLength(nameBuf.length() - 1);
            }
            if (class_437.method_25437(key) && field_22787 != null) typeInto(field_22787.field_1774.method_1460());
            return true;
        }
        if (key == GLFW.GLFW_KEY_R) { resetView(); return true; }
        if (key == GLFW.GLFW_KEY_SPACE) { if (time - jumpStart > .6f) jumpStart = time; return true; }
        return super.method_25404(key, scan, mods);
    }

    @Override
    public boolean method_25400(char c, int mods) {
        if (naming) { typeInto(String.valueOf(c)); return true; }
        return super.method_25400(c, mods);
    }

    @Override
    public void profileChanged() {
        // купили відтінок, який приміряли, — залишаємо його на предметі й зберігаємо
        if (pendingColor >= 0 && selected != null) {
            MetaProfile mp = me();
            Worn w = look().get(selected.slot());
            if (mp != null && w != null && mp.ownsColor(selected, pendingColor)) {
                w.color = pendingColor;
                pendingColor = -1;
                dirty();
                burstItem(w.color, 50);
            }
        }
        // Покупка/крафт додали предмет — лишаємо локальні зміни образу, але оновлюємо вибір.
        if (selected != null && owns(selected) && !worn(selected)) burstItem(theme.gold(), 60);
    }
}
