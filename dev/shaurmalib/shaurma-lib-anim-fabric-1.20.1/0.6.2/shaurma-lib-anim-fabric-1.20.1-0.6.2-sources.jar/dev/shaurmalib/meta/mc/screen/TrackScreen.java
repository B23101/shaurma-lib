package dev.shaurmalib.meta.mc.screen;

import dev.shaurmalib.meta.client.MetaClient;
import dev.shaurmalib.meta.cosmetics.CosmeticDef;
import dev.shaurmalib.meta.economy.Reward;
import dev.shaurmalib.meta.economy.RewardTrack;
import dev.shaurmalib.meta.economy.UpgradeDef;
import dev.shaurmalib.meta.mc.MetaScreens;
import dev.shaurmalib.meta.mc.skin.MetaSkin;
import dev.shaurmalib.meta.mc.ui.MetaIcons;
import dev.shaurmalib.meta.mc.ui.MetaUi;
import dev.shaurmalib.meta.profile.MetaProfile;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * Пропуск сезону (лише безкоштовний — платної гілки й вкладки покращень немає). Вигляд — скін режиму.
 * Шапка: «СЕЗОН · до 30 листопада», назва, «N/28» і сегментована смужка. Ряд карток-ступенів (колесо,
 * перетягування або стрілки), перша плитка — щоденний подарунок із таймером. Під картками — номери ступенів;
 * поточний підсвічений. Відкрита незабрана картка має «Забрати»; праворуч — твій персонаж у косметиці.
 */
public class TrackScreen extends MetaScreen {

    private float offset = Float.NaN, offsetGoal;
    private boolean dragging;
    private final List<float[]> sparks = new ArrayList<>();
    private final Random rnd = new Random();
    private final Map<Integer, Float> claimedAt = new HashMap<>();

    private static final int TOP = 84, TILE = 108, GAP = 8, ROW_H = 122;
    private static final int VIEW_X = 112, VIEW_W = 628;
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("d MMMM", new Locale("uk"));

    public TrackScreen(class_437 parent, boolean upgrades) {
        super("Пропуск", parent);
    }

    @Override protected String section() { return "track"; }

    @Override
    protected void draw(class_332 g) {
        header(g, "ПРОПУСК", "НАГОРОДИ СЕЗОНУ");
        drawPass(g);
        drawSparks(g);
    }

    private int tier(MetaProfile p) {
        long sxp = p.season.equals(mode.track.id()) ? p.seasonXp : 0;
        return mode.track.tier(sxp, p.level(mode));
    }

    // ── пропуск ─────────────────────────────────────────────────────────
    private void drawPass(class_332 g) {
        MetaProfile p = me();
        if (p == null) return;
        RewardTrack t = mode.track;
        List<Integer> tiers = new ArrayList<>(t.steps().keySet());
        int bx = 14, by = TOP, bw = 932, bh = 340;
        panel(g, bx, by, bw, bh, true);

        String season = "СЕЗОН" + (t.endsAt() > 0 ? " · ДО " + DATE.format(Instant.ofEpochMilli(t.endsAt()).atZone(ZoneId.systemDefault())).toUpperCase() : "");
        skin.header(g, field_22793, bx + 16, by + 12, season, t.title().toUpperCase(), time);
        int tier = tier(p), max = Math.max(1, t.maxTier());
        MetaUi.textS(g, field_22793, String.valueOf(tier), bx + 16, by + 60, 1.6f, MetaUi.solid(theme.text()), false);
        MetaUi.text(g, field_22793, "/" + max, bx + 19 + (int) (field_22793.method_1727(String.valueOf(tier)) * 1.6f), by + 65, MetaUi.solid(theme.dim()), false);
        int segX = bx + 64, segW = 420, segs = Math.min(max, 40);
        float prog = t.seasonal() ? t.tierProgress(p.seasonXp) : mode.curve.progress(p.totalXp());
        for (int k = 0; k < segs; k++) {
            int sx = segX + k * segW / segs, ex = segX + (k + 1) * segW / segs - 2;
            int kTier = 1 + k * max / segs;
            boolean milestone = t.rewards(kTier).stream().anyMatch(r -> r.type() == Reward.Type.COSMETIC || r.type() == Reward.Type.CHEST);
            float f = kTier < tier ? 1f : kTier == tier ? prog : 0f;
            skin.bar(g, sx, by + 66, ex - sx, 5, f, milestone ? theme.gold() : theme.accent(), time);
        }
        if (t.seasonal()) MetaUi.textS(g, field_22793, MetaUi.num(p.seasonXp % t.xpPerTier()) + " / " + MetaUi.num(t.xpPerTier()) + " XP до наступного ступеня",
                segX, by + 76, .75f, MetaUi.solid(theme.dim()), false);
        int claimable = t.claimable(tier, p.claimed).size();
        primary(g, "claimAll", bx + 540, by + 24, 180, 28, claimable > 0 ? "ЗАБРАТИ ВСЕ (" + claimable + ")" : "УСЕ ЗАБРАНО", claimable > 0 ? () -> {
            click();
            for (int lv : t.claimable(tier, p.claimed)) { claimedAt.put(lv, time); MetaClient.claim(lv); }
            burst(630, by + 38, theme.gold(), 50);
        } : null);

        int rowY = by + 104;
        dailyTile(g, p, bx + 14, rowY, 84, ROW_H);

        if (Float.isNaN(offset)) {
            int focus = 0;
            for (int i = 0; i < tiers.size(); i++) {
                int lv = tiers.get(i);
                if (lv <= tier && !p.claimed.contains(lv)) { focus = i; break; }
                if (lv <= tier) focus = i;
            }
            offsetGoal = Math.max(0, focus * (TILE + GAP) - TILE);
            offset = offsetGoal;
        }
        float maxOff = Math.max(0, tiers.size() * (TILE + GAP) - VIEW_W);
        offsetGoal = Math.max(0, Math.min(maxOff, offsetGoal));
        offset = MetaUi.approach(offset, offsetGoal, 10f, dt);
        int lineY = rowY + ROW_H + 24;
        g.method_44379((int) (ox + VIEW_X * ui), (int) (oy + (rowY - 4) * ui), (int) (ox + (VIEW_X + VIEW_W) * ui), (int) (oy + (lineY + 12) * ui));
        int x0 = VIEW_X + 4 - Math.round(offset);
        int reached = -1;
        for (int i = 0; i < tiers.size(); i++) if (tiers.get(i) <= tier) reached = i;
        g.method_25294(VIEW_X, lineY - 1, VIEW_X + VIEW_W, lineY + 1, MetaUi.a(theme.border(), .9f));
        if (reached >= 0) g.method_25294(VIEW_X, lineY - 1, x0 + reached * (TILE + GAP) + TILE / 2, lineY + 1, MetaUi.solid(theme.accent()));
        for (int i = 0; i < tiers.size(); i++) {
            int x = x0 + i * (TILE + GAP);
            if (x + TILE < VIEW_X || x > VIEW_X + VIEW_W) continue;
            int lv = tiers.get(i);
            tile(g, p, lv, x, rowY, tier, i);
            int cx = x + TILE / 2;
            boolean cur = i == reached;
            String n = String.valueOf(lv);
            int w = Math.max(24, field_22793.method_1727(n) + 14);
            skin.button(g, field_22793, cx - w / 2, lineY - 9, w, 18, n, cur ? MetaSkin.Kind.SELECTED : MetaSkin.Kind.NORMAL, 0, true, time);
        }
        g.method_44380();
        if (offsetGoal < maxOff) button(g, "next", VIEW_X + VIEW_W + 4, rowY + ROW_H / 2 - 16, 22, 32, ">", false, () -> { offsetGoal += TILE + GAP; click(); });
        if (offsetGoal > 0) button(g, "prev", VIEW_X - 26, rowY + ROW_H / 2 - 16, 22, 32, "<", false, () -> { offsetGoal -= TILE + GAP; click(); });

        if (field_22787 != null && field_22787.field_1724 != null) {
            Preview.figure(g, this, 846, by + bh - 16, 90, 200 + (float) Math.sin(time * .5) * 14,
                    p.wardrobe.look(mode.variants.get(0)), 768, by + 2, 176, bh - 4, false, 0);
        }

        panel(g, 14, 434, 932, 74, false);
        skin.levelBadge(g, field_22793, 50, 471, 22, p.level(mode), theme.accent(), 0, time);
        MetaUi.text(g, field_22793, "РІВЕНЬ ГРАВЦЯ " + p.level(mode) + "   ·   " + MetaUi.num(mode.curve.intoLevel(p.totalXp())) + " / "
                + MetaUi.num(mode.curve.needed(p.level(mode))) + " XP", 86, 452, MetaUi.solid(theme.text()), false);
        skin.bar(g, 86, 465, 300, 4, mode.curve.progress(p.totalXp()), theme.accent(), time);
        MetaUi.textS(g, field_22793, "Кожен матч дає досвід і в рівень, і в пропуск.", 86, 476, .8f, MetaUi.solid(theme.dim()), false);
        MetaUi.textS(g, field_22793, "колесо / перетягування — гортати ступені", 86, 488, .75f, MetaUi.a(theme.dim(), .7f), false);
    }

    private void dailyTile(class_332 g, MetaProfile p, int x, int y, int w, int h) {
        RewardTrack t = mode.track;
        boolean has = !t.daily().isEmpty();
        long left = p.lastDaily + t.dailyCooldownMs() - System.currentTimeMillis();
        boolean ready = has && left <= 0;
        skin.card(g, x, y, w, h, theme.gold(), ready, 0, time);
        MetaUi.textC(g, field_22793, "ПОДАРУНОК", x + w / 2, y + 8, MetaUi.solid(theme.dim()), false);
        float pulse = ready ? .5f + .5f * (float) Math.sin(time * 4) : 0;
        Preview.itemIcon(g, "minecraft:chest", x + w / 2f, y + 46 - pulse * 3, 3.2f);
        if (has) {
            if (ready) primary(g, "daily", x + 6, y + h - 28, w - 12, 22, "ЗАБРАТИ", () -> {
                click();
                burst(x + w / 2f, y + 40, theme.gold(), 40);
                MetaClient.daily();
            });
            else {
                long s = Math.max(0, left / 1000);
                skin.button(g, field_22793, x + 6, y + h - 28, w - 12, 22, String.format("%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60),
                        MetaSkin.Kind.NORMAL, 0, false, time);
            }
        }
        skin.cardOverlay(g, x, y, w, h, theme.gold(), ready, 0, time);
    }

    private void tile(class_332 g, MetaProfile p, int lv, int x, int y, int tier, int i) {
        boolean open = lv <= tier, claimed = p.claimed.contains(lv), ready = open && !claimed;
        List<Reward> rewards = mode.track.rewards(lv);
        Reward main = rewards.isEmpty() ? null : rewards.get(0);
        float hv = hv("tile" + lv, over(x, y, TILE, ROW_H));
        Float at = claimedAt.get(lv);
        float sx = at == null ? 1 : Math.max(.05f, Math.abs((float) Math.cos(MetaUi.clamp01((time - at) / .5f) * Math.PI)));
        int cx = x + TILE / 2, cy = y + ROW_H / 2;
        int rc = main == null ? theme.border() : MetaScreens.rewardColor(mode, main);
        g.method_51448().method_22903();
        g.method_51448().method_46416(cx, cy, 0);
        g.method_51448().method_22905(sx, 1, 1);
        g.method_51448().method_46416(-cx, -cy, 0);
        skin.card(g, x, y, TILE, ROW_H, ready ? theme.accent() : rc, ready, hv, time);
        int stageH = ROW_H - 34;
        skin.stage(g, x + 3, y + 3, TILE - 6, stageH, open ? rc : theme.border(), time, hv);
        if (main != null) {
            CosmeticDef d = main.type() == Reward.Type.COSMETIC ? mode.cosmetics.get(main.id()) : null;
            if (d != null && sx > .9f) Preview.item(g, this, d, x + 3, y + 3, TILE - 6, stageH, 160 + (float) Math.sin(time + i) * 20 + hv * 25);
            else if (main.type() == Reward.Type.CHEST && mode.chest(main.id()) != null)
                Preview.itemIcon(g, mode.chest(main.id()).model(), cx, y + 46 + (float) Math.sin(time * 2 + i) * 2, 3.2f);
            else icon(g, MetaScreens.rewardIcon(mode, main), cx - 16, y + 30 + (int) (Math.sin(time * 2 + i) * 2), 4,
                    open ? MetaUi.solid(rc) : MetaUi.a(rc, .45f));
            if (!ready) {
                String label = label(main) + (rewards.size() > 1 ? " +" + (rewards.size() - 1) : "");
                MetaUi.textC(g, field_22793, MetaUi.fit(field_22793, label, TILE - 14), cx, y + ROW_H - 21, claimed ? MetaUi.solid(theme.good()) : MetaUi.solid(theme.text()), false);
            }
        }
        if (!open) MetaUi.lock(g, x + TILE - 14, y + 7, MetaUi.a(theme.dim(), .9f));
        if (claimed) { g.method_25294(x + 3, y + 3, x + TILE - 3, y + 3 + stageH, MetaUi.a(0, .4f)); MetaUi.check(g, x + 8, y + 8, MetaUi.solid(theme.good())); }
        skin.cardOverlay(g, x, y, TILE, ROW_H, ready ? theme.accent() : rc, ready, hv, time);
        g.method_51448().method_22909();
        if (ready && x >= VIEW_X && x + TILE <= VIEW_X + VIEW_W) {
            primary(g, "claim" + lv, x + 6, y + ROW_H - 28, TILE - 12, 22, "ЗАБРАТИ", () -> {
                click();
                claimedAt.put(lv, time);
                burst(cx, cy, theme.gold(), 50);
                MetaClient.claim(lv);
            });
        }
    }

    /** Короткий підпис плитки: «25», «Звичайна скриня», «Рідкісний». */
    private String label(Reward r) {
        return switch (r.type()) {
            case CURRENCY, MATERIAL, UPGRADE_POINTS -> MetaUi.num(r.amount());
            case CHEST -> { var c = mode.chest(r.id()); yield c == null ? "Скриня" : c.name(); }
            case COSMETIC -> { var d = mode.cosmetics.get(r.id()); yield d == null ? r.id() : d.rarity().title; }
        };
    }

    // ── іскри / ввід ────────────────────────────────────────────────────
    private void burst(float x, float y, int rgb, int n) {
        if (!skin.sparks()) return;
        for (int i = 0; i < n; i++) {
            double a = rnd.nextDouble() * Math.PI * 2, sp = 40 + rnd.nextDouble() * 160;
            sparks.add(new float[]{x, y, (float) (Math.cos(a) * sp), (float) (Math.sin(a) * sp - 40), .6f + rnd.nextFloat() * .7f, rgb});
        }
    }

    private void drawSparks(class_332 g) {
        for (int i = sparks.size() - 1; i >= 0; i--) {
            float[] s = sparks.get(i);
            s[4] -= dt;
            if (s[4] <= 0) { sparks.remove(i); continue; }
            s[3] += 80 * dt;
            s[0] += s[2] * dt;
            s[1] += s[3] * dt;
            g.method_25294((int) s[0], (int) s[1], (int) s[0] + 2, (int) s[1] + 2, MetaUi.a((int) s[5], Math.min(1f, s[4] * 1.5f)));
        }
    }

    @Override
    public boolean method_25401(double rx, double ry, double amount) {
        offsetGoal -= (float) amount * (TILE + GAP);
        return true;
    }

    @Override
    public boolean method_25402(double rx, double ry, int button) {
        if (super.method_25402(rx, ry, button)) return true;
        updateMouse(rx, ry);
        if (over(VIEW_X, TOP + 100, VIEW_W, ROW_H + 40)) { dragging = true; return true; }
        return false;
    }

    @Override
    public boolean method_25403(double rx, double ry, int button, double dx, double dy) {
        if (dragging) { offsetGoal -= (float) (dx / ui); offset = offsetGoal; return true; }
        return super.method_25403(rx, ry, button, dx, dy);
    }

    @Override
    public boolean method_25406(double rx, double ry, int button) {
        dragging = false;
        return super.method_25406(rx, ry, button);
    }
}
