package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.ShaurmaAnim;
import dev.shaurmalib.anim.io.AnimPackScanner;
import dev.shaurmalib.anim.io.AnimResourceLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_4013;

/**
 * Перезавантажує бібліотеку кліпів (старт клієнта і F3+T). Ванільний інтерфейс —
 * лоадер лише реєструє екземпляр (Forge: RegisterClientReloadListenersEvent; Fabric: ResourceManagerHelper).
 *
 * <p>Два джерела, друге перекриває перше:
 * <ol>
 *   <li>ресурс-паки й моди ({@code assets/<ns>/shaurma_anim/...});</li>
 *   <li>папка гри {@code <гра>/shaurma_anim/}: {@code .zip} з Blockbench-плагіна (розпаковувати не треба)
 *       або теки — кліпи, моделі пропсів і їхні PNG (реєструються як текстури гри).</li>
 * </ol>
 */
public final class AnimReloader implements class_4013 {

    private static final Logger LOG = LoggerFactory.getLogger("ShaurmaAnim");
    private static final String[] ROOTS = { "shaurma_anim", "player_animation", "player_animations", "animations" };
    /** Текстури з папки гри, зареєстровані минулого разу — звільняються перед новим читанням. */
    private final Set<class_2960> folderTextures = new HashSet<>();

    @Override
    public void method_14491(class_3300 rm) {
        AnimResourceLoader loader = new AnimResourceLoader(w -> LOG.warn("[ShaurmaAnim] {}", w));
        for (String root : ROOTS) {
            Map<class_2960, class_3298> found = rm.method_14488(root, rl -> rl.method_12832().endsWith(".json"));
            for (Map.Entry<class_2960, class_3298> e : found.entrySet()) {
                class_2960 rl = e.getKey();
                try (Reader r = e.getValue().method_43039()) {
                    StringBuilder sb = new StringBuilder();
                    char[] buf = new char[8192];
                    int n;
                    while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
                    loader.accept(rl.method_12836(), rl.method_12832(), sb.toString());
                } catch (IOException ex) {
                    LOG.warn("[ShaurmaAnim] не прочитано {}: {}", rl, ex.toString());
                }
            }
        }

        AnimPackScanner.Result folder = null;
        try {
            Path dir = class_310.method_1551().field_1697.toPath().resolve(AnimPackScanner.FOLDER);
            folder = AnimPackScanner.scan(dir, loader, w -> LOG.warn("[ShaurmaAnim] {}", w));
            registerTextures(folder.textures());
        } catch (RuntimeException ex) {
            LOG.warn("[ShaurmaAnim] папка {}: {}", AnimPackScanner.FOLDER, ex.toString());
        }

        ShaurmaAnim.clips().replaceAll(loader.clips(), loader.meshes());
        LOG.info("[ShaurmaAnim] завантажено {} кліпів і {} моделей пропсів з {} файлів{}",
            loader.clips().size(), loader.meshes().size(), loader.files(),
            folder == null || folder.sources().isEmpty() ? "" : "; з папки " + AnimPackScanner.FOLDER + ": " + folder.sources()
                + " (" + folder.textures().size() + " текстур)");
    }

    /** PNG з папки гри → текстури за тими самими id, що пише плагін ({@code ns:textures/shaurma_anim/x.png}). */
    private void registerTextures(Map<String, byte[]> textures) {
        class_1060 tm = class_310.method_1551().method_1531();
        for (class_2960 old : folderTextures) tm.method_4615(old);
        folderTextures.clear();
        for (Map.Entry<String, byte[]> e : textures.entrySet()) {
            class_2960 rl = class_2960.method_12829(e.getKey());
            if (rl == null) {
                LOG.warn("[ShaurmaAnim] погане ім'я текстури {} (лише a-z0-9_./-)", e.getKey());
                continue;
            }
            try {
                class_1011 img = class_1011.method_4309(new ByteArrayInputStream(e.getValue()));
                tm.method_4616(rl, new class_1043(img));
                folderTextures.add(rl);
            } catch (IOException | RuntimeException ex) {
                LOG.warn("[ShaurmaAnim] текстура {}: {}", rl, ex.toString());
            }
        }
    }
}
