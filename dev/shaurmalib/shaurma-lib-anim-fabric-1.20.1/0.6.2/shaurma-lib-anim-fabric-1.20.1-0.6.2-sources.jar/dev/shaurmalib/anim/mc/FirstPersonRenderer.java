package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.anim.pose.Pose;
import net.minecraft.class_1007;
import net.minecraft.class_1306;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import net.minecraft.class_897;

/**
 * Перша особа для кліпів з {@code first_person: "model"}: замість ванільних рук рушій малює
 * анімовані руки гравця (його скін), предмети на кістках {@code right_item/left_item} і пропси —
 * тобто те саме, що бачать інші, але з камери. Відкрити аптечку, дістати бинт — видно від першої особи.
 *
 * Геометрія: при тілі, поверненому за камерою, вигляд-з-моделі = {@code Rx(pitch)·T(0,−eye,0)·S(−1,−1,1)·T(0,−1.501,0)}.
 * {@code first_person_pitch} 0 — руки «прикручені» до камери (як вʼюмодель у шутерах), 1 — висять у світі.
 */
public final class FirstPersonRenderer {

    private FirstPersonRenderer() {}

    /**
     * Викликається замість ванільного {@code renderHandsWithItems}.
     * @return true — рушій сам намалював (або сховав) руки; ваніль пропустити
     */
    public static boolean render(float partial, class_4587 ps, class_4597.class_4598 buffers, class_746 player, int light) {
        // вимкнено модом або є first-person мод зі справжнім тілом — нічого не підміняти (ні руки, ні hide)
        if (!dev.shaurmalib.anim.ShaurmaAnim.firstPersonArms()) return false;
        class_310 mc = class_310.method_1551();
        if (!mc.field_1690.method_31044().method_31034() || player.method_31550()) return false;
        Pose pose = McAnim.evaluate(player, partial, null, true);
        if (pose == null || pose.firstPersonClip == null || pose.firstPersonWeight < 0.5f) return false;
        if (pose.firstPersonMode == AnimationClip.FirstPerson.HIDE) {
            buffers.method_22993();
            return true;
        }
        class_897<? super class_746> r = mc.method_1561().method_3953(player);
        if (!(r instanceof class_1007 pr)) return false;
        class_591<class_742> model = pr.method_4038();

        ps.method_22903();
        // та сама легка інерція камери, що у ванільних рук
        float xBob = class_3532.method_16439(partial, player.field_3914, player.field_3916);
        float yBob = class_3532.method_16439(partial, player.field_3931, player.field_3932);
        ps.method_22907(class_7833.field_40714.rotationDegrees((player.method_5695(partial) - xBob) * 0.1f));
        ps.method_22907(class_7833.field_40716.rotationDegrees((player.method_5705(partial) - yBob) * 0.1f));
        float pitch = class_3532.method_16439(partial, player.field_6004, player.method_36455());
        if (pose.firstPersonPitch != 0) ps.method_22907(class_7833.field_40714.rotationDegrees(pitch * pose.firstPersonPitch));
        float[] off = pose.firstPersonOffset;
        ps.method_46416(off[0] / 16f, off[1] / 16f, off[2] / 16f);
        if (off.length > 3 && off[3] != 0) ps.method_22907(class_7833.field_40714.rotationDegrees(off[3]));
        ps.method_46416(0, -player.method_5751(), 0);
        ps.method_22905(-1f, -1f, 1f);
        ps.method_46416(0, -1.501f, 0);

        PlayerModelBridge.reset(model);
        model.field_3447 = 0;
        model.field_3400 = false;
        PlayerModelBridge.applyArms(model, pose);
        McAnimHooks.markDirty(model);

        var skin = player.method_3117();
        var solid = buffers.getBuffer(class_1921.method_23572(skin));
        model.field_3401.method_22698(ps, solid, light, class_4608.field_21444);
        model.field_27433.method_22698(ps, solid, light, class_4608.field_21444);
        var translucent = buffers.getBuffer(class_1921.method_23580(skin));
        model.field_3486.method_22698(ps, translucent, light, class_4608.field_21444);
        model.field_3484.method_22698(ps, translucent, light, class_4608.field_21444);

        renderHeld(ps, buffers, light, player, model, pose, class_1306.field_6183);
        renderHeld(ps, buffers, light, player, model, pose, class_1306.field_6182);
        PropRenderer.renderProps(ps, buffers, light, player, model, pose, false);
        ps.method_22909();
        buffers.method_22993();
        return true;
    }

    private static void renderHeld(class_4587 ps, class_4597 buffers, int light, class_746 player,
                                   class_591<class_742> model, Pose pose, class_1306 arm) {
        if (arm == class_1306.field_6183 ? pose.hideRightHeld : pose.hideLeftHeld) return;
        class_1799 stack = arm == player.method_6068() ? player.method_6047() : player.method_6079();
        if (stack.method_7960()) return;
        boolean left = arm == class_1306.field_6182;
        ps.method_22903();
        model.method_2803(arm, ps);
        ps.method_22907(class_7833.field_40714.rotationDegrees(-90f));
        ps.method_22907(class_7833.field_40716.rotationDegrees(180f));
        ps.method_46416((left ? -1 : 1) / 16f, 0.125f, -0.625f);
        PlayerModelBridge.applyItemBone(ps, pose, arm);
        class_310.method_1551().method_1561().method_43336().method_3233(player, stack,
            left ? class_811.field_4323 : class_811.field_4320, left, ps, buffers, light);
        ps.method_22909();
    }
}
