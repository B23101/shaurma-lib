package dev.shaurmalib.meta.mc.screen;

import dev.shaurmalib.meta.client.MetaClient;
import dev.shaurmalib.meta.cosmetics.CosmeticDef;
import dev.shaurmalib.meta.cosmetics.CosmeticSlot;
import dev.shaurmalib.meta.cosmetics.Rarity;
import dev.shaurmalib.meta.cosmetics.Worn;
import dev.shaurmalib.meta.economy.ChestDef;
import dev.shaurmalib.meta.economy.Reward;
import dev.shaurmalib.meta.mc.MetaScreens;
import dev.shaurmalib.meta.mc.skin.MetaSkin;
import dev.shaurmalib.meta.mc.ui.MetaUi;
import dev.shaurmalib.meta.profile.MetaProfile;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.class_332;
import net.minecraft.class_437;

/**
 * Відкриття скрині з рулеткою.
 *
 * <ol>
 *   <li><b>Скриня</b> (0–1 с): модель скрині трясеться дедалі сильніше, світиться кольором рідкості, що випала;</li>
 *   <li><b>Удар</b>: спалах, струс, іскри — скриня «розкривається»;</li>
 *   <li><b>Рулетка</b> (~4.6 с): стрічка карток із 3D-предметами каталогу мчить і гальмує до виграшу; кожна картка,
 *       що проходить маркер, — тік (тон росте, інтервал рідшає);</li>
 *   <li><b>Показ</b>: виграшна картка збільшується, промені й кільця кольору рідкості, великий предмет обертається,
 *       «НОВЕ» або «ДУБЛІКАТ → уламки»; кнопки «ЗАБРАТИ», «ВІДКРИТИ ЩЕ» (якщо є ще), «ПРИМІРЯТИ».</li>
 * </ol>
 * Що випало, вирішує СЕРВЕР до анімації; рулетка лише показує його вибір (картки-«заповнювачі» — випадкові
 * предмети за вагами рідкостей цієї скрині). Enter/Пробіл — одразу до показу.
 */
public class ChestOpenScreen extends MetaScreen {

    private static final float SHAKE_END = 1.0f, SPIN_START = 1.15f, SPIN_LEN = 4.6f;
    private static final int WIN = 38, CARD_W = 96, CARD_H = 108, GAP = 8;

    private final String chestId, item;
    private final Rarity rarity;
    private final List<Reward> given;
    private final int left;
    private final ChestDef chest;
    /** Елемент стрічки: косметика (3D) або будь-яка інша нагорода — уламки, монети, деталі (іконка). */
    private record Entry(CosmeticDef d, Reward r, Rarity rar) {}

    private final List<Entry> strip = new ArrayList<>();
    private final Random rnd = new Random();
    private float skipT = -1, lastTickPos = Float.NaN, revealAt = -1;
    private boolean burstDone, revealSound;

    private static final class P { float x, y, vx, vy, life, max; int rgb, size; }
    private final List<P> parts = new ArrayList<>();

    public ChestOpenScreen(class_437 parent, String chestId, String rarity, String item, List<Reward> given, int left) {
        super("Скриня", parent);
        this.nav = false;
        this.chestId = chestId;
        this.item = item == null ? "" : item;
        Rarity r;
        try { r = Rarity.valueOf(rarity); } catch (RuntimeException e) { r = Rarity.COMMON; }
        this.rarity = r;
        this.given = List.copyOf(given);
        this.left = left;
        this.chest = mode == null ? null : mode.chest(chestId);
        buildStrip();
    }

    public class_437 parentScreen() { return parent; }

    @Override protected String section() { return "shop"; }

    /** Стрічка: випадкові предмети за вагами скрині, на позиції {@link #WIN} — справжній виграш. */
    private void buildStrip() {
        if (mode == null) return;
        List<CosmeticDef> pool = new ArrayList<>();
        for (CosmeticDef d : mode.cosmetics.all()) if (!d.starter() && !d.hidden() && !d.model().isEmpty()) pool.add(d);
        CosmeticDef win = mode.cosmetics.get(item);
        // не лише косметика: уламки/монети й деталі для крафту теж «крутяться» (як і можуть випасти)
        List<Reward> other = new ArrayList<>();
        String shard = mode.shardCurrency.isEmpty() ? mode.currency.id() : mode.shardCurrency;
        for (int k = 1; k <= 3; k++) other.add(Reward.coins(shard, mode.duplicateRefund * k * 2));
        for (var m : mode.materials.values()) other.add(Reward.material(m.id(), 1 + rnd.nextInt(3)));
        for (int i = 0; i < WIN + 6; i++) {
            if (i == WIN) {
                if (win != null) strip.add(new Entry(win, null, win.rarity()));
                else strip.add(new Entry(null, given.isEmpty() ? Reward.coins(shard, 0) : given.get(0), rarity));
                continue;
            }
            if (!other.isEmpty() && (pool.isEmpty() || rnd.nextInt(4) == 0)) {
                strip.add(new Entry(null, other.get(rnd.nextInt(other.size())), Rarity.values()[rnd.nextInt(2)]));
                continue;
            }
            Rarity want = rollRarity();
            List<CosmeticDef> of = new ArrayList<>();
            for (CosmeticDef d : pool) if (d.rarity() == want) of.add(d);
            if (of.isEmpty()) of = pool;
            CosmeticDef d = of.isEmpty() ? null : of.get(rnd.nextInt(of.size()));
            strip.add(new Entry(d, d == null ? other.isEmpty() ? null : other.get(0) : null, d == null ? Rarity.COMMON : d.rarity()));
        }
        // за крок до виграшу — «ледь не» рідкісніша (класична інтрига рулетки)
        if (WIN + 1 < strip.size()) for (CosmeticDef d : pool) if (d.rarity().ordinal() > rarity.ordinal()) { strip.set(WIN + 1, new Entry(d, null, d.rarity())); break; }
    }

    private Rarity rollRarity() {
        if (chest == null || chest.weights().isEmpty()) return Rarity.values()[rnd.nextInt(3)];
        int total = 0;
        for (int w : chest.weights().values()) total += Math.max(0, w);
        int pick = rnd.nextInt(Math.max(1, total));
        for (Map.Entry<Rarity, Integer> e : chest.weights().entrySet()) { pick -= Math.max(0, e.getValue()); if (pick < 0) return e.getKey(); }
        return Rarity.COMMON;
    }

    private float t() { return skipT >= 0 ? Math.max(time, SPIN_START + SPIN_LEN + .05f) : time; }

    /** Позиція стрічки (у картках) з плавним гальмуванням: швидко → дуже повільно → рівно на виграші. */
    private float spinPos(float t) {
        float u = MetaUi.clamp01((t - SPIN_START) / SPIN_LEN);
        float e = 1f - (float) Math.pow(1f - u, 3.6);
        // зупинка не точно по центру картки — трохи «доїжджає», як справжня рулетка
        return e * (WIN + .18f * (float) Math.sin(u * 3.1f) * (1 - u));
    }

    private void cue(String c, float pitch) {
        if (skipT >= 0 && !c.equals("reward") && !c.equals("levelup") && !c.equals("victory")) return;
        if (!skin.sound(c, pitch) && field_22787 != null) {
            var ev = switch (c) {
                case "levelup" -> net.minecraft.class_3417.field_14709;
                case "victory" -> net.minecraft.class_3417.field_15195;
                case "reward" -> net.minecraft.class_3417.field_14627;
                case "stamp" -> net.minecraft.class_3417.field_14982;
                default -> net.minecraft.class_3417.field_15204.comp_349();
            };
            field_22787.method_1483().method_4873(net.minecraft.class_1109.method_4757(ev, pitch, c.equals("tick") ? .35f : .7f));
        }
    }

    @Override
    protected void draw(class_332 g) {
        float t = t();
        int rc = rarity.color;
        updateParts();
        // затемнення — на все вікно, а не лише на полотно 960×540 (інакше видно шов по краях полотна)
        g.method_25294(Math.round(-ox / ui) - 1, Math.round(-oy / ui) - 1, Math.round((field_22789 - ox) / ui) + 1, Math.round((field_22790 - oy) / ui) + 1, MetaUi.a(0, .55f));
        MetaUi.glowEllipse(g, 480, 270, 420, 160, rc, .10f + .05f * (float) Math.sin(time * 2));

        String title = chest == null ? "СКРИНЯ" : chest.name().toUpperCase();
        MetaUi.textSC(g, field_22793, title, 480, 34, 2f, MetaUi.solid(theme.text()), true);
        MetaUi.textSC(g, field_22793, t < SPIN_START ? "ВІДКРИВАЮ…" : t < SPIN_START + SPIN_LEN ? "КРУТИТЬСЯ…" : "ВИПАЛО!", 480, 56, 1f,
                MetaUi.solid(t < SPIN_START + SPIN_LEN ? theme.dim() : MetaUi.mix(rc, 0xFFFFFF, .3f)), false);

        if (t < SPIN_START) drawShake(g, t, rc);
        else drawStrip(g, t, rc);
        if (t >= SPIN_START + SPIN_LEN) drawReveal(g, t, rc);
        drawParts(g);
    }

    // ── 1. скриня трясеться ──
    private void drawShake(class_332 g, float t, int rc) {
        float k = MetaUi.clamp01(t / SHAKE_END);
        float amp = k * k * 7f;
        float sx = (float) Math.sin(time * 60) * amp, sy = (float) Math.cos(time * 47) * amp * .6f;
        float sc = 5f + k * 1.2f + (float) Math.sin(time * 30) * k * .2f;
        MetaUi.glowDisc(g, 480, 270, (int) (60 + 50 * k), rc, .25f + .45f * k);
        Preview.itemIcon(g, chest == null ? "minecraft:chest" : chest.model(), 480 + sx, 270 + sy, sc);
        int ticks = (int) (t * (6 + 14 * k));
        if (!Float.isNaN(lastTickPos) && ticks != (int) lastTickPos) cue("tick", .7f + .6f * k);
        lastTickPos = ticks;
        if (t >= SHAKE_END && !burstDone) {
            burstDone = true;
            cue("stamp", 1f);
            for (int i = 0; i < 70; i++) spawn(480, 270, rc, 120 + rnd.nextFloat() * 260);
        }
    }

    // ── 2. рулетка ──
    private void drawStrip(class_332 g, float t, int rc) {
        if (!burstDone) { burstDone = true; for (int i = 0; i < 70; i++) spawn(480, 270, rc, 120 + rnd.nextFloat() * 260); }
        float flash = MetaUi.clamp01(1f - (t - SHAKE_END) / .4f);
        float pos = spinPos(t);
        int stripY = 220, cx = 480, x0 = 40, x1 = 920;
        float in = MetaUi.outCubic((t - SHAKE_END) / .35f);
        panel(g, x0 - 6, stripY - 8, x1 - x0 + 12, CARD_H + 16, true);
        g.method_44379((int) (ox + x0 * ui), (int) (oy + (stripY - 6) * ui), (int) (ox + x1 * ui), (int) (oy + (stripY + CARD_H + 6) * ui));
        int first = Math.max(0, (int) Math.floor(pos) - 7), last = Math.min(strip.size() - 1, (int) Math.ceil(pos) + 7);
        for (int i = first; i <= last; i++) {
            float off = (i - pos) * (CARD_W + GAP);
            int x = Math.round(cx - CARD_W / 2f + off + (1f - in) * 300f);
            if (x + CARD_W < x0 || x > x1) continue;
            drawCard(g, strip.get(i), x, stripY, i == WIN && t >= SPIN_START + SPIN_LEN, t);
        }
        g.method_44380();
        depthBarrier(g);   // 3D-предмети пишуть глибину — маркер і затемнення мають бути ПОВЕРХ них
        // боки затемнені — фокус на центрі
        // плавне затухання країв (замість 10-піксельних сходинок)
        MetaUi.gradH(g, x0, stripY - 6, 140, CARD_H + 12, MetaUi.a(0, .85f), MetaUi.a(0, 0f));
        MetaUi.gradH(g, x1 - 140, stripY - 6, 140, CARD_H + 12, MetaUi.a(0, 0f), MetaUi.a(0, .85f));
        // маркер
        int mc = MetaUi.mix(theme.gold(), 0xFFFFFF, .3f);
        // лінія маркера — лише над сценою картки, рядок назви лишається вільним
        g.method_25294(cx - 1, stripY - 14, cx + 1, stripY + CARD_H - 24, MetaUi.solid(mc));
        for (int i = 0; i < 6; i++) {
            g.method_25294(cx - 6 + i, stripY - 16 + i, cx + 6 - i, stripY - 15 + i, MetaUi.solid(mc));
            g.method_25294(cx - 6 + i, stripY + CARD_H + 15 - i, cx + 6 - i, stripY + CARD_H + 16 - i, MetaUi.solid(mc));
        }
        // тік на кожну картку, що проходить маркер
        int cell = (int) Math.floor(pos + .5f);
        if (!Float.isNaN(lastTickPos) && cell != (int) lastTickPos && t < SPIN_START + SPIN_LEN) {
            float sp = MetaUi.clamp01((t - SPIN_START) / SPIN_LEN);
            cue("tick", .85f + .5f * sp);
        }
        lastTickPos = cell;
        if (flash > 0) g.method_25294(0, 0, DW, DH, MetaUi.a(0xFFFFFF, flash * .35f));
    }

    private void drawCard(class_332 g, Entry e, int x, int y, boolean win, float t) {
        CosmeticDef d = e == null ? null : e.d();
        int col = e == null ? theme.dim() : e.rar().color;
        float glow = win ? .6f + .4f * (float) Math.sin(time * 6) : 0f;
        skin.card(g, x, y, CARD_W, CARD_H, col, win, glow, time);
        skin.stage(g, x + 2, y + 2, CARD_W - 4, CARD_H - 26, col, time, glow);
        if (d != null) {
            Worn w = new Worn(d.id(), d.defaultColor());
            w.validate(d.slot());
            boolean au = d.slot() == CosmeticSlot.AURA;
            // предмет моделі може бути більшим за блок — дрібніше, щоб цілком влазив у сцену картки
            Preview.cosmeticOnly(g, this, w, d.slot(), x + CARD_W / 2f, y + 2 + (CARD_H - 26) / 2f + (au ? 10 : 2), au ? 24f : 34f,
                    200f + time * 50f, x + 2, y + 2, CARD_W - 4, CARD_H - 26);
            MetaUi.text(g, field_22793, MetaUi.fit(field_22793, d.name(), CARD_W - 10), x + 5, y + CARD_H - 19, MetaUi.solid(theme.text()), false);
            g.method_25294(x + 3, y + CARD_H - 6, x + CARD_W - 3, y + CARD_H - 3, MetaUi.solid(col));
        } else if (e != null && e.r() != null) {
            int ic = MetaScreens.rewardColor(mode, e.r());
            MetaUi.glowDisc(g, x + CARD_W / 2, y + 40, 22, ic, .35f);
            icon(g, MetaScreens.rewardIcon(mode, e.r()), x + CARD_W / 2 - 12, y + 28, 3, MetaUi.solid(ic));
            MetaUi.text(g, field_22793, MetaUi.fit(field_22793, MetaScreens.rewardText(mode, e.r()), CARD_W - 10), x + 5, y + CARD_H - 19, MetaUi.solid(theme.text()), false);
            g.method_25294(x + 3, y + CARD_H - 6, x + CARD_W - 3, y + CARD_H - 3, MetaUi.solid(col));
        }
        skin.cardOverlay(g, x, y, CARD_W, CARD_H, col, win, glow, time);
    }

    // ── 3. показ виграшу ──
    private void drawReveal(class_332 g, float t, int rc) {
        if (revealAt < 0) {
            revealAt = time;
            for (int i = 0; i < 120; i++) spawn(480, 272, rc, 80 + rnd.nextFloat() * 360);
        }
        float k = (time - revealAt);
        if (!revealSound) {
            revealSound = true;
            cue("reward", 1f);
            if (rarity.ordinal() >= Rarity.EPIC.ordinal()) cue("levelup", .9f + .1f * rarity.ordinal());
            if (rarity.ordinal() >= Rarity.LEGENDARY.ordinal()) cue("victory", 1f);
        }
        // промені кольору рідкості
        float ra = MetaUi.clamp01(k / .4f);
        for (int i = 0; i < 16; i++) {
            double an = i * Math.PI / 8 + time * .4;
            for (int dd = 70; dd < 70 + 200 * ra; dd += 4) {
                int px = 480 + (int) (Math.cos(an) * dd), py = 272 + (int) (Math.sin(an) * dd * .5);
                g.method_25294(px, py, px + 2, py + 2, MetaUi.a(rc, .35f * (1f - (dd - 70) / 200f) * ra));
            }
        }
        // кільця, що розходяться
        for (int r = 0; r < 3; r++) {
            float rk = MetaUi.clamp01((k - r * .15f) / .9f);
            if (rk <= 0 || rk >= 1) continue;
            MetaUi.ring(g, 480, 272, (int) (50 + rk * 330), (int) (25 + rk * 150), MetaUi.a(rc, (1 - rk) * .8f), 64, time);
        }
        // інформаційна плашка під стрічкою
        float in = MetaUi.outBack(MetaUi.clamp01(k / .45f));
        int py = 350 + Math.round((1f - in) * 30);
        CosmeticDef d = mode == null ? null : mode.cosmetics.get(item);
        String name = d != null ? d.name() : given.isEmpty() ? "—" : MetaScreens.rewardText(mode, given.get(0));
        MetaUi.textSC(g, field_22793, name, 480, py, 2f, MetaUi.solid(MetaUi.mix(rc, 0xFFFFFF, .35f)), true);
        int tw = (int) (MetaUi.widthS(field_22793, rarity.title, .75f)) + 8;
        skin.tag(g, field_22793, 480 - tw / 2, py + 22, rarity.title, rc, true);
        boolean dup = d != null && !given.isEmpty() && given.get(0).type() != Reward.Type.COSMETIC;
        String sub = dup ? "Уже був — замість нього " + MetaScreens.rewardText(mode, given.get(0)) : d != null ? "НОВЕ — додано в гардероб" : "";
        if (!sub.isEmpty()) MetaUi.textSC(g, field_22793, sub, 480, py + 40, 1f, MetaUi.solid(dup ? theme.dim() : theme.good()), false);
        if (chest != null && chest.pityEvery() > 0 && chest.pityRarity() != null) {
            MetaProfile p = me();
            long pity = p == null ? 0 : p.stats.get(chest.pityKey());
            MetaUi.textSC(g, field_22793, "Гарант «" + chest.pityRarity().title + "»: " + pity + " / " + chest.pityEvery(), 480, py + 56, .8f, MetaUi.solid(theme.dim()), false);
        }

        float ba = MetaUi.clamp01((k - .5f) / .3f);
        if (ba <= 0) return;
        int by = 450;
        primary(g, "take", 480 - 100, by, 200, 28, "ЗАБРАТИ  [ENTER]", this::method_25419);
        if (left > 0) button(g, "again", 480 - 320, by, 200, 28, "ВІДКРИТИ ЩЕ (" + left + ")", MetaSkin.Kind.NORMAL, () -> { click(); MetaClient.openChest(chestId); });
        if (d != null && !dup) button(g, "try", 480 + 120, by, 200, 28, "ПРИМІРЯТИ", MetaSkin.Kind.NORMAL, () -> { click(); MetaScreens.open("wardrobe", parent); });
    }

    // ── частинки ──
    private void spawn(float x, float y, int rgb, float sp) {
        P p = new P();
        double an = rnd.nextDouble() * Math.PI * 2;
        p.x = x; p.y = y;
        p.vx = (float) (Math.cos(an) * sp);
        p.vy = (float) (Math.sin(an) * sp * .7) - 60;
        p.max = p.life = .7f + rnd.nextFloat() * .9f;
        p.size = 1 + rnd.nextInt(3);
        p.rgb = rnd.nextInt(4) == 0 ? 0xFFFFFF : rgb;
        parts.add(p);
    }

    private void updateParts() {
        for (int i = parts.size() - 1; i >= 0; i--) {
            P p = parts.get(i);
            p.life -= dt;
            if (p.life <= 0) { parts.remove(i); continue; }
            p.vy += 220 * dt;
            p.vx *= (float) Math.exp(-dt * 1.8);
            p.x += p.vx * dt;
            p.y += p.vy * dt;
        }
    }

    private void drawParts(class_332 g) {
        for (P p : parts) {
            float a = MetaUi.clamp01(p.life / p.max * 1.4f);
            g.method_25294((int) p.x, (int) p.y, (int) p.x + p.size, (int) p.y + p.size, MetaUi.a(p.rgb, a));
        }
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER || key == GLFW.GLFW_KEY_SPACE) {
            if (time >= SPIN_START + SPIN_LEN || skipT >= 0) method_25419();
            else { skipT = time; burstDone = true; }
            return true;
        }
        return super.method_25404(key, scan, mods);
    }
}
