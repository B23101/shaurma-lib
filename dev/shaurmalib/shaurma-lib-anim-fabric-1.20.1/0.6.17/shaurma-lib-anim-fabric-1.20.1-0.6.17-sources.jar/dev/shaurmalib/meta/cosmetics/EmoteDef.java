package dev.shaurmalib.meta.cosmetics;

/**
 * Анімація (емоція колеса) як косметика: купується за валюту, ставиться в слот колеса в гардеробі.
 * {@code id} — id емоції рушія ({@code maniacmod:wave}); {@code starter} — є в усіх одразу.
 */
public record EmoteDef(String id, String name, Rarity rarity, String currency, long price, boolean starter) {

    /** Ключ у {@code MetaProfile.owned}. */
    public static String key(String emoteId) { return "emote:" + emoteId; }
}
