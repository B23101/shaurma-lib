package dev.shaurmalib.meta.cosmetics;

import dev.shaurmalib.meta.io.J;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Гардероб гравця: окремий образ на кожен «варіант» режиму (мафія — «Гравець»; маніяк — «Виживий» і «Маніяк»)
 * плюс {@link #PRESETS} збережених образів. Який варіант зараз на гравці — вирішує сервер режиму
 * ({@code MetaServer#setVariant}), а не клієнт.
 */
public final class Wardrobe {

    public static final int PRESETS = 3;

    private final Map<String, Look> looks = new LinkedHashMap<>();
    /** Збережені образи за «областю»: «» — спільні (гравець/виживий), інакше — id персонажа (свої в кожного маніяка). */
    private final Map<String, Look[]> presetsBy = new LinkedHashMap<>();
    private final Map<String, String[]> namesBy = new LinkedHashMap<>();

    private Look[] presets(String scope) { return presetsBy.computeIfAbsent(scope == null ? "" : scope, k -> new Look[PRESETS]); }

    private String[] names(String scope) { return namesBy.computeIfAbsent(scope == null ? "" : scope, k -> new String[PRESETS]); }

    public static final int NAME_MAX = 24;

    public Look look(String variant) { return looks.computeIfAbsent(variant, k -> new Look()); }

    public void setLook(String variant, Look look) { looks.put(variant, look == null ? new Look() : look); }

    public Look preset(int slot) { return preset("", slot); }

    public Look preset(String scope, int slot) { return slot >= 0 && slot < PRESETS ? presets(scope)[slot] : null; }

    public void setPreset(int slot, Look look) { setPreset("", slot, look); }

    public void setPreset(String scope, int slot, Look look) {
        if (slot < 0 || slot >= PRESETS) return;
        presets(scope)[slot] = look;
        if (look == null) names(scope)[slot] = null;
    }

    /** Зберегти образ під вигаданою назвою. */
    public void setPreset(int slot, Look look, String name) { setPreset("", slot, look, name); }

    public void setPreset(String scope, int slot, Look look, String name) {
        setPreset(scope, slot, look);
        if (slot >= 0 && slot < PRESETS && look != null) names(scope)[slot] = cleanName(name);
    }

    /** Назва образу; порожньо — без назви. */
    public String presetName(int slot) { return presetName("", slot); }

    public String presetName(String scope, int slot) {
        String[] n = names(scope);
        return slot >= 0 && slot < PRESETS && n[slot] != null ? n[slot] : "";
    }

    /** Без керівних символів і крайніх пробілів, не довше {@link #NAME_MAX} (діє й на сервері, тож чужий клієнт не вставить сміття). */
    public static String cleanName(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length() && b.length() < NAME_MAX * 2; i++) {
            char c = s.charAt(i);
            if (c >= 32 && c != 127) b.append(c);
        }
        String t = b.toString().trim();
        return t.length() > NAME_MAX ? t.substring(0, NAME_MAX).trim() : t;
    }

    public Map<String, Look> looks() { return java.util.Collections.unmodifiableMap(looks); }

    public Wardrobe copy() {
        Wardrobe w = new Wardrobe();
        looks.forEach((k, v) -> w.looks.put(k, v.copy()));
        presetsBy.forEach((scope, arr) -> {
            Look[] to = w.presets(scope);
            String[] from = names(scope), toN = w.names(scope);
            for (int i = 0; i < PRESETS; i++) { to[i] = arr[i] == null ? null : arr[i].copy(); toN[i] = from[i]; }
        });
        return w;
    }

    public void validate(CosmeticCatalog catalog, java.util.function.Predicate<String> owned, List<String> variants) {
        validate(catalog, owned, variants, null);
    }

    public void validate(CosmeticCatalog catalog, java.util.function.Predicate<String> owned, List<String> variants,
                         java.util.function.BiPredicate<String, Integer> colorOwned) {
        validateBy(catalog, (v, item) -> owned == null || owned.test(item), variants,
                colorOwned == null ? null : (v, item, c) -> colorOwned.test(item, c));
    }

    /** Перевірка відтінку для варіанта: {@code (варіант, предмет, RGB)}. */
    @FunctionalInterface
    public interface ColorCheck { boolean test(String variant, String item, int rgb); }

    /**
     * Сервер: кожен образ перевіряється володінням СВОГО варіанта ({@code owned(варіант, предмет)}) — у маніяка свої покупки.
     * Образи невідомих варіантів і чужі області пресетів прибираються.
     */
    public void validateBy(CosmeticCatalog catalog, java.util.function.BiPredicate<String, String> owned, List<String> variants,
                           ColorCheck colorOwned) {
        looks.keySet().removeIf(k -> !variants.contains(k));
        for (Map.Entry<String, Look> e : looks.entrySet()) {
            String v = e.getKey();
            e.getValue().validate(catalog, owned == null ? null : item -> owned.test(v, item),
                    colorOwned == null ? null : (item, c) -> colorOwned.test(v, item, c));
        }
        presetsBy.keySet().removeIf(k -> !k.isEmpty() && !variants.contains(k));
        namesBy.keySet().removeIf(k -> !presetsBy.containsKey(k));
        for (Look[] arr : presetsBy.values()) for (Look p : arr) if (p != null) p.validate(catalog, null);
    }

    /** Прибрати з образів слоти, не дозволені варіанту (маніяк не носить тіло й ноги). */
    public void restrict(java.util.function.Function<String, ? extends java.util.Collection<CosmeticSlot>> allowed) {
        for (Map.Entry<String, Look> e : looks.entrySet()) {
            java.util.Collection<CosmeticSlot> ok = allowed.apply(e.getKey());
            for (CosmeticSlot s : CosmeticSlot.values()) if (!ok.contains(s)) e.getValue().remove(s);
        }
    }

    /** Зняти предмет з усіх образів (наприклад, якщо його прибрали з каталогу). */
    public void strip(String itemId) {
        for (Look l : looks.values()) l.view().entrySet().stream()
                .filter(e -> e.getValue().item.equals(itemId)).map(Map.Entry::getKey).toList().forEach(l::remove);
    }

    public Map<String, Object> toJson() {
        Map<String, Object> l = new LinkedHashMap<>();
        looks.forEach((k, v) -> l.put(k, v.toJson()));
        // спільні образи — у старих полях (старий клієнт їх прочитає), образи персонажів — у «scoped»
        Map<String, Object> scoped = new LinkedHashMap<>();
        presetsBy.forEach((scope, arr) -> { if (!scope.isEmpty()) scoped.put(scope, J.o("presets", presetList(scope), "names", nameList(scope))); });
        return J.o("looks", l, "presets", presetList(""), "presetNames", nameList(""), "scoped", scoped);
    }

    private List<Object> presetList(String scope) {
        List<Object> p = new ArrayList<>();
        for (Look x : presets(scope)) p.add(x == null ? null : x.toJson());
        return p;
    }

    private List<Object> nameList(String scope) {
        List<Object> n = new ArrayList<>();
        for (String x : names(scope)) n.add(x == null ? "" : x);
        return n;
    }

    private static void readPresets(Wardrobe w, String scope, List<Object> p, List<Object> names) {
        Look[] arr = w.presets(scope);
        String[] nm = w.names(scope);
        for (int i = 0; i < Math.min(PRESETS, p.size()); i++) arr[i] = p.get(i) instanceof Map ? Look.fromJson(J.asObj(p.get(i))) : null;
        for (int i = 0; i < Math.min(PRESETS, names.size()); i++) {
            if (arr[i] != null && names.get(i) instanceof String n && !cleanName(n).isEmpty()) nm[i] = cleanName(n);
        }
    }

    public static Wardrobe fromJson(Map<String, Object> o) {
        Wardrobe w = new Wardrobe();
        for (Map.Entry<String, Object> e : J.obj(o, "looks").entrySet()) w.looks.put(e.getKey(), Look.fromJson(J.asObj(e.getValue())));
        readPresets(w, "", J.arr(o, "presets"), J.arr(o, "presetNames"));
        for (Map.Entry<String, Object> e : J.obj(o, "scoped").entrySet()) {
            if (e.getKey().isEmpty()) continue;
            Map<String, Object> s = J.asObj(e.getValue());
            readPresets(w, e.getKey(), J.arr(s, "presets"), J.arr(s, "names"));
        }
        return w;
    }
}
