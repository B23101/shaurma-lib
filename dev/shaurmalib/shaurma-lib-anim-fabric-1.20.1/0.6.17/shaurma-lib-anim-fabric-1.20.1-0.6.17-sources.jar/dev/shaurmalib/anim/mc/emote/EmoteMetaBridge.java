package dev.shaurmalib.anim.mc.emote;

import dev.shaurmalib.anim.ShaurmaAnim;
import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.anim.emote.Emote;
import dev.shaurmalib.anim.emote.EmoteWheel;
import dev.shaurmalib.anim.emote.ShaurmaEmotes;
import dev.shaurmalib.anim.runtime.Animator;
import dev.shaurmalib.anim.runtime.PlayRequest;
import dev.shaurmalib.anim.runtime.Slot;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 * Міст для мета-двигуна (гардероб): лише прості типи Java, бо мета-артефакт не залежить від рушія анімацій і
 * викликає цей клас рефлексією ({@code MetaEmotes}). Тут — список емоцій, превʼю на манекені гардероба й колесо.
 */
public final class EmoteMetaBridge {

    private EmoteMetaBridge() {}

    /** Усі емоції, дозволені режимом: {id, назва, категорія, маска}. */
    public static List<String[]> list() {
        List<String[]> out = new ArrayList<>();
        for (Emote e : ShaurmaEmotes.registry().available()) out.add(new String[]{e.id(), EmoteText.name(e).getString(), e.category(), e.mask()});
        return out;
    }

    /** Програти емоцію на аніматорі превʼю (манекен гардероба) по колу; null — зупинити. */
    public static void preview(Object animator, String emoteId) {
        if (!(animator instanceof Animator a)) return;
        Emote e = emoteId == null ? null : ShaurmaEmotes.get(emoteId);
        if (e == null || !ShaurmaAnim.clips().has(e.clip())) {
            a.stop(Slot.ACTION, .2f);
            return;
        }
        a.play(PlayRequest.of(e.clip()).slot(Slot.ACTION).mask(e.mask()).restart(true).fade(.12f, .2f)
                .loop(AnimationClip.LoopMode.LOOP).tag("wardrobe"));
    }

    /** Колесо з профілю (сервер — джерело правди) → локальне колесо емоцій і файл. */
    public static void applyWheel(List<String> ids) {
        boolean any = false;
        for (String id : ids) if (id != null && !id.isEmpty()) { any = true; break; }
        if (!any) return;   // на сервері колесо ще не налаштоване — лишаємо локальне
        EmoteWheel w = EmoteClient.wheel();
        w.reset();
        for (int i = 0; i < Math.min(EmoteWheel.SLOTS, ids.size()); i++) {
            String id = ids.get(i);
            if (id != null && !id.isEmpty()) w.set(i, id);
        }
        EmoteClient.save();
    }

    public static void setClientOwned(Predicate<String> owned) { ShaurmaEmotes.setClientOwned(owned); }

    public static int slots() { return EmoteWheel.SLOTS; }
}
