package dev.shaurmalib.meta.mc.screen;

import dev.shaurmalib.meta.cosmetics.CosmeticDef;
import dev.shaurmalib.meta.cosmetics.CosmeticSlot;
import dev.shaurmalib.meta.cosmetics.Look;
import dev.shaurmalib.meta.cosmetics.Worn;
import dev.shaurmalib.meta.mc.render.CosmeticRenderer;
import net.minecraft.class_1664;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_490;
import net.minecraft.class_745;
import org.joml.Quaternionf;

/**
 * 3D-прев'ю косметики на манекені зі скіном гравця (картки магазину, пропуску, гардероба) і фон-«промені»
 * за рідкістю, як у карток вітрини.
 */
final class Preview {

    private static class_745 mannequin;

    private Preview() {}

    static class_745 mannequin() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return null;
        if (mannequin == null || mannequin.method_37908() != mc.field_1687) {
            mannequin = new class_745(mc.field_1687, mc.field_1724.method_7334()) {
                @Override public boolean method_7348(class_1664 part) { return true; }
                @Override public boolean method_7325() { return false; }   // інакше манекен з UUID спостерігача — лише голова
                @Override public boolean method_7337() { return false; }
            };
        }
        return mannequin;
    }

    /** Манекен з одним предметом у прямокутнику (дизайнові координати екрана {@code s}). */
    static void item(class_332 g, MetaScreen s, CosmeticDef d, int x, int y, int w, int h, float yaw) {
        Worn worn = new Worn(d.id(), d.defaultColor());
        worn.validate(d.slot());
        Look look = new Look().only(d.slot(), worn);
        boolean aura = d.slot() == CosmeticSlot.AURA, pet = d.slot() == CosmeticSlot.PET;
        // для капелюха — крупніше й вище (видно голову), для улюбленця/аури — весь манекен
        // аура: ступня — біля низу сцени; render() сам піднімає сцену на висоту кільця, тож голова не обрізається
        float size = d.slot() == CosmeticSlot.HEAD ? h * .62f : aura ? h * .30f : h * .40f;
        int foot = d.slot() == CosmeticSlot.HEAD ? y + h + (int) (h * .55f) : y + h - (aura ? 4 : 8);
        figure(g, s, x + w / 2, foot, size, yaw, look, x, y, w, h, aura, pet ? -.1f : 0);
    }

    static void figure(class_332 g, MetaScreen s, int cx, int foot, float size, float yaw, Look look,
                       int clx, int cly, int clw, int clh, boolean tilt, float lift) {
        class_745 m = mannequin();
        if (m == null) return;
        float t = (System.nanoTime() / 1_000_000L % 1_000_000L) / 1000f;
        m.field_6012 = (int) (t * 20f);   // від нього залежить гойдання рук у ванільній idle-позі
        idle(m, t, false);
        g.method_44379((int) (s.ox + clx * s.ui), (int) (s.oy + cly * s.ui), (int) (s.ox + (clx + clw) * s.ui), (int) (s.oy + (cly + clh) * s.ui));
        CosmeticRenderer.preview = look;
        CosmeticRenderer.drawingPreview = true;
        CosmeticRenderer.previewYaw = yaw;
        CosmeticRenderer.previewTilt = tilt ? .42f : 0f;
        CosmeticRenderer.previewLift = lift;
        try {
            render(g, cx, foot, size, yaw, m, look.get(CosmeticSlot.AURA), tilt, clw);
        } finally {
            CosmeticRenderer.drawingPreview = false;
            CosmeticRenderer.preview = null;
            CosmeticRenderer.previewTilt = CosmeticRenderer.previewLift = 0;
            g.method_44380();
        }
    }

    /**
     * Жива idle-поза манекена замість «статуї»: повільний зсув ваги, голова злегка дрейфує й раз на ~7 с
     * «роззирається» убік з легким кивком (напрям змінюється щоразу). Під час ходьби голова тримається прямо.
     * Ванільне гойдання рук іде від {@code tickCount}, тож його виставляє той, хто викликає (екран чи {@link #figure}).
     */
    static void idle(class_745 m, float t, boolean moving) { idle(m, t, moving, 0f, 0f); }

    /** Те саме + додатковий поворот голови (градуси) — гардероб користується ним, коли персонаж «оглядає себе». */
    static void idle(class_745 m, float t, boolean moving, float extraYaw, float extraPitch) {
        float body = (float) Math.sin(t * .50) * 4f;
        float yawOff = 0f, pitch = 0f;
        if (!moving) {
            float period = 7f, u = (t % period) / period;
            float side = ((long) (t / period) & 1L) == 0 ? 1f : -1f;
            float glance = u < .22f ? (float) Math.sin(u / .22f * Math.PI) : 0f;
            yawOff = (float) Math.sin(t * .70) * 8f + glance * 36f * side;
            pitch = (float) Math.sin(t * .90) * 2.5f + glance * 4f;
        }
        yawOff += extraYaw;
        pitch += extraPitch;
        m.field_6283 = m.field_6220 = body;
        m.field_6241 = m.field_6259 = body + yawOff;
        m.method_36456(0);
        m.method_36457(pitch);
        m.field_6004 = pitch;
    }

    /** 0..1 — наскільки «дихати»: гардероб вимикає дихання, поки персонаж у польоті. */
    static float breathMul = 1f;

    /**
     * Дихання — повільний вертикальний рух усієї моделі: вдих піднімає плечі (≈1.2 % висоти), видих опускає, з короткою
     * паузою внизу. Другий, швидший обертон дає несиметричність, щоб рух не виглядав механічним метрономом.
     * @return зсув у пікселях GUI (мінус — вгору)
     */
    static float breathOffset(float t, float size) {
        float phase = t * 1.75f;                                   // ≈ 3.6 с на цикл
        float in = (float) (.5 - .5 * Math.cos(phase));            // 0..1
        float shaped = in * in * (3f - 2f * in);                   // smoothstep: м'які краї вдиху/видиху
        float second = (float) Math.sin(phase * 2.0 + 1.1) * .12f;
        return -size * .012f * (shaped + second) * breathMul;
    }

    private static float clock() { return (System.nanoTime() / 1_000_000L % 1_000_000L) / 1000f; }

    /** Нахил сцени вперед (рад) для превʼю з аурою: кільце на підлозі читається еліпсом, а не лінією. */
    static final float AURA_PITCH = .30f;

    /**
     * Окремий аніматор для манекена (гардероб). Манекен має UUID справжнього гравця, тож без цього він брав би
     * аніматор гравця зі світу — а той у меню «стоїть» і своїм idle-кліпом перекриває ходьбу/біг.
     */
    static Object animatorOverride;

    /**
     * Єдине місце, де манекен малюється у превʼю (магазин, пропуск, гардероб, профіль): аура — ПЕРШОЮ,
     * позаду моделі (без запису глибини вона інакше лягала б поверх ніг), уся сцена — манекен разом з
     * аурою — трохи нахилена вперед, а кільце стиснуте так, щоб влізти у вікно шириною {@code clipW}.
     * Викликати всередині {@code drawingPreview = true} і зі scissor вікна.
     */
    static void render(class_332 g, float cx, float foot, float size, float yawDeg,
                       net.minecraft.class_1309 entity, Worn aura, boolean tilt, float clipW) {
        float pitch = tilt || aura != null ? AURA_PITCH : 0f;
        // Pitch — у просторі екрана (зліва від Z-фліпа), щоб нахилялася вся сцена, а не лише модель.
        Quaternionf rot = new Quaternionf().rotationX(pitch).rotateZ((float) Math.PI)
                .rotateY((float) Math.toRadians(yawDeg));
        // Після нахилу передня дуга кільця аури опускається нижче ніг — renderScene піднімає сцену на цю висоту.
        // Сплющення/розтягування й нахил усієї сцени (гардероб: приземлення, «невагомість» у руці).
        boolean deform = squashX != 1f || squashY != 1f || roll != 0f;
        if (deform) {
            var ps = g.method_51448();
            ps.method_22903();
            ps.method_46416(cx, foot - pivotUp, 0f);
            ps.method_22907(net.minecraft.class_7833.field_40718.rotationDegrees(roll));
            ps.method_46416(0f, pivotUp, 0f);
            ps.method_22905(squashX, squashY, 1f);
            ps.method_46416(-cx, -foot, 0f);
        }
        try {
            renderScene(g, cx, foot, size, yawDeg, entity, aura, rot, clipW);
        } finally {
            if (deform) g.method_51448().method_22909();
            // модель пише глибину (z≈50…200): ярлики, ціни й рамки картки, намальовані ПІСЛЯ неї, інакше лягали під ноги
            g.method_51452();
            com.mojang.blaze3d.systems.RenderSystem.clear(org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT, class_310.field_1703);
        }
    }

    /** Множники сплющення сцени відносно ніг (1 — без змін) і нахил (градуси) навколо точки на {@code pivotUp} px вище ніг. */
    static float squashX = 1f, squashY = 1f, roll = 0f, pivotUp = 0f;

    static void resetDeform() { squashX = squashY = 1f; roll = pivotUp = 0f; }

    private static void renderScene(class_332 g, float cx, float foot, float size, float yawDeg,
                                    net.minecraft.class_1309 entity, Worn aura, Quaternionf rot, float clipW) {
        float pitch = AURA_PITCH;
        if (aura != null) {
            float fit = clipW > 0 ? clipW * .44f / size : Float.MAX_VALUE;
            float r = Math.min(aura.param(CosmeticSlot.AURA, "scale") * 1.22f, fit);
            foot -= (float) (r * size * Math.sin(pitch));
        }
        final float fx = cx, ffoot = foot, fsize = size;
        final float auraTime = class_310.method_1551().field_1687 == null ? 0
                : class_310.method_1551().field_1687.method_8510() + class_310.method_1551().method_1488();
        final float fitBlocks = clipW > 0 ? clipW * .44f / size : Float.MAX_VALUE;
        CosmeticRenderer.previewAuraFit = entity instanceof net.minecraft.class_742 acp ? CosmeticRenderer.fitOf(acp)[1] : 1f;
        try {
            if (aura != null) {
                // Сендвіч: задня половина аури — ДО манекена (його тіло її перекриє), передня — ПІСЛЯ нього (лягає поверх ніг).
                drawAuraPass(g, fx, ffoot, fsize, rot, aura, yawDeg, auraTime, fitBlocks, -1);
                CosmeticRenderer.previewAuraSeparate = true;
            }
            // Дихання: зсув у float-координатах GUI (renderEntityInInventory бере int, тож зсуваємо матрицю, а не позицію).
            g.method_51448().method_22903();
            g.method_51448().method_46416(0f, breathOffset(clock() + (entity.method_5628() & 7) * 1.3f, size), 0f);
            try {
                final int ix = (int) cx, iy = (int) foot, isz = (int) size;
                if (animatorOverride != null) {
                    MetaAnimationPreview.withPreview(entity, animatorOverride, class_310.method_1551().method_1488(),
                            () -> class_490.method_48472(g, ix, iy, isz, rot, null, entity));
                } else {
                    class_490.method_48472(g, ix, iy, isz, rot, null, entity);
                }
            } finally {
                g.method_51448().method_22909();
            }
            if (aura != null) drawAuraPass(g, fx, ffoot, fsize, rot, aura, yawDeg, auraTime, fitBlocks, +1);
        } finally {
            CosmeticRenderer.previewAuraSeparate = false;
            CosmeticRenderer.previewAuraFit = 1f;
        }
    }

    /** Один прохід аури у тій самій матриці сцени, що й манекен. side: -1 позаду моделі, +1 попереду. */
    private static void drawAuraPass(class_332 g, float cx, float foot, float size, Quaternionf rot, Worn aura,
                                     float yawDeg, float time, float fitBlocks, int side) {
        var ps = g.method_51448();
        ps.method_22903();
        ps.method_22904(cx, foot, 50.0);
        ps.method_34425(new org.joml.Matrix4f().scaling(size, size, -size));
        ps.method_22907(rot);
        CosmeticRenderer.drawPreviewAura(ps, g.method_51450(), aura, yawDeg, 0f, time, fitBlocks, side);
        ps.method_22909();
        g.method_51452();
    }

    /**
     * Лише сам предмет косметики, без манекена (права панель гардероба): капелюх, рюкзак чи улюбленець — 3D-модель,
     * що повільно обертається й «плаває»; аура — саме кільце з ефектами. Центр (cx, cy), {@code size} — пікселів на блок.
     */
    static void cosmeticOnly(class_332 g, MetaScreen s, Worn w, CosmeticSlot slot, float cx, float cy, float size, float yaw,
                             int clx, int cly, int clw, int clh) {
        if (w == null) return;
        class_310 mc = class_310.method_1551();
        g.method_44379((int) (s.ox + clx * s.ui), (int) (s.oy + cly * s.ui), (int) (s.ox + (clx + clw) * s.ui), (int) (s.oy + (cly + clh) * s.ui));
        try {
            if (slot == CosmeticSlot.AURA) {
                float pitch = .55f;
                Quaternionf rot = new Quaternionf().rotationX(pitch).rotateZ((float) Math.PI).rotateY((float) Math.toRadians(yaw));
                float fit = clw * .46f / size;
                float t = mc.field_1687 == null ? clock() * 20f : mc.field_1687.method_8510() + mc.method_1488();
                drawAuraPass(g, cx, cy, size, rot, w, yaw, t, fit, 0);
                return;
            }
            net.minecraft.class_1792 it = CosmeticRenderer.item(w.item);
            if (it == null) return;
            var ps = g.method_51448();
            ps.method_22903();
            ps.method_46416(cx, cy, 150f);
            ps.method_34425(new org.joml.Matrix4f().scaling(1f, -1f, 1f));   // як GuiGraphics.renderItem: Y GUI — вниз
            ps.method_22905(size, size, size);
            ps.method_22907(net.minecraft.class_7833.field_40714.rotationDegrees(slot == CosmeticSlot.PET ? 12f : 18f));
            ps.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(yaw));
            mc.method_1480().method_23178(CosmeticRenderer.stack(it, w.color), net.minecraft.class_811.field_4315,
                    net.minecraft.class_765.field_32767, net.minecraft.class_4608.field_21444,
                    ps, g.method_51450(), mc.field_1687, 0);
            g.method_51452();
            ps.method_22909();
        } finally {
            g.method_44380();
        }
    }

    /** Предмет гри як 3D-іконка (скрині, подарунок): {@code itemId} з реєстру, центр (cx, cy), масштаб від 16 px. */
    static void itemIcon(class_332 g, String itemId, float cx, float cy, float scale) {
        var rl = net.minecraft.class_2960.method_12829(itemId);
        var it = rl == null ? net.minecraft.class_1802.field_8106 : net.minecraft.class_7923.field_41178.method_10223(rl);
        if (it == net.minecraft.class_1802.field_8162) it = net.minecraft.class_1802.field_8106;
        g.method_51448().method_22903();
        g.method_51448().method_46416(cx, cy, 0);
        g.method_51448().method_22905(scale, scale, 1);
        g.method_51448().method_46416(-8, -8, 0);
        g.method_51427(new net.minecraft.class_1799(it), 0, 0);
        g.method_51448().method_22909();
    }

    static String timer(long msLeft) {
        if (msLeft <= 0) return "0хв";
        long m = msLeft / 60_000L, h = m / 60, d = h / 24;
        if (d > 0) return d + "д " + (h % 24) + "год";
        if (h > 0) return h + "год " + (m % 60) + "хв";
        return m + "хв";
    }
}
