package dev.shaurmalib.mc;

import dev.shaurmalib.platform.math.Vec3d;
import dev.shaurmalib.platform.ref.LevelRef;
import dev.shaurmalib.platform.ref.PlayerRef;
import java.util.UUID;
import net.minecraft.class_1657;

/** Обгортка {@code Player} → {@link PlayerRef}. Єдине місце 1.20.1, що знає тип гравця. */
public record McPlayerRef(class_1657 player) implements PlayerRef {
    @Override public Object raw() { return player; }
    @Override public UUID uuid() { return player.method_5667(); }
    @Override public String name() { return player.method_7334().getName(); }
    @Override public Vec3d position() { return new Vec3d(player.method_23317(), player.method_23318(), player.method_23321()); }
    @Override public LevelRef level() { return McLevelRef.of(player.method_37908()); }
}
