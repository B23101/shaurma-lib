package dev.shaurmalib.mc;

import dev.shaurmalib.platform.ref.LevelRef;
import dev.shaurmalib.platform.ref.PlayerRef;
import dev.shaurmalib.platform.ref.ServerRef;
import dev.shaurmalib.platform.service.RefFactory;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.server.MinecraftServer;

public final class RefFactoryImpl implements RefFactory {
    @Override public PlayerRef player(Object p) { return new McPlayerRef((class_1657) p); }
    @Override public LevelRef level(Object l) { return McLevelRef.of((class_1937) l); }
    @Override public ServerRef server(Object s) { MinecraftServer m = (MinecraftServer) s; return () -> m; }
}
