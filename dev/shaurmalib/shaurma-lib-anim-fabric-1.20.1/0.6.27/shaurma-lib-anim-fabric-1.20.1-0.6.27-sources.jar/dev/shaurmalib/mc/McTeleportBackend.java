package dev.shaurmalib.mc;

import dev.shaurmalib.platform.ref.LevelRef;
import dev.shaurmalib.platform.ref.PlayerRef;
import dev.shaurmalib.platform.service.TeleportBackend;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3230;

/** Ванільний телепорт і тікети чанків для Minecraft 1.20.1 та 1.21.1. */
public final class McTeleportBackend implements TeleportBackend {
    private static class_3222 p(PlayerRef r) { return r.unwrap(class_3222.class); }

    @Override
    public void teleport(PlayerRef player, LevelRef target, double x, double y, double z, float yaw, float pitch) {
        class_3222 sp = p(player);
        class_3218 level = target != null ? target.unwrap(class_3218.class) : sp.method_51469();
        sp.method_14251(level, x, y, z, yaw, pitch);
    }

    @Override
    public void ensureChunkLoaded(LevelRef level, double x, double z) {
        class_3218 l = level.unwrap(class_3218.class);
        class_2338 pos = class_2338.method_49637(x, 0, z);
        class_1923 cp = new class_1923(pos);
        l.method_14178().method_17297(class_3230.field_19280, cp, 1, pos);
        l.method_8497(cp.field_9181, cp.field_9180);
    }

    @Override
    public void resetMotionAndFall(PlayerRef player) {
        class_3222 sp = p(player);
        sp.field_6017 = 0f;
        sp.method_18799(class_243.field_1353);
    }

    @Override public boolean hasPassengers(PlayerRef player) { return p(player).method_5782(); }
    @Override public boolean isPassenger(PlayerRef player) { return p(player).method_5765(); }
    @Override public void ejectPassengers(PlayerRef player) { p(player).method_5772(); }

    @Override
    public void dismount(PlayerRef player) {
        dismount(p(player));
    }

    public static void dismount(class_3222 player) {
        var vehicle = player.method_5854();
        if (vehicle == null) return;

        player.method_5848();
        if (player.method_5854() == vehicle) vehicle.method_5772();
    }
}
