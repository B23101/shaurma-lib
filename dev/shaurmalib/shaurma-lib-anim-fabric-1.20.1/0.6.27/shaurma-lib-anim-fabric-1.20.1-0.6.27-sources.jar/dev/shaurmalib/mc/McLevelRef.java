package dev.shaurmalib.mc;

import dev.shaurmalib.platform.ref.LevelRef;
import dev.shaurmalib.platform.ref.ResourceId;
import net.minecraft.class_1937;

public record McLevelRef(class_1937 level) implements LevelRef {
    public static McLevelRef of(class_1937 l) { return new McLevelRef(l); }
    @Override public Object raw() { return level; }
    @Override public ResourceId dimension() {
        var loc = level.method_27983().method_29177(); // 26.x: Identifier — лише тут зміниться
        return ResourceId.of(loc.method_12836(), loc.method_12832());
    }
}
