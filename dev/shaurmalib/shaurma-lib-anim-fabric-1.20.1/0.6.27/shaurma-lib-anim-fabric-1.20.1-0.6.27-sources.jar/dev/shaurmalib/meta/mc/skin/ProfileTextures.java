package dev.shaurmalib.meta.mc.skin;

import com.mojang.authlib.GameProfile;

/** Значення першої текстури профілю або порожній рядок для стандартного скіна. */
public final class ProfileTextures {
    private ProfileTextures() {}

    public static String read(GameProfile profile) {
        var textures = profile.getProperties().get("textures").iterator();
        return textures.hasNext() ? textures.next().getValue() : "";
    }
}
