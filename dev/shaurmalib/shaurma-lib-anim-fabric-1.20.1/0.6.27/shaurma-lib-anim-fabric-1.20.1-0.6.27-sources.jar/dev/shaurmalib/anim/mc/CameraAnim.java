package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.pose.Pose;
import dev.shaurmalib.anim.runtime.CameraSolver;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3532;

/**
 * Камера першої особи за анімованою головою: впав — камера падає разом з головою, лягає на спину —
 * дивиться вгору, нахилився — нахиляється. Вмикається вагою {@code camera}/{@code camera_rotation}
 * у кліпі, запиті або правилі; переходить плавно разом з fade кліпа. Мишка працює поверх (кути додаються).
 *
 * Ваніль-рівень: міксин {@code Camera.setup} TAIL ставить позицію й yaw/pitch, міксин
 * {@code GameRenderer.bobHurt} додає крен — однаково на Forge/Fabric/NeoForge.
 */
public final class CameraAnim {

    private CameraAnim() {}

    private static final CameraSolver.Frame FRAME = new CameraSolver.Frame();
    private static float roll;
    /** Око перед обличчям (пікселі моделі): півголови (4) + запас, щоб не бачити зсередини голову/шию. */
    private static final float FACE_FORWARD = 3.5f;
    /**
     * Найменша відстань камери до блоків (блоки). Ванільне око — мінімум 0.3 від стіни (півширина хітбокса);
     * зсунута камера (обличчя, нахил, лежання) не підходить до блока ближче, ніж на це, інакше ближня площина
     * відсікання показує крізь стіну/підлогу.
     */
    private static final double WALL_MARGIN = 0.22;
    /** Чи цей кадр камеру поставив рушій (для власного гравця) — First-person Model тоді не зсуває тіло. */
    private static volatile boolean placedLocal;

    public static boolean placedLocal() { return placedLocal; }

    /** Результат для {@code Camera.setup}: null — камеру не чіпати. */
    public record Result(class_243 position, float yRot, float xRot) {}

    public static Result apply(class_1297 entity, boolean detached, float partial, class_243 camPos, float camYRot, float camXRot) {
        roll = 0;
        placedLocal = false;
        if (detached || !dev.shaurmalib.anim.ShaurmaAnim.headCamera() || !(entity instanceof class_1309 e)) return null;
        if (McAnim.rigOf(e) == null || dev.shaurmalib.anim.ShaurmaAnim.find(e.method_5667()) == null) return null;
        Pose pose = McAnim.evaluate(e, partial, null, true);
        boolean body = dev.shaurmalib.anim.ShaurmaAnim.bodyCamera() && e instanceof net.minecraft.class_1657;
        if (pose == null || !CameraSolver.solve(pose, FRAME, body ? 1f : 0f, body ? FACE_FORWARD : 0f)) return null;
        placedLocal = body;

        float bodyYaw = class_3532.method_17821(partial, e.field_6220, e.field_6283) * class_3532.field_29847;
        // сцена Blockbench: +X праворуч, +Y вгору, −Z вперед → світ за поворотом тіла
        double fx = -class_3532.method_15374(bodyYaw), fz = class_3532.method_15362(bodyYaw);   // вперед
        double rx = -class_3532.method_15362(bodyYaw), rz = -class_3532.method_15374(bodyYaw);  // праворуч
        // модель малюється в масштабі рендерера (гравець — 0.9375, PlayerRenderer.scale), а на шифті гра
        // опускає її на 0.125 блока (getRenderOffset) — око камери має бути там, де намальована голова
        boolean player = e instanceof net.minecraft.class_1657;
        double s = (player ? 0.9375 : 1.0) / 16.0;
        double lx = FRAME.eyeX * s, ly = FRAME.eyeY * s, lz = FRAME.eyeZ * s;
        class_243 base = e.method_30950(partial);
        if (player && e.method_18276()) base = base.method_1031(0, -0.125, 0);
        class_243 target = new class_243(base.field_1352 + rx * lx + fx * -lz, base.field_1351 + ly, base.field_1350 + rz * lx + fz * -lz);
        class_243 pos = keepOutOfBlocks(e, camPos, camPos.method_35590(target, FRAME.positionWeight));

        float w = FRAME.rotationWeight;
        roll = FRAME.roll * w;
        return new Result(pos, camYRot + FRAME.yaw * w, camXRot + FRAME.pitch * w);
    }

    /**
     * Камера йде від ванільного ока (воно завжди поза блоками) до цілі лише доки до блока лишається
     * {@link #WALL_MARGIN}: промінь по видимих формах блоків продовжено на запас за ціль.
     */
    private static class_243 keepOutOfBlocks(class_1309 e, class_243 from, class_243 to) {
        class_243 d = to.method_1020(from);
        double len = d.method_1033();
        if (len < 1e-4) return to;
        class_243 n = d.method_1021(1.0 / len);
        net.minecraft.class_3965 hit = e.method_37908().method_17742(new net.minecraft.class_3959(
            from, to.method_1019(n.method_1021(WALL_MARGIN)), net.minecraft.class_3959.class_3960.field_23142,
            net.minecraft.class_3959.class_242.field_1348, e));
        if (hit.method_17783() == net.minecraft.class_239.class_240.field_1333) return to;
        double free = Math.max(0, hit.method_17784().method_1022(from) - WALL_MARGIN);
        return from.method_1019(n.method_1021(Math.min(free, len)));
    }

    /** Крен поточного кадру (градуси) для {@code GameRenderer.bobHurt}. */
    public static float roll() { return roll; }
}
