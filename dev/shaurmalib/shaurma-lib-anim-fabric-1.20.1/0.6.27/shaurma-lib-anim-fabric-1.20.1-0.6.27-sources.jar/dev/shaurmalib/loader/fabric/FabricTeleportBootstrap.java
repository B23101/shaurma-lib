package dev.shaurmalib.loader.fabric;

import dev.shaurmalib.mc.McTeleportBackend;
import dev.shaurmalib.mc.RefFactoryImpl;
import dev.shaurmalib.platform.Platform;
import dev.shaurmalib.platform.service.RefFactory;
import dev.shaurmalib.platform.service.TeleportBackend;
import net.fabricmc.api.ModInitializer;

public final class FabricTeleportBootstrap implements ModInitializer {
    @Override
    public void onInitialize() {
        Platform.register(TeleportBackend.class, new McTeleportBackend());
        Platform.register(RefFactory.class, new RefFactoryImpl());
    }
}
