package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.bend.BendMath;
import dev.shaurmalib.anim.mc.bend.BendablePart;
import dev.shaurmalib.anim.pose.BoneTransform;
import dev.shaurmalib.anim.pose.Pose;
import dev.shaurmalib.anim.rig.Rig;
import net.minecraft.class_1306;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_5603;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Переклад пози рушія ↔ ванільна {@link class_572}.
 *
 * <h2>Простори (перевірено проти GeckoLib і Blockbench)</h2>
 * Кліп зберігає значення як у Blockbench. Сцена Blockbench має Y вгору; {@code ModelPart} — Y вниз і
 * дзеркальний X, тобто сцена, повернута на 180° навколо Z. Звідси для ванільної моделі:
 * <pre>
 *   обертання (x, y, z)°  →  xRot, yRot, zRot += rad(x, y, z)      (порядок ZYX, як у ModelPart)
 *   зсув      (x, y, z)px →  x += x;  y −= y;  z += z
 * </pre>
 * Півоти ригу Blockbench (Y вгору від ступнів) ↔ ванільні: точка сцени (x,y,z) = ModelPart (−x, 24−y, z).
 * Якір предмета в руці (кістка {@code right_item}, півот (6,12,−2)) збігається з ванільним
 * {@code ItemInHandLayer} точно: (−1, 10, −2) у просторі руки — тому предмет у кліпі стоїть там, де в Blockbench.
 */
public final class PlayerModelBridge {

    private PlayerModelBridge() {}

    private static final Rig R = Rig.PLAYER;
    static final int HEAD = R.indexOf("head"), TORSO = R.indexOf("torso"), RIGHT_ARM = R.indexOf("right_arm"),
        LEFT_ARM = R.indexOf("left_arm"), RIGHT_LEG = R.indexOf("right_leg"), LEFT_LEG = R.indexOf("left_leg"),
        ROOT = R.indexOf("body"), RIGHT_ITEM = R.indexOf("right_item"), LEFT_ITEM = R.indexOf("left_item"),
        RIGHT_FOREARM = R.indexOf("right_forearm"), LEFT_FOREARM = R.indexOf("left_forearm"),
        RIGHT_SHIN = R.indexOf("right_shin"), LEFT_SHIN = R.indexOf("left_shin"),
        UPPER_TORSO = R.indexOf("upper_torso");

    /** Нижній сегмент кінцівки → кістка, чия частина згинається ({@link BendablePart}). */
    private static final int[][] BENDS = {
        { RIGHT_FOREARM, RIGHT_ARM }, { LEFT_FOREARM, LEFT_ARM }, { RIGHT_SHIN, RIGHT_LEG }, { LEFT_SHIN, LEFT_LEG } };

    /** Півот кореня (стегна) у просторі ModelPart, пікселі. */
    private static final float ROOT_PIVOT_Y = 24f - 12f;

    static class_630 part(class_572<?> m, int bone) {
        if (bone == HEAD) return m.field_3398;
        if (bone == TORSO) return m.field_3391;
        if (bone == RIGHT_ARM) return m.field_3401;
        if (bone == LEFT_ARM) return m.field_27433;
        if (bone == RIGHT_LEG) return m.field_3392;
        if (bone == LEFT_LEG) return m.field_3397;
        return null;
    }

    private static final int[] PARTS = { HEAD, TORSO, RIGHT_ARM, LEFT_ARM, RIGHT_LEG, LEFT_LEG };

    /** Ванільна поза моделі → поза рушія (база під кліпами). */
    public static void capture(class_572<?> m, Pose base) {
        base.reset();
        for (int bone : PARTS) {
            class_630 p = part(m, bone);
            class_5603 rest = p.method_41921();
            BoneTransform b = base.bone(bone);
            b.rx = (p.field_3654 - rest.field_27705) * class_3532.field_29848;
            b.ry = (p.field_3675 - rest.field_27706) * class_3532.field_29848;
            b.rz = (p.field_3674 - rest.field_27707) * class_3532.field_29848;
            b.px = p.field_3657 - rest.field_27702;
            b.py = -(p.field_3656 - rest.field_27703);
            b.pz = p.field_3655 - rest.field_27704;
            b.sx = p.field_37938;
            b.sy = p.field_37939;
            b.sz = p.field_37940;
        }
    }

    /** Пише в модель ЛИШЕ кістки, які змінив рушій. @return чи щось змінено. */
    public static boolean apply(class_572<?> m, Pose pose) {
        boolean any = false;
        for (int bone : PARTS) {
            if (!pose.touched(bone)) continue;
            write(part(m, bone), pose.bone(bone));
            any = true;
        }
        for (int[] limb : BENDS) any |= writeBend(m, pose, limb[0], limb[1]);
        any |= writeChest(m, pose);
        if (any && (pose.touched(RIGHT_LEG) || pose.touched(LEFT_LEG) || pose.touched(TORSO))) writePelvis(m);
        if (any && m instanceof class_591<?> pm) syncOverlays(pm);
        else if (any) m.field_3394.method_17138(m.field_3398);
        return any;
    }

    /** Лише руки (перша особа). */
    public static void applyArms(class_572<?> m, Pose pose) {
        if (pose.touched(RIGHT_ARM)) write(m.field_3401, pose.bone(RIGHT_ARM));
        if (pose.touched(LEFT_ARM)) write(m.field_27433, pose.bone(LEFT_ARM));
        writeBend(m, pose, RIGHT_FOREARM, RIGHT_ARM);
        writeBend(m, pose, LEFT_FOREARM, LEFT_ARM);
        if (m instanceof class_591<?> pm) syncOverlays(pm);
    }

    /**
     * Обертання нижнього сегмента → згин сітки верхньої частини. Ті самі числа, що пішли б у
     * {@code xRot/yRot/zRot} дочірньої частини, тож простір збігається з рештою кісток.
     * Зсув і масштаб передпліччя поки не застосовуються (етап 4 плану).
     */
    private static boolean writeBend(class_572<?> m, Pose pose, int lowerBone, int partBone) {
        if (lowerBone < 0 || !pose.touched(lowerBone)) return false;
        BoneTransform b = pose.bone(lowerBone);
        ((BendablePart) (Object) part(m, partBone)).shaurma$setBend(b.rx, b.ry, b.rz);
        return true;
    }

    // ── Згин спини (upper_torso) ─────────────────────────────────────────

    /** Тулуб ванільного гравця у просторі частини: кубоїд (−4,0,−2)..(4,12,2), шарнір посередині. */
    private static final float TORSO_HY = 6f, TORSO_HALF_X = 4f, TORSO_HALF_Z = 2f, TORSO_HALF_LEN = 6f;
    private static final BendMath CHEST = new BendMath();
    private static final Matrix4f BODY = new Matrix4f(), BODY_INV = new Matrix4f();
    private static final Quaternionf BODY_ROT = new Quaternionf(), CHEST_ROT = new Quaternionf(),
        TMP_Q = new Quaternionf();
    private static final Vector3f TMP_V = new Vector3f();
    private static final float[] TMP_P = new float[3];

    /**
     * Груди відносно поясниці: сітка тулуба гнеться дугою (поясниця стоїть на стегнах), а голова й руки —
     * окремі {@code ModelPart}, тож їх переносимо тим самим жорстким рухом грудей: півот і обертання.
     * Предмет у руці, капелюх і рукави йдуть за ними (ItemInHandLayer / syncOverlays).
     */
    private static boolean writeChest(class_572<?> m, Pose pose) {
        if (UPPER_TORSO < 0 || !pose.touched(UPPER_TORSO)) return false;
        BoneTransform b = pose.bone(UPPER_TORSO);
        ((BendablePart) (Object) m.field_3391).shaurma$setBendUpper(b.rx, b.ry, b.rz);
        if (!CHEST.setUpper(b.rx, b.ry, b.rz, 0, TORSO_HY, 0, TORSO_HALF_X, TORSO_HALF_Z, TORSO_HALF_LEN)) return true;
        class_630 body = m.field_3391;
        BODY.translation(body.field_3657, body.field_3656, body.field_3655).rotateZYX(body.field_3674, body.field_3675, body.field_3654)
            .scale(safe(body.field_37938), safe(body.field_37939), safe(body.field_37940));
        BODY.invert(BODY_INV);
        BODY_ROT.rotationZYX(body.field_3674, body.field_3675, body.field_3654);
        float[] full = CHEST.lowerRotation();
        // рух грудей у просторі моделі: R_body · full⁻¹ · R_body⁻¹
        CHEST_ROT.set(-full[0], -full[1], -full[2], full[3]);
        CHEST_ROT.premul(BODY_ROT).mul(TMP_Q.set(BODY_ROT).conjugate());
        followChest(m.field_3398);
        followChest(m.field_3401);
        followChest(m.field_27433);
        m.field_3394.method_17138(m.field_3398);
        return true;
    }

    /** Яку частку кута між тулубом і стегнами бере таз (решту — дуга кульші на нозі). */
    private static final float PELVIS_SHARE = 0.7f;
    private static final float PELVIS_MAX_DEG = 110f;
    private static final BendMath PELVIS = new BendMath();
    private static final Quaternionf PELVIS_Q = new Quaternionf(), LEG_R = new Quaternionf(), LEG_L = new Quaternionf();
    private static final float[] PELVIS_ARR = new float[4];

    /**
     * Таз і кульші. Більшу частину повороту від тулуба до стегон бере ТІЛО: низ тулуба загинається дугою до
     * середнього напряму стегон ({@code BendMath.setTail}), суглоби ніг їдуть за низом таза, а нога лише
     * докручує решту короткою дугою від торця ({@code BendMath.setRoot}) — нога приклеєна до тулуба, не стирчить.
     * Ноги в різні боки (хода) — середнє ≈ 0, таз майже не гнеться.
     */
    private static void writePelvis(class_572<?> m) {
        class_630 body = m.field_3391, rl = m.field_3392, ll = m.field_3397;
        BODY_ROT.rotationZYX(body.field_3674, body.field_3675, body.field_3654);
        // стегна відносно тулуба: R_body⁻¹·R_leg
        TMP_Q.set(BODY_ROT).conjugate();
        LEG_R.rotationZYX(rl.field_3674, rl.field_3675, rl.field_3654).premul(TMP_Q);
        LEG_L.rotationZYX(ll.field_3674, ll.field_3675, ll.field_3654).premul(TMP_Q);
        if (LEG_R.dot(LEG_L) < 0) LEG_L.mul(-1f);
        PELVIS_Q.set(LEG_R).add(LEG_L).normalize();
        // лише swing (без закручування навколо осі тулуба), частка PELVIS_SHARE
        float tl = (float) Math.sqrt(PELVIS_Q.w * PELVIS_Q.w + PELVIS_Q.y * PELVIS_Q.y);
        if (tl > 1e-6f) TMP_Q.set(0, PELVIS_Q.y / tl, 0, PELVIS_Q.w / tl).conjugate(); else TMP_Q.identity();
        PELVIS_Q.mul(TMP_Q).normalize();
        if (PELVIS_Q.w < 0) PELVIS_Q.mul(-1f);
        float ang = 2f * (float) Math.acos(Math.min(1f, PELVIS_Q.w));
        float sinH = (float) Math.sqrt(Math.max(0f, 1f - PELVIS_Q.w * PELVIS_Q.w));
        float target = Math.min(ang * PELVIS_SHARE, PELVIS_MAX_DEG * class_3532.field_29847);
        if (sinH < 1e-5f || target < 1e-3f) {
            ((BendablePart) (Object) body).shaurma$clearTailBend();
        } else {
            float s = (float) Math.sin(target * 0.5f) / sinH;
            PELVIS_Q.set(PELVIS_Q.x * s, PELVIS_Q.y * s, PELVIS_Q.z * s, (float) Math.cos(target * 0.5f));
            PELVIS_ARR[0] = PELVIS_Q.x; PELVIS_ARR[1] = PELVIS_Q.y; PELVIS_ARR[2] = PELVIS_Q.z; PELVIS_ARR[3] = PELVIS_Q.w;
            ((BendablePart) (Object) body).shaurma$setTailBend(PELVIS_Q.x, PELVIS_Q.y, PELVIS_Q.z, PELVIS_Q.w);
            // зона грудей, якщо вони зігнуті (дуга таза не налазить на неї)
            float limit = 2f;
            BendablePart bb = (BendablePart) (Object) body;
            if (bb.shaurma$hasBend() && bb.shaurma$bendUpper()
                && CHEST.setUpper(bb.shaurma$bendX(), bb.shaurma$bendY(), bb.shaurma$bendZ(), 0, TORSO_HY, 0, TORSO_HALF_X, TORSO_HALF_Z, TORSO_HALF_LEN)) {
                limit = (TORSO_HY + TORSO_HALF_LEN - CHEST.slabEnd()) * 0.5f - 0.05f;
            }
            if (PELVIS.setTail(PELVIS_ARR, 0, TORSO_HY + TORSO_HALF_LEN, 0, TORSO_HALF_X, TORSO_HALF_Z, limit)) {
                BODY.translation(body.field_3657, body.field_3656, body.field_3655).rotateZYX(body.field_3674, body.field_3675, body.field_3654)
                    .scale(safe(body.field_37938), safe(body.field_37939), safe(body.field_37940));
                BODY.invert(BODY_INV);
                followPelvis(rl);
                followPelvis(ll);
            }
            // торець ноги — по низу таза: R_body·pelvis
            float[] full = PELVIS.lowerRotation();
            BODY_ROT.mul(TMP_Q.set(full[0], full[1], full[2], full[3]));
        }
        writeHip(rl, BODY_ROT);
        writeHip(ll, BODY_ROT);
    }

    /** Суглоб ноги (півот частини) їде разом із низом таза; обертання ноги не змінюється. */
    private static void followPelvis(class_630 leg) {
        BODY_INV.transformPosition(TMP_V.set(leg.field_3657, leg.field_3656, leg.field_3655));
        PELVIS.lower(TMP_V.x, TMP_V.y, TMP_V.z, TMP_P);
        BODY.transformPosition(TMP_V.set(TMP_P[0], TMP_P[1], TMP_P[2]));
        leg.field_3657 = TMP_V.x; leg.field_3656 = TMP_V.y; leg.field_3655 = TMP_V.z;
    }

    /** Кульша: торець ноги вирівняний по {@code parentRot} (низ таза), обертання торця = {@code R_leg⁻¹·parentRot}. */
    private static void writeHip(class_630 leg, Quaternionf parentRot) {
        LEG_R.rotationZYX(leg.field_3674, leg.field_3675, leg.field_3654).conjugate().mul(parentRot);
        ((BendablePart) (Object) leg).shaurma$setRootBend(LEG_R.x, LEG_R.y, LEG_R.z, LEG_R.w);
    }

    private static void followChest(class_630 p) {
        BODY_INV.transformPosition(TMP_V.set(p.field_3657, p.field_3656, p.field_3655));
        TMP_P[0] = TMP_V.x; TMP_P[1] = TMP_V.y; TMP_P[2] = TMP_V.z;
        CHEST.unlower(TMP_P);
        BODY.transformPosition(TMP_V.set(TMP_P[0], TMP_P[1], TMP_P[2]));
        p.field_3657 = TMP_V.x; p.field_3656 = TMP_V.y; p.field_3655 = TMP_V.z;
        TMP_Q.rotationZYX(p.field_3674, p.field_3675, p.field_3654).premul(CHEST_ROT);
        TMP_Q.getEulerAnglesZYX(TMP_V);
        p.field_3654 = TMP_V.x; p.field_3675 = TMP_V.y; p.field_3674 = TMP_V.z;
    }

    private static void write(class_630 p, BoneTransform b) {
        class_5603 rest = p.method_41921();
        p.field_3654 = rest.field_27705 + b.rx * class_3532.field_29847;
        p.field_3675 = rest.field_27706 + b.ry * class_3532.field_29847;
        p.field_3674 = rest.field_27707 + b.rz * class_3532.field_29847;
        p.field_3657 = rest.field_27702 + b.px;
        p.field_3656 = rest.field_27703 - b.py;
        p.field_3655 = rest.field_27704 + b.pz;
        p.field_37938 = b.sx;
        p.field_37939 = b.sy;
        p.field_37940 = b.sz;
    }

    static void syncOverlays(class_591<?> m) {
        m.field_3394.method_17138(m.field_3398);
        m.field_3483.method_17138(m.field_3391);
        m.field_3484.method_17138(m.field_27433);
        m.field_3486.method_17138(m.field_3401);
        m.field_3482.method_17138(m.field_3397);
        m.field_3479.method_17138(m.field_3392);
    }

    /**
     * Повертає частини в позу спокою (на початку setupAnim, якщо попередній кадр їх зсував).
     * {@code resetPose} скидає і згин ({@code MixinModelPartBend}) — модель гравця спільна для всіх.
     */
    public static void reset(class_572<?> m) {
        for (int bone : PARTS) part(m, bone).method_41923();
        m.field_3394.method_41923();
        if (m instanceof class_591<?> pm) {
            pm.field_3483.method_41923();
            pm.field_3484.method_41923();
            pm.field_3486.method_41923();
            pm.field_3482.method_41923();
            pm.field_3479.method_41923();
        }
    }

    /** Корінь {@code body} (усе тіло: лягти, нахилитись, бути піднятим) — у просторі моделі перед частинами. */
    public static void applyRoot(class_4587 ps, Pose pose) {
        if (pose == null || ROOT < 0 || !pose.touched(ROOT)) return;
        BoneTransform b = pose.bone(ROOT);
        ps.method_46416(b.px / 16f, -b.py / 16f, b.pz / 16f);
        ps.method_46416(0, ROOT_PIVOT_Y / 16f, 0);
        if (b.rx != 0 || b.ry != 0 || b.rz != 0) {
            ps.method_22907(new Quaternionf().rotationZYX(b.rz * class_3532.field_29847, b.ry * class_3532.field_29847, b.rx * class_3532.field_29847));
        }
        if (b.sx != 1 || b.sy != 1 || b.sz != 1) ps.method_22905(safe(b.sx), safe(b.sy), safe(b.sz));
        ps.method_46416(0, -ROOT_PIVOT_Y / 16f, 0);
    }

    /**
     * Скасувати {@link #applyRoot} (точний обернений порядок) — для вільних пропсів ({@code parent: world}),
     * які живуть у просторі сутності й не мають іти за нахилом/зсувом кореня тіла.
     */
    public static void undoRoot(class_4587 ps, Pose pose) {
        if (pose == null || ROOT < 0 || !pose.touched(ROOT)) return;
        BoneTransform b = pose.bone(ROOT);
        ps.method_46416(0, ROOT_PIVOT_Y / 16f, 0);
        if (b.sx != 1 || b.sy != 1 || b.sz != 1) ps.method_22905(1f / safe(b.sx), 1f / safe(b.sy), 1f / safe(b.sz));
        if (b.rx != 0 || b.ry != 0 || b.rz != 0) {
            ps.method_22907(new Quaternionf().rotationZYX(b.rz * class_3532.field_29847, b.ry * class_3532.field_29847, b.rx * class_3532.field_29847).conjugate());
        }
        ps.method_46416(0, -ROOT_PIVOT_Y / 16f, 0);
        ps.method_46416(-b.px / 16f, b.py / 16f, -b.pz / 16f);
    }

    /**
     * Кістка предмета, викликати там, де ванільний {@code ItemInHandLayer} уже поставив стек у якір
     * (після {@code XP(-90)·YP(180)·translate}). Перетворення задане в осях руки, тож обертаємо назад,
     * застосовуємо і повертаємо ванільну орієнтацію: {@code R⁻¹·B·R}.
     */
    public static void applyItemBone(class_4587 ps, Pose pose, class_1306 arm) {
        int bone = arm == class_1306.field_6183 ? RIGHT_ITEM : LEFT_ITEM;
        if (pose == null || !pose.touched(bone)) return;
        BoneTransform b = pose.bone(bone);
        ps.method_22907(class_7833.field_40716.rotationDegrees(-180f));
        ps.method_22907(class_7833.field_40714.rotationDegrees(90f));
        applyLocal(ps, b);
        ps.method_22907(class_7833.field_40714.rotationDegrees(-90f));
        ps.method_22907(class_7833.field_40716.rotationDegrees(180f));
    }

    /** Трансформ кістки в осях ModelPart навколо поточного початку стеку. */
    static void applyLocal(class_4587 ps, BoneTransform b) {
        ps.method_46416(b.px / 16f, -b.py / 16f, b.pz / 16f);
        if (b.rx != 0 || b.ry != 0 || b.rz != 0) {
            ps.method_22907(new Quaternionf().rotationZYX(b.rz * class_3532.field_29847, b.ry * class_3532.field_29847, b.rx * class_3532.field_29847));
        }
        if (b.sx != 1 || b.sy != 1 || b.sz != 1) ps.method_22905(safe(b.sx), safe(b.sy), safe(b.sz));
    }

    /** Якір предмета в руці, простір ModelPart (пікселі). */
    static float[] itemAnchor(class_1306 arm) {
        return arm == class_1306.field_6183 ? new float[] { -1, 10, -2 } : new float[] { 1, 10, -2 };
    }

    static float safe(float s) { return Math.abs(s) < 1e-4f ? 1e-4f : s; }
}
