package dev.shaurmalib.meta.mc.screen;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

/** Optional bridge to the animation module; the meta-only artifact remains independent of it. */
final class MetaAnimationPreview {

    private static final String ANIM_PACKAGE = "dev.shaurmalib.anim.";

    private MetaAnimationPreview() {}

    static Object createPlayerAnimator(UUID playerId) {
        try {
            Class<?> rigType = Class.forName(ANIM_PACKAGE + "rig.Rig");
            Object rig = rigType.getField("PLAYER").get(null);
            Class<?> apiType = Class.forName(ANIM_PACKAGE + "ShaurmaAnim");
            Object clips = apiType.getMethod("clips").invoke(null);
            Class<?> animatorType = Class.forName(ANIM_PACKAGE + "runtime.Animator");
            Object animator = animatorType.getConstructor(UUID.class, rigType, clips.getClass())
                    .newInstance(UUID.randomUUID(), rig, clips);

            Object real = apiType.getMethod("animator", UUID.class, rigType).invoke(null, playerId, rig);
            Object locomotion = real == null ? null : real.getClass().getMethod("locomotion").invoke(real);
            if (locomotion == null && Boolean.TRUE.equals(apiType.getMethod("playerLocomotion").invoke(null))) {
                locomotion = apiType.getMethod("defaultPlayerLocomotion").invoke(null);
            }
            if (locomotion != null) {
                animatorType.getMethod("locomotion", locomotion.getClass()).invoke(animator, locomotion);
            }
            return animator;
        } catch (ClassNotFoundException e) {
            return null;
        } catch (ReflectiveOperationException e) {
            throw reflectionFailure(e);
        }
    }

    static void tick(Object animator, class_1657 mannequin, boolean moving, boolean running) {
        if (animator == null) return;
        try {
            Object inputs = animator.getClass().getMethod("inputs").invoke(animator);
            set(inputs, "onGround", true);
            set(inputs, "sneaking", false);
            set(inputs, "swimming", false);
            set(inputs, "crawling", false);
            set(inputs, "riding", false);
            set(inputs, "climbing", false);
            set(inputs, "flying", false);
            set(inputs, "inWater", false);
            set(inputs, "usingItem", false);
            set(inputs, "swinging", false);
            set(inputs, "sleeping", false);
            set(inputs, "dead", false);
            set(inputs, "sprinting", moving && running);
            set(inputs, "horizontalSpeed", moving ? (running ? .28f : .2f) : 0f);
            set(inputs, "verticalSpeed", 0f);
            set(inputs, "fallDistance", 0f);
            set(inputs, "ageTicks", mannequin.field_6012);
            set(inputs, "limbSwingAmount", mannequin.field_42108.method_48566());
            set(inputs, "limbSwing", mannequin.field_42108.method_48569());
            invoke(animator.getClass().getMethod("tick", Class.forName(ANIM_PACKAGE + "runtime.AnimSubject"),
                    Iterable.class, Class.forName(ANIM_PACKAGE + "runtime.AnimEventSink")), animator, null, null, null);
        } catch (ReflectiveOperationException e) {
            throw reflectionFailure(e);
        }
    }

    static void withPreview(class_1297 entity, Object animator, float partial, Runnable render) {
        if (animator == null) {
            render.run();
            return;
        }
        try {
            Class<?> mcAnimType = Class.forName(ANIM_PACKAGE + "mc.McAnim");
            for (Method method : mcAnimType.getMethods()) {
                Class<?>[] parameters = method.getParameterTypes();
                if (method.getName().equals("withPreview") && parameters.length == 4
                        && parameters[0].isInstance(entity) && parameters[1].isInstance(animator)
                        && parameters[2] == float.class && parameters[3] == Runnable.class) {
                    invoke(method, null, entity, animator, partial, render);
                    return;
                }
            }
            throw new NoSuchMethodException("McAnim.withPreview");
        } catch (ClassNotFoundException e) {
            render.run();
        } catch (ReflectiveOperationException e) {
            throw reflectionFailure(e);
        }
    }

    private static void set(Object target, String name, boolean value) throws ReflectiveOperationException {
        Field field = target.getClass().getField(name);
        field.setBoolean(target, value);
    }

    private static void set(Object target, String name, float value) throws ReflectiveOperationException {
        Field field = target.getClass().getField(name);
        field.setFloat(target, value);
    }

    private static void set(Object target, String name, int value) throws ReflectiveOperationException {
        Field field = target.getClass().getField(name);
        field.setInt(target, value);
    }

    private static Object invoke(Method method, Object target, Object... args) throws ReflectiveOperationException {
        try {
            return method.invoke(target, args);
        } catch (InvocationTargetException e) {
            Throwable cause = e.getCause();
            if (cause instanceof RuntimeException runtime) throw runtime;
            if (cause instanceof Error error) throw error;
            throw new IllegalStateException(cause);
        }
    }

    private static RuntimeException reflectionFailure(ReflectiveOperationException e) {
        Throwable cause = e instanceof InvocationTargetException invocation && invocation.getCause() != null
                ? invocation.getCause() : e;
        if (cause instanceof RuntimeException runtime) return runtime;
        if (cause instanceof Error error) throw error;
        return new IllegalStateException("Could not integrate the optional animation module", cause);
    }
}
