package dev.shaurmalib.anim.mc.emote;

import dev.shaurmalib.anim.ShaurmaAnim;
import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.anim.emote.Emote;
import dev.shaurmalib.anim.mc.McAnim;
import dev.shaurmalib.anim.rig.Rig;
import dev.shaurmalib.anim.runtime.AnimInputs;
import dev.shaurmalib.anim.runtime.Animator;
import dev.shaurmalib.anim.runtime.PlayRequest;
import dev.shaurmalib.anim.runtime.Slot;
import org.joml.Quaternionf;

import java.util.UUID;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_490;

/**
 * 3D-превʼю емоції на моделі самого гравця (його скін, броня, предмет у руці).
 *
 * Окремий {@link Animator} — не той, що в світі: колесо показує наведену емоцію, а справжній гравець
 * у цей час стоїть як стояв. Малюється ванільним {@link class_490#method_48472}, тобто
 * через звичайний {@code PlayerRenderer} з міксинами рушія — ті самі маски, шари, пропси, що й у грі.
 */
public final class EmotePreview {

    /** Пауза між повторами одноразової емоції у превʼю, с. */
    private static final float REPLAY_PAUSE = 0.6f;

    private final Animator animator = new Animator(UUID.randomUUID(), Rig.PLAYER, ShaurmaAnim.clips());
    private Emote current;
    private int ticks, replayAt = -1;

    public EmotePreview() {
        // база під емоцією — та сама локомоція, що в грі (стояння рушія або ванільна поза)
        if (ShaurmaAnim.playerLocomotion()) animator.locomotion(ShaurmaAnim.defaultPlayerLocomotion());
    }

    public Animator animator() { return animator; }

    public Emote current() { return current; }

    /** Показати емоцію (null — стояти). Та сама — продовжує, без перезапуску. */
    public void show(Emote e) {
        if (e == current) return;
        current = e;
        if (e == null) {
            animator.stop(Slot.ACTION, 0.2f);
            replayAt = -1;
            return;
        }
        start();
    }

    private void start() {
        AnimationClip clip = ShaurmaAnim.clip(current.clip());
        PlayRequest r = PlayRequest.of(current.clip()).slot(Slot.ACTION).mask(current.mask()).restart(true).fade(0.12f, 0.2f)
            .tag("preview");
        if (current.loop() != null) r.loop(current.loop() ? AnimationClip.LoopMode.LOOP : AnimationClip.LoopMode.ONCE);
        animator.play(r);
        boolean loops = current.loop() != null ? current.loop() : clip != null && clip.loop() == AnimationClip.LoopMode.LOOP;
        replayAt = loops || clip == null ? -1 : ticks + Math.round((clip.length() + REPLAY_PAUSE) * 20);
    }

    /** З {@code Screen.tick} — 20 разів на секунду, як і аніматори світу. */
    public void tick() {
        ticks++;
        AnimInputs in = animator.inputs();
        in.onGround = true;
        in.sneaking = in.sprinting = in.swimming = in.crawling = in.riding = in.climbing = in.flying = false;
        in.usingItem = in.swinging = in.sleeping = in.dead = false;
        in.horizontalSpeed = in.verticalSpeed = in.fallDistance = 0;
        in.ageTicks = ticks;
        animator.tick(null, null, null); // без правил і подій: превʼю не грає звуків і не тягне чужі пози
        if (current != null && replayAt >= 0 && ticks >= replayAt) start();
    }

    /**
     * @param x,yFeet точка ступнів на екрані
     * @param scale   пікселів на блок
     * @param yaw     поворот моделі (0 — обличчям до гравця)
     */
    public void render(class_332 g, class_1309 entity, int x, int yFeet, int scale, float yaw) {
        renderEntity(g, entity, animator, x, yFeet, scale, yaw, class_310.method_1551().method_1488());
    }

    /** Як ванільний {@code renderEntityInInventoryFollowsMouse}, але з фіксованим поворотом і аніматором превʼю. */
    public static void renderEntity(class_332 g, class_1309 e, Animator animator, int x, int yFeet, int scale,
                                    float yaw, float partial) {
        Quaternionf pose = new Quaternionf().rotateZ((float) Math.PI);
        Quaternionf cam = new Quaternionf().rotateX(-8f * class_3532.field_29847);
        pose.mul(cam);
        float bodyRot = e.field_6283, bodyRotO = e.field_6220, yRot = e.method_36454(), yRotO = e.field_5982;
        float xRot = e.method_36455(), xRotO = e.field_6004, head = e.field_6241, headO = e.field_6259;
        float facing = 180f + yaw;
        e.field_6283 = e.field_6220 = facing;
        e.method_36456(facing);
        e.field_5982 = facing;
        e.method_36457(0);
        e.field_6004 = 0;
        e.field_6241 = e.field_6259 = facing;
        try {
            McAnim.withPreview(e, animator, partial, () -> class_490.method_48472(g, x, yFeet, scale, pose, cam, e));
        } finally {
            e.field_6283 = bodyRot;
            e.field_6220 = bodyRotO;
            e.method_36456(yRot);
            e.field_5982 = yRotO;
            e.method_36457(xRot);
            e.field_6004 = xRotO;
            e.field_6241 = head;
            e.field_6259 = headO;
        }
    }
}
