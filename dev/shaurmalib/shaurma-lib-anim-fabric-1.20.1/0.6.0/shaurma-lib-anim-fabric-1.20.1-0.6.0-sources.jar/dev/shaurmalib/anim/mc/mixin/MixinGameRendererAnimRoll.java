package dev.shaurmalib.anim.mc.mixin;

import dev.shaurmalib.anim.mc.CameraAnim;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Крен камери (у ванільного Camera його немає): той самий стек, де ваніль хитає камеру від удару. */
@Mixin(class_757.class)
public abstract class MixinGameRendererAnimRoll {

    @Inject(method = "bobHurt", at = @At("HEAD"))
    private void shaurma$anim$roll(class_4587 ps, float partial, CallbackInfo ci) {
        float roll = CameraAnim.roll();
        if (roll != 0) ps.method_22907(class_7833.field_40718.rotationDegrees(roll));
    }
}
