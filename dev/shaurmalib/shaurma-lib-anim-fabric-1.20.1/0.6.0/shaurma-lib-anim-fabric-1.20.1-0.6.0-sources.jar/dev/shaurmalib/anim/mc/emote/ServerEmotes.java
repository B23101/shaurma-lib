package dev.shaurmalib.anim.mc.emote;

import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.anim.emote.Emote;
import dev.shaurmalib.anim.emote.EmoteMessage;
import dev.shaurmalib.anim.emote.EmoteSessions;
import dev.shaurmalib.anim.emote.ShaurmaEmotes;
import dev.shaurmalib.anim.mc.ServerAnimations;
import dev.shaurmalib.anim.net.AnimMessage;
import dev.shaurmalib.anim.runtime.Slot;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * Серверна частина емоцій: прийняти запит клієнта, спитати хук мода, розіслати анімацію всім
 * ({@link ServerAnimations#play}); щотіка — погасити, якщо гравець пішов (для емоцій усього тіла)
 * або хук більше не дозволяє (впав, почав дію). Клей лоадера кличе {@link #handle}, {@link #tick}, {@link #onLogout}.
 *
 * Шар {@link Slot#ACTION}: серверна дія предмета (аптечка) природно витісняє емоцію, а пози станів
 * (лежить, на гаку — {@link Slot#POSE}) лежать вище й перекривають її, навіть якщо хук мода щось пропустив.
 */
public final class ServerEmotes {

    private ServerEmotes() {}

    public static final Slot SLOT = Slot.ACTION;

    public static void handle(class_3222 player, EmoteMessage m) {
        if (player == null || m == null) return;
        EmoteSessions sessions = ShaurmaEmotes.sessions();
        if (m.op() == EmoteMessage.Op.STOP) {
            stop(player);
            return;
        }
        Emote e = ShaurmaEmotes.get(m.emote());
        if (e == null) return;
        if (!ShaurmaEmotes.allowedOnServer(player, e)) {
            player.method_7353(class_2561.method_48321("shaurma_lib.emote.denied", "Зараз не можна"), true);
            return;
        }
        EmoteSessions.Active prev = sessions.active(player.method_5667());
        if (prev != null && !prev.emote().clip().equals(e.clip())) ServerAnimations.stop(player, prev.emote().clip());
        AnimMessage.PlayRequestSpec spec = AnimMessage.PlayRequestSpec.of(e.clip()).slot(SLOT).mask(e.mask()).restart(true);
        if (e.loop() != null) spec.loop(e.loop() ? AnimationClip.LoopMode.LOOP : AnimationClip.LoopMode.ONCE);
        ServerAnimations.play(player, spec);
        sessions.start(player.method_5667(), e, player.method_23317(), player.method_23318(), player.method_23321(), player.method_37908().method_8510());
    }

    /** Зупинити емоцію гравця (рух, повторне натискання, мод). */
    public static void stop(class_3222 player) {
        EmoteSessions.Active a = ShaurmaEmotes.sessions().stop(player.method_5667());
        if (a != null) ServerAnimations.stop(player, a.emote().clip());
    }

    public static void tick(MinecraftServer server) {
        EmoteSessions sessions = ShaurmaEmotes.sessions();
        for (UUID id : sessions.players()) {
            class_3222 p = server.method_3760().method_14602(id);
            EmoteSessions.Active a = sessions.active(id);
            if (p == null || a == null) {
                sessions.stop(id);
                continue;
            }
            boolean allowed = p.method_5805() && ShaurmaEmotes.allowedOnServer(p, a.emote());
            if (sessions.check(id, p.method_23317(), p.method_23318(), p.method_23321(), allowed, p.method_37908().method_8510()) != EmoteSessions.Decision.KEEP) stop(p);
        }
    }

    public static void onLogout(UUID player) { ShaurmaEmotes.sessions().stop(player); }

    public static void onServerStopped() { ShaurmaEmotes.sessions().clear(); }
}
