package dev.shaurmalib.anim.mc.emote;

import com.mojang.logging.LogUtils;
import dev.shaurmalib.anim.ShaurmaAnim;
import dev.shaurmalib.anim.emote.Emote;
import dev.shaurmalib.anim.emote.EmoteMessage;
import dev.shaurmalib.anim.emote.EmoteNetwork;
import dev.shaurmalib.anim.emote.EmoteWheel;
import dev.shaurmalib.anim.emote.ShaurmaEmotes;
import dev.shaurmalib.anim.runtime.Animator;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Path;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_746;

/**
 * Клієнт емоцій: клавіша колеса, локальні слоти, запит на сервер. Клей лоадера реєструє {@link #KEY}
 * і кличе {@link #tick()} щотіка. Сам клієнт анімацію НЕ запускає — лише просить сервер, а той
 * розсилає її всім (і нам теж), тож усі бачать одне й те саме.
 */
public final class EmoteClient {

    private EmoteClient() {}

    /** Утримати — колесо; відпустити на сегменті — зіграти. */
    public static final class_304 KEY = new class_304("key.shaurma_lib.emote_wheel", class_3675.class_307.field_1668,
        GLFW.GLFW_KEY_B, "key.categories.shaurma_lib");

    private static boolean loaded;

    public static void tick() {
        class_310 mc = class_310.method_1551();
        while (KEY.method_1436()) {
            if (mc.field_1755 == null && canOpen()) mc.method_1507(new EmoteWheelScreen(true));
        }
    }

    public static boolean canOpen() {
        class_746 p = class_310.method_1551().field_1724;
        return p != null && !p.method_7325() && ShaurmaEmotes.canOpenWheel(p);
    }

    /** Чи клавіша колеса зараз фізично натиснута (екран не отримує KeyMapping-подій — питаємо GLFW). */
    static boolean keyHeld() {
        long win = class_310.method_1551().method_22683().method_4490();
        class_3675.class_306 k = class_3675.method_15981(KEY.method_1428());
        if (k == null || k == class_3675.field_16237) return false;
        if (k.method_1442() == class_3675.class_307.field_1672) return GLFW.glfwGetMouseButton(win, k.method_1444()) == GLFW.GLFW_PRESS;
        if (k.method_1442() == class_3675.class_307.field_1668) return class_3675.method_15987(win, k.method_1444());
        return false;
    }

    // ── Слоти ────────────────────────────────────────────────────────────

    public static EmoteWheel wheel() {
        EmoteWheel w = ShaurmaEmotes.wheel();
        if (!loaded) {
            loaded = true;
            w.load(file());
        }
        // гравець ще нічого не налаштовував — колесо не порожнє, а з емоціями мода
        if (!w.configured()) w.fillEmpty(ShaurmaEmotes.available());
        return w;
    }

    public static Emote[] resolvedSlots() {
        EmoteWheel w = wheel();
        Emote[] out = new Emote[EmoteWheel.SLOTS];
        for (int i = 0; i < out.length; i++) {
            Emote e = w.resolve(i, ShaurmaEmotes.registry());
            out[i] = e != null && ShaurmaAnim.clips().has(e.clip()) ? e : null;
        }
        return out;
    }

    public static void save() {
        try {
            ShaurmaEmotes.wheel().save(file());
        } catch (IOException e) {
            LogUtils.getLogger().warn("[ShaurmaAnim] не вдалося зберегти колесо емоцій: {}", e.toString());
        }
    }

    static Path file() {
        return class_310.method_1551().field_1697.toPath().resolve("config").resolve("shaurma_lib").resolve("emote_wheel.txt");
    }

    // ── Запити ───────────────────────────────────────────────────────────

    /** Зіграти; якщо саме ця емоція вже грає — зупинити (повторне натискання). */
    public static void request(Emote e) {
        if (e == null) return;
        if (e.equals(activeLocal())) {
            stop();
            return;
        }
        EmoteNetwork.get().sendToServer(EmoteMessage.play(e.id()));
    }

    public static void stop() { EmoteNetwork.get().sendToServer(EmoteMessage.stop()); }

    /** Емоція, що зараз грає на локальному гравці (за кліпом в аніматорі світу), або null. */
    public static Emote activeLocal() {
        class_746 p = class_310.method_1551().field_1724;
        if (p == null) return null;
        Animator a = ShaurmaAnim.find(p.method_5667());
        if (a == null) return null;
        for (Emote e : ShaurmaEmotes.registry().all()) if (a.isPlaying(e.clip())) return e;
        return null;
    }

    public static void openSettings(int slot) {
        class_310 mc = class_310.method_1551();
        mc.method_1507(new EmoteSettingsScreen(slot));
    }
}
