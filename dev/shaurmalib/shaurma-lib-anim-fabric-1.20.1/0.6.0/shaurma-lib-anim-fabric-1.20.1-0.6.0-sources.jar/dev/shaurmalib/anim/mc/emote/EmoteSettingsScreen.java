package dev.shaurmalib.anim.mc.emote;

import dev.shaurmalib.anim.ShaurmaAnim;
import dev.shaurmalib.anim.emote.Emote;
import dev.shaurmalib.anim.emote.EmoteWheel;
import dev.shaurmalib.anim.emote.ShaurmaEmotes;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Налаштування колеса: ліворуч — усі доступні емоції за категоріями, посередині — 3D-модель гравця, що
 * грає вибрану/наведену емоцію, праворуч — 8 слотів колеса.
 *
 * <ul>
 *   <li>перетягнути емоцію зі списку в слот (або слот у слот — поміняти місцями; зі слота за колесо — прибрати);</li>
 *   <li>або клацнути емоцію, потім слот;</li>
 *   <li>ПКМ по слоту — очистити. Зберігається одразу.</li>
 * </ul>
 */
public final class EmoteSettingsScreen extends class_437 {

    private static final int ROW = 16, HEADER = 14;

    private final EmotePreview preview = new EmotePreview();
    private final List<Row> rows = new ArrayList<>();
    private Emote[] slots;
    private Emote selected, dragging, hoverEmote;
    private int dragFromSlot = -1, pressedSlot = -1, highlightSlot;
    private double pressX, pressY;
    private boolean pressedRow;
    private int scroll, listX, listY, listW, listH, contentH;
    private float cx, cy, r0, r1;

    private record Row(Emote emote, String category, int y) {}

    public EmoteSettingsScreen(int slot) {
        super(EmoteText.ui("settings", "Колесо емоцій — налаштування"));
        this.highlightSlot = slot;
    }

    @Override
    protected void method_25426() {
        refresh();
        listX = 10;
        listY = 30;
        listW = class_3532.method_15340(Math.round(field_22789 * 0.27f), 110, 190);
        listH = field_22790 - listY - 52;
        r1 = Math.min(field_22790 * 0.32f, field_22789 * 0.18f);
        r0 = r1 * 0.42f;
        cx = field_22789 - r1 - 34; // місце для назв і номерів слотів зовні кільця
        cy = field_22790 / 2f;
        rows.clear();
        int y = 0;
        List<Emote> all = ShaurmaEmotes.available();
        for (String cat : ShaurmaEmotes.registry().categories()) {
            rows.add(new Row(null, cat, y));
            y += HEADER;
            for (Emote e : all) {
                if (!e.category().equals(cat) || !ShaurmaAnim.clips().has(e.clip())) continue;
                rows.add(new Row(e, cat, y));
                y += ROW;
            }
        }
        contentH = y;
        if (highlightSlot >= 0 && slots[highlightSlot] != null) selected = slots[highlightSlot];
        if (selected == null && !all.isEmpty()) selected = all.get(0);

        int bw = 90;
        method_37063(class_4185.method_46430(EmoteText.ui("done", "Готово"), b -> method_25419())
            .method_46434(field_22789 - bw - 10, field_22790 - 26, bw, 20).method_46431());
        method_37063(class_4185.method_46430(EmoteText.ui("reset", "Скинути"), b -> {
            EmoteWheel w = ShaurmaEmotes.wheel();
            w.reset();
            w.fillEmpty(ShaurmaEmotes.available());
            EmoteClient.save();
            refresh();
        }).method_46434(field_22789 - 2 * bw - 16, field_22790 - 26, bw, 20).method_46431());
    }

    private void refresh() { slots = EmoteClient.resolvedSlots(); }

    @Override
    public void method_25393() {
        Emote show = dragging != null ? dragging : hoverEmote != null ? hoverEmote : selected;
        preview.show(show);
        preview.tick();
    }

    // ── Рендер ───────────────────────────────────────────────────────────

    @Override
    public void method_25394(class_332 g, int mx, int my, float partial) {
        method_25420(g);
        g.method_27534(field_22793, field_22785, field_22789 / 2, 10, 0xFFFFFFFF);
        hoverEmote = null;

        // список
        g.method_25294(listX - 2, listY - 2, listX + listW + 2, listY + listH + 2, 0x90000000);
        g.method_44379(listX, listY, listX + listW, listY + listH);
        for (Row r : rows) {
            int y = listY + r.y - scroll;
            if (y + ROW < listY || y > listY + listH) continue;
            if (r.emote == null) {
                g.method_27535(field_22793, EmoteText.category(r.category).method_27661().method_27694(s -> s.method_10982(true)), listX + 3, y + 3, 0xFFD9A441);
                continue;
            }
            boolean over = mx >= listX && mx < listX + listW && my >= y && my < y + ROW && my >= listY && my < listY + listH;
            if (over) hoverEmote = r.emote;
            int inWheel = ShaurmaEmotes.wheel().indexOf(r.emote.id());
            int bg = r.emote == selected ? 0xC0D9A441 : over ? 0x60FFFFFF : 0x30FFFFFF;
            g.method_25294(listX + 1, y + 1, listX + listW - 1, y + ROW - 1, bg);
            g.method_27535(field_22793, EmoteText.name(r.emote), listX + 6, y + 4, 0xFFFFFFFF);
            String tag = (r.emote.canMove() ? "↔ " : "■ ") + (inWheel >= 0 ? "#" + (inWheel + 1) : "");
            g.method_25303(field_22793, tag, listX + listW - 6 - field_22793.method_1727(tag), y + 4, inWheel >= 0 ? 0xFF8FD18F : 0xFF909090);
        }
        g.method_44380();

        // колесо слотів
        int seg = WheelDraw.segmentAt(mx, my, cx, cy, r0 * 0.6f, r1 + 6);
        if (seg >= 0 && dragging == null && slots[seg] != null) hoverEmote = slots[seg];
        WheelDraw.wheel(g, slots, cx, cy, r0, r1, dragging != null ? seg : seg >= 0 ? seg : highlightSlot, null);
        WheelDraw.disc(g, cx, cy, r0 - 3, WheelDraw.COL_CENTER);
        for (int i = 0; i < EmoteWheel.SLOTS; i++) {
            float rad = WheelDraw.centerAngle(i) * class_3532.field_29847;
            g.method_25300(field_22793, String.valueOf(i + 1), Math.round(cx + class_3532.method_15362(rad) * (r1 + 11)),
                Math.round(cy + class_3532.method_15374(rad) * (r1 + 11)) - 4, 0x90FFFFFF);
        }

        // 3D-превʼю посередині
        class_310 mc = class_310.method_1551();
        int left = listX + listW + 8, right = Math.round(cx - r1 - 12);
        int pcx = (left + right) / 2;
        g.method_25294(left, listY - 2, right, listY + listH + 2, 0x50000000);
        Emote shown = preview.current();
        if (mc.field_1724 != null && right - left > 40) {
            int scale = Math.min(Math.round(listH * 0.36f), Math.round((right - left) * 0.42f));
            g.method_44379(left, listY, right, listY + listH);
            preview.render(g, mc.field_1724, pcx, listY + Math.round(listH * 0.84f), scale, -18f);
            g.method_44380();
        }
        if (shown != null) {
            g.method_27534(field_22793, EmoteText.name(shown), pcx, listY + 4, 0xFFFFFFFF);
            class_2561 how = shown.canMove() ? EmoteText.ui("can_move", "можна йти") : EmoteText.ui("full_body", "усе тіло");
            g.method_27534(field_22793, how, pcx, listY + 16, 0xFFA0A0A0);
        }

        class_2561 hint = EmoteText.ui("settings.hint", "Перетягни емоцію в слот або вибери її і клацни слот · ПКМ по слоту — очистити");
        int hy = listY + listH + 6;
        for (var line : field_22793.method_1728(hint, field_22789 - 2 * 96 - 30)) {
            g.method_35720(field_22793, line, 10, hy, 0xFF909090);
            hy += 10;
        }
        super.method_25394(g, mx, my, partial);

        if (dragging != null && (Math.abs(mx - pressX) > 3 || Math.abs(my - pressY) > 3)) {
            g.method_51448().method_22903();
            g.method_51448().method_46416(0, 0, 400);
            class_2561 n = EmoteText.name(dragging);
            int w = field_22793.method_27525(n) + 8;
            g.method_25294(mx - w / 2, my - 6, mx + w / 2, my + 7, 0xE0D9A441);
            g.method_27534(field_22793, n, mx, my - 3, 0xFFFFFFFF);
            g.method_51448().method_22909();
        }
    }

    // ── Мишка ────────────────────────────────────────────────────────────

    private Emote rowAt(double mx, double my) {
        if (mx < listX || mx >= listX + listW || my < listY || my >= listY + listH) return null;
        for (Row r : rows) {
            int y = listY + r.y - scroll;
            if (r.emote != null && my >= y && my < y + ROW) return r.emote;
        }
        return null;
    }

    @Override
    public boolean method_25402(double mx, double my, int button) {
        if (super.method_25402(mx, my, button)) return true;
        int seg = WheelDraw.segmentAt(mx, my, cx, cy, r0 * 0.6f, r1 + 6);
        if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT && seg >= 0) {
            ShaurmaEmotes.wheel().clear(seg);
            EmoteClient.save();
            refresh();
            return true;
        }
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT) return false;
        pressX = mx;
        pressY = my;
        Emote row = rowAt(mx, my);
        if (row != null) {
            selected = row;
            dragging = row;
            dragFromSlot = -1;
            pressedSlot = -1;
            pressedRow = true;
            return true;
        }
        if (seg >= 0) {
            pressedSlot = seg;
            pressedRow = false;
            dragging = slots[seg];
            dragFromSlot = slots[seg] != null ? seg : -1;
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25406(double mx, double my, int button) {
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT) return super.method_25406(mx, my, button);
        boolean moved = Math.abs(mx - pressX) > 3 || Math.abs(my - pressY) > 3;
        int seg = WheelDraw.segmentAt(mx, my, cx, cy, r0 * 0.6f, r1 + 6);
        EmoteWheel w = ShaurmaEmotes.wheel();
        boolean changed = false;
        if (moved && dragging != null) {
            if (seg >= 0) {
                if (dragFromSlot >= 0) w.swap(dragFromSlot, seg);
                else w.set(seg, dragging.id());
                highlightSlot = seg;
                changed = true;
            } else if (dragFromSlot >= 0 && rowAt(mx, my) == null) {
                w.clear(dragFromSlot); // витягли за межі колеса — прибрати
                changed = true;
            }
        } else if (!moved && !pressedRow && pressedSlot >= 0) {
            Emote inSlot = slots[pressedSlot];
            if (selected != null && selected != inSlot) {
                w.set(pressedSlot, selected.id());
                changed = true;
            } else if (inSlot != null) {
                selected = inSlot;
            }
            highlightSlot = pressedSlot;
        }
        dragging = null;
        dragFromSlot = pressedSlot = -1;
        pressedRow = false;
        if (changed) {
            EmoteClient.save();
            refresh();
        }
        return true;
    }

    @Override
    public boolean method_25401(double mx, double my, double delta) {
        if (mx >= listX && mx < listX + listW) {
            scroll = class_3532.method_15340(scroll - (int) Math.round(delta * ROW * 2), 0, Math.max(0, contentH - listH));
            return true;
        }
        return super.method_25401(mx, my, delta);
    }

    @Override
    public void method_25419() {
        EmoteClient.save();
        super.method_25419();
    }

    @Override
    public boolean method_25421() { return false; }

    // ── Для автотесту ───────────────────────────────────────────────────

    public EmotePreview preview() { return preview; }

    public void debugSelect(Emote e) { selected = e; }

    public void debugAssign(int slot, Emote e) {
        ShaurmaEmotes.wheel().set(slot, e.id());
        EmoteClient.save();
        refresh();
        highlightSlot = slot;
    }
}
