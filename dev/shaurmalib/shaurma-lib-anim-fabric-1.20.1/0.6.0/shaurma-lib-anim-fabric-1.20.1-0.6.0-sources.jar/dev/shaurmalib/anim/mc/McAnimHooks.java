package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.pose.Pose;
import dev.shaurmalib.anim.rig.Rig;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_572;
import net.minecraft.class_583;

/**
 * Усе, що роблять міксини 1.20.1 (кожен міксин — 1–3 рядки виклику сюди). Порт на іншу версію —
 * це нові міксини з тими ж викликами, логіка тут і в ядрі не змінюється.
 *
 * Порядок за кадр для гравця:
 * <ol>
 *   <li>{@code LivingEntityRenderer.render} перед {@code prepareMobModel} → {@link #beginRender}: корінь тіла;</li>
 *   <li>{@code setupAnim} HEAD → {@link #beforeSetupAnim}: прибрати зсуви минулого кадру (модель спільна);</li>
 *   <li>{@code setupAnim} TAIL → {@link #afterSetupAnim}: ванільна поза = база, поверх — шари рушія;</li>
 *   <li>{@code ItemInHandLayer} → {@link #itemBone}/{@link #hideHeld}; шар пропсів;</li>
 *   <li>кінець {@code render} → {@link #endRender}.</li>
 * </ol>
 */
public final class McAnimHooks {

    private McAnimHooks() {}

    private static final Set<class_583<?>> DIRTY = Collections.newSetFromMap(new WeakHashMap<>());
    private static final Map<class_572<?>, Pose> BASES = new WeakHashMap<>();
    private static float partial;

    static void markDirty(class_583<?> m) { DIRTY.add(m); }

    public static void beginRender(class_1309 e, float partialTick, class_4587 ps, class_583<?> model) {
        McAnim.renderingEntity = null;
        if (!(model instanceof class_572<?>) || McAnim.renderRigOf(e) != Rig.PLAYER) return;
        McAnim.renderingEntity = e;
        partial = partialTick;
        Pose pose = McAnim.evaluate(e, partialTick, null, true);
        PlayerModelBridge.applyRoot(ps, pose);
    }

    public static void endRender() {
        McAnim.renderingEntity = null;
    }

    public static void beforeSetupAnim(class_572<?> model) {
        if (DIRTY.remove(model)) PlayerModelBridge.reset(model);
    }

    public static void afterSetupAnim(class_572<?> model, class_1309 e) {
        if (e != McAnim.renderingEntity || e == null) return;
        Pose base = BASES.computeIfAbsent(model, k -> new Pose(Rig.PLAYER));
        PlayerModelBridge.capture(model, base);
        Pose pose = McAnim.evaluate(e, partial, base, true);
        if (pose != null && PlayerModelBridge.apply(model, pose)) DIRTY.add(model);
    }

    /** Кістка предмета в руці (третя особа). */
    public static void itemBone(class_1309 e, class_4587 ps, class_1306 arm) {
        if (e != McAnim.renderingEntity) return;
        PlayerModelBridge.applyItemBone(ps, McAnim.framePose(e), arm);
    }

    /** Пропс замінює предмет у руці — ванільний не малювати. */
    public static boolean hideHeld(class_1309 e, class_1306 arm) {
        if (e != McAnim.renderingEntity) return false;
        Pose p = McAnim.framePose(e);
        return p != null && (arm == class_1306.field_6183 ? p.hideRightHeld : p.hideLeftHeld);
    }
}
