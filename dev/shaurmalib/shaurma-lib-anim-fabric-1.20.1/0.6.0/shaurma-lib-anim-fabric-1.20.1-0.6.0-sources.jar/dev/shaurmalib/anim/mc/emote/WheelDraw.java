package dev.shaurmalib.anim.mc.emote;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.shaurmalib.anim.emote.Emote;
import dev.shaurmalib.anim.emote.EmoteWheel;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_757;
import org.joml.Matrix4f;

/** Геометрія й малювання колеса (спільне для колеса і екрана налаштувань). */
public final class WheelDraw {

    private WheelDraw() {}

    public static final float SEGMENT = 360f / EmoteWheel.SLOTS;
    /** Проміжок між сегментами, градуси. */
    private static final float GAP = 1.6f;

    public static final int COL_SEGMENT = 0xB0141418, COL_HOVER = 0xE0D9A441, COL_EMPTY = 0x70141418,
        COL_CENTER = 0xC00B0B0E, COL_RIM = 0x60FFFFFF, COL_ACTIVE = 0xC0396B3A;

    /** Центр сегмента, градуси екрана (0 — праворуч, −90 — угорі). Слот 0 — угорі, далі за годинниковою. */
    public static float centerAngle(int slot) { return -90f + slot * SEGMENT; }

    /** Сегмент під курсором або −1 (у центрі ближче за {@code deadZone}). */
    public static int segmentAt(double mx, double my, float cx, float cy, float deadZone, float maxRadius) {
        double dx = mx - cx, dy = my - cy;
        double d = Math.sqrt(dx * dx + dy * dy);
        if (d < deadZone || (maxRadius > 0 && d > maxRadius)) return -1;
        double a = Math.toDegrees(Math.atan2(dy, dx)) + 90.0;
        int i = (int) Math.floor((a + SEGMENT / 2) / SEGMENT);
        return Math.floorMod(i, EmoteWheel.SLOTS);
    }

    /** Заповнений сектор кільця (r0 = 0 — сектор круга). */
    public static void sector(class_332 g, float cx, float cy, float r0, float r1, float a0, float a1, int argb) {
        g.method_51452(); // спершу намалювати те, що GuiGraphics накопичив, — інакше порядок шарів зламається
        Matrix4f m = g.method_51448().method_23760().method_23761();
        float a = (argb >>> 24 & 255) / 255f, r = (argb >> 16 & 255) / 255f, gr = (argb >> 8 & 255) / 255f, b = (argb & 255) / 255f;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(class_757::method_34540);
        class_287 buf = class_289.method_1348().method_1349();
        buf.method_1328(class_293.class_5596.field_27380, class_290.field_1576);
        int steps = Math.max(2, (int) Math.ceil(Math.abs(a1 - a0) / 3f));
        for (int i = 0; i <= steps; i++) {
            float t = (a0 + (a1 - a0) * i / steps) * class_3532.field_29847;
            float c = class_3532.method_15362(t), s = class_3532.method_15374(t);
            buf.method_22918(m, cx + c * r1, cy + s * r1, 0).method_22915(r, gr, b, a).method_1344();
            buf.method_22918(m, cx + c * r0, cy + s * r0, 0).method_22915(r, gr, b, a).method_1344();
        }
        class_286.method_43433(buf.method_1326());
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    public static void disc(class_332 g, float cx, float cy, float r, int argb) { sector(g, cx, cy, 0, r, 0, 360, argb); }

    /**
     * Повне колесо: 8 сегментів з назвами/іконками.
     * @param hovered  підсвічений сегмент (−1 — жоден)
     * @param active   емоція, що зараз грає на гравці (підсвічується зеленим), або null
     */
    public static void wheel(class_332 g, Emote[] slots, float cx, float cy, float r0, float r1,
                             int hovered, Emote active) {
        for (int i = 0; i < EmoteWheel.SLOTS; i++) {
            float c = centerAngle(i);
            Emote e = slots[i];
            int col = i == hovered ? COL_HOVER : e == null ? COL_EMPTY : e == active ? COL_ACTIVE : COL_SEGMENT;
            float grow = i == hovered ? 4 : 0;
            sector(g, cx, cy, r0, r1 + grow, c - SEGMENT / 2 + GAP, c + SEGMENT / 2 - GAP, col);
            sector(g, cx, cy, r1 + grow - 1.5f, r1 + grow, c - SEGMENT / 2 + GAP, c + SEGMENT / 2 - GAP, COL_RIM);
        }
        class_327 font = class_310.method_1551().field_1772;
        for (int i = 0; i < EmoteWheel.SLOTS; i++) {
            Emote e = slots[i];
            float rad = centerAngle(i) * class_3532.field_29847, mid = (r0 + r1) / 2;
            int lx = Math.round(cx + class_3532.method_15362(rad) * mid), ly = Math.round(cy + class_3532.method_15374(rad) * mid);
            if (e == null) {
                g.method_25300(font, "·", lx, ly - 4, 0x80FFFFFF);
                continue;
            }
            int textY = ly - 4;
            class_2960 icon = e.icon() == null ? null : class_2960.method_12829(e.icon());
            if (icon != null) {
                g.method_25290(icon, lx - 8, ly - 14, 0, 0, 16, 16, 16, 16);
                textY = ly + 4;
            }
            class_2561 name = EmoteText.name(e);
            int maxW = Math.round((r1 - r0) * 1.25f);
            if (font.method_27525(name) > maxW) {
                String s = font.method_27523(name.getString(), maxW - font.method_1727("…")) + "…";
                g.method_25300(font, s, lx, textY, i == hovered ? 0xFFFFFFFF : 0xFFE0E0E0);
            } else {
                g.method_27534(font, name, lx, textY, i == hovered ? 0xFFFFFFFF : 0xFFE0E0E0);
            }
        }
    }
}
