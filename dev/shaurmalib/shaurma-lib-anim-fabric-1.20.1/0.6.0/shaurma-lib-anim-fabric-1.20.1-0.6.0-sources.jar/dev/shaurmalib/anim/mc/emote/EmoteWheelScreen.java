package dev.shaurmalib.anim.mc.emote;

import dev.shaurmalib.anim.emote.Emote;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/**
 * Колесо емоцій. Відкривається утриманням клавіші (B): навів на сегмент — у центрі ти сам, у своєму скіні,
 * вже грає цю емоцію; відпустив — емоція йде на сервер і її бачать усі. Відпустив у центрі — нічого.
 * Коротке натискання, поки емоція грає, — зупинити її. ПКМ по сегменту — налаштування слотів.
 */
public final class EmoteWheelScreen extends class_437 {

    /** Скільки тіків триває «коротке натискання». */
    private static final int TAP_TICKS = 5;

    private final boolean holdMode;
    private final EmotePreview preview = new EmotePreview();
    private Emote[] slots;
    private int hovered = -1, forcedHover = -2, age;
    private boolean done;
    private float cx, cy, r0, r1;

    /** @param holdMode true — закривається, коли відпустили клавішу (звичайне відкриття з гри) */
    public EmoteWheelScreen(boolean holdMode) {
        super(EmoteText.ui("wheel", "Емоції"));
        this.holdMode = holdMode;
    }

    @Override
    protected void method_25426() {
        slots = EmoteClient.resolvedSlots();
        r1 = Math.min(field_22789, field_22790) * 0.40f;
        r0 = r1 * 0.46f;
        cx = field_22789 / 2f;
        cy = field_22790 / 2f + 6;
    }

    @Override
    public void method_25393() {
        age++;
        preview.show(hovered >= 0 ? slots[hovered] : EmoteClient.activeLocal());
        preview.tick();
        if (holdMode && !done && !EmoteClient.keyHeld()) release();
        if (!EmoteClient.canOpen()) method_25419(); // впав / почалась дія — колесо зникає саме
    }

    /** Відпустили клавішу або клацнули: зіграти наведену, коротке натискання — зупинити. */
    private void release() {
        if (done) return;
        done = true;
        Emote e = hovered >= 0 ? slots[hovered] : null;
        if (e != null) EmoteClient.request(e);
        else if (age <= TAP_TICKS && EmoteClient.activeLocal() != null) EmoteClient.stop();
        method_25419();
    }

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float partial) {
        hovered = forcedHover >= -1 ? forcedHover : WheelDraw.segmentAt(mouseX, mouseY, cx, cy, r0 * 0.55f, 0);
        if (hovered >= 0 && slots[hovered] == null) hovered = -1;
        g.method_25296(0, 0, field_22789, field_22790, 0x50000000, 0x70000000);

        WheelDraw.wheel(g, slots, cx, cy, r0, r1, hovered, EmoteClient.activeLocal());
        WheelDraw.disc(g, cx, cy, r0 - 3, WheelDraw.COL_CENTER);

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            g.method_44379(Math.round(cx - r0), Math.round(cy - r0), Math.round(cx + r0), Math.round(cy + r0));
            int scale = Math.round(r0 * 0.6f);
            preview.render(g, mc.field_1724, Math.round(cx), Math.round(cy + r0 * 0.6f), scale, 0f);
            g.method_44380();
        }

        Emote h = hovered >= 0 ? slots[hovered] : null;
        class_2561 title = h != null ? EmoteText.name(h) : this.field_22785;
        g.method_27534(field_22793, title, Math.round(cx), Math.round(cy - r1 - 18), 0xFFFFFFFF);
        class_2561 hint = EmoteText.ui("wheel.hint", "Відпусти — зіграти · у центрі — скасувати · ПКМ — налаштувати");
        g.method_27534(field_22793, hint, Math.round(cx), Math.round(cy + r1 + 10), 0xFFB0B0B0);
        super.method_25394(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean method_25402(double mx, double my, int button) {
        int seg = WheelDraw.segmentAt(mx, my, cx, cy, r0 * 0.55f, 0);
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            if (seg >= 0 && slots[seg] != null) {
                hovered = seg;
                release();
            } else if (seg < 0) {
                done = true;
                method_25419();
            }
            return true;
        }
        if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) {
            done = true;
            EmoteClient.openSettings(seg);
            return true;
        }
        return super.method_25402(mx, my, button);
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        // у режимі «не утримання» (відкрито кодом/тестом) повторне натискання клавіші колеса закриває його
        if (!holdMode && EmoteClient.KEY.method_1417(key, scan)) {
            release();
            return true;
        }
        return super.method_25404(key, scan, mods);
    }

    @Override
    public boolean method_25421() { return false; }

    // ── Для автотесту ───────────────────────────────────────────────────

    /** Навести сегмент без мишки (−1 — центр, −2 — знову мишка). */
    public void debugHover(int segment) { forcedHover = segment; hovered = segment; }

    /** Вибрати наведений сегмент, як при відпусканні клавіші. */
    public void debugRelease() { release(); }

    public EmotePreview preview() { return preview; }
}
