package dev.shaurmalib.anim.mc.mixin;

import dev.shaurmalib.anim.mc.McAnimHooks;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import net.minecraft.class_989;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Кістки {@code right_item}/{@code left_item} кліпа + ховання предмета, коли його замінює пропс. */
@Mixin(class_989.class)
public abstract class MixinItemInHandLayerAnim {

    @Inject(method = "renderArmWithItem", at = @At("HEAD"), cancellable = true)
    private void shaurma$anim$hide(class_1309 entity, class_1799 stack, class_811 ctx, class_1306 arm,
                                   class_4587 ps, class_4597 buffers, int light, CallbackInfo ci) {
        if (McAnimHooks.hideHeld(entity, arm)) ci.cancel();
    }

    @Inject(method = "renderArmWithItem",
            at = @At(value = "INVOKE",
                     target = "Lnet/minecraft/client/renderer/ItemInHandRenderer;renderItem(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemDisplayContext;ZLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V"))
    private void shaurma$anim$itemBone(class_1309 entity, class_1799 stack, class_811 ctx, class_1306 arm,
                                       class_4587 ps, class_4597 buffers, int light, CallbackInfo ci) {
        McAnimHooks.itemBone(entity, ps, arm);
    }
}
