package dev.shaurmalib.anim.fabric;

import dev.shaurmalib.anim.emote.EmoteMessage;
import dev.shaurmalib.anim.mc.emote.ServerEmotes;
import dev.shaurmalib.anim.net.AnimMessage;
import dev.shaurmalib.anim.net.AnimNetwork;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1297;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import java.io.IOException;
import java.io.UncheckedIOException;

/**
 * Клей рушія анімацій для Fabric 1.20.1 — той самий обсяг, що й {@code ForgeAnimBootstrap}:
 * лише мережа (сервер → усі, хто бачить сутність). Логіка — в ядрі і в шарі версії.
 */
public final class FabricAnimBootstrap implements ModInitializer {

    public static final class_2960 CHANNEL = new class_2960("shaurma_lib", "anim");
    /** Клієнт → сервер: запит емоції. */
    public static final class_2960 EMOTE_CHANNEL = new class_2960("shaurma_lib", "emote");

    @Override
    public void onInitialize() {
        AnimNetwork.set((entity, message, includeSelf) -> {
            if (!(entity instanceof class_1297 e) || e.method_37908().field_9236) return;
            class_2540 buf = encode(message);
            for (class_3222 p : PlayerLookup.tracking(e)) ServerPlayNetworking.send(p, CHANNEL, new class_2540(buf.copy()));
            if (includeSelf && e instanceof class_3222 self) ServerPlayNetworking.send(self, CHANNEL, new class_2540(buf.copy()));
        });
        ServerPlayNetworking.registerGlobalReceiver(EMOTE_CHANNEL, (server, player, handler, buf, sender) -> {
            EmoteMessage m;
            try (ByteBufInputStream in = new ByteBufInputStream(buf)) {
                m = EmoteMessage.read(in);
            } catch (IOException ex) {
                return;
            }
            server.execute(() -> ServerEmotes.handle(player, m));
        });
        ServerTickEvents.END_SERVER_TICK.register(ServerEmotes::tick);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> ServerEmotes.onLogout(handler.method_32311().method_5667()));
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> ServerEmotes.onServerStopped());
    }

    static class_2540 encode(EmoteMessage m) {
        class_2540 buf = new class_2540(Unpooled.buffer());
        try (ByteBufOutputStream out = new ByteBufOutputStream(buf)) {
            m.write(out);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return buf;
    }

    static class_2540 encode(AnimMessage m) {
        class_2540 buf = new class_2540(Unpooled.buffer());
        try (ByteBufOutputStream out = new ByteBufOutputStream(buf)) {
            m.write(out);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return buf;
    }
}
