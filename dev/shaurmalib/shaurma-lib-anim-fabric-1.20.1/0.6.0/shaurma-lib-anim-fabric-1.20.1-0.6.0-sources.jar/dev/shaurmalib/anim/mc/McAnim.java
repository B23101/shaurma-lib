package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.ShaurmaAnim;
import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.anim.clip.ClipEvent;
import dev.shaurmalib.anim.pose.Pose;
import dev.shaurmalib.anim.rig.Rig;
import dev.shaurmalib.anim.runtime.AnimInputs;
import dev.shaurmalib.anim.runtime.AnimSubject;
import dev.shaurmalib.anim.runtime.Animator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3532;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_7923;

/**
 * Клієнтський клей рушія для Minecraft 1.20.1 (ваніль, без лоадера). Лоадер кличе:
 * {@link #clientTick()} щотіка, {@link #onDisconnect()} при виході, і реєструє {@link AnimReloader}.
 *
 * Тут вирішується, ЯКИЙ риг у сутності ({@link #setRigResolver}): звичайний гравець — {@link Rig#PLAYER},
 * маньяк — риг його geo-моделі. Рушію байдуже: шари, маски, правила працюють однаково.
 */
public final class McAnim {

    private McAnim() {}

    private static final Function<class_1297, Rig> DEFAULT_RESOLVER = e -> e instanceof class_1657 ? Rig.PLAYER : null;
    private static Function<class_1297, Rig> rigResolver = DEFAULT_RESOLVER;
    private static final Map<UUID, Subject> SUBJECTS = new HashMap<>();
    private static final Map<UUID, Pose> FRAME = new HashMap<>();

    /** Сутність, яку зараз малює LivingEntityRenderer (лише тоді setupAnim-міксин чіпає модель). */
    static class_1309 renderingEntity;

    static {
        ShaurmaAnim.onEvent(McAnim::defaultEvents);
    }

    /**
     * Який риг у сутності. null — не анімувати рушієм. За замовчуванням гравці — {@link Rig#PLAYER},
     * решта — ні. Мод може повернути geo-риг (маньяк) або увімкнути рушій для мобів.
     */
    public static void setRigResolver(Function<class_1297, Rig> resolver) {
        rigResolver = resolver == null ? DEFAULT_RESOLVER : resolver;
    }

    public static Rig rigOf(class_1297 e) {
        try {
            return rigResolver.apply(e);
        } catch (RuntimeException ex) {
            return DEFAULT_RESOLVER.apply(e);
        }
    }

    // ── Превʼю в GUI: та сама сутність, але окремий аніматор ─────────────

    private static class_1297 previewEntity;
    private static Animator previewAnimator;
    private static float previewPartial;

    /**
     * Намалювати сутність (у GUI) з ІНШИМ аніматором: колесо емоцій показує гравця, що грає наведену
     * емоцію, а справжній гравець у світі в цей час стоїть як стояв. Весь рендер-ланцюг (міксини моделі,
     * предмети, пропси) питає {@link #animator(class_1297)} — тому підміни тут досить.
     */
    public static void withPreview(class_1297 e, Animator animator, float partial, Runnable render) {
        class_1297 pe = previewEntity;
        Animator pa = previewAnimator;
        float pp = previewPartial;
        previewEntity = e;
        previewAnimator = animator;
        previewPartial = partial;
        try {
            render.run();
        } finally {
            previewEntity = pe;
            previewAnimator = pa;
            previewPartial = pp;
            FRAME.remove(e.method_5667()); // поза превʼю не має потрапити в шари світу цього кадру
        }
    }

    static boolean previewing(class_1297 e) { return previewAnimator != null && e == previewEntity; }

    /** Риг, яким сутність малюється зараз (у превʼю — риг аніматора превʼю). */
    public static Rig renderRigOf(class_1297 e) { return previewing(e) ? previewAnimator.rig() : rigOf(e); }

    /** Аніматор сутності з правильним ригом (створює за потреби). */
    public static Animator animator(class_1297 e) {
        if (previewAnimator != null && e == previewEntity) return previewAnimator;
        Rig rig = rigOf(e);
        return rig == null ? null : ShaurmaAnim.animator(e.method_5667(), rig);
    }

    // ── Тік ──────────────────────────────────────────────────────────────

    public static void clientTick() {
        class_310 mc = class_310.method_1551();
        class_638 level = mc.field_1687;
        if (level == null) {
            onDisconnect();
            return;
        }
        if (mc.method_1493()) return;
        Set<UUID> alive = new HashSet<>();
        for (class_742 p : level.method_18456()) {
            Rig rig = rigOf(p);
            if (rig == null) continue;
            alive.add(p.method_5667());
            Animator a = ShaurmaAnim.animator(p.method_5667(), rig);
            Subject s = SUBJECTS.get(p.method_5667());
            if (s == null || s.entity != p || s.animator != a) {
                s = new Subject(p, a);
                SUBJECTS.put(p.method_5667(), s);
            }
            fillTickInputs(p, a.inputs(), p == mc.field_1724);
            try {
                ShaurmaAnim.tick(s);
            } catch (RuntimeException ex) {
                // одна сутність з битим кліпом не зупиняє анімації решти
            }
        }
        SUBJECTS.keySet().retainAll(alive);
        FRAME.keySet().retainAll(alive);
        ShaurmaAnim.retainOnly(alive);
    }

    public static void onDisconnect() {
        SUBJECTS.clear();
        FRAME.clear();
        ShaurmaAnim.clearAll();
    }

    static void fillTickInputs(class_1309 e, AnimInputs in, boolean local) {
        in.onGround = e.method_24828();
        in.sneaking = e.method_18276();
        in.sprinting = e.method_5624();
        in.swimming = e.method_5681();
        in.crawling = e.method_20448();
        in.riding = e.method_5765();
        in.climbing = e.method_6101();
        in.flying = e.method_6128() || (e instanceof class_1657 p && p.method_31549().field_7479);
        in.inWater = e.method_5799();
        in.usingItem = e.method_6115();
        in.swinging = e.field_6252;
        in.sleeping = e.method_6113();
        in.dead = !e.method_5805();
        in.localPlayer = local;
        in.verticalSpeed = (float) (e.method_23318() - e.field_6036);
        double dx = e.method_23317() - e.field_6014, dz = e.method_23321() - e.field_5969;
        in.horizontalSpeed = (float) Math.sqrt(dx * dx + dz * dz);
        in.fallDistance = e.field_6017;
        in.hurtTime = e.field_6235;
        in.ageTicks = e.field_6012;
        in.mainHandItem = itemId(e.method_6047());
        in.offHandItem = itemId(e.method_6079());
        in.limbSwingAmount = e.field_42108.method_48566();
        in.limbSwing = e.field_42108.method_48569();
    }

    static void fillFrameInputs(class_1309 e, AnimInputs in, float partial) {
        in.limbSwing = e.field_42108.method_48572(partial);
        in.limbSwingAmount = Math.min(1f, e.field_42108.method_48570(partial));
        float body = class_3532.method_17821(partial, e.field_6220, e.field_6283);
        float head = class_3532.method_17821(partial, e.field_6259, e.field_6241);
        in.netHeadYaw = class_3532.method_15393(head - body);
        in.headPitch = class_3532.method_16439(partial, e.field_6004, e.method_36455());
    }

    public static String itemId(class_1799 s) {
        if (s == null || s.method_7960()) return "";
        class_2960 key = class_7923.field_41178.method_10221(s.method_7909());
        return key == null ? "" : key.toString();
    }

    // ── Кадр ─────────────────────────────────────────────────────────────

    /**
     * Обчислює позу кадру для сутності (база — вхідна поза моделі або null).
     * Результат кешується до наступного виклику — шари рендера (предмет, пропси) читають {@link #framePose}.
     */
    public static Pose evaluate(class_1309 e, float partial, Pose base, boolean baseHasLook) {
        Animator a = animator(e);
        if (a == null) return null;
        if (previewing(e)) partial = previewPartial; // GUI малює з partial=1 — превʼю плавне власним
        fillFrameInputs(e, a.inputs(), partial);
        return evaluateWith(e, a, partial, base, baseHasLook);
    }

    static Pose evaluateWith(class_1309 e, Animator a, float partial, Pose base, boolean baseHasLook) {
        Pose out = FRAME.get(e.method_5667());
        if (out == null || out.rig() != a.rig()) {
            out = new Pose(a.rig());
            FRAME.put(e.method_5667(), out);
        }
        a.evaluate(partial, base, baseHasLook, out);
        return out;
    }

    /** Остання обчислена поза сутності (цей кадр) або null. */
    public static Pose framePose(class_1297 e) {
        Pose p = FRAME.get(e.method_5667());
        Rig rig = previewing(e) ? previewAnimator.rig() : rigOf(e);
        return p != null && p.rig() == rig ? p : null;
    }

    // ── Події за замовчуванням: звук і частинки ──────────────────────────

    private static void defaultEvents(AnimSubject subject, AnimationClip clip, ClipEvent event) {
        if (!(subject.entity() instanceof class_1297 e) || e.method_37908() == null || !e.method_37908().field_9236) return;
        String type = event.type();
        class_2960 id = class_2960.method_12829(event.value());
        if (id == null) return;
        if ("sound".equals(type)) {
            class_3414 sound = class_3414.method_47908(id);
            e.method_37908().method_8486(e.method_23317(), e.method_23318() + e.method_17682() * 0.6, e.method_23321(), sound, class_3419.field_15248,
                (float) event.param("volume", 1), (float) event.param("pitch", 1), false);
        } else if ("particle".equals(type)) {
            class_2396<?> pt = class_7923.field_41180.method_10223(id);
            if (pt instanceof class_2394 opts) {
                int n = (int) Math.max(1, event.param("count", 1));
                for (int i = 0; i < n; i++) {
                    e.method_37908().method_8406(opts, e.method_23317(), e.method_23318() + e.method_17682() * 0.6, e.method_23321(), 0, 0.02, 0);
                }
            }
        }
    }

    /** Суб'єкт для правил: сира сутність + її аніматор. */
    static final class Subject implements AnimSubject {
        final class_1309 entity;
        final Animator animator;

        Subject(class_1309 entity, Animator animator) {
            this.entity = entity;
            this.animator = animator;
        }

        @Override public UUID uuid() { return entity.method_5667(); }
        @Override public Object entity() { return entity; }
        @Override public AnimInputs inputs() { return animator.inputs(); }
        @Override public Animator animator() { return animator; }
    }
}
