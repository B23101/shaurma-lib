package dev.shaurmalib.meta.mc.screen;

import dev.shaurmalib.meta.cosmetics.CosmeticDef;
import dev.shaurmalib.meta.cosmetics.CosmeticSlot;
import dev.shaurmalib.meta.cosmetics.Look;
import dev.shaurmalib.meta.cosmetics.Worn;
import dev.shaurmalib.meta.mc.render.CosmeticRenderer;
import net.minecraft.class_1664;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_490;
import net.minecraft.class_745;
import org.joml.Quaternionf;

/**
 * 3D-прев'ю косметики на манекені зі скіном гравця (картки магазину, пропуску, гардероба) і фон-«промені»
 * за рідкістю, як у карток вітрини.
 */
final class Preview {

    private static class_745 mannequin;

    private Preview() {}

    static class_745 mannequin() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return null;
        if (mannequin == null || mannequin.method_37908() != mc.field_1687) {
            mannequin = new class_745(mc.field_1687, mc.field_1724.method_7334()) {
                @Override public boolean method_7348(class_1664 part) { return true; }
            };
        }
        return mannequin;
    }

    /** Манекен з одним предметом у прямокутнику (дизайнові координати екрана {@code s}). */
    static void item(class_332 g, MetaScreen s, CosmeticDef d, int x, int y, int w, int h, float yaw) {
        Worn worn = new Worn(d.id(), d.defaultColor());
        worn.validate(d.slot());
        Look look = new Look().only(d.slot(), worn);
        boolean aura = d.slot() == CosmeticSlot.AURA, pet = d.slot() == CosmeticSlot.PET;
        // для капелюха — крупніше й вище (видно голову), для улюбленця/аури — весь манекен
        float size = d.slot() == CosmeticSlot.HEAD ? h * .62f : aura ? h * .34f : h * .40f;
        int foot = d.slot() == CosmeticSlot.HEAD ? y + h + (int) (h * .55f) : y + h - (aura ? h / 3 : 8);
        figure(g, s, x + w / 2, foot, size, yaw, look, x, y, w, h, aura, pet ? -.1f : 0);
    }

    static void figure(class_332 g, MetaScreen s, int cx, int foot, float size, float yaw, Look look,
                       int clx, int cly, int clw, int clh, boolean tilt, float lift) {
        class_745 m = mannequin();
        if (m == null) return;
        m.field_6283 = m.field_6220 = m.field_6241 = m.field_6259 = 0;
        m.method_36456(0);
        m.method_36457(0);
        g.method_44379((int) (s.ox + clx * s.ui), (int) (s.oy + cly * s.ui), (int) (s.ox + (clx + clw) * s.ui), (int) (s.oy + (cly + clh) * s.ui));
        CosmeticRenderer.preview = look;
        CosmeticRenderer.drawingPreview = true;
        CosmeticRenderer.previewYaw = yaw;
        CosmeticRenderer.previewTilt = tilt ? .42f : 0f;
        CosmeticRenderer.previewLift = lift;
        try {
            class_490.method_48472(g, cx, foot, (int) size,
                    new Quaternionf().rotationZ((float) Math.PI).rotateY((float) Math.toRadians(yaw)), null, m);
        } finally {
            CosmeticRenderer.drawingPreview = false;
            CosmeticRenderer.preview = null;
            CosmeticRenderer.previewTilt = CosmeticRenderer.previewLift = 0;
            g.method_44380();
        }
    }

    /** Предмет гри як 3D-іконка (скрині, подарунок): {@code itemId} з реєстру, центр (cx, cy), масштаб від 16 px. */
    static void itemIcon(class_332 g, String itemId, float cx, float cy, float scale) {
        var rl = net.minecraft.class_2960.method_12829(itemId);
        var it = rl == null ? net.minecraft.class_1802.field_8106 : net.minecraft.class_7923.field_41178.method_10223(rl);
        if (it == net.minecraft.class_1802.field_8162) it = net.minecraft.class_1802.field_8106;
        g.method_51448().method_22903();
        g.method_51448().method_46416(cx, cy, 0);
        g.method_51448().method_22905(scale, scale, 1);
        g.method_51448().method_46416(-8, -8, 0);
        g.method_51427(new net.minecraft.class_1799(it), 0, 0);
        g.method_51448().method_22909();
    }

    static String timer(long msLeft) {
        if (msLeft <= 0) return "0хв";
        long m = msLeft / 60_000L, h = m / 60, d = h / 24;
        if (d > 0) return d + "д " + (h % 24) + "год";
        if (h > 0) return h + "год " + (m % 60) + "хв";
        return m + "хв";
    }
}
