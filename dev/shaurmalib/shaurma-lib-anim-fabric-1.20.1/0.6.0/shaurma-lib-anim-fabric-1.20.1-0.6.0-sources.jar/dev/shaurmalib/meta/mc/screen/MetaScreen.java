package dev.shaurmalib.meta.mc.screen;

import dev.shaurmalib.meta.MetaMode;
import dev.shaurmalib.meta.MetaTheme;
import dev.shaurmalib.meta.client.MetaClient;
import dev.shaurmalib.meta.economy.Currency;
import dev.shaurmalib.meta.mc.MetaScreens;
import dev.shaurmalib.meta.mc.skin.MetaSkin;
import dev.shaurmalib.meta.mc.skin.MetaSkins;
import dev.shaurmalib.meta.mc.ui.MetaUi;
import dev.shaurmalib.meta.profile.MetaProfile;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1109;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_437;

/**
 * База екранів мета-двигуна: «дизайнові» координати 960×540, що рівномірно масштабуються під вікно,
 * клікабельні зони, плавні hover-стани, верхня навігація між розділами й гаманець. Усе МАЛЮВАННЯ —
 * через {@link MetaSkin} режиму, тож кожен мод показує ці екрани у власному стилі.
 */
public abstract class MetaScreen extends class_437 {

    public static final int DW = 960, DH = 540;

    protected record Zone(int x, int y, int w, int h, Runnable action) {}

    protected final class_437 parent;
    protected final MetaMode mode;
    protected final MetaSkin skin;
    protected final MetaTheme theme;
    protected float ui = 1, ox, oy;
    protected int mx, my;
    protected float dt, time;
    private long lastNanos = System.nanoTime();
    protected final List<Zone> zones = new ArrayList<>();
    private final Map<String, Float> hover = new HashMap<>();
    protected int accent;
    private String notice = "";
    private int noticeColor;
    private long noticeUntil;
    /** Показувати верхню навігацію між розділами. */
    protected boolean nav = true;
    /** Нижня межа клікабельної області (для прокручуваних списків під шапкою). */
    protected int clipTop = 0;

    protected MetaScreen(String title, class_437 parent) {
        super(class_2561.method_43470(title));
        this.parent = parent;
        this.mode = MetaClient.mode();
        this.skin = MetaSkins.of(mode);
        this.theme = skin.theme();
        this.accent = theme.accent();
    }

    /** Ключ розділу для підсвітки в навігації: profile, wardrobe, shop, track, leaderboard. */
    protected abstract String section();

    protected abstract void draw(class_332 g);

    protected MetaProfile me() { return MetaClient.self(); }

    @Override public boolean method_25421() { return false; }

    @Override
    protected void method_25426() {
        ui = Math.min(field_22789 / (float) DW, field_22790 / (float) DH);
        ox = (field_22789 - DW * ui) / 2f;
        oy = (field_22790 - DH * ui) / 2f;
    }

    @Override
    public void method_25394(class_332 g, int rawX, int rawY, float partial) {
        long now = System.nanoTime();
        dt = Math.min(.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        time += dt;
        mx = (int) Math.floor((rawX - ox) / ui);
        my = (int) Math.floor((rawY - oy) / ui);
        zones.clear();
        skin.backdrop(g, field_22789, field_22790, time, MetaUi.outCubic(time / .35f));
        g.method_51448().method_22903();
        g.method_51448().method_46416(ox, oy, 0);
        g.method_51448().method_22905(ui, ui, 1f);
        if (nav && mode != null) navBar(g);
        draw(g);
        drawNotice(g);
        g.method_51448().method_22909();
        MetaScreens.renderToasts(g, field_22789, field_22790);
    }

    protected void panel(class_332 g, int x, int y, int w, int h, boolean main) { skin.panel(g, x, y, w, h, main, time); }

    /** Іконка: спершу скін мода, інакше піксельна бібліотечна (8·px). */
    protected void icon(class_332 g, String id, int x, int y, int px, int argb) {
        if (!skin.icon(g, id, x, y, 8 * px, argb, 0f)) dev.shaurmalib.meta.mc.ui.MetaIcons.draw(g, id, x, y, px, argb);
    }

    // ── навігація ────────────────────────────────────────────────────────
    private static final String[][] NAV = {
            {"profile", "ПРОФІЛЬ", "profile"}, {"wardrobe", "ГАРДЕРОБ", "head"}, {"shop", "МАГАЗИН", "shop"},
            {"track", "ПРОПУСК", "track"}, {"leaderboard", "ЛІДЕРИ", "board"}};

    /** Права межа навігації (ліворуч від гаманця). */
    private int navRight() {
        MetaProfile p = me();
        int w = 0;
        if (p != null && mode != null) for (Currency c : mode.currencies) w += field_22793.method_1727(MetaUi.num(p.wallet.get(c.id()))) + 32;
        return 946 - w - 8;
    }

    private void navBar(class_332 g) {
        int total = 0;
        for (String[] n : NAV) total += skin.tabWidth(field_22793, n[1]) + 4;
        int x = Math.min(330, navRight() - total), y = 10;
        for (String[] n : NAV) {
            int w = skin.tabWidth(field_22793, n[1]);
            boolean act = n[0].equals(section());
            final String target = n[0];
            float hv = hv("nav" + n[0], zone(x, y, w, 20, () -> { if (!act) { click(); MetaScreens.open(target, parent); } }));
            skin.tab(g, field_22793, x, y, w, 20, n[1], n[2], act, hv);
            x += w + 4;
        }
        wallet(g, 946, 13);
    }

    /** Гаманець праворуч зверху. */
    protected void wallet(class_332 g, int right, int y) {
        MetaProfile p = me();
        if (p == null || mode == null) return;
        int x = right;
        for (int i = mode.currencies.size() - 1; i >= 0; i--) {
            Currency c = mode.currencies.get(i);
            String v = MetaUi.num(p.wallet.get(c.id()));
            int w = field_22793.method_1727(v) + 22;
            x -= w;
            skin.chip(g, field_22793, x, y, v, c.icon(), c.color());
            x -= 6;
        }
    }

    // ── віджети ──────────────────────────────────────────────────────────
    protected boolean over(int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    protected boolean zone(int x, int y, int w, int h, Runnable action) {
        if (y + h <= clipTop) return false;
        zones.add(new Zone(x, Math.max(y, clipTop), w, h - Math.max(0, clipTop - y), action));
        return over(x, Math.max(y, clipTop), w, h - Math.max(0, clipTop - y));
    }

    protected float hv(String key, boolean on) {
        float v = hover.getOrDefault(key, 0f);
        v += ((on ? 1f : 0f) - v) * Math.min(1f, dt * 14f);
        hover.put(key, v);
        return v;
    }

    protected void button(class_332 g, String key, int x, int y, int w, int h, String label, boolean active, Runnable action) {
        button(g, key, x, y, w, h, label, active ? MetaSkin.Kind.SELECTED : MetaSkin.Kind.NORMAL, action);
    }

    protected void button(class_332 g, String key, int x, int y, int w, int h, String label, MetaSkin.Kind kind, Runnable action) {
        float hv = hv(key, action != null && zone(x, y, w, h, action));
        skin.button(g, field_22793, x, y, w, h, label, kind, hv, action != null, time);
    }

    protected void primary(class_332 g, String key, int x, int y, int w, int h, String label, Runnable action) {
        button(g, key, x, y, w, h, label, MetaSkin.Kind.PRIMARY, action);
    }

    protected void header(class_332 g, String title, String sub) {
        skin.header(g, field_22793, 16, 8, sub, title, time);
    }

    protected void say(String text, boolean error) {
        notice = text;
        noticeColor = error ? theme.bad() : theme.gold();
        noticeUntil = System.currentTimeMillis() + 3500;
    }

    private void drawNotice(class_332 g) {
        long left = noticeUntil - System.currentTimeMillis();
        if (left <= 0 || notice.isEmpty()) return;
        float a = Math.min(1f, left / 400f);
        int w = field_22793.method_1727(notice) + 24, x = (DW - w) / 2, y = 512;
        skin.toast(g, x, y, w, 20, a, time);
        MetaUi.text(g, field_22793, notice, x + 12, y + 6, MetaUi.a(noticeColor, a), true);
    }

    public void serverNotice(String text, String kind) { say(text, "error".equals(kind)); }

    protected void click() {
        if (field_22787 != null) field_22787.method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1f));
    }

    // ── ввід ─────────────────────────────────────────────────────────────
    protected void updateMouse(double rx, double ry) {
        mx = (int) Math.floor((rx - ox) / ui);
        my = (int) Math.floor((ry - oy) / ui);
    }

    @Override
    public boolean method_25402(double rx, double ry, int button) {
        updateMouse(rx, ry);
        if (button == 0) {
            for (int i = zones.size() - 1; i >= 0; i--) {
                Zone z = zones.get(i);
                if (over(z.x, z.y, z.w, z.h)) { z.action.run(); return true; }
            }
        }
        return super.method_25402(rx, ry, button);
    }

    @Override
    public boolean method_25404(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE) { method_25419(); return true; }
        return super.method_25404(key, scan, mods);
    }

    @Override
    public void method_25419() { if (field_22787 != null) field_22787.method_1507(parent); }

    /** Перемалювати дані, коли сервер прислав новий профіль. */
    public void profileChanged() { }

    // ── доступ для Preview (той самий пакет) ─────────────────────────────
    float ui() { return ui; }
}
