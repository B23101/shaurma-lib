package dev.shaurmalib.anim.bend;

/**
 * Геометрія згину кінцівки (лікоть / коліно) — без гри, щоб перевірятись тестами.
 *
 * <h2>Модель: плавна дуга</h2>
 * Простір частини, як у {@code ModelPart}: Y вниз, верх кінцівки — менші Y. Кінцівка ділиться на три зони:
 * <ul>
 *   <li><b>upper</b> ({@code y < slabStart}) — не рухається;</li>
 *   <li><b>зона згину</b> ({@code slabStart ≤ y ≤ slabEnd}) — вісь кінцівки (spine) йде по дузі кола радіуса
 *       {@code arcR}; перетин на частці {@code f} зони повертається на {@code f·θ} (swing) і {@code f·τ} (twist).
 *       Сітка ріжеться на {@link #SEGMENTS} кілець, тож лікоть/коліно круглий, без зламу і трикутників;</li>
 *   <li><b>lower</b> ({@code y > slabEnd}) — жорстко: продовження дуги з повним обертанням.</li>
 * </ul>
 *
 * Обертання розкладається на <b>swing</b> (власне згин, вісь ⊥ Y) і <b>twist</b> (поворот навколо осі
 * кінцівки): {@code q = swing · twist}.
 *
 * <h2>Довжина не змінюється</h2>
 * Ділянка {@code [hinge − a, hinge + a]} згортається в дугу рівно тієї ж довжини {@code 2a}, тож вісь
 * руки/ноги від плеча до кисті має ту саму довжину, що й пряма кінцівка, — рука не «коротшає», а лікоть
 * просто округлюється назовні. {@code a ≥ 1.15·h·θ/2}, щоб радіус дуги був більший за півтовщину {@code h}
 * (внутрішній бік лишається вузькою дугою, а не вивертається). Зона не заходить ближче
 * {@link #END_MARGIN} до торців — торці лишаються жорсткими. Через округлення нижній сегмент стоїть на
 * частки пікселя всередину згину від того місця, куди його поставила б жорстка кістка навколо шарніра.
 *
 * Ейлерові кути — як у {@code ModelPart}/кістках рушія: градуси, порядок ZYX ({@code q = Rz·Ry·Rx}).
 * Кватерніони — {@code float[4] = (x, y, z, w)}.
 *
 * Клас — змінний стан на одну кінцівку на кадр: {@link #set} один раз, потім {@link #lower}/{@link #ring}
 * для кожної вершини. Без алокацій після створення.
 */
public final class BendMath {

    /** Найбільший кут згину (swing), градуси. */
    public static final float MAX_SWING_DEG = 160f;

    /** На скільки сегментів ріжеться зона згину (кілець = SEGMENTS + 1). */
    public static final int SEGMENTS = 8;

    /** Скільки пікселів лишити від торця кінцівки до зони згину. */
    public static final float END_MARGIN = 0.25f;

    private static final float IDENTITY_EPS = 1e-6f;
    private static final float SWING_EPS = 1e-4f;

    private final float[] hinge = new float[3];
    /** Шарнір (сумісність API: окремого півота більше нема). */
    private final float[] pivot = new float[3];
    /** Повне обертання нижнього сегмента (swing після обмеження · twist). */
    private final float[] full = { 0, 0, 0, 1 };
    private final float[] twist = new float[4], twistInv = new float[4], swing = new float[4];
    /** Вісь swing (одинична) і напрямок, куди йде нижній сегмент (увігнутий бік, ⊥ Y). */
    private final float[] ax = { 1, 0, 0 };
    private final float[] concave = new float[3];
    /** Центр дуги spine. */
    private final float[] center = new float[3];
    /** Кінець дуги (вісь на slabEnd після згину). */
    private final float[] arcEnd = new float[3];
    private final float[] rotIn = new float[4];
    private final float[] tmp = new float[3], tmp2 = new float[3], qa = new float[4], qb = new float[4], qf = new float[4];
    private static final float[] Y = { 0, 1, 0 };

    private boolean active;
    private boolean curved;
    private float swingRad, twistRad;
    private float slabStart, slabLen, arcR;

    /** Без розмірів кубоїда (рука 4×12×4 за замовчуванням не припускається — зсуву півота нема). */
    public boolean set(float rxDeg, float ryDeg, float rzDeg, float hx, float hy, float hz) {
        return set(rxDeg, ryDeg, rzDeg, hx, hy, hz, 0, 0, 6);
    }

    /**
     * @param rxDeg,ryDeg,rzDeg обертання нижнього сегмента відносно верхнього (ZYX, градуси)
     * @param hx,hy,hz          точка шарніра у просторі частини (пікселі) — центр кінцівки
     * @param halfX,halfZ       півтовщина кубоїда по X і Z (пікселі)
     * @param halfLen           половина довжини кінцівки (від шарніра до торця), пікселі
     * @return чи є згин узагалі (false — малюй ванільно)
     */
    public boolean set(float rxDeg, float ryDeg, float rzDeg, float hx, float hy, float hz,
                       float halfX, float halfZ, float halfLen) {
        eulerZYX((float) Math.toRadians(rxDeg), (float) Math.toRadians(ryDeg), (float) Math.toRadians(rzDeg), rotIn);
        return setRotation(rotIn, hx, hy, hz, halfX, halfZ, halfLen);
    }

    /**
     * Згин, де стоїть НИЖНЯ половина, а рухається верхня (тулуб: поясниця на стегнах, груди гнуться).
     * Та сама дуга, що й для {@code conj(upperRot)} на нижньому сегменті, потім уся сітка переводиться
     * в систему нижнього сегмента ({@link #unlower}) — низ повертається на місце, верх отримує {@code upperRot}.
     *
     * @param rxDeg,ryDeg,rzDeg обертання ВЕРХНЬОГО сегмента відносно нижнього (ZYX, градуси)
     */
    public boolean setUpper(float rxDeg, float ryDeg, float rzDeg, float hx, float hy, float hz,
                            float halfX, float halfZ, float halfLen) {
        eulerZYX((float) Math.toRadians(rxDeg), (float) Math.toRadians(ryDeg), (float) Math.toRadians(rzDeg), rotIn);
        conj(rotIn, rotIn);
        return setRotation(rotIn, hx, hy, hz, halfX, halfZ, halfLen);
    }

    /**
     * @param rot обертання нижнього сегмента відносно верхнього, кватерніон {@code (x,y,z,w)} (не змінюється)
     */
    public boolean setRotation(float[] rot, float hx, float hy, float hz, float halfX, float halfZ, float halfLen) {
        rootMode = false;
        tailMode = false;
        return setup(rot, hx, hy, hz, halfX, halfZ, halfLen);
    }

    /**
     * Згин біля НИЖНЬОГО торця (таз): дуга {@code [bottom − 2a, bottom]}, а нижче неї — лише торець, повернутий
     * на {@code rot} (звичайний режим: верх стоїть). Низ тулуба загинається до стегон, суглоби ніг їдуть за ним
     * ({@link #lower} точки торця).
     *
     * @param rot  обертання торця відносно частини, кватерніон {@code (x,y,z,w)}
     * @param aMax найбільша півзона (щоб не налізти на зону грудей)
     */
    public boolean setTail(float[] rot, float hx, float bottom, float hz, float halfX, float halfZ, float aMax) {
        rootMode = false;
        tailMode = true;
        tailBottom = bottom;
        tailAMax = Math.max(0.05f, aMax);
        return setup(rot, hx, bottom, hz, halfX, halfZ, 6);
    }

    private boolean tailMode;
    private float tailBottom, tailAMax;

    /** Найбільша півзона кореневого згину (кульша), пікселі: дуга не довша за 2·ROOT_MAX_A. */
    public static final float ROOT_MAX_A = 1.6f;

    /**
     * Кореневий згин (кульша): торець кінцівки на {@code top} лишається вирівняним по батьківській частині
     * (низ тулуба) і стоїть на місці, а кінцівка виходить із нього короткою дугою {@code [top, top+2a]} у свій
     * напрям. Щоб торець не рухався, уся сітка зсувається на {@link #rootShift()} (нижче дуги — лише цей зсув).
     *
     * Робочий цикл: {@link #transform} / {@link #ring} → {@link #unlower} для вершин до кінця дуги, потім
     * {@code + rootShift} для всіх (див. {@code BendMeshRenderer}).
     *
     * @param capRot обертання торця відносно кінцівки, кватерніон {@code (x,y,z,w)} — {@code R_part⁻¹·R_parent}
     * @param top    Y торця у просторі частини
     * @param aMax   найбільша півзона (щоб не налізти на зону коліна)
     */
    public boolean setRoot(float[] capRot, float hx, float top, float hz, float halfX, float halfZ, float aMax) {
        rootMode = true;
        tailMode = false;
        rootTop = top;
        rootAMax = Math.max(0.05f, Math.min(ROOT_MAX_A, aMax));
        conj(capRot, rotIn);
        boolean on = setup(rotIn, hx, top, hz, halfX, halfZ, 6);
        tmp2[0] = hx; tmp2[1] = top; tmp2[2] = hz;
        unlower(tmp2);
        rootShift[0] = hx - tmp2[0]; rootShift[1] = top - tmp2[1]; rootShift[2] = hz - tmp2[2];
        return on;
    }

    /** Зсув усієї сітки для {@link #setRoot}: торець повертається на місце. */
    public float[] rootShift() { return rootShift; }

    private boolean rootMode;
    private float rootTop, rootAMax;
    private final float[] rootShift = new float[3];

    private boolean setup(float[] rot, float hx, float hy, float hz, float halfX, float halfZ, float halfLen) {
        hinge[0] = hx; hinge[1] = hy; hinge[2] = hz;
        float[] q = full;
        q[0] = rot[0]; q[1] = rot[1]; q[2] = rot[2]; q[3] = rot[3];
        normalize(q);

        // twist навколо Y: проєкція кватерніона на вісь
        float tw = q[3], ty = q[1];
        float tl = (float) Math.sqrt(tw * tw + ty * ty);
        twist[0] = twist[1] = twist[2] = 0; twist[3] = 1;
        if (tl > IDENTITY_EPS) { twist[1] = ty / tl; twist[3] = tw / tl; }
        // swing = q · twist⁻¹
        mul(q, conj(twist, twistInv), swing);
        normalize(swing);
        if (swing[3] < 0) { swing[0] = -swing[0]; swing[1] = -swing[1]; swing[2] = -swing[2]; swing[3] = -swing[3]; }

        float angle = 2f * (float) Math.acos(Math.min(1f, swing[3]));
        float max = (float) Math.toRadians(MAX_SWING_DEG);
        ax[0] = swing[0]; ax[1] = swing[1]; ax[2] = swing[2];
        float axLen = len(ax);
        if (axLen < IDENTITY_EPS) { angle = 0; ax[0] = 1; ax[1] = 0; ax[2] = 0; }
        else { ax[0] /= axLen; ax[1] /= axLen; ax[2] /= axLen; }
        if (angle > max) angle = max;
        axisAngle(ax, angle, swing);
        swingRad = angle;
        mul(swing, twist, full);
        normalize(full);
        twistRad = 2f * (float) Math.atan2(twist[1], twist[3]);

        // увігнутий бік: куди йде нижній сегмент. Для осі ax ⊥ Y це ax × Y.
        concave[0] = ax[1] * 0 - ax[2] * 1;
        concave[1] = ax[2] * 0 - ax[0] * 0;
        concave[2] = ax[0] * 1 - ax[1] * 0;
        float cl = len(concave);
        if (cl > 1e-5f) { concave[0] /= cl; concave[1] /= cl; concave[2] /= cl; }
        else { concave[0] = 0; concave[1] = 0; concave[2] = 1; }
        // півтовщина в площині згину
        float h = Math.abs(concave[0]) * halfX + Math.abs(concave[2]) * halfZ;

        // Зона згину [hy − a, hy + a] згортається в дугу ТІЄЇ Ж довжини (2a): вісь руки не коротшає.
        // Радіус дуги 2a/θ ≥ 1.15·h, щоб внутрішній бік не вивертався і не складався в точку.
        float budget = Math.max(0, halfLen - END_MARGIN);
        curved = angle > SWING_EPS;
        float a;
        if (tailMode) {
            // таз: дуга біля нижнього торця; радіус ≥ ~0.87·h — низ тулуба круглий, не ламається
            a = Math.min(Math.max(0.575f * h * angle, 1f), tailAMax);
            hinge[1] = tailBottom - a;
            hy = hinge[1];
        } else if (rootMode) {
            // кульша: коротка дуга від торця; внутрішній бік (пах) може зібратися в складку — його ховає тулуб
            a = Math.min(Math.max(0.5f * h * angle, 0.75f), rootAMax);
            hinge[1] = rootTop + a;
            hy = hinge[1];
        } else {
            a = Math.max(Math.max(h, 1f), 1.15f * h * angle * 0.5f);
            a = Math.min(a, budget);
        }
        slabStart = hy - a;
        slabLen = 2f * a;
        arcR = curved ? slabLen / angle : 0;

        pivot[0] = hx; pivot[1] = hy; pivot[2] = hz;

        // центр дуги і її кінець
        center[0] = hx + concave[0] * arcR;
        center[1] = slabStart;
        center[2] = hz + concave[2] * arcR;
        spine(1f, arcEnd);

        active = angle > 1e-5f || Math.abs(twistRad) > 1e-5f;
        return active;
    }

    public boolean active() { return active; }

    /** Кут згину після обмеження, радіани. */
    public float swingRadians() { return swingRad; }

    public float twistRadians() { return twistRad; }

    public float[] hinge() { return hinge; }

    /** Те саме, що {@link #hinge()} — збережено для сумісності. */
    public float[] pivot() { return pivot; }

    /** Повне обертання нижнього сегмента {@code (x,y,z,w)} — для нормалей і того, що висить нижче шарніра. */
    public float[] lowerRotation() { return full; }

    public float[] twistRotation() { return twist; }

    public float[] swingRotation() { return swing; }

    /** Зона згину у спокої: {@code [slabStart, slabEnd]} по Y. */
    public float slabStart() { return slabStart; }

    public float slabEnd() { return slabStart + slabLen; }

    /** Y у спокої для кільця на частці {@code f ∈ [0,1]} зони згину. */
    public float slabY(float f) { return slabStart + f * slabLen; }

    /** Радіус дуги осі (0 — без swing). */
    public float arcRadius() { return arcR; }

    /** Вершина за зоною, у яку вона потрапила (неперервно по Y). */
    public void transform(float x, float y, float z, float[] out) {
        if (y <= slabStart) { out[0] = x; out[1] = y; out[2] = z; return; }
        if (y >= slabStart + slabLen) { lower(x, y, z, out); return; }
        ring((y - slabStart) / slabLen, x, z, 0, 0, 0, out, tmp2);
    }

    /** Нижній сегмент: кінець дуги + повне обертання відносно осі на slabEnd. */
    public void lower(float x, float y, float z, float[] out) {
        rotate(full, x - hinge[0], y - (slabStart + slabLen), z - hinge[2], out);
        out[0] += arcEnd[0]; out[1] += arcEnd[1]; out[2] += arcEnd[2];
    }

    /**
     * Вершина кільця на частці {@code f} зони згину з відступом {@code (x, z)} у перетині (позиція у спокої)
     * і її нормаль: обидві повернуті на {@code swing(f·θ)·twist(f·τ)}.
     */
    public void ring(float f, float x, float z, float nx, float ny, float nz, float[] pos, float[] nrm) {
        frame(f, qf);
        spine(f, pos);
        rotate(qf, x - hinge[0], 0, z - hinge[2], tmp);
        pos[0] += tmp[0]; pos[1] += tmp[1]; pos[2] += tmp[2];
        rotate(qf, nx, ny, nz, nrm);
    }

    /**
     * Обернений жорсткий трансформ нижнього сегмента, на місці: {@code p ← full⁻¹·(p − arcEnd) + axis(slabEnd)}.
     * Для {@link #setUpper}: після звичайного {@link #transform}/{@link #ring} переводить вершину в систему,
     * де низ стоїть. Верхній сегмент (вершини у спокої) під цим трансформом — жорсткий рух грудей.
     */
    public void unlower(float[] p) {
        conj(full, qa);
        rotate(qa, p[0] - arcEnd[0], p[1] - arcEnd[1], p[2] - arcEnd[2], p);
        p[0] += hinge[0]; p[1] += slabStart + slabLen; p[2] += hinge[2];
    }

    /** Нормаль/напрям під {@link #unlower} (без зсуву), на місці. */
    public void unlowerNormal(float[] n) {
        conj(full, qa);
        rotate(qa, n[0], n[1], n[2], n);
    }

    /** Нормаль нижнього сегмента (одиничний вектор). */
    public void lowerNormal(float nx, float ny, float nz, float[] out) {
        rotate(full, nx, ny, nz, out);
    }

    /** Обертання перетину на частці f зони: swing(f·θ) · twist(f·τ). */
    private void frame(float f, float[] out) {
        axisAngle(ax, swingRad * f, qa);
        axisAngle(Y, twistRad * f, qb);
        mul(qa, qb, out);
    }

    /** Точка осі кінцівки на частці f зони згину. */
    private void spine(float f, float[] out) {
        if (!curved) {
            out[0] = hinge[0]; out[1] = slabStart + f * slabLen; out[2] = hinge[2];
            return;
        }
        axisAngle(ax, swingRad * f, qa);
        rotate(qa, hinge[0] - center[0], slabStart - center[1], hinge[2] - center[2], out);
        out[0] += center[0]; out[1] += center[1]; out[2] += center[2];
    }

    /** Шарнір кубоїда: центр по X/Z і середина довгої осі Y (пікселі, простір частини). */
    public static void cubeHinge(float minX, float minY, float minZ, float maxX, float maxY, float maxZ, float[] out) {
        out[0] = (minX + maxX) * 0.5f;
        out[1] = (minY + maxY) * 0.5f;
        out[2] = (minZ + maxZ) * 0.5f;
    }

    // ── кватерніони (x, y, z, w) ─────────────────────────────────────────

    /** {@code q = Rz(z)·Ry(y)·Rx(x)} — як {@code Quaternionf.rotationZYX(z, y, x)} у ModelPart. */
    public static float[] eulerZYX(float x, float y, float z, float[] q) {
        float sx = (float) Math.sin(x * 0.5f), cx = (float) Math.cos(x * 0.5f);
        float sy = (float) Math.sin(y * 0.5f), cy = (float) Math.cos(y * 0.5f);
        float sz = (float) Math.sin(z * 0.5f), cz = (float) Math.cos(z * 0.5f);
        q[0] = sx * cy * cz - cx * sy * sz;
        q[1] = cx * sy * cz + sx * cy * sz;
        q[2] = cx * cy * sz - sx * sy * cz;
        q[3] = cx * cy * cz + sx * sy * sz;
        return q;
    }

    public static float[] axisAngle(float[] axis, float rad, float[] q) {
        float s = (float) Math.sin(rad * 0.5f);
        q[0] = axis[0] * s; q[1] = axis[1] * s; q[2] = axis[2] * s;
        q[3] = (float) Math.cos(rad * 0.5f);
        return q;
    }

    /** {@code out = a·b} (спершу b, потім a). {@code out} не може бути {@code a} чи {@code b}. */
    public static float[] mul(float[] a, float[] b, float[] out) {
        out[0] = a[3] * b[0] + a[0] * b[3] + a[1] * b[2] - a[2] * b[1];
        out[1] = a[3] * b[1] - a[0] * b[2] + a[1] * b[3] + a[2] * b[0];
        out[2] = a[3] * b[2] + a[0] * b[1] - a[1] * b[0] + a[2] * b[3];
        out[3] = a[3] * b[3] - a[0] * b[0] - a[1] * b[1] - a[2] * b[2];
        return out;
    }

    public static float[] conj(float[] q, float[] out) {
        out[0] = -q[0]; out[1] = -q[1]; out[2] = -q[2]; out[3] = q[3];
        return out;
    }

    /** {@code out = q·v·q⁻¹} для одиничного q. {@code out} може бути довільним масивом довжини ≥ 3. */
    public static void rotate(float[] q, float vx, float vy, float vz, float[] out) {
        float qx = q[0], qy = q[1], qz = q[2], qw = q[3];
        float tx = 2 * (qy * vz - qz * vy);
        float ty = 2 * (qz * vx - qx * vz);
        float tz = 2 * (qx * vy - qy * vx);
        out[0] = vx + qw * tx + (qy * tz - qz * ty);
        out[1] = vy + qw * ty + (qz * tx - qx * tz);
        out[2] = vz + qw * tz + (qx * ty - qy * tx);
    }

    private static void normalize(float[] q) {
        float l = (float) Math.sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]);
        if (l < IDENTITY_EPS) { q[0] = q[1] = q[2] = 0; q[3] = 1; return; }
        q[0] /= l; q[1] /= l; q[2] /= l; q[3] /= l;
    }

    private static float len(float[] v) {
        return (float) Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    }
}
