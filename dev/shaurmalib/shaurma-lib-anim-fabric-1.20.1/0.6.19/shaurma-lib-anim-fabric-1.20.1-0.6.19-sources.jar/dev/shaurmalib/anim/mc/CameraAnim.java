package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.pose.Pose;
import dev.shaurmalib.anim.runtime.CameraSolver;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3532;

/**
 * Камера першої особи за анімованою головою: впав — камера падає разом з головою, лягає на спину —
 * дивиться вгору, нахилився — нахиляється. Вмикається вагою {@code camera}/{@code camera_rotation}
 * у кліпі, запиті або правилі; переходить плавно разом з fade кліпа. Мишка працює поверх (кути додаються).
 *
 * Ваніль-рівень: міксин {@code Camera.setup} TAIL ставить позицію й yaw/pitch, міксин
 * {@code GameRenderer.bobHurt} додає крен — однаково на Forge/Fabric/NeoForge.
 */
public final class CameraAnim {

    private CameraAnim() {}

    private static final CameraSolver.Frame FRAME = new CameraSolver.Frame();
    private static float roll;
    /** Око перед обличчям (пікселі моделі): півголови (4) + запас, щоб не бачити зсередини голову/шию. */
    private static final float FACE_FORWARD = 4.6f;
    /** Чи цей кадр камеру поставив рушій (для власного гравця) — First-person Model тоді не зсуває тіло. */
    private static volatile boolean placedLocal;

    public static boolean placedLocal() { return placedLocal; }

    /** Результат для {@code Camera.setup}: null — камеру не чіпати. */
    public record Result(class_243 position, float yRot, float xRot) {}

    public static Result apply(class_1297 entity, boolean detached, float partial, class_243 camPos, float camYRot, float camXRot) {
        roll = 0;
        placedLocal = false;
        if (detached || !dev.shaurmalib.anim.ShaurmaAnim.headCamera() || !(entity instanceof class_1309 e)) return null;
        if (McAnim.rigOf(e) == null || dev.shaurmalib.anim.ShaurmaAnim.find(e.method_5667()) == null) return null;
        Pose pose = McAnim.evaluate(e, partial, null, true);
        boolean body = dev.shaurmalib.anim.ShaurmaAnim.bodyCamera() && e instanceof net.minecraft.class_1657;
        if (pose == null || !CameraSolver.solve(pose, FRAME, body ? 1f : 0f, body ? FACE_FORWARD : 0f)) return null;
        placedLocal = body;

        float bodyYaw = class_3532.method_17821(partial, e.field_6220, e.field_6283) * class_3532.field_29847;
        // сцена Blockbench: +X праворуч, +Y вгору, −Z вперед → світ за поворотом тіла
        double fx = -class_3532.method_15374(bodyYaw), fz = class_3532.method_15362(bodyYaw);   // вперед
        double rx = -class_3532.method_15362(bodyYaw), rz = -class_3532.method_15374(bodyYaw);  // праворуч
        // модель малюється в масштабі рендерера (гравець — 0.9375, PlayerRenderer.scale), а на шифті гра
        // опускає її на 0.125 блока (getRenderOffset) — око камери має бути там, де намальована голова
        boolean player = e instanceof net.minecraft.class_1657;
        double s = (player ? 0.9375 : 1.0) / 16.0;
        double lx = FRAME.eyeX * s, ly = FRAME.eyeY * s, lz = FRAME.eyeZ * s;
        class_243 base = e.method_30950(partial);
        if (player && e.method_18276()) base = base.method_1031(0, -0.125, 0);
        class_243 target = new class_243(base.field_1352 + rx * lx + fx * -lz, base.field_1351 + ly, base.field_1350 + rz * lx + fz * -lz);
        class_243 pos = camPos.method_35590(target, FRAME.positionWeight);

        float w = FRAME.rotationWeight;
        roll = FRAME.roll * w;
        return new Result(pos, camYRot + FRAME.yaw * w, camXRot + FRAME.pitch * w);
    }

    /** Крен поточного кадру (градуси) для {@code GameRenderer.bobHurt}. */
    public static float roll() { return roll; }
}
