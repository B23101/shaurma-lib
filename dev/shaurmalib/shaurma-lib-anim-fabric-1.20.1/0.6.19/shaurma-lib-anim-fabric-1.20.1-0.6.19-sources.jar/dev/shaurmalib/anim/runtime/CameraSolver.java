package dev.shaurmalib.anim.runtime;

import dev.shaurmalib.anim.bend.BendMath;

import dev.shaurmalib.anim.math.Mat4;
import dev.shaurmalib.anim.pose.BoneTransform;
import dev.shaurmalib.anim.pose.Pose;
import dev.shaurmalib.anim.rig.Rig;

import java.util.ArrayList;
import java.util.List;

/**
 * Камера першої особи «за головою»: де опинилось око анімованої моделі і куди дивиться голова.
 *
 * Ланцюжок кісток від кореня до голови (для гравця: {@code body} → {@code head}) множиться в просторі
 * сцени Blockbench (Y вгору, обличчя до −Z, права рука на +X) — тими ж правилами, що Blockbench показує
 * кістки: обертання {@code (−x, −y, z)}, зсув {@code (−x, y, z)}, порядок ZYX навколо півота.
 * Голова береться БЕЗ процедурного погляду ({@link Pose#headNoLook}): погляд — це сама камера (мишка).
 *
 * Результат — абсолютна точка ока відносно ступнів моделі та кути відносно спокою. Адаптер переводить
 * це у світ за поворотом тіла. Абсолютна точка (а не «зсув від стоячого ока») — щоб камера правильно
 * лягала навіть тоді, коли гра вже сама опустила око (поза SWIMMING у лежачого).
 */
public final class CameraSolver {

    private CameraSolver() {}

    public static final class Frame {
        /** Око в просторі сцени (пікселі від ступнів; +X праворуч, +Y вгору, −Z вперед). */
        public float eyeX, eyeY, eyeZ;
        /** Кути відносно стоячої голови, градуси: yaw праворуч +, pitch вниз +, roll за годинниковою +. */
        public float yaw, pitch, roll;
        public float positionWeight, rotationWeight;

        public boolean active() { return positionWeight > 1e-3f || rotationWeight > 1e-3f; }
    }

    /** @return false — у ригу немає ока/голови або камера в кадрі не задіяна. */
    public static boolean solve(Pose pose, Frame out) {
        return solve(pose, out, 0f, 0f);
    }

    /**
     * @param minPosition найменша вага позиції (1 — камера завжди в оці моделі, навіть без кліпа з камерою)
     * @param eyeForward  на скільки пікселів винести око вперед від голови (перед обличчя: голову й тулуб не видно)
     */
    public static boolean solve(Pose pose, Frame out, float minPosition, float eyeForward) {
        Rig rig = pose.rig();
        float[] eye = rig.eye();
        int head = rig.indexOf("head");
        out.positionWeight = Math.max(pose.cameraWeight, minPosition);
        out.rotationWeight = pose.cameraRotWeight;
        if (eye == null || head < 0 || !out.active()) return false;

        List<Integer> chain = new ArrayList<>();
        for (int b = head; b >= 0; b = rig.parent(b)) chain.add(0, b);
        Mat4 m = new Mat4();
        for (int b : chain) {
            // голова їде за зігнутими грудьми (upper_torso), як у PlayerModelBridge.writeChest
            if (b == head) chestMotion(pose, rig, m);
            BoneTransform t = b == head ? pose.headNoLook : pose.bone(b);
            float[] p = rig.pivot(b);
            m.translate(-t.px, t.py, t.pz)
             .translate(p[0], p[1], p[2])
             .rotateZ((float) Math.toRadians(t.rz))
             .rotateY((float) Math.toRadians(-t.ry))
             .rotateX((float) Math.toRadians(-t.rx))
             .scale(t.sx, t.sy, t.sz)
             .translate(-p[0], -p[1], -p[2]);
        }
        float[] v = new float[3];
        m.transformPoint(eye[0], eye[1], eye[2] - eyeForward, v);
        out.eyeX = v[0];
        out.eyeY = v[1];
        out.eyeZ = v[2];

        float[] f = new float[3], r = new float[3];
        m.transformNormal(0, 0, -1, f);
        m.transformNormal(1, 0, 0, r);
        out.pitch = (float) -Math.toDegrees(Math.asin(clamp(f[1])));
        out.yaw = (Math.abs(f[0]) < 1e-5f && Math.abs(f[2]) < 1e-5f) ? 0f : (float) Math.toDegrees(Math.atan2(f[0], -f[2]));
        out.roll = (float) -Math.toDegrees(Math.asin(clamp(r[1])));
        return true;
    }

    private static float clamp(float v) { return v < -1 ? -1 : (v > 1 ? 1 : v); }

    /** Тулуб гравця у просторі частини (ModelPart): кубоїд (−4,0,−2)..(4,12,2), шарнір посередині. */
    private static final float TORSO_HY = 6f, TORSO_HALF_X = 4f, TORSO_HALF_Z = 2f, TORSO_HALF_LEN = 6f;

    /**
     * Жорсткий рух грудей у просторі кореня (сцена Blockbench) — множиться в {@code m}: {@code m ← m · T·U·T⁻¹},
     * де T — трансформ кістки torso, U — {@link BendMath#unlower} у системі частини тулуба (X і Y дзеркальні).
     */
    private static void chestMotion(Pose pose, Rig rig, Mat4 m) {
        int chest = rig.indexOf("upper_torso"), torso = rig.indexOf("torso");
        if (chest < 0 || torso < 0 || !pose.touched(chest)) return;
        BoneTransform c = pose.bone(chest);
        BendMath bend = new BendMath();
        if (!bend.setUpper(c.rx, c.ry, c.rz, 0, TORSO_HY, 0, TORSO_HALF_X, TORSO_HALF_Z, TORSO_HALF_LEN)) return;
        BoneTransform t = pose.bone(torso);
        float[] p = rig.pivot(torso);
        // T (як у ланцюжку вище) і T⁻¹
        m.translate(-t.px, t.py, t.pz)
         .translate(p[0], p[1], p[2])
         .rotateZ((float) Math.toRadians(t.rz))
         .rotateY((float) Math.toRadians(-t.ry))
         .rotateX((float) Math.toRadians(-t.rx))
         .scale(t.sx, t.sy, t.sz);
        // U у системі тулуба (початок — півот): точка сцени q ↔ частина (−qx, −qy, qz)
        float[] o = u(bend, 0, 0, 0), ex = u(bend, 1, 0, 0), ey = u(bend, 0, 1, 0), ez = u(bend, 0, 0, 1);
        m.mul(new float[] {
            ex[0] - o[0], ey[0] - o[0], ez[0] - o[0], o[0],
            ex[1] - o[1], ey[1] - o[1], ez[1] - o[1], o[1],
            ex[2] - o[2], ey[2] - o[2], ez[2] - o[2], o[2],
            0, 0, 0, 1 });
        m.scale(1f / safe(t.sx), 1f / safe(t.sy), 1f / safe(t.sz))
         .rotateX((float) Math.toRadians(t.rx))
         .rotateY((float) Math.toRadians(t.ry))
         .rotateZ((float) Math.toRadians(-t.rz))
         .translate(-p[0], -p[1], -p[2])
         .translate(t.px, -t.py, -t.pz);
    }

    private static float[] u(BendMath bend, float x, float y, float z) {
        float[] q = { -x, -y, z };
        bend.unlower(q);
        return new float[] { -q[0], -q[1], q[2] };
    }

    private static float safe(float s) { return Math.abs(s) < 1e-4f ? 1e-4f : s; }
}
