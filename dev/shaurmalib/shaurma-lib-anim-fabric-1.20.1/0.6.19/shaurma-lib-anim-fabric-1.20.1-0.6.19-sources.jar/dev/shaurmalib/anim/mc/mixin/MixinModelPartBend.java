package dev.shaurmalib.anim.mc.mixin;

import dev.shaurmalib.anim.mc.bend.BendMeshRenderer;
import dev.shaurmalib.anim.mc.bend.BendablePart;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;

/**
 * Згин кінцівки (лікоть/коліно): стан на частині + малювання розрізаної сітки замість ванільних 6 граней.
 * Без згину — нуль втручання (один boolean на виклик). Пріоритет 900 — раніше за типові 1000, щоб
 * зігнута частина не пішла в чужий швидкий шлях рендеру кубоїдів.
 */
@Mixin(value = class_630.class, priority = 900)
public abstract class MixinModelPartBend implements BendablePart {

    @Shadow @Final private List<class_630.class_628> cubes;

    @Unique private boolean shaurma$bent;
    @Unique private boolean shaurma$upper;
    @Unique private float[] shaurma$root;
    @Unique private float shaurma$bx, shaurma$by, shaurma$bz;

    @Override
    public void shaurma$setBendUpper(float rx, float ry, float rz) {
        shaurma$setBend(rx, ry, rz);
        shaurma$upper = true;
    }

    @Override public boolean shaurma$bendUpper() { return shaurma$upper; }

    @Override
    public void shaurma$setRootBend(float qx, float qy, float qz, float qw) {
        if (shaurma$root == null) shaurma$root = new float[4];
        shaurma$root[0] = qx; shaurma$root[1] = qy; shaurma$root[2] = qz; shaurma$root[3] = qw;
        shaurma$rootOn = Math.abs(qw) < 0.99999f;
    }

    @Override public void shaurma$clearRootBend() { shaurma$rootOn = false; }

    @Override public float[] shaurma$rootBend() { return shaurma$rootOn ? shaurma$root : null; }

    @Unique private boolean shaurma$rootOn;
    @Unique private float[] shaurma$tail;
    @Unique private boolean shaurma$tailOn;

    @Override
    public void shaurma$setTailBend(float qx, float qy, float qz, float qw) {
        if (shaurma$tail == null) shaurma$tail = new float[4];
        shaurma$tail[0] = qx; shaurma$tail[1] = qy; shaurma$tail[2] = qz; shaurma$tail[3] = qw;
        shaurma$tailOn = Math.abs(qw) < 0.99999f;
    }

    @Override public void shaurma$clearTailBend() { shaurma$tailOn = false; }

    @Override public float[] shaurma$tailBend() { return shaurma$tailOn ? shaurma$tail : null; }

    @Override
    public void shaurma$setBend(float rx, float ry, float rz) {
        shaurma$upper = false;
        shaurma$bx = rx;
        shaurma$by = ry;
        shaurma$bz = rz;
        shaurma$bent = rx != 0 || ry != 0 || rz != 0;
    }

    @Override
    public void shaurma$clearBend() {
        shaurma$bent = false;
        shaurma$upper = false;
        shaurma$bx = shaurma$by = shaurma$bz = 0;
    }

    @Override public boolean shaurma$hasBend() { return shaurma$bent; }
    @Override public float shaurma$bendX() { return shaurma$bx; }
    @Override public float shaurma$bendY() { return shaurma$by; }
    @Override public float shaurma$bendZ() { return shaurma$bz; }

    @Inject(method = "compile", at = @At("HEAD"), cancellable = true)
    private void shaurma$bend$compile(class_4587.class_4665 pose, class_4588 vc, int light, int overlay,
                                      float r, float g, float b, float a, CallbackInfo ci) {
        if (!shaurma$bent && !shaurma$rootOn && !shaurma$tailOn) return;
        BendMeshRenderer.render(cubes, this, pose, vc, light, overlay, r, g, b, a);
        ci.cancel();
    }

    /** Згин — частина пози: рукави/штани і броня отримують його разом з обертанням. */
    @Inject(method = "copyFrom", at = @At("TAIL"))
    private void shaurma$bend$copy(class_630 other, CallbackInfo ci) {
        BendablePart o = (BendablePart) (Object) other;
        if (o.shaurma$hasBend() && o.shaurma$bendUpper()) shaurma$setBendUpper(o.shaurma$bendX(), o.shaurma$bendY(), o.shaurma$bendZ());
        else if (o.shaurma$hasBend()) shaurma$setBend(o.shaurma$bendX(), o.shaurma$bendY(), o.shaurma$bendZ());
        else shaurma$clearBend();
        float[] r = o.shaurma$rootBend();
        if (r != null) shaurma$setRootBend(r[0], r[1], r[2], r[3]);
        else shaurma$clearRootBend();
        float[] tl = o.shaurma$tailBend();
        if (tl != null) shaurma$setTailBend(tl[0], tl[1], tl[2], tl[3]);
        else shaurma$clearTailBend();
    }

    @Inject(method = "resetPose", at = @At("TAIL"))
    private void shaurma$bend$reset(CallbackInfo ci) {
        shaurma$clearBend();
        shaurma$clearRootBend();
        shaurma$clearTailBend();
    }
}
