package dev.shaurmalib.meta.mc.screen;

import dev.shaurmalib.meta.MetaMode;
import dev.shaurmalib.meta.MetaTheme;
import dev.shaurmalib.meta.client.MetaClient;
import dev.shaurmalib.meta.economy.Currency;
import dev.shaurmalib.meta.mc.MetaScreens;
import dev.shaurmalib.meta.mc.skin.MetaSkin;
import dev.shaurmalib.meta.mc.skin.MetaSkins;
import dev.shaurmalib.meta.mc.ui.MetaUi;
import dev.shaurmalib.meta.profile.MetaProfile;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * База екранів мета-двигуна: «дизайнові» координати 960×540, що рівномірно масштабуються під вікно,
 * клікабельні зони, плавні hover-стани, верхня навігація між розділами й гаманець. Усе МАЛЮВАННЯ —
 * через {@link MetaSkin} режиму, тож кожен мод показує ці екрани у власному стилі.
 */
public abstract class MetaScreen extends Screen {

    public static final int DW = 960, DH = 540;

    protected record Zone(int x, int y, int w, int h, Runnable action) {}

    protected final Screen parent;
    protected final MetaMode mode;
    protected final MetaSkin skin;
    protected final MetaTheme theme;
    protected float ui = 1, ox, oy;
    protected int mx, my;
    /** Курсор у пікселях GUI (для екранів, що малюють вміст у власних координатах вікна). */
    protected double rawMx, rawMy;
    protected float dt, time;
    private long lastNanos = System.nanoTime();
    protected final List<Zone> zones = new ArrayList<>();
    private final Map<String, Float> hover = new HashMap<>();
    protected int accent;
    private String notice = "";
    private int noticeColor;
    private long noticeUntil;
    /**
     * Гнучке полотно: замість фіксованих 960×540 з полями — на ВЕСЬ екран ({@link #CW}×{@link #CH}, висота ≈ 540),
     * масштаб — ціле число фізичних пікселів на дизайн-піксель (чіткі шрифт і рамки). Верстка — відносно CW/CH.
     */
    protected boolean flexible = false;
    /** Малювати фон скіна (екрани з видом на світ — freecam підсумків — вимикають). */
    protected boolean drawBackdrop = true;
    /** Розмір полотна в дизайн-пікселях (960×540 для звичайних екранів). */
    protected int CW = DW, CH = DH;

    /** Показувати верхню навігацію між розділами. */
    protected boolean nav = true;
    /** Нижня межа клікабельної області (для прокручуваних списків під шапкою). */
    protected int clipTop = 0;

    protected MetaScreen(String title, Screen parent) {
        super(Component.literal(title));
        this.parent = parent;
        this.mode = MetaClient.mode();
        this.skin = MetaSkins.of(mode);
        this.theme = skin.theme();
        this.accent = theme.accent();
    }

    /** Ключ розділу для підсвітки в навігації: profile, wardrobe, shop, track, leaderboard. */
    protected abstract String section();

    protected abstract void draw(GuiGraphics g);

    protected MetaProfile me() { return MetaClient.self(); }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    protected void init() {
        float gs = minecraft == null ? 1f : (float) minecraft.getWindow().getGuiScale();
        if (flexible) {
            int n = Math.max(1, Math.round(height * gs / (float) DH));
            ui = n / gs;
            CW = (int) Math.floor(width / ui);
            CH = (int) Math.floor(height / ui);
            ox = 0;
            oy = 0;
        } else {
            ui = Math.min(width / (float) DW, height / (float) DH);
            CW = DW;
            CH = DH;
            // початок полотна — по фізичному пікселю
            ox = Math.round((width - DW * ui) / 2f * gs) / gs;
            oy = Math.round((height - DH * ui) / 2f * gs) / gs;
        }
        if (!openSounded) { openSounded = true; sound("open"); }
    }

    @Override
    public void render(GuiGraphics g, int rawX, int rawY, float partial) {
        long now = System.nanoTime();
        dt = Math.min(.1f, (now - lastNanos) / 1e9f);
        lastNanos = now;
        time += dt;
        mx = (int) Math.floor((rawX - ox) / ui);
        my = (int) Math.floor((rawY - oy) / ui);
        rawMx = rawX;
        rawMy = rawY;
        zones.clear();
        MetaUi.pixelRatio = ui * (minecraft == null ? 1f : (float) minecraft.getWindow().getGuiScale());
        if (drawBackdrop) skin.backdrop(g, width, height, time, MetaUi.outCubic(time / .35f));
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0);
        g.pose().scale(ui, ui, 1f);
        cursorTip = null;
        draw(g);
        if (nav && mode != null) navBar(g);
        depthBarrier(g);   // 3D-моделі пишуть глибину на z≈50…200 — без цього кутики й підказки ховались би за ними
        drawFocus(g);
        drawCursorTipMaybe(g);
        drawNotice(g);
        g.pose().popPose();
        // підказка мода — у координатах вікна, точно біля курсора (а не на масштабованому полотні)
        if (cursorTip != null) { depthBarrier(g); skinTipDrawn = skin.tooltip(g, font, java.util.List.of(cursorTip), rawX, rawY); }
        MetaUi.pixelRatio = 0f;   // тости й HUD малюються в іншому просторі — без підгонки під полотно
        MetaScreens.renderToasts(g, width, height);
    }

    /**
     * «Бар'єр шарів»: дорисувати накопичене і стерти глибину. Манекени ({@code renderEntityInInventory}) пишуть глибину
     * на z≈50…200, тож будь-яка плоска 2D-графіка після них (діалог, підказка, кутики) інакше лягала б ПІД модель.
     * Усе, що малюється після виклику, гарантовано поверх уже намальованих моделей.
     */
    protected void depthBarrier(GuiGraphics g) {
        g.flush();
        com.mojang.blaze3d.systems.RenderSystem.clear(org.lwjgl.opengl.GL11.GL_DEPTH_BUFFER_BIT, net.minecraft.client.Minecraft.ON_OSX);
    }

    // ── кутики фокусу, що «їздять» за курсором ───────────────────────────
    /** Показувати анімовані кутики навколо елемента під курсором. */
    protected boolean focusCursor = true;
    private float fX, fY, fW, fH, fA, fPop;
    private int fKey = Integer.MIN_VALUE;

    /**
     * Прямокутник, який зараз «у фокусі» ({x, y, w, h} у дизайнових координатах) або null.
     * Кутики — лише для того, що РЕДАГУЄШ на моделі (гардероб віддає предмет під курсором); звичайні кнопки й картки
     * їх не отримують — там вистачає власної підсвітки скіна.
     */
    protected int[] focusTarget() { return null; }

    /** Колір кутиків фокусу. */
    protected int focusColor() { return theme.gold(); }

    private void drawFocus(GuiGraphics g) {
        int[] t = focusCursor ? focusTarget() : null;
        float k = Math.min(1f, dt * 16f);
        if (t != null) {
            // ключ — ЩО у фокусі (5-й елемент), а не де: предмет на моделі рухається щокадру (дихання, улюбленець
            // гойдається), і ключ з координат перезапускав «поп» щокадру — кутики смикались
            int key = t.length > 4 ? t[4] : t[0] * 31 + t[1] * 17 + t[2] * 7 + t[3];
            if (fA < .05f) { fX = t[0]; fY = t[1]; fW = t[2]; fH = t[3]; }   // з'явились — одразу на місці
            if (key != fKey) { if (fKey != Integer.MIN_VALUE) fPop = 1f; fKey = key; }
            float kk = Math.min(1f, dt * 22f);
            fX += (t[0] - fX) * kk; fY += (t[1] - fY) * kk; fW += (t[2] - fW) * kk; fH += (t[3] - fH) * kk;
        } else fKey = Integer.MIN_VALUE;
        fA += ((t != null ? 1f : 0f) - fA) * Math.min(1f, dt * 12f);
        fPop = Math.max(0f, fPop - dt * 4f);
        if (fA < .02f) return;
        // «вдих»: кутики трохи відходять від рамки, а при новому фокусі — коротко розлітаються ширше
        float pad = 3f + fPop * fPop * 5f;
        int x1 = Math.round(fX - pad), y1 = Math.round(fY - pad), x2 = Math.round(fX + fW + pad), y2 = Math.round(fY + fH + pad);
        int len = Math.max(4, Math.min(9, Math.round(Math.min(fW, fH) / 3f)));
        MetaUi.brackets(g, x1 + 1, y1 + 1, x2 + 1, y2 + 1, len, 1, MetaUi.a(0, .5f * fA));
        MetaUi.brackets(g, x1, y1, x2, y2, len, 1, MetaUi.a(focusColor(), fA));
    }

    // ── підказка біля курсора ────────────────────────────────────────────
    private String cursorTip;
    private int cursorTipColor;
    private float tipA;
    private String lastTip = "";

    /** Підказка (бінд, назва предмета), що малюється біля курсора поверх усього; викликати щокадру з draw(). */
    protected void cursorTip(String text) { cursorTip(text, theme.gold()); }

    protected void cursorTip(String text, int color) { cursorTip = text; cursorTipColor = color; }

    /** Скін мода сам малює підказки — бібліотечна плашка не потрібна. */
    private boolean skinTipDrawn;

    private void drawCursorTipMaybe(GuiGraphics g) {
        if (skinTipDrawn) { tipA = 0f; return; }
        drawCursorTip(g);
    }

    private void drawCursorTip(GuiGraphics g) {
        if (cursorTip != null) lastTip = cursorTip;
        tipA += ((cursorTip != null ? 1f : 0f) - tipA) * Math.min(1f, dt * 14f);
        if (tipA < .03f || lastTip.isEmpty()) return;
        float sc = .85f;
        int tw = (int) (font.width(lastTip) * sc) + 10, th = 14;
        int x = mx + 12, y = my + 14;
        if (x + tw > DW - 4) x = mx - tw - 6;
        if (y + th > DH - 4) y = my - th - 6;
        y += Math.round((1f - tipA) * 4f);
        skin.toast(g, x, y, tw, th, tipA, time);
        MetaUi.textS(g, font, lastTip, x + 5, y + 3, sc, MetaUi.a(cursorTipColor, tipA), false);
    }

    protected void panel(GuiGraphics g, int x, int y, int w, int h, boolean main) { skin.panel(g, x, y, w, h, main, time); }

    /** Іконка: спершу скін мода, інакше піксельна бібліотечна (8·px). */
    protected void icon(GuiGraphics g, String id, int x, int y, int px, int argb) {
        if (!skin.icon(g, id, x, y, 8 * px, argb, 0f)) dev.shaurmalib.meta.mc.ui.MetaIcons.draw(g, id, x, y, px, argb);
    }

    // ── навігація ────────────────────────────────────────────────────────
    private static final String[][] NAV = {
            {"profile", "ПРОФІЛЬ", "profile"}, {"wardrobe", "ГАРДЕРОБ", "head"}, {"shop", "МАГАЗИН", "shop"},
            {"track", "ПРОПУСК", "track"}, {"leaderboard", "ЛІДЕРИ", "board"}};

    private static String navLabel(String[] n) {
        return net.minecraft.network.chat.Component.translatableWithFallback("shaurma_lib.nav." + n[0], n[1]).getString();
    }

    /** Права межа навігації (ліворуч від гаманця). */
    private int navRight() {
        MetaProfile p = me();
        int w = 0;
        if (p != null && mode != null) for (Currency c : mode.currencies) w += font.width(MetaUi.num(p.wallet.get(c.id()))) + 32;
        return 946 - w - 8;
    }

    private void navBar(GuiGraphics g) {
        int total = 0;
        for (String[] n : NAV) total += skin.tabWidth(font, navLabel(n)) + 4;
        int x = Math.min(330, navRight() - total), y = 10;
        for (String[] n : NAV) {
            int w = skin.tabWidth(font, navLabel(n));
            boolean act = n[0].equals(section());
            final String target = n[0];
            float hv = hv("nav" + n[0], zone(x, y, w, 20, () -> { if (!act) { sound("tab"); MetaScreens.open(target, parent); } }));
            skin.tab(g, font, x, y, w, 20, navLabel(n), n[2], act, hv);
            x += w + 4;
        }
        wallet(g, 946, 13);
    }

    /** Гаманець праворуч зверху. */
    protected void wallet(GuiGraphics g, int right, int y) {
        MetaProfile p = me();
        if (p == null || mode == null) return;
        int x = right;
        for (int i = mode.currencies.size() - 1; i >= 0; i--) {
            Currency c = mode.currencies.get(i);
            String v = MetaUi.num(p.wallet.get(c.id()));
            int w = font.width(v) + 22;
            x -= w;
            skin.chip(g, font, x, y, v, c.icon(), c.color());
            x -= 6;
        }
    }

    // ── віджети ──────────────────────────────────────────────────────────
    protected boolean over(int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    protected boolean zone(int x, int y, int w, int h, Runnable action) {
        if (y + h <= clipTop) return false;
        zones.add(new Zone(x, Math.max(y, clipTop), w, h - Math.max(0, clipTop - y), action));
        return over(x, Math.max(y, clipTop), w, h - Math.max(0, clipTop - y));
    }

    private float lastHoverSound = -1f;
    private boolean openSounded;

    protected float hv(String key, boolean on) {
        float v = hover.getOrDefault(key, 0f);
        // щойно навели — тихий тік (не частіше 20 разів на секунду: швидкий прохід мишею не тріщить)
        if (on && v < .05f && time > .3f && time - lastHoverSound > .05f) { lastHoverSound = time; sound("hover"); }
        v += ((on ? 1f : 0f) - v) * Math.min(1f, dt * 14f);
        hover.put(key, v);
        return v;
    }

    protected void button(GuiGraphics g, String key, int x, int y, int w, int h, String label, boolean active, Runnable action) {
        button(g, key, x, y, w, h, label, active ? MetaSkin.Kind.SELECTED : MetaSkin.Kind.NORMAL, action);
    }

    protected void button(GuiGraphics g, String key, int x, int y, int w, int h, String label, MetaSkin.Kind kind, Runnable action) {
        float hv = hv(key, action != null && zone(x, y, w, h, action));
        skin.button(g, font, x, y, w, h, label, kind, hv, action != null, time);
    }

    protected void primary(GuiGraphics g, String key, int x, int y, int w, int h, String label, Runnable action) {
        button(g, key, x, y, w, h, label, MetaSkin.Kind.PRIMARY, action);
    }

    protected void header(GuiGraphics g, String title, String sub) {
        skin.header(g, font, 16, 8, sub, title, time);
    }

    protected void say(String text, boolean error) {
        notice = text;
        noticeColor = error ? theme.bad() : theme.gold();
        noticeUntil = System.currentTimeMillis() + 3500;
    }

    private void drawNotice(GuiGraphics g) {
        long left = noticeUntil - System.currentTimeMillis();
        if (left <= 0 || notice.isEmpty()) return;
        float a = Math.min(1f, left / 400f);
        int w = font.width(notice) + 24, x = (DW - w) / 2, y = 512;
        skin.toast(g, x, y, w, 20, a, time);
        MetaUi.text(g, font, notice, x + 12, y + 6, MetaUi.a(noticeColor, a), true);
    }

    public void serverNotice(String text, String kind) { say(text, "error".equals(kind)); }

    protected void click() { sound("click"); }

    /** Підказки без ванільного відповідника: без звуку, якщо скін мода свого не має. */
    private static boolean quietWithoutSkin(String cue) {
        return cue.equals("hover") || cue.equals("open") || cue.equals("close") || cue.equals("page");
    }

    /** Звук меню: спершу скін мода (свої звуки), інакше — ванільний клік. */
    protected void sound(String cue) {
        if (skin.sound(cue) || minecraft == null || quietWithoutSkin(cue)) return;
        minecraft.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, "buy".equals(cue) ? 1.3f : 1f));
    }

    // ── ввід ─────────────────────────────────────────────────────────────
    protected void updateMouse(double rx, double ry) {
        rawMx = rx;
        rawMy = ry;
        mx = (int) Math.floor((rx - ox) / ui);
        my = (int) Math.floor((ry - oy) / ui);
    }

    @Override
    public boolean mouseClicked(double rx, double ry, int button) {
        updateMouse(rx, ry);
        if (button == 0) {
            for (int i = zones.size() - 1; i >= 0; i--) {
                Zone z = zones.get(i);
                if (over(z.x, z.y, z.w, z.h)) { z.action.run(); return true; }
            }
        }
        return super.mouseClicked(rx, ry, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public void onClose() {
        sound("close");
        if (minecraft != null) minecraft.setScreen(parent);
    }

    /** Перемалювати дані, коли сервер прислав новий профіль. */
    public void profileChanged() { }

    /** Масштаб полотна (дизайн-піксель → піксель GUI) — щоб підказки модів мали ту саму щільність, що меню. */
    public float canvasScale() { return ui; }

    // ── доступ для Preview (той самий пакет) ─────────────────────────────
    float ui() { return ui; }
}
