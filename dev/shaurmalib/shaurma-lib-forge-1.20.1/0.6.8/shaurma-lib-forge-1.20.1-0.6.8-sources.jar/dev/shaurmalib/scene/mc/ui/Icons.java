package dev.shaurmalib.scene.mc.ui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;

/**
 * Малювання білих піксель-арт іконок. Один піксель іконки стає цілою кількістю пікселів екрана при будь-якому GUI
 * scale — тоді лінії рівні, а не «замилені» чи нерівні.
 *
 * <p>Розмір залежить не від точного {@code box}, а від його <b>класу</b>: малі (рядки списків, заголовки панелей,
 * кнопки «+», «−», «×») однакові між собою, середні (панель інструментів, кнопки таймлайну, меню) — теж. Раніше
 * {@code box} 9, 10 і 11 при деяких масштабах давали іконки вдвічі різного розміру. Іконка завжди по центру свого
 * {@code box}.
 */
public final class Icons {
    public static final ResourceLocation ATLAS = new ResourceLocation("shaurma_lib", "textures/scene/icons.png");

    /** Бажаний розмір (GUI-пікселі) малих і середніх іконок. */
    private static final double SMALL = 10, MEDIUM = 15;
    /** Скільки GUI-пікселів можна перебрати понад бажаний розмір, щоб узяти більший цілий множник. */
    private static final double TOLERANCE = 1.5;

    private Icons() {}

    /** Фізичний розмір іконки в пікселях екрана: кратний 16 (1:1, 2:1, 3:1…) або 8 на зовсім малому інтерфейсі. */
    static int physicalSize(double scale, int box) {
        double target = box <= 12 ? SMALL : box <= 24 ? MEDIUM : box;
        double limit = (target + TOLERANCE) * scale;
        if (limit < 16) return limit >= 13 ? 16 : (int) Math.max(8, Math.floor(limit / 8.0) * 8);
        return (int) Math.floor(limit / 16.0) * 16;
    }

    /** Іконка по центру квадрата box×box (координати GUI), кольором color (ARGB; іконка біла — колір множиться). */
    public static void draw(GuiGraphics g, Icon icon, int x, int y, int box, int color) {
        double scale = Minecraft.getInstance().getWindow().getGuiScale();
        int phys = physicalSize(scale, box);
        float d = (float) (phys / scale);
        // вирівнюємо початок на межу фізичного пікселя
        float px = (float) (Math.round((x + (box - d) / 2f) * scale) / scale);
        float py = (float) (Math.round((y + (box - d) / 2f) * scale) / scale);
        g.pose().pushPose();
        g.pose().translate(px, py, 0);
        g.pose().scale(d / 16f, d / 16f, 1);
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor((color >> 16 & 255) / 255f, (color >> 8 & 255) / 255f, (color & 255) / 255f, (color >>> 24) / 255f);
        g.blit(ATLAS, 0, 0, 16, 16, icon.u(), icon.v(), 16, 16, Icon.ATLAS_W, Icon.ATLAS_H);
        RenderSystem.setShaderColor(1, 1, 1, 1);
        g.pose().popPose();
    }
}
