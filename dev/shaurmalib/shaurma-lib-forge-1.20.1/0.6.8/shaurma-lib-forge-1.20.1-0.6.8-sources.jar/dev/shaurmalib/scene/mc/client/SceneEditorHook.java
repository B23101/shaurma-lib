package dev.shaurmalib.scene.mc.client;

import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.mc.editor.ScenePickerScreen;
import dev.shaurmalib.scene.mc.editor.SceneEditorScreen;
import dev.shaurmalib.scene.mc.ui.Toasts;
import dev.shaurmalib.scene.net.SceneMessage;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** Вхід у редактор: сервер дозволив (EDIT_OPEN) — відкрити; клавіша редактора — вибір сцени. */
public final class SceneEditorHook {

    private SceneEditorHook() {}

    public static void open(SceneMessage m) {
        SceneDoc cached = SceneClient.doc(m.scene);
        // редактор працює з КОПІЄЮ: незбережені зміни не мають потрапити в кеш, з якого грають сесії
        SceneDoc doc = cached == null ? new SceneDoc(m.scene)
            : dev.shaurmalib.scene.io.SceneCodec.read(dev.shaurmalib.scene.io.SceneCodec.write(cached, false));
        doc.id = m.scene;
        doc.revision = cached == null ? 0 : cached.revision;
        Minecraft.getInstance().setScreen(new SceneEditorScreen(doc, (m.flags & 1) != 0, m.a));
    }

    public static void toast(String s) {
        var mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("§c[Сцени] §f" + s), false);
        Toasts.warn(Component.literal(s));
    }

    /** Клавіша «Редактор сцен»: список зареєстрованих сцен. */
    public static void openPicker() {
        Minecraft.getInstance().setScreen(new ScenePickerScreen());
        SceneClient.requestCatalog();
    }
}
