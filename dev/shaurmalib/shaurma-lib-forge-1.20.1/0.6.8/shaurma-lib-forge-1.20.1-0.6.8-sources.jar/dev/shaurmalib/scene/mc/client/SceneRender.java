package dev.shaurmalib.scene.mc.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.shaurmalib.anim.math.Mat4;
import dev.shaurmalib.anim.mc.PlayerModelBridge;
import dev.shaurmalib.anim.mesh.GeoMesh;
import dev.shaurmalib.anim.pose.BoneTransform;
import dev.shaurmalib.anim.pose.Pose;
import dev.shaurmalib.anim.rig.Rig;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.eval.SceneFrame;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.Map;
import java.util.Set;

/**
 * Малює акторів сцени у світі (без сутностей): ванільна модель гравця зі справжнім скіном або модель
 * з .bbmodel/geo. Кістки з міткою {@code player_skin} (і їхні діти) малюються скіном прив'язаного гравця
 * в UV-розкладці 64×64 — так «опудало на гачку» отримує скін жертви. Сховані кістки пропускаються.
 *
 * <p>Простір актора — {@code T(pos) · Ry(180−yaw) · Rx(pitch) · Rz(roll) · S}, той самий, що в
 * {@link dev.shaurmalib.scene.eval.SceneRig}, тож прикріплення й look-at збігаються з картинкою.
 */
public final class SceneRender {

    private SceneRender() {}

    public static final String SKIN_LABEL = "player_skin";
    private static PlayerModel<LivingEntity> wide, slim;

    /** Кадр світу (після сутностей): усі активні сесії + превʼю редактора. */
    public static void renderWorld(PoseStack ps, MultiBufferSource buffers, Vec3 cam, float partial) {
        for (SceneClient.Active a : SceneClient.active()) {
            if (a.playback.inPreroll()) continue;
            render(ps, buffers, cam, a.frame, a.clips, a.playback.doc(), false);
        }
        if (SceneClient.editorFrame != null && SceneClient.editorClips != null) {
            render(ps, buffers, cam, SceneClient.editorFrame, SceneClient.editorClips, editorDoc, true);
            for (Ghost g : onion) {
                SceneFrame.Actor a = g.actor();
                ps.pushPose();
                ps.translate(a.x - cam.x, a.y - cam.y, a.z - cam.z);
                try { actor(ps, buffers, a, SceneClient.editorClips, editorDoc, LightTexture.FULL_BRIGHT, 0.22f); } catch (RuntimeException ignored) { }
                ps.popPose();
            }
        }
    }

    /** Документ, який зараз редагується (ставить редактор). */
    public static SceneDoc editorDoc;

    /** Onion skin: примарні копії актора в сусідніх ключах (ставить редактор). */
    public record Ghost(SceneFrame.Actor actor, int color) {}
    public static final java.util.List<Ghost> onion = new java.util.ArrayList<>();

    public static void render(PoseStack ps, MultiBufferSource buffers, Vec3 cam, SceneFrame f, SceneClips clips, SceneDoc doc, boolean editor) {
        for (SceneFrame.Actor a : f.actors) {
            if (!a.visible && !editor) continue;
            if (editor && a.object.editorHidden) continue;
            try {
                ps.pushPose();
                ps.translate(a.x - cam.x, a.y - cam.y, a.z - cam.z);
                int light = light(a);
                actor(ps, buffers, a, clips, doc, light, a.visible ? 1f : 0.3f);
                ps.popPose();
            } catch (RuntimeException e) {
                ps.popPose();
            }
        }
    }

    private static int light(SceneFrame.Actor a) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return LightTexture.FULL_BRIGHT;
        return LevelRenderer.getLightColor(mc.level, BlockPos.containing(a.x, a.y + 0.6, a.z));
    }

    /** Актор у поточному стеку (початок — точка ступнів актора). Також для GUI-превʼю. */
    public static void actor(PoseStack ps, MultiBufferSource buffers, SceneFrame.Actor a, SceneClips clips, SceneDoc doc, int light, float alpha) {
        SceneObject o = a.object;
        ps.mulPose(Axis.YP.rotationDegrees(180f - a.yaw));
        if (a.pitch != 0) ps.mulPose(Axis.XP.rotationDegrees(a.pitch));
        if (a.roll != 0) ps.mulPose(Axis.ZP.rotationDegrees(a.roll));
        ps.scale(a.scale, a.scale, a.scale);
        if (o.modelType == SceneObject.ModelType.PLAYER) player(ps, buffers, a, doc, light, alpha);
        else {
            GeoMesh mesh = clips.mesh(o);
            if (mesh != null) mesh(ps, buffers, a, mesh, texture(o, doc), doc, light, alpha);
        }
    }

    private static ResourceLocation texture(SceneObject o, SceneDoc doc) {
        if (o.texture != null) {
            if (o.texture.contains(":")) return ResourceLocation.tryParse(o.texture);
            ResourceLocation rl = SceneAssets.texture(doc, o.texture);
            if (rl != null) return rl;
        }
        if (o.modelType == SceneObject.ModelType.ASSET) {
            SceneAssets.Model m = SceneAssets.model(doc, o.model);
            if (m != null && m.texture != null) return m.texture;
        }
        if (o.modelType == SceneObject.ModelType.RESOURCE && o.model != null) {
            // конвенція GeckoLib: geo/<шлях>.geo.json ↔ textures/<шлях>.png
            ResourceLocation rl = ResourceLocation.tryParse(o.model);
            if (rl != null) return new ResourceLocation(rl.getNamespace(), "textures/" + rl.getPath() + ".png");
        }
        return null;
    }

    // ── гравець ──

    private static void player(PoseStack ps, MultiBufferSource buffers, SceneFrame.Actor a, SceneDoc doc, int light, float alpha) {
        SceneSkins.Skin skin = SceneSkins.resolve(a.object, a.binding, doc);
        PlayerModel<LivingEntity> model = model(skin.slim());
        PlayerModelBridge.reset(model);
        model.young = false;
        model.crouching = false;
        model.riding = false;
        model.setAllVisible(true);
        Pose pose = new Pose(Rig.PLAYER);
        for (Map.Entry<String, float[]> e : a.pose.entrySet()) {
            int idx = Rig.PLAYER.indexOf(e.getKey());
            if (idx < 0) continue;
            float[] p = e.getValue();
            BoneTransform b = pose.bone(idx);
            b.rx = p[0]; b.ry = p[1]; b.rz = p[2]; b.px = p[3]; b.py = p[4]; b.pz = p[5]; b.sx = p[6]; b.sy = p[7]; b.sz = p[8];
            pose.markTouched(idx);
        }
        hide(model, a.object.hiddenBones);
        ps.pushPose();
        ps.scale(-1f, -1f, 1f);
        ps.translate(0, -1.501f, 0);
        PlayerModelBridge.applyRoot(ps, pose);
        PlayerModelBridge.apply(model, pose);
        RenderType type = alpha < 1 ? RenderType.entityTranslucent(skin.texture()) : RenderType.entityCutoutNoCull(skin.texture());
        model.renderToBuffer(ps, buffers.getBuffer(type), light, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, alpha);
        ps.popPose();
        PlayerModelBridge.reset(model);
    }

    private static void hide(PlayerModel<?> m, Set<String> hidden) {
        if (hidden.isEmpty()) return;
        for (String h : hidden) {
            ModelPart p = switch (h) {
                case "head" -> m.head;
                case "torso" -> m.body;
                case "right_arm" -> m.rightArm;
                case "left_arm" -> m.leftArm;
                case "right_leg" -> m.rightLeg;
                case "left_leg" -> m.leftLeg;
                default -> null;
            };
            if (p != null) p.visible = false;
            if ("body".equals(h)) m.setAllVisible(false);
        }
        m.hat.visible = m.head.visible;
        m.jacket.visible = m.body.visible;
        m.rightSleeve.visible = m.rightArm.visible;
        m.leftSleeve.visible = m.leftArm.visible;
        m.rightPants.visible = m.rightLeg.visible;
        m.leftPants.visible = m.leftLeg.visible;
    }

    private static PlayerModel<LivingEntity> model(boolean isSlim) {
        if (isSlim) {
            if (slim == null) slim = new PlayerModel<>(Minecraft.getInstance().getEntityModels().bakeLayer(ModelLayers.PLAYER_SLIM), true);
            return slim;
        }
        if (wide == null) wide = new PlayerModel<>(Minecraft.getInstance().getEntityModels().bakeLayer(ModelLayers.PLAYER), false);
        return wide;
    }

    // ── сітка ──

    private static void mesh(PoseStack ps, MultiBufferSource buffers, SceneFrame.Actor a, GeoMesh mesh, ResourceLocation tex,
                             SceneDoc doc, int light, float alpha) {
        SceneObject o = a.object;
        ResourceLocation main = tex != null ? tex : MISSING;
        RenderType tMain = alpha < 1 ? RenderType.entityTranslucent(main) : RenderType.entityCutoutNoCull(main);
        RenderType tSkin = null;
        if (o.boneLabels.containsValue(SKIN_LABEL)) {
            SceneSkins.Skin skin = SceneSkins.resolve(o.skinMode == SceneObject.SkinMode.DEFAULT ? slotSkinObject(o) : o, a.binding, doc);
            tSkin = alpha < 1 ? RenderType.entityTranslucent(skin.texture()) : RenderType.entityCutoutNoCull(skin.texture());
        }
        Matrix4f m4 = ps.last().pose();
        Matrix3f m3 = ps.last().normal();
        float[] tmp = new float[3], n = new float[3];
        for (GeoMesh.MeshBone b : mesh.roots) bone(b, new Mat4(), a.pose, o, false, buffers, tMain, tSkin, m4, m3, light, alpha, tmp, n);
    }

    /** Мітка player_skin без явного режиму скіна — беремо гравця зі слота. */
    private static SceneObject slotSkinObject(SceneObject o) {
        SceneObject s = new SceneObject(o.id, o.name, o.kind);
        s.skinMode = SceneObject.SkinMode.SLOT;
        s.modelType = SceneObject.ModelType.PLAYER;
        s.slim = o.slim;
        return s;
    }

    private static final ResourceLocation MISSING = new ResourceLocation("minecraft", "textures/misc/white.png");

    private static void bone(GeoMesh.MeshBone b, Mat4 parent, Map<String, float[]> pose, SceneObject o, boolean skinned,
                             MultiBufferSource buffers, RenderType main, RenderType skin, Matrix4f m4, Matrix3f m3, int light, float alpha, float[] tmp, float[] n) {
        if (o.hiddenBones.contains(b.name)) return;
        boolean useSkin = skinned || SKIN_LABEL.equals(o.boneLabels.get(b.name));
        Mat4 m = new Mat4().set(parent);
        float rx = b.rotX, ry = b.rotY, rz = b.rotZ;
        float[] p = pose.get(b.name);
        if (p != null) {
            m.translate(-p[3] / 16f, p[4] / 16f, p[5] / 16f);
            rx += (float) Math.toRadians(-p[0]);
            ry += (float) Math.toRadians(-p[1]);
            rz += (float) Math.toRadians(p[2]);
        }
        m.translate(b.pivotX, b.pivotY, b.pivotZ);
        m.rotateZ(rz).rotateY(ry).rotateX(rx);
        if (p != null) {
            if (Math.abs(p[6]) < 1e-4f && Math.abs(p[7]) < 1e-4f && Math.abs(p[8]) < 1e-4f) return;   // масштаб 0 = сховано
            m.scale(p[6], p[7], p[8]);
        }
        m.translate(-b.pivotX, -b.pivotY, -b.pivotZ);
        // буфер — заново для КОЖНОЇ кістки: BufferSource ділить один будівник між типами, і старий VertexConsumer
        // після getBuffer(іншого типу) пише вже в новий батч (через це весь гачок малювався скіном)
        VertexConsumer vc = b.cubes.isEmpty() ? null : buffers.getBuffer(useSkin && skin != null ? skin : main);
        for (GeoMesh.MeshCube c : b.cubes) {
            Mat4 cm = new Mat4().set(m).translate(c.pivotX, c.pivotY, c.pivotZ).rotateZ(c.rotZ).rotateY(c.rotY).rotateX(c.rotX)
                .translate(-c.pivotX, -c.pivotY, -c.pivotZ);
            for (GeoMesh.Quad q : c.quads) {
                cm.transformNormal(q.nx, q.ny, q.nz, n);
                for (int v = 0; v < 4; v++) {
                    cm.transformPoint(q.pos[v * 3], q.pos[v * 3 + 1], q.pos[v * 3 + 2], tmp);
                    vc.vertex(m4, tmp[0], tmp[1], tmp[2]).color(1f, 1f, 1f, alpha).uv(q.uv[v * 2], q.uv[v * 2 + 1])
                        .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(m3, n[0], n[1], n[2]).endVertex();
                }
            }
        }
        for (GeoMesh.MeshBone c : b.children) bone(c, m, pose, o, useSkin, buffers, main, skin, m4, m3, light, alpha, tmp, n);
    }
}
