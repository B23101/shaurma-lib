package dev.shaurmalib.scene.mc.client;

import dev.shaurmalib.anim.ShaurmaAnim;
import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.anim.mesh.GeoMesh;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.eval.ClipSource;
import dev.shaurmalib.scene.eval.SceneRig;

import java.util.HashMap;
import java.util.Map;

/**
 * Кліпи й риги для сцени на клієнті: {@code asset:<id>/<назва>} — анімації з .bbmodel світу,
 * решта — бібліотека ShaurmaAnim (ресурси модів: «маніяк сміється» запускається за ключем).
 */
public final class SceneClips implements ClipSource {

    private final SceneDoc doc;
    private final Map<String, SceneRig> resourceRigs = new HashMap<>();

    public SceneClips(SceneDoc doc) { this.doc = doc; }

    @Override
    public AnimationClip clip(String id) {
        if (id == null) return null;
        if (id.startsWith("asset:")) {
            int slash = id.indexOf('/', 6);
            if (slash < 0) return null;
            SceneAssets.Model m = SceneAssets.model(doc, id.substring(6, slash));
            return m == null ? null : m.clips.get(id);
        }
        return ShaurmaAnim.clip(id);
    }

    @Override
    public SceneRig rig(SceneObject actor) {
        switch (actor.modelType) {
            case PLAYER -> { return PLAYER_RIG; }
            case ASSET -> {
                SceneAssets.Model m = SceneAssets.model(doc, actor.model);
                return m == null ? null : m.rig;
            }
            case RESOURCE -> {
                if (actor.model == null) return null;
                return resourceRigs.computeIfAbsent(actor.model, k -> {
                    GeoMesh mesh = resourceMesh(k);
                    return mesh == null ? null : SceneRig.of(k, mesh);
                });
            }
            default -> { return null; }
        }
    }

    /** Сітка актора (ассет або ресурс), null — немає/ще вантажиться. */
    public GeoMesh mesh(SceneObject actor) {
        if (actor.modelType == SceneObject.ModelType.ASSET) {
            SceneAssets.Model m = SceneAssets.model(doc, actor.model);
            return m == null ? null : m.mesh;
        }
        if (actor.modelType == SceneObject.ModelType.RESOURCE && actor.model != null) return resourceMesh(actor.model);
        return null;
    }

    private static final Map<String, GeoMesh> GECKO = new HashMap<>();

    /**
     * Модель з ресурсів мода: спершу бібліотека ShaurmaAnim ({@code shaurma_anim/**.geo.json}), потім
     * будь-яка GeckoLib-модель {@code assets/<ns>/geo/<шлях>.geo.json} — тож у сцену стає кожна модель мода
     * (маніяки, гачок, пастки) без копіювання файлів.
     */
    public static GeoMesh resourceMesh(String id) {
        GeoMesh m = ShaurmaAnim.clips().mesh(id);
        if (m != null) return m;
        if (GECKO.containsKey(id)) return GECKO.get(id);
        GeoMesh found = null;
        net.minecraft.resources.ResourceLocation rl = net.minecraft.resources.ResourceLocation.tryParse(id);
        if (rl != null) {
            var res = net.minecraft.client.Minecraft.getInstance().getResourceManager()
                .getResource(new net.minecraft.resources.ResourceLocation(rl.getNamespace(), "geo/" + rl.getPath() + ".geo.json"));
            if (res.isPresent()) {
                try (var in = res.get().open()) {
                    found = GeoMesh.parse(new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8));
                } catch (Exception e) {
                    System.err.println("[shaurma_scene] geo " + id + ": " + e);
                }
            }
        }
        GECKO.put(id, found);
        return found;
    }

    /** Після F3+T: ресурси могли змінитись. */
    public static void clearResourceCache() { GECKO.clear(); }
}
