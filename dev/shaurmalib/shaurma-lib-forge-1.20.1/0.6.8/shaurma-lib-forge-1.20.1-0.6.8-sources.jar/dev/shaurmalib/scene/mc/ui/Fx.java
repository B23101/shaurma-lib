package dev.shaurmalib.scene.mc.ui;

import net.minecraft.client.gui.GuiGraphics;

/**
 * Візуальні ефекти інтерфейсу: easing, плавні значення (не залежать від FPS), «скляні» панелі з тінню й світінням,
 * градієнти, світлова смуга (shimmer), віньєтка, іскри. Усе — звичайні заливки GuiGraphics, без шейдерів: дешево
 * й сумісно з будь-якими модами. «Менше руху» в налаштуваннях вимикає анімації (усе одразу в кінцевому стані).
 */
public final class Fx {
    private Fx() {}

    public static boolean reduced() { return false; }

    // ───────── easing ─────────

    public static float clamp01(float t) { return t < 0 ? 0 : t > 1 ? 1 : t; }

    public static float outCubic(float t) { t = clamp01(t); float u = 1 - t; return 1 - u * u * u; }

    public static float outBack(float t) {
        t = clamp01(t);
        float c1 = 1.70158f, c3 = c1 + 1, u = t - 1;
        return 1 + c3 * u * u * u + c1 * u * u;
    }

    public static float inOutCubic(float t) {
        t = clamp01(t);
        return t < 0.5f ? 4 * t * t * t : 1 - (float) Math.pow(-2 * t + 2, 3) / 2;
    }

    public static float outExpo(float t) { t = clamp01(t); return t >= 1 ? 1 : 1 - (float) Math.pow(2, -10 * t); }

    /** Хвиля від точки кліку: розширюється й згасає; малюється лише всередині прямокутника. t — 0..1. */
    public static void ripple(GuiGraphics g, int x, int y, int w, int h, int r, float cx, float cy, float t, int rgb, float strength) {
        if (t <= 0 || t >= 1 || strength <= 0.01f) return;
        float e = outExpo(t);
        float far = (float) Math.hypot(Math.max(cx - x, x + w - cx), Math.max(cy - y, y + h - cy));
        int rad = Math.max(2, (int) (far * e));
        int x0 = Math.max(x, (int) cx - rad), x1 = Math.min(x + w, (int) cx + rad);
        int y0 = Math.max(y, (int) cy - rad), y1 = Math.min(y + h, (int) cy + rad);
        if (x1 <= x0 || y1 <= y0) return;
        rrect(g, x0, y0, x1 - x0, y1 - y0, Math.min(r, Math.min(x1 - x0, y1 - y0) / 2), withAlpha(rgb, strength * (1 - t) * (1 - t)));
    }

    /** Кільце фокусу (клавіатурна навігація / активне поле). */
    public static void focusRing(GuiGraphics g, int x, int y, int w, int h, int r, int rgb, float a) {
        if (a <= 0.01f) return;
        rborder(g, x - 1, y - 1, w + 2, h + 2, r + 1, withAlpha(rgb, a));
        rborder(g, x - 2, y - 2, w + 4, h + 4, r + 2, withAlpha(rgb, a * 0.35f));
    }

    /** М'яке згасання вмісту, що прокручується, біля верхнього й нижнього краю. */
    public static void edgeFade(GuiGraphics g, int x, int y, int w, int h, int rgb, float top, float bottom) {
        int fh = Math.min(10, h / 3);
        if (top > 0.01f) g.fillGradient(x, y, x + w, y + fh, withAlpha(rgb, 0.9f * top), withAlpha(rgb, 0));
        if (bottom > 0.01f) g.fillGradient(x, y + h - fh, x + w, y + h, withAlpha(rgb, 0), withAlpha(rgb, 0.9f * bottom));
    }

    public static float progress(long now, long start, long durMs) {
        if (reduced() || durMs <= 0) return 1;
        return clamp01((now - start) / (float) durMs);
    }

    /** Поява зі зсувом за індексом (каскад карток / кнопок). */
    public static float stagger(long now, long start, int index, long stepMs, long durMs) {
        return outCubic(progress(now, start + Math.min(index, 24) * stepMs, durMs));
    }

    /** Плавне наближення до цілі (hover, вибір), швидкість — «частка за секунду». */
    public static final class Smooth {
        private float value;
        private long last = -1;
        private final float speed;

        public Smooth(float speed) { this.speed = speed; }

        public float to(float target) {
            long now = System.nanoTime();
            if (last < 0 || reduced()) { last = now; value = target; return value; }
            float dt = Math.min(0.1f, (now - last) / 1e9f);
            last = now;
            value += (target - value) * (1 - (float) Math.exp(-speed * dt));
            if (Math.abs(target - value) < 0.002f) value = target;
            return value;
        }

        public float get() { return value; }

        public void set(float v) { value = v; last = -1; }
    }

    // ───────── кольори ─────────

    public static int withAlpha(int rgb, float a) { return ((int) (clamp01(a) * 255 + 0.5f) << 24) | (rgb & 0xFFFFFF); }

    public static int mulAlpha(int argb, float f) { return ((int) ((argb >>> 24) * clamp01(f)) << 24) | (argb & 0xFFFFFF); }

    public static int lerp(int a, int b, float t) { return Theme.lerp(a, b, clamp01(t)); }

    public static int brighten(int rgb, float f) {
        int r = Math.min(255, (int) ((rgb >> 16 & 255) * f)), g = Math.min(255, (int) ((rgb >> 8 & 255) * f)), b = Math.min(255, (int) ((rgb & 255) * f));
        return (rgb & 0xFF000000) | r << 16 | g << 8 | b;
    }

    // ───────── форми ─────────

    private static final int[][] INSETS = new int[24][];

    private static int[] insets(int r) {
        if (r < INSETS.length && INSETS[r] != null) return INSETS[r];
        int[] a = new int[r];
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            a[i] = Math.max(0, r - (int) Math.round(Math.sqrt(Math.max(0, (double) r * r - dy * dy))));
        }
        if (r < INSETS.length) INSETS[r] = a;
        return a;
    }

    /** Усі «закруглені» прямокутники мода тепер квадратні (плаский стиль MenuSkin). */
    private static int clampR(int r, int w, int h) { return 0; }

    /** Закруглений прямокутник. */
    public static void rrect(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0 || color >>> 24 == 0) return;
        r = clampR(r, w, h);
        if (r <= 0) { g.fill(x, y, x + w, y + h, color); return; }
        int[] in = insets(r);
        for (int i = 0; i < r; i++) {
            g.fill(x + in[i], y + i, x + w - in[i], y + i + 1, color);
            g.fill(x + in[i], y + h - 1 - i, x + w - in[i], y + h - i, color);
        }
        if (h - 2 * r > 0) g.fill(x, y + r, x + w, y + h - r, color);
    }

    /** Закруглена рамка 1 px. */
    public static void rborder(GuiGraphics g, int x, int y, int w, int h, int r, int color) {
        if (w <= 2 || h <= 2 || color >>> 24 == 0) return;
        r = clampR(r, w, h);
        if (r <= 1) {
            g.fill(x + 1, y, x + w - 1, y + 1, color); g.fill(x + 1, y + h - 1, x + w - 1, y + h, color);
            g.fill(x, y + 1, x + 1, y + h - 1, color); g.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
            return;
        }
        int[] in = insets(r);
        g.fill(x + in[0], y, x + w - in[0], y + 1, color);
        g.fill(x + in[0], y + h - 1, x + w - in[0], y + h, color);
        for (int i = 1; i < r; i++) {
            int o = in[i], p = in[i - 1];
            int len = Math.max(1, p - o);
            g.fill(x + o, y + i, x + o + len, y + i + 1, color);
            g.fill(x + w - o - len, y + i, x + w - o, y + i + 1, color);
            g.fill(x + o, y + h - 1 - i, x + o + len, y + h - i, color);
            g.fill(x + w - o - len, y + h - 1 - i, x + w - o, y + h - i, color);
        }
        g.fill(x, y + r, x + 1, y + h - r, color);
        g.fill(x + w - 1, y + r, x + w, y + h - r, color);
    }

    /** Закруглений прямокутник з вертикальним градієнтом. */
    public static void rrectGradient(GuiGraphics g, int x, int y, int w, int h, int r, int top, int bottom) {
        if (w <= 0 || h <= 0) return;
        r = clampR(r, w, h);
        int[] in = r > 0 ? insets(r) : new int[0];
        // смугами по 2 px — непомітно оку і вдвічі дешевше
        for (int i = 0; i < h; i += 2) {
            int c = Theme.lerp(top, bottom, h <= 1 ? 0 : i / (float) (h - 1));
            for (int k = i; k < Math.min(h, i + 2); k++) {
                int o = k < r ? in[k] : k >= h - r ? in[h - 1 - k] : 0;
                g.fill(x + o, y + k, x + w - o, y + k + 1, c);
            }
        }
    }

    /** М'яка тінь під елементом. */
    public static void shadow(GuiGraphics g, int x, int y, int w, int h, int r, float strength) {
        if (true) return;
        for (int k = 4; k >= 1; k--) rrect(g, x - k, y - k + 2, w + 2 * k, h + 2 * k, r + k, withAlpha(0, strength * 0.09f * (5 - k) / 4f));
    }

    /** Кольорове світіння навколо елемента. */
    public static void glow(GuiGraphics g, int x, int y, int w, int h, int r, int rgb, float strength) {
        if (true) return;
        for (int k = 5; k >= 1; k--) rrect(g, x - k, y - k, w + 2 * k, h + 2 * k, r + k, withAlpha(rgb, strength * 0.08f * (6 - k) / 5f));
    }

    /** Панель у пласкому стилі: чорний контур, рамка (до акценту при glowAmt), темне тіло. */
    public static void panel(GuiGraphics g, int x, int y, int w, int h, int r, int accent, float alpha, float glowAmt) {
        if (alpha <= 0.01f) return;
        MenuSkin.window(g, x, y, w, h, lerp(MenuSkin.EDGE, withAlpha(accent, 1f), clamp01(glowAmt) * 0.6f));
    }

    /** Світлова смуга, що пробігає по прямокутнику. */
    public static void shimmer(GuiGraphics g, int x, int y, int w, int h, long now, long periodMs, int rgb, float strength) {
    }

    /** Віньєтка по краях екрана. */
    public static void vignette(GuiGraphics g, int sw, int sh, float strength) {
        if (strength <= 0.01f) return;
        int ey = (int) (sh * 0.25f), ex = (int) (sw * 0.18f);
        g.fillGradient(0, 0, sw, ey, withAlpha(0, strength), 0);
        g.fillGradient(0, sh - ey, sw, sh, 0, withAlpha(0, strength));
        for (int i = 0; i < ex; i += 2) {
            float f = 1 - i / (float) ex;
            int c = withAlpha(0, strength * f * f * 0.7f);
            g.fill(i, 0, i + 2, sh, c);
            g.fill(sw - i - 2, 0, sw - i, sh, c);
        }
    }

    private static float hash(int n) {
        n = (n << 13) ^ n;
        return ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 2147483648f;
    }

    /** Іскри, що повільно підіймаються в області (фон меню). */
    public static void embers(GuiGraphics g, int x, int y, int w, int h, int count, int rgb, float alpha, long now) {
        if (alpha <= 0.01f || reduced()) return;
        for (int i = 0; i < count; i++) {
            float seed = hash(i * 7 + 3), speed = 0.00004f + hash(i * 13 + 5) * 0.00007f;
            float phase = (now * speed + seed) % 1f;
            int px = x + (int) (hash(i * 3 + 1) * w + Math.sin(phase * 9 + seed * 6.28) * 8);
            int py = y + (int) (h * (1 - phase));
            float a = (float) Math.sin(phase * Math.PI) * alpha;
            int size = hash(i * 11 + 9) > 0.8f ? 2 : 1;
            if (a < 0.02f) continue;
            g.fill(px, py, px + size, py + size, withAlpha(rgb, a * 0.9f));
            if (size == 2) g.fill(px - 1, py - 1, px + 3, py + 3, withAlpha(rgb, a * 0.18f));
        }
    }

    /** Фон меню: градієнт, віньєтка й іскри кольору акценту; прозорість — за прогресом відкриття. */
    public static void backdrop(GuiGraphics g, int w, int h, float t) {
        g.fillGradient(0, 0, w, h, withAlpha(0x0A1226, 0.55f * t), withAlpha(0x050912, 0.80f * t));
    }

    /** Текст із м'яким світінням. */
    public static void textGlow(GuiGraphics g, net.minecraft.client.gui.Font font, String s, int x, int y, int color, int glowRgb, float glow) {
        MenuSkin.text(g, font, s, x, y, color);
    }

    /**
     * Поява вікна: прозорість (через колір шейдера — діє на заливки й текст) і підйом на кілька пікселів.
     * Обов'язково закрити {@link #appearEnd}.
     */
    public static void appearBegin(GuiGraphics g, float t, float rise) {
        g.flush();
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1, 1, 1, Math.max(0.02f, t));
        g.pose().pushPose();
        g.pose().translate(0, (1 - t) * rise, 0);
    }

    /** Як {@link #appearBegin}, але вікно піднято по глибині: текст панелей під ним не пробивається крізь заливку. Закривати {@link #appearEnd}. */
    public static void overlayBegin(GuiGraphics g, float t, float rise) {
        appearBegin(g, t, rise);
        g.pose().translate(0, 0, 200);
    }

    public static void appearEnd(GuiGraphics g) {
        g.flush();
        g.pose().popPose();
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    /** Масштаб навколо точки (поява вікна «pop»). Парний {@link #pop}. */
    public static void push(GuiGraphics g, float cx, float cy, float scale) {
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().scale(scale, scale, 1);
        g.pose().translate(-cx, -cy, 0);
    }

    public static void pop(GuiGraphics g) { g.pose().popPose(); }
}
