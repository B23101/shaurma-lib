package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.edit.SceneValidator;
import dev.shaurmalib.scene.mc.ui.Fx;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.network.chat.Component;

/** Рядок стану внизу — як у Shaurma Modeling: підказка «що зараз робить миша», праворуч — вибір і проблеми сцени. */
final class StatusBar {

    private StatusBar() {}

    private static String last = "";
    private static long changedAt;

    static void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        MenuSkin.bar(gui.g, x, y, w, h, true);
        int ty = y + 2 + (h - 2 - 8) / 2;
        String hint;
        if (s.possessed != null) hint = "В камері «" + s.name(s.variant().object(s.possessed)) + "»: ПКМ+миша — повертати · ПКМ+WASD/QE — летіти · колесо — наїзд · C/Esc — вийти";
        else if (s.modal != 0) hint = "X/Y/Z — вісь · Shift — точно · ЛКМ/Enter — так · ПКМ/Esc — скасувати";
        else if (ViewportTools.busy()) hint = "Shift — точно · Ctrl — без сітки";
        else if (TimelinePanel.hovered) hint = "Тягни кліп · краї — обрізати (далі за кінець — цикл) · Alt — slip · Ctrl+стик — roll · кутики — fade · лінія — гучність";
        else if (s.inViewport(gui.mx, gui.my)) {
            SceneObject o = s.selected();
            hint = o == null ? "ЛКМ — вибрати · Ctrl — кілька · тягни — рамка · СКМ — орбіта · Shift+СКМ — панорама · ПКМ+WASD — політ"
                : s.selBone == null && o.kind == SceneObject.Kind.ACTOR ? "Клік по актору ще раз — вибрати кістку під курсором · 3 — поворот, тягни кільце"
                : "Тягни гізмо · K — ключ · F — до вибраного · Del — видалити";
        } else hint = "";
        String text = hint.isEmpty() ? s.status : hint + (s.status.isEmpty() ? "" : "   ·   " + s.status);
        if (!text.equals(last)) { last = text; changedAt = System.currentTimeMillis(); }
        float fade = Fx.outCubic(Fx.progress(System.currentTimeMillis(), changedAt, 160));
        int errors = 0, warns = 0;
        for (var i : s.issues) if (i.level() == SceneValidator.Level.ERROR) errors++; else warns++;
        String right = (errors > 0 ? "✖ " + errors + "  " : "") + (warns > 0 ? "⚠ " + warns + "  " : "")
            + (ViewportTools.multi.size() > 1 ? "вибрано " + ViewportTools.multi.size() + "  " : "")
            + (s.selected() != null ? s.name(s.selected()) + (s.selBone != null ? " › " + s.selBone : "") : "");
        int rw = gui.font.width(right);
        gui.textClip(text, x + 6, ty, w - rw - 20, Fx.lerp(Theme.RAIL, MenuSkin.LABEL, fade));
        gui.text(right, x + w - rw - 6, ty, errors > 0 ? Theme.DANGER : warns > 0 ? Theme.WARN : MenuSkin.TITLE);
        if ((errors > 0 || warns > 0) && gui.hover(x + w - rw - 8, y, rw + 8, h)) {
            gui.tip(Component.literal("Проблеми сцени — панель «Слоти й перевірка» (клік)"));
            if (gui.clicked(x + w - rw - 8, y, rw + 8, h, 0)) SceneDock.expand("slots");
        }
    }
}
