package dev.shaurmalib.scene.mc.mixin;

import dev.shaurmalib.scene.mc.client.SceneWorldFilter;
import net.minecraft.client.renderer.LevelRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** «Лише світ»: без дощу й снігу (смуги опадів і бризки від крапель). */
@Mixin(LevelRenderer.class)
public abstract class MixinSceneWeather {

    @Inject(method = "renderSnowAndRain", at = @At("HEAD"), cancellable = true)
    private void shaurma$scene$noRain(CallbackInfo ci) {
        if (SceneWorldFilter.hideWeather()) ci.cancel();
    }

    @Inject(method = "tickRain", at = @At("HEAD"), cancellable = true)
    private void shaurma$scene$noSplash(CallbackInfo ci) {
        if (SceneWorldFilter.hideWeather()) ci.cancel();
    }
}
