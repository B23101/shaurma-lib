package dev.shaurmalib.scene.mc.client;

import dev.shaurmalib.scene.io.AudioPcm;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.BitstreamException;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.DecoderException;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;

import java.io.ByteArrayInputStream;
import java.io.IOException;

/** MP3 → PCM через JLayer (вшитий у бібліотеку, LGPL). */
final class Mp3 {

    private Mp3() {}

    static AudioPcm decode(byte[] data) throws IOException {
        Bitstream bs = new Bitstream(new ByteArrayInputStream(data));
        Decoder dec = new Decoder();
        short[] out = new short[1 << 16];
        int n = 0, channels = 2, rate = 44100;
        try {
            for (int frames = 0; frames < 200_000; frames++) {
                Header h = bs.readFrame();
                if (h == null) break;
                SampleBuffer sb = (SampleBuffer) dec.decodeFrame(h, bs);
                channels = sb.getChannelCount();
                rate = sb.getSampleFrequency();
                int len = sb.getBufferLength();
                if (n + len > out.length) out = java.util.Arrays.copyOf(out, Math.max(out.length * 2, n + len));
                System.arraycopy(sb.getBuffer(), 0, out, n, len);
                n += len;
                bs.closeFrame();
            }
        } catch (BitstreamException | DecoderException e) {
            if (n == 0) throw new IOException("MP3 не декодується: " + e.getMessage());
        } finally {
            try { bs.close(); } catch (BitstreamException ignored) { }
        }
        if (n == 0) throw new IOException("MP3 порожній");
        return new AudioPcm(java.util.Arrays.copyOf(out, n), channels, rate);
    }
}
