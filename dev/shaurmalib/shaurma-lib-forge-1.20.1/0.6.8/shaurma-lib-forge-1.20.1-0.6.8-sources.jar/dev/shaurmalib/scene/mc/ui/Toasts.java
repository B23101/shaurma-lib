package dev.shaurmalib.scene.mc.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;

/** Короткі повідомлення в правому верхньому куті (і в редакторі, і в грі). Зрозумілий текст замість кодів помилок. */
public final class Toasts {
    private record T(Component text, int color, long born, long until) {}

    private static final Deque<T> ITEMS = new ArrayDeque<>();

    private Toasts() {}

    public static void info(Component c) { push(c, Theme.TEXT); }

    public static void ok(Component c) { push(c, Theme.OK); }

    public static void warn(Component c) { push(c, Theme.WARN); }

    public static void error(Component c) { push(c, Theme.DANGER); }

    private static void push(Component c, int color) {
        // однакові повідомлення не накопичуються
        ITEMS.removeIf(t -> t.text.getString().equals(c.getString()));
        long now = System.currentTimeMillis();
        ITEMS.addLast(new T(c, color, now, now + 4500));
        while (ITEMS.size() > 5) ITEMS.removeFirst();
    }

    /** Виїжджають справа (з легким «відскоком»), кольорова смуга-позначка, тінь; зникають, плавно відпливаючи. */
    public static void render(GuiGraphics g, int screenW, int top) {
        long now = System.currentTimeMillis();
        var font = Minecraft.getInstance().font;
        float y = top;
        for (Iterator<T> it = ITEMS.iterator(); it.hasNext(); ) {
            T t = it.next();
            if (now > t.until) { it.remove(); continue; }
            float in = Fx.outBack(Fx.progress(now, t.born, 320));
            float out = Fx.clamp01((t.until - now) / 400f);
            float a = Math.min(Fx.clamp01(in * 1.4f), out);
            int w = Math.min(280, font.width(t.text) + 40);
            int h = 20;
            int x = screenW - w - 6 + (int) ((1 - in) * (w + 12)) + (int) ((1 - out) * 20);
            int iy = (int) y;
            // пласка плашка в стилі меню: чорний контур, темне тіло, кольоровий корінець і квадратний значок статусу
            g.fill(x - 1, iy - 1, x + w + 1, iy + h + 1, Fx.mulAlpha(MenuSkin.OUTLINE, a));
            g.fill(x, iy, x + w, iy + h, Fx.mulAlpha(MenuSkin.PANE_EDGE, a));
            g.fill(x + 1, iy + 1, x + w - 1, iy + h - 1, Fx.mulAlpha(MenuSkin.PANE, a));
            g.fill(x + 1, iy + 1, x + 4, iy + h - 1, Fx.withAlpha(t.color, a));
            g.fill(x + 7, iy + 4, x + 19, iy + 16, Fx.withAlpha(t.color, 0.25f * a));
            String glyph = t.color == Theme.OK ? "\u2713" : t.color == Theme.WARN || t.color == Theme.DANGER ? "!" : "i";
            g.drawString(font, glyph, x + 13 - font.width(glyph) / 2, iy + 6, Fx.withAlpha(t.color, Math.max(0.08f, a)), false);
            // смужка часу, що лишився
            float life = Fx.clamp01((t.until - now) / (float) (t.until - t.born));
            g.fill(x + 5, iy + h - 3, x + 5 + (int) ((w - 10) * life), iy + h - 2, Fx.withAlpha(t.color, 0.55f * a));
            g.drawString(font, font.plainSubstrByWidth(t.text.getString(), w - 32), x + 25, iy + 6, Fx.withAlpha(0xE8EAF4, Math.max(0.08f, a)), false);
            y += 24 * Math.min(1, out * 2);
        }
    }
}
