package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.mc.ui.Fx;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;

import java.util.ArrayList;
import java.util.List;

/** Контекстне меню (ПКМ по кліпу/ключу/треку): список пунктів поверх усього, клік поза ним — закрити. */
final class Popup {

    record Item(String label, Runnable action, boolean enabled) {}

    private static List<Item> items;
    private static int x, y;
    private static long openedAt;
    private static String title;

    private Popup() {}

    static void open(String t, int px, int py, List<Item> list) {
        openedAt = System.currentTimeMillis();
        title = t;
        items = new ArrayList<>(list);
        x = px;
        y = py;
    }

    static Item item(String label, Runnable r) { return new Item(label, r, true); }

    static Item item(String label, Runnable r, boolean enabled) { return new Item(label, r, enabled); }

    static boolean isOpen() { return items != null; }

    static void close() { items = null; }

    /** Малювати ОСТАННІМ; поки меню відкрите, екран ставить {@code gui.modal = true} — решта віджетів кліків не бачить. */
    static void render(Gui gui, int sw, int sh) {
        if (items == null) return;
        // той самий вигляд, що в контекстних меню Shaurma Modeling: скляне вікно, рядки 14 px, плавна поява рядків
        final int ih = 14;
        int w = 40;
        for (Item i : items) w = Math.max(w, gui.font.width(i.label()) + 20);
        if (title != null) w = Math.max(w, gui.font.width(title) + 20);
        int h = items.size() * ih + (title != null ? 14 : 0) + 8;
        int px = Math.min(x, sw - w - 2), py = Math.min(y, sh - h - 2);
        gui.modalBegin();
        gui.g.pose().pushPose();
        gui.g.pose().translate(0, 0, 400);
        MenuSkin.window(gui.g, px, py, w, h);
        int cy = py + 4;
        if (title != null) {
            gui.text(title, px + 8, cy + 2, Theme.MUTED);
            cy += 14;
        }
        long now = System.currentTimeMillis();
        int idx = 0;
        Item fired = null;
        for (Item i : items) {
            boolean hov = gui.hover(px, cy, w, ih);
            MenuSkin.row(gui.g, px + 1, cy, w - 2, ih, i.enabled() && hov, false);
            float ia = Fx.stagger(now, openedAt, idx++, 14, 160);
            gui.text(i.label(), px + 8 + Math.round((1 - ia) * 8), cy + (ih - 8) / 2,
                Fx.mulAlpha(i.enabled() ? 0xFF000000 | Theme.TEXT : 0xFF5A6A88, Math.max(0.05f, ia)));
            if (i.enabled() && gui.clicked(px, cy, w, ih, 0)) fired = i;
            cy += ih;
        }
        gui.g.pose().popPose();
        gui.modalEnd();
        if (fired != null) { close(); fired.action().run(); return; }
        if (gui.pendingClick() >= 0 && !(gui.pendingClickX() >= px && gui.pendingClickX() < px + w && gui.pendingClickY() >= py && gui.pendingClickY() < py + h)) {
            close();
            gui.consumeClick();
        }
    }
}
