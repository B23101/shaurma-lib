package dev.shaurmalib.scene.mc.client;

import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexSorting;
import com.mojang.math.Axis;
import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.eval.ScenePlayback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

import java.util.HashMap;
import java.util.Map;

/**
 * Зациклена сценка в меню (превʼю кіта, косметики): актори з анімаціями й камерою сцени малюються
 * в прямокутник GUI, без світу і без ліміту часу. Документ береться з сервера (кеш клієнта).
 *
 * <pre>{@code
 * // у render() екрана кіта:
 * SceneGuiPreview.render(g, "maniac:kit_preview", x, y, 160, 220, SceneGuiPreview.viewer("viewer"));
 * }</pre>
 */
public final class SceneGuiPreview {

    private SceneGuiPreview() {}

    private static final class Live {
        ScenePlayback playback;
        SceneClips clips;
        final SceneFrame frame = new SceneFrame();
        long lastNs;
        int revision = -1;
    }

    private static final Map<String, Live> LIVE = new HashMap<>();
    private static final Map<String, Long> REQUESTED = new HashMap<>();

    /** Прив'язки «в усіх слотах — я» (найчастіше для превʼю). */
    public static SceneBindings viewer(String... slots) {
        SceneBindings b = new SceneBindings();
        var p = Minecraft.getInstance().player;
        if (p == null) return b;
        for (String s : slots) b.bind(s, SceneBindings.Binding.player(p.getUUID(), p.getGameProfile().getName()));
        return b;
    }

    /** @return false — документ ще не прийшов (малюйте заглушку) */
    public static boolean render(GuiGraphics g, String sceneId, int x, int y, int w, int h, SceneBindings bindings) {
        SceneDoc doc = SceneClient.doc(sceneId);
        if (doc == null) {
            long now = System.currentTimeMillis();
            if (now - REQUESTED.getOrDefault(sceneId, 0L) > 5000) { REQUESTED.put(sceneId, now); SceneClient.requestDoc(sceneId); }
            return false;
        }
        Live l = LIVE.computeIfAbsent(sceneId, k -> new Live());
        if (l.playback == null || l.revision != doc.revision) {
            l.playback = new ScenePlayback(-1000 - sceneId.hashCode(), doc, doc.variant(null), bindings, 0, 0, false);
            l.clips = new SceneClips(doc);
            l.playback.evaluator().clips(l.clips);
            l.revision = doc.revision;
            SceneAssets.ensure(doc);
        }
        long now = System.nanoTime();
        double dt = l.lastNs == 0 ? 0 : Math.min(0.1, (now - l.lastNs) / 1e9);
        l.lastNs = now;
        l.playback.advance(dt);
        if (l.playback.ended()) l.playback.seek(0);
        l.playback.evaluator().eval(l.playback.time(), l.frame);
        draw(g, l, doc, x, y, w, h);
        return true;
    }

    private static void draw(GuiGraphics g, Live l, SceneDoc doc, int x, int y, int w, int h) {
        SceneFrame f = l.frame;
        if (!f.hasCamera) return;
        Minecraft mc = Minecraft.getInstance();
        g.flush();
        double scale = mc.getWindow().getGuiScale();
        int fx = (int) (x * scale), fw = (int) (w * scale), fh = (int) (h * scale);
        int fy = mc.getWindow().getHeight() - (int) ((y + h) * scale);
        RenderSystem.viewport(fx, fy, fw, fh);
        Matrix4f oldProj = RenderSystem.getProjectionMatrix();
        VertexSorting oldSort = RenderSystem.getVertexSorting();
        RenderSystem.setProjectionMatrix(new Matrix4f().perspective((float) Math.toRadians(f.camera.fov), w / (float) h, 0.05f, 256f), VertexSorting.DISTANCE_TO_ORIGIN);
        RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
        var mv = RenderSystem.getModelViewStack();
        mv.pushPose();
        mv.setIdentity();
        RenderSystem.applyModelViewMatrix();
        PoseStack ps = new PoseStack();
        ps.mulPose(Axis.ZP.rotationDegrees(f.camera.roll));
        ps.mulPose(Axis.XP.rotationDegrees(f.camera.pitch));
        ps.mulPose(Axis.YP.rotationDegrees(f.camera.yaw + 180f));
        Lighting.setupLevel(ps.last().pose());
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        for (SceneFrame.Actor a : f.actors) {
            if (!a.visible) continue;
            ps.pushPose();
            ps.translate(a.x - f.camera.x, a.y - f.camera.y, a.z - f.camera.z);
            SceneRender.actor(ps, buffers, a, l.clips, doc, LightTexture.FULL_BRIGHT, 1f);
            ps.popPose();
        }
        buffers.endBatch();
        mv.popPose();
        RenderSystem.applyModelViewMatrix();
        RenderSystem.setProjectionMatrix(oldProj, oldSort);
        RenderSystem.viewport(0, 0, mc.getWindow().getWidth(), mc.getWindow().getHeight());
        Lighting.setupFor3DItems();
        g.pose().pushPose();
        g.enableScissor(x, y, x + w, y + h);
        g.pose().translate(x, y, 0);
        SceneHud.layers(g, w, h, f);
        g.disableScissor();
        g.pose().popPose();
    }

    /** Звільнити (екран закрито). */
    public static void forget(String sceneId) { LIVE.remove(sceneId); }
}
