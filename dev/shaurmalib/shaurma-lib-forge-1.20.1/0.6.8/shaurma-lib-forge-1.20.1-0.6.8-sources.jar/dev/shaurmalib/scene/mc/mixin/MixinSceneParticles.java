package dev.shaurmalib.scene.mc.mixin;

import dev.shaurmalib.scene.mc.client.SceneWorldFilter;
import net.minecraft.client.particle.ParticleEngine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** «Лише світ»: партікли не малюються (усі перевантаження render, і ванільне, і Forge з Frustum). */
@Mixin(ParticleEngine.class)
public abstract class MixinSceneParticles {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void shaurma$scene$noParticles(CallbackInfo ci) {
        if (SceneWorldFilter.hideParticles()) ci.cancel();
    }
}
