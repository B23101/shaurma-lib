package dev.shaurmalib.scene.mc.client;

import dev.shaurmalib.scene.eval.SceneFrame;

/**
 * Хто зараз веде камеру гри: редактор (вільна камера / вид з камери сцени) або сесія сцени.
 * Міксини {@code Camera.setup}, {@code GameRenderer.getFov/bobHurt/renderItemInHand} лише питають тут.
 */
public final class SceneCamera {

    private SceneCamera() {}

    /** Камера редактора (ставить екран редактора); null — редактор не веде камеру. */
    public interface EditorCam {
        SceneFrame.Cam camera(float partial);
        boolean hideHand();
    }

    public static volatile EditorCam editor;
    private static float roll;
    private static float fov = -1;
    private static boolean controlling;

    /** @return поза камери на цей кадр або null — не чіпати ванільну */
    public static SceneFrame.Cam pose(float partial) {
        roll = 0;
        fov = -1;
        controlling = false;
        EditorCam e = editor;
        SceneFrame.Cam c = null;
        if (e != null) c = e.camera(partial);
        if (c == null) {
            SceneClient.Active a = SceneClient.cinematic();
            if (a != null && a.frame.hasCamera) c = a.frame.camera;
        }
        if (c == null) return null;
        controlling = true;
        roll = c.roll;
        fov = c.fov;
        return c;
    }

    public static float roll() { return roll; }

    /** FOV сцени або -1 (ванільний). */
    public static float fov() { return fov; }

    public static boolean controlling() { return controlling; }

    /** Сховати руку: сцена в кадрі або редактор. */
    public static boolean hideHand() {
        EditorCam e = editor;
        if (e != null && e.hideHand()) return true;
        return SceneClient.cinematicActive();
    }

    /** Сховати HUD гри (кінематографічна сесія). */
    public static boolean hideHud() { return SceneClient.cinematicActive() && editor == null; }
}
