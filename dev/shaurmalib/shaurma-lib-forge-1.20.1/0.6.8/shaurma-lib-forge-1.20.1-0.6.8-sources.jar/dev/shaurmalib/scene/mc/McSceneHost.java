package dev.shaurmalib.scene.mc;

import com.mojang.authlib.properties.Property;
import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.server.SceneHost;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import net.minecraft.network.protocol.game.ClientboundSetChunkCacheCenterPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.LevelResource;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Реалізація {@link SceneHost} для ванілі 1.20.1.
 *
 * <h3>Камера окремо від тіла</h3>
 * Ваніль шле клієнту чанки лише навколо гравця, але ТІЛО гравця тут не чіпається: ні перенесення, ні
 * спостерігач, ні невразливість — інші гравці й сервер бачать його там, де воно стоїть. Замість цього
 * хост стрімить клієнту світ навколо КАМЕРИ: переносить центр кешу чанків клієнта
 * ({@code ClientboundSetChunkCacheCenterPacket}), тримає чанки камери (з випередженням) тікетами й
 * шле їх пакетами чанків із бюджетом на тік. На виході клієнту повертається центр і його власні чанки.
 * Обмеження: потоком іде вимір гравця (камера в іншому вимірі не підтримується). Додатково точки акторів
 * і камер тримаються тікетами ({@link #holdChunks}).
 */
public final class McSceneHost implements SceneHost {

    private static final TicketType<ChunkPos> TICKET = TicketType.create("shaurma_scene", Comparator.comparingLong(ChunkPos::toLong));
    private static final TicketType<ChunkPos> VIEW_TICKET =
        TicketType.create("shaurma_scene_view", Comparator.comparingLong(ChunkPos::toLong), 60);
    /** Радіус потоку чанків навколо камери й бюджет відправки за тік. */
    private static final int RADIUS = 8;
    private static final int PER_TICK = 40;
    private static final int MAX_TICKETS = 96;

    private final MinecraftServer server;
    private final Map<UUID, View> saved = new HashMap<>();
    private final Map<Long, List<Held>> held = new HashMap<>();

    private record Held(ServerLevel level, ChunkPos pos) {}

    /** Що вже відправлено клієнту навколо камери. */
    private static final class View {
        final ServerLevel level;
        final Set<Long> sent = new HashSet<>();
        int centerX = Integer.MIN_VALUE, centerZ = Integer.MIN_VALUE;
        long home = Long.MIN_VALUE;
        int tick;

        View(ServerLevel level) { this.level = level; }
    }

    public McSceneHost(MinecraftServer server) { this.server = server; }

    @Override public Path sceneRoot() { return server.getWorldPath(LevelResource.ROOT).resolve("scene_editor"); }

    private ServerPlayer player(UUID id) { return server.getPlayerList().getPlayer(id); }

    @Override public boolean canEdit(UUID id) {
        ServerPlayer p = player(id);
        return p != null && (p.hasPermissions(2) || server.isSingleplayerOwner(p.getGameProfile()));
    }

    @Override public boolean online(UUID id) { return player(id) != null; }

    @Override public String name(UUID id) {
        ServerPlayer p = player(id);
        return p == null ? id.toString().substring(0, 8) : p.getGameProfile().getName();
    }

    @Override public SceneBindings.Binding binding(UUID id) {
        ServerPlayer p = player(id);
        if (p == null) return null;
        return of(p);
    }

    /** Прив'язка «гравець як є»: UUID, нік, текстура скіна з профілю, позиція. Для режимів — {@code McScene.bind(player)}. */
    public static SceneBindings.Binding of(ServerPlayer p) {
        SceneBindings.Binding b = SceneBindings.Binding.player(p.getUUID(), p.getGameProfile().getName()).at(p.getX(), p.getY(), p.getZ());
        for (Property prop : p.getGameProfile().getProperties().get("textures")) { b.skin(prop.getValue(), prop.getSignature()); break; }
        return b;
    }

    private ServerLevel level(String dim, ServerLevel fallback) {
        if (dim == null) return fallback;
        ResourceLocation rl = ResourceLocation.tryParse(dim);
        ServerLevel l = rl == null ? null : server.getLevel(ResourceKey.create(Registries.DIMENSION, rl));
        return l == null ? fallback : l;
    }

    @Override public void beginView(UUID id, String dimension, SceneFrame.Cam cam, boolean cinematic) {
        ServerPlayer p = player(id);
        if (p == null) return;
        View v = new View(p.serverLevel());
        saved.put(id, v);
        stream(p, v, cam, cam);
    }

    @Override public void updateView(UUID id, SceneFrame.Cam cam, SceneFrame.Cam ahead) {
        ServerPlayer p = player(id);
        View v = saved.get(id);
        if (p == null || v == null) return;
        if (p.serverLevel() != v.level) { saved.remove(id); return; }   // гравець змінив вимір — потік скасовано
        stream(p, v, cam, ahead != null ? ahead : cam);
    }

    private void stream(ServerPlayer p, View v, SceneFrame.Cam cam, SceneFrame.Cam ahead) {
        ChunkPos c0 = new ChunkPos(Mth.floor(cam.x) >> 4, Mth.floor(cam.z) >> 4);
        ChunkPos c1 = new ChunkPos(Mth.floor(ahead.x) >> 4, Mth.floor(ahead.z) >> 4);
        v.tick++;
        if (v.tick % 20 == 1) {
            v.level.getChunkSource().addRegionTicket(VIEW_TICKET, c0, RADIUS, c0);
            if (!c1.equals(c0)) v.level.getChunkSource().addRegionTicket(VIEW_TICKET, c1, RADIUS, c1);
        }
        // ваніль сама переносить центр клієнта, коли гравець перейшов в інший чанк — повертаємо свій
        long home = p.chunkPosition().toLong();
        boolean homeMoved = home != v.home;
        v.home = home;
        if (c0.x != v.centerX || c0.z != v.centerZ || homeMoved || v.tick % 40 == 0) {
            v.centerX = c0.x;
            v.centerZ = c0.z;
            p.connection.send(new ClientboundSetChunkCacheCenterPacket(c0.x, c0.z));
            // клієнт сам відкидає чанки поза новим центром — забуваємо їх і в нас
            v.sent.removeIf(l -> Math.abs(ChunkPos.getX(l) - c0.x) > RADIUS || Math.abs(ChunkPos.getZ(l) - c0.z) > RADIUS);
        }
        int budget = PER_TICK;
        for (int r = 0; r <= RADIUS && budget > 0; r++) {
            for (int dx = -r; dx <= r && budget > 0; dx++) {
                for (int dz = -r; dz <= r && budget > 0; dz++) {
                    if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                    int cx = c0.x + dx, cz = c0.z + dz;
                    long key = ChunkPos.asLong(cx, cz);
                    if (v.sent.contains(key)) continue;
                    LevelChunk c = v.level.getChunkSource().getChunkNow(cx, cz);
                    if (c == null) continue;   // ще вантажиться (тікет) — наступного тіка
                    p.connection.send(new ClientboundLevelChunkWithLightPacket(c, v.level.getLightEngine(), null, null));
                    v.sent.add(key);
                    budget--;
                }
            }
        }
    }

    @Override public void endView(UUID id) {
        View v = saved.remove(id);
        ServerPlayer p = player(id);
        if (v == null || p == null) return;
        restore(p, v);
    }

    /** Повернути клієнту центр і власні чанки навколо гравця. */
    private void restore(ServerPlayer p, View v) {
        if (p.serverLevel() != v.level) return;
        ChunkPos home = p.chunkPosition();
        p.connection.send(new ClientboundSetChunkCacheCenterPacket(home.x, home.z));
        int vd = Math.min(server.getPlayerList().getViewDistance(), 16);
        for (int dx = -vd; dx <= vd; dx++) {
            for (int dz = -vd; dz <= vd; dz++) {
                LevelChunk c = v.level.getChunkSource().getChunkNow(home.x + dx, home.z + dz);
                if (c != null) p.connection.send(new ClientboundLevelChunkWithLightPacket(c, v.level.getLightEngine(), null, null));
            }
        }
    }

    /** Вихід з гри посеред сцени: клієнтові вже нічого не слати. */
    public void onLogout(ServerPlayer p) {
        saved.remove(p.getUUID());
    }

    public boolean viewing(UUID id) { return saved.containsKey(id); }

    @Override public void holdChunks(long session, String dimension, double[][] points) {
        ServerLevel l = level(dimension, server.overworld());
        List<Held> list = new ArrayList<>();
        java.util.Set<Long> seen = new java.util.HashSet<>();
        for (double[] p : points) {
            ChunkPos cp = new ChunkPos(Mth.floor(p[0]) >> 4, Mth.floor(p[2]) >> 4);
            if (!seen.add(cp.toLong()) || list.size() >= MAX_TICKETS) continue;
            l.getChunkSource().addRegionTicket(TICKET, cp, 2, cp);
            list.add(new Held(l, cp));
        }
        held.put(session, list);
    }

    @Override public void releaseChunks(long session) {
        List<Held> list = held.remove(session);
        if (list == null) return;
        for (Held h : list) h.level.getChunkSource().removeRegionTicket(TICKET, h.pos, 2, h.pos);
    }

    @Override public long gameTime() { return server.overworld().getGameTime(); }

    public void shutdown() {
        for (Map.Entry<UUID, View> e : new ArrayList<>(saved.entrySet())) {
            ServerPlayer p = player(e.getKey());
            if (p != null) restore(p, e.getValue());
        }
        saved.clear();
        for (Long id : new ArrayList<>(held.keySet())) releaseChunks(id);
    }
}
