package dev.shaurmalib.scene.mc;

import com.mojang.authlib.properties.Property;
import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.server.SceneHost;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.TicketType;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.LevelResource;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Реалізація {@link SceneHost} для ванілі 1.20.1.
 *
 * <h3>Камера як гравець</h3>
 * Ваніль шле клієнту чанки й сутності ЛИШЕ навколо позиції гравця. Тому на час сцени тіло глядача
 * стає «якорем»: режим спостерігача (невидимий, без колізій і шкоди), перенесення у вимір сцени й
 * на висоту {@code maxBuildHeight + 16} над X/Z камери. Стеження чанків і сутностей (відстань по
 * горизонталі) тоді йде навколо КАМЕРИ, навіть якщо гравець на іншому кінці світу чи в іншому вимірі.
 * Якір переїжджає лише коли камера (з випередженням 0.6 с) переходить в інший чанк. На виході —
 * вимір, позиція, кути й режим гри повертаються. Додатково точки акторів і камер тримаються
 * тікетами (чанки готові до приїзду камери).
 */
public final class McSceneHost implements SceneHost {

    private static final TicketType<ChunkPos> TICKET = TicketType.create("shaurma_scene", Comparator.comparingLong(ChunkPos::toLong));
    private static final int ABOVE = 16;
    private static final int MAX_TICKETS = 96;

    private final MinecraftServer server;
    private final Map<UUID, Saved> saved = new HashMap<>();
    private final Map<Long, List<Held>> held = new HashMap<>();

    private record Held(ServerLevel level, ChunkPos pos) {}

    private static final class Saved {
        ResourceKey<Level> dim;
        double x, y, z;
        float yaw, pitch;
        GameType mode;
        boolean invulnerable;
        ServerLevel sceneLevel;
        long anchorChunk = Long.MIN_VALUE;
    }

    public McSceneHost(MinecraftServer server) { this.server = server; }

    @Override public Path sceneRoot() { return server.getWorldPath(LevelResource.ROOT).resolve("scene_editor"); }

    private ServerPlayer player(UUID id) { return server.getPlayerList().getPlayer(id); }

    @Override public boolean canEdit(UUID id) {
        ServerPlayer p = player(id);
        return p != null && (p.hasPermissions(2) || server.isSingleplayerOwner(p.getGameProfile()));
    }

    @Override public boolean online(UUID id) { return player(id) != null; }

    @Override public String name(UUID id) {
        ServerPlayer p = player(id);
        return p == null ? id.toString().substring(0, 8) : p.getGameProfile().getName();
    }

    @Override public SceneBindings.Binding binding(UUID id) {
        ServerPlayer p = player(id);
        if (p == null) return null;
        return of(p);
    }

    /** Прив'язка «гравець як є»: UUID, нік, текстура скіна з профілю, позиція. Для режимів — {@code McScene.bind(player)}. */
    public static SceneBindings.Binding of(ServerPlayer p) {
        SceneBindings.Binding b = SceneBindings.Binding.player(p.getUUID(), p.getGameProfile().getName()).at(p.getX(), p.getY(), p.getZ());
        for (Property prop : p.getGameProfile().getProperties().get("textures")) { b.skin(prop.getValue(), prop.getSignature()); break; }
        return b;
    }

    private ServerLevel level(String dim, ServerLevel fallback) {
        if (dim == null) return fallback;
        ResourceLocation rl = ResourceLocation.tryParse(dim);
        ServerLevel l = rl == null ? null : server.getLevel(ResourceKey.create(Registries.DIMENSION, rl));
        return l == null ? fallback : l;
    }

    @Override public void beginView(UUID id, String dimension, SceneFrame.Cam cam, boolean cinematic) {
        ServerPlayer p = player(id);
        if (p == null) return;
        Saved s = saved.get(id);
        if (s == null) {
            s = new Saved();
            s.dim = p.level().dimension();
            s.x = p.getX(); s.y = p.getY(); s.z = p.getZ();
            s.yaw = p.getYRot(); s.pitch = p.getXRot();
            s.mode = p.gameMode.getGameModeForPlayer();
            s.invulnerable = p.isInvulnerable();
            saved.put(id, s);
        }
        s.sceneLevel = level(dimension, p.serverLevel());
        p.setInvulnerable(true);
        if (p.gameMode.getGameModeForPlayer() != GameType.SPECTATOR) p.setGameMode(GameType.SPECTATOR);
        s.anchorChunk = Long.MIN_VALUE;
        move(p, s, cam);
    }

    @Override public void updateView(UUID id, SceneFrame.Cam cam, SceneFrame.Cam ahead) {
        ServerPlayer p = player(id);
        Saved s = saved.get(id);
        if (p == null || s == null) return;
        if (p.gameMode.getGameModeForPlayer() != GameType.SPECTATOR) p.setGameMode(GameType.SPECTATOR);
        move(p, s, ahead != null ? ahead : cam);
    }

    private void move(ServerPlayer p, Saved s, SceneFrame.Cam cam) {
        long chunk = ChunkPos.asLong(Mth.floor(cam.x) >> 4, Mth.floor(cam.z) >> 4);
        if (chunk == s.anchorChunk && p.level() == s.sceneLevel) return;
        s.anchorChunk = chunk;
        double y = s.sceneLevel.getMaxBuildHeight() + ABOVE;
        p.teleportTo(s.sceneLevel, cam.x, y, cam.z, cam.yaw, cam.pitch);
    }

    @Override public void endView(UUID id) {
        Saved s = saved.remove(id);
        ServerPlayer p = player(id);
        if (s == null || p == null) return;
        restore(p, s);
    }

    private void restore(ServerPlayer p, Saved s) {
        ServerLevel back = server.getLevel(s.dim);
        if (back == null) back = server.overworld();
        p.teleportTo(back, s.x, s.y, s.z, s.yaw, s.pitch);
        if (s.mode != null && p.gameMode.getGameModeForPlayer() != s.mode) p.setGameMode(s.mode);
        p.setInvulnerable(s.invulnerable);
    }

    /** Вихід з гри посеред сцени: повернути ДО збереження гравця. */
    public void onLogout(ServerPlayer p) {
        Saved s = saved.remove(p.getUUID());
        if (s != null) restore(p, s);
    }

    public boolean viewing(UUID id) { return saved.containsKey(id); }

    @Override public void holdChunks(long session, String dimension, double[][] points) {
        ServerLevel l = level(dimension, server.overworld());
        List<Held> list = new ArrayList<>();
        java.util.Set<Long> seen = new java.util.HashSet<>();
        for (double[] p : points) {
            ChunkPos cp = new ChunkPos(Mth.floor(p[0]) >> 4, Mth.floor(p[2]) >> 4);
            if (!seen.add(cp.toLong()) || list.size() >= MAX_TICKETS) continue;
            l.getChunkSource().addRegionTicket(TICKET, cp, 2, cp);
            list.add(new Held(l, cp));
        }
        held.put(session, list);
    }

    @Override public void releaseChunks(long session) {
        List<Held> list = held.remove(session);
        if (list == null) return;
        for (Held h : list) h.level.getChunkSource().removeRegionTicket(TICKET, h.pos, 2, h.pos);
    }

    @Override public long gameTime() { return server.overworld().getGameTime(); }

    public void shutdown() {
        for (Map.Entry<UUID, Saved> e : new ArrayList<>(saved.entrySet())) {
            ServerPlayer p = player(e.getKey());
            if (p != null) restore(p, e.getValue());
        }
        saved.clear();
        for (Long id : new ArrayList<>(held.keySet())) releaseChunks(id);
    }
}
