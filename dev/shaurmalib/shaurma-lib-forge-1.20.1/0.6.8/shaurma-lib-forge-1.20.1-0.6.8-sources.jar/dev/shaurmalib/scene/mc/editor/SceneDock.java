package dev.shaurmalib.scene.mc.editor;

import com.mojang.math.Axis;
import dev.shaurmalib.scene.mc.ui.Fx;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.Icons;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.network.chat.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Смуга модульних панелей — та сама, що в Shaurma Modeling ({@code Dock}): заголовок 16 px зі стрілкою
 * згортання (плавно повертається), значком і назвою; подвійний клік по заголовку — згорнути; роздільник 3 px.
 * Згорнуті панелі віддають висоту розгорнутим.
 */
final class SceneDock {

    static final int HEADER = 16, DIV = 3;

    interface Content { void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h); }

    record Panel(String id, String title, Icon icon, double weight, Content content) {}

    private static final Set<String> COLLAPSED = new HashSet<>();

    private SceneDock() {}

    static void expand(String id) { COLLAPSED.remove(id); }

    static void render(SceneEditorScreen s, Gui gui, List<Panel> panels, boolean left, int x, int y, int w, int h) {
        gui.g.fill(x, y, x + w, y + h, Theme.PANEL);
        double total = 0;
        for (Panel p : panels) if (!COLLAPSED.contains(p.id())) total += p.weight();
        int avail = h - panels.size() * (HEADER + DIV);
        int cy = y;
        for (Panel p : panels) {
            boolean collapsed = COLLAPSED.contains(p.id());
            header(gui, p, x, cy, w, collapsed);
            cy += HEADER;
            int target = collapsed || total <= 0 ? 0 : Math.max(26, (int) Math.round(avail * p.weight() / total));
            int ch = Math.min(Math.round(gui.anim("sdock." + p.id(), target, 15)), y + h - cy);
            if (ch > 4) {
                gui.g.enableScissor(x, cy, x + w, cy + ch);
                gui.pushClip(x, cy, w, ch);
                try { p.content().render(s, gui, x, cy, w, ch); }
                finally { gui.popClip(); gui.g.disableScissor(); }
            }
            cy += Math.max(0, ch);
            gui.g.fill(x, cy, x + w, cy + DIV, MenuSkin.OUTLINE);
            gui.g.fill(x, cy + 1, x + w, cy + 2, MenuSkin.PANE_EDGE);
            cy += DIV;
        }
        // рамка смуги з боку в'юпорта
        gui.g.fill(left ? x + w - 1 : x, y, left ? x + w : x + 1, y + h, MenuSkin.EDGE);
    }

    private static void header(Gui gui, Panel p, int x, int y, int w, boolean collapsed) {
        boolean hov = gui.hover(x, y, w, HEADER);
        float hv = gui.anim("sdock.hv." + p.id(), hov ? 1 : 0, 18);
        gui.g.fill(x, y, x + w, y + HEADER, Fx.lerp(Theme.HEADER, Theme.PANEL_HI, hv));
        gui.g.fill(x, y, x + w, y + 1, MenuSkin.PANE_EDGE);
        gui.g.fill(x, y + HEADER - 1, x + w, y + HEADER, MenuSkin.OUTLINE);
        int cxi = x + 3, cyi = y + (HEADER - 1 - 12) / 2;
        boolean hc = gui.hover(cxi, cyi, 12, 12);
        float open = gui.anim("sdock.chev." + p.id(), collapsed ? 0 : 1, 18);
        if (hc) { gui.cursor(Gui.CUR_HAND); gui.tip(Component.literal(collapsed ? "Розгорнути" : "Згорнути")); }
        gui.g.pose().pushPose();
        gui.g.pose().translate(cxi + 6, cyi + 6, 0);
        gui.g.pose().mulPose(Axis.ZP.rotationDegrees((open - 1) * 90f));
        gui.g.pose().translate(-6, -6, 0);
        Icons.draw(gui.g, Icon.CHEVRON_DOWN, 0, 0, 12, Fx.lerp(0xFF9DB1D6, 0xFFFFFFFF, hc ? 1 : 0));
        gui.g.pose().popPose();
        int mid = y + (HEADER - 1 - 10) / 2;
        Icons.draw(gui.g, p.icon(), x + 17, mid, 10, Fx.lerp(0xFF8C92AD, 0xFFFFFFFF, hv));
        gui.textClip(p.title(), x + 31, y + (HEADER - 1 - 8) / 2, Math.max(10, w - 36), MenuSkin.TITLE);
        if (gui.clicked(cxi, cyi, 12, 12, 0) || gui.doubleClicked(x + 14, y, w - 14, HEADER)) {
            if (!COLLAPSED.remove(p.id())) COLLAPSED.add(p.id());
            gui.consumeClick();
        }
    }
}
