package dev.shaurmalib.scene.mc.client;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.shaurmalib.scene.mc.editor.EditorOverlay;
import dev.shaurmalib.scene.mc.editor.EditorView;
import dev.shaurmalib.scene.mc.editor.SceneEditorScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Клієнтський клей рушія сцен (без лоадера): лоадер кличе ці методи зі своїх подій. */
public final class McSceneClient {

    private McSceneClient() {}

    /** Початок кадру гри (до Camera.setup). */
    public static void renderTick() {
        dev.shaurmalib.scene.mc.editor.SceneEditorScreen.recordFrame();
        SceneClient.renderTick();
        boolean paused = Minecraft.getInstance().isPaused();
        for (SceneClient.Active a : SceneClient.active()) {
            SceneSound.update(a.playback.id(), a.playback.doc(), a.frame, !paused && !a.playback.inPreroll() && !a.playback.ended());
        }
    }

    /** Кадр світу після сутностей. */
    public static void onWorld(PoseStack ps, MultiBufferSource buffers, Vec3 cam, float partial, Matrix4f projection) {
        EditorView.captureMatrices(ps.last().pose(), projection, cam);
        SceneRender.renderWorld(ps, buffers, cam, partial);
        EditorOverlay.world(ps, buffers, cam);
    }

    /** Перед HUD (чистий кадр світу — знімок для crossfade). */
    public static void beforeHud() { SceneHud.beforeHud(); }

    /** Після HUD. */
    /** Клієнтський тік (кінець): запис руху актора. */
    public static void clientTick() { dev.shaurmalib.scene.mc.editor.SceneEditorScreen.recordTick(); }

    public static void onHud(GuiGraphics g, float partial) {
        dev.shaurmalib.scene.mc.editor.SceneEditorScreen.recordHud(g);
        if (Minecraft.getInstance().screen instanceof SceneEditorScreen) return;
        SceneHud.render(g, partial);
    }

    /** Ховати ванільний HUD (кінематографічна сцена). */
    public static boolean hideHud() { return SceneCamera.hideHud(); }

    /** Блокувати рух гравця (кінематографічна сцена; тіло — якір камери). */
    public static boolean lockInput() { return SceneClient.cinematicActive(); }

    public static void openEditor() { SceneEditorHook.openPicker(); }

    public static void onDisconnect() { SceneClient.onDisconnect(); }
}
