package dev.shaurmalib.scene.mc.client;

import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.eval.ScenePlayback;
import dev.shaurmalib.scene.io.SceneCodec;
import dev.shaurmalib.scene.net.SceneMessage;
import dev.shaurmalib.scene.net.SceneNetwork;
import net.minecraft.client.Minecraft;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Клієнтський стан сцен: отримані документи, активні сесії (свій годинник + корекція з сервера),
 * поточний кадр для камери/HUD/світу, каталог для редактора. Один кадр рахується ОДИН раз за кадр гри
 * ({@link #renderTick}) і читається всіма споживачами.
 */
public final class SceneClient {

    private SceneClient() {}

    public static final class Active {
        public final ScenePlayback playback;
        public final SceneClips clips;
        public final SceneFrame frame = new SceneFrame();
        public final boolean cinematic, preview, local;

        Active(ScenePlayback p, boolean cinematic, boolean preview, boolean local) {
            this.playback = p;
            this.clips = new SceneClips(p.doc());
            p.evaluator().clips(clips);
            this.cinematic = cinematic;
            this.preview = preview;
            this.local = local;
        }
    }

    private static final Map<String, SceneDoc> DOCS = new HashMap<>();
    private static final Map<Long, Active> PLAYING = new LinkedHashMap<>();
    private static final SceneMessage.Assembler DOC_ASM = new SceneMessage.Assembler(8L << 20);
    private static final List<String> CATALOG = new ArrayList<>();
    private static long lastNs;
    private static long localIds = -1;

    /** Редактор: власний кадр (превʼю) замість сесій. */
    public static SceneFrame editorFrame;
    public static SceneClips editorClips;
    /** Слухачі редактора. */
    public static Consumer<SceneMessage> editorListener;
    public static Consumer<List<String>> catalogListener;

    public static SceneDoc doc(String id) { return DOCS.get(id); }

    /** Редактор зберіг ревізію — оновити кеш копією (сесії грають саме її). */
    public static void putDoc(SceneDoc d) {
        SceneDoc copy = SceneCodec.read(SceneCodec.write(d, false));
        copy.id = d.id;
        copy.revision = d.revision;
        DOCS.put(copy.id, copy);
    }

    public static List<String> catalog() { return CATALOG; }

    public static void requestCatalog() { SceneNetwork.Holder.get().toServer(SceneMessage.of(SceneMessage.Op.LIST)); }

    public static void requestEdit(String sceneId) { SceneNetwork.Holder.get().toServer(SceneMessage.of(SceneMessage.Op.EDIT).scene(sceneId)); }

    /** Документ сцени з сервера (для превʼю в меню, напр. кіта). */
    public static void requestDoc(String sceneId) { SceneNetwork.Holder.get().toServer(SceneMessage.of(SceneMessage.Op.REQ_DOC).scene(sceneId)); }

    // ═════════════════════════ мережа ═════════════════════════

    public static void handle(SceneMessage m) {
        switch (m.op) {
            case CATALOG -> {
                CATALOG.clear();
                CATALOG.addAll(m.list);
                if (catalogListener != null) catalogListener.accept(CATALOG);
            }
            case DOC -> {
                byte[] gz = DOC_ASM.accept(m.scene + "#" + m.revision, m);
                if (gz == null) return;
                try {
                    SceneDoc d = SceneCodec.read(new String(SceneMessage.gunzip(gz, 16 << 20), StandardCharsets.UTF_8));
                    d.id = m.scene;
                    d.revision = m.revision;
                    DOCS.put(d.id, d);
                    SceneAssets.ensure(d);
                } catch (IOException | RuntimeException e) {
                    System.err.println("[shaurma_scene] документ " + m.scene + ": " + e);
                }
            }
            case ASSET -> SceneAssets.accept(m);
            case PLAY -> {
                SceneDoc d = DOCS.get(m.scene);
                if (d == null) { requestDoc(m.scene); return; }
                SceneDoc.Variant v = d.variant(m.variant);
                ScenePlayback p = new ScenePlayback(m.session, d, v, m.bindings, m.time, m.preroll, false);
                PLAYING.put(m.session, new Active(p, (m.flags & 1) != 0, (m.flags & 2) != 0, false));
                lastNs = 0;
            }
            case STOP -> stop(m.session);
            case SYNC -> {
                Active a = PLAYING.get(m.session);
                if (a != null && m.preroll <= 0 && Math.abs(a.playback.time() - m.time) > 0.25) a.playback.seek(m.time);
            }
            case EDIT_OPEN, RESULT -> { if (editorListener != null) editorListener.accept(m); else if (m.op == SceneMessage.Op.EDIT_OPEN) SceneEditorHook.open(m); else if (m.a != null && m.flags != 0) SceneEditorHook.toast(m.a); }
            default -> { }
        }
    }

    // ═════════════════════════ програвання ═════════════════════════

    /** Локальна сцена без сервера (превʼю в меню, тест у редакторі). @return id для {@link #stop} */
    public static long playLocal(SceneDoc doc, String variant, SceneBindings bindings, boolean cinematic) {
        long id = localIds--;
        ScenePlayback p = new ScenePlayback(id, doc, doc.variant(variant), bindings, 0, 0, false);
        PLAYING.put(id, new Active(p, cinematic, true, true));
        SceneAssets.ensure(doc);
        return id;
    }

    public static void stop(long session) {
        Active a = PLAYING.remove(session);
        if (a != null) {
            a.playback.stop();
            SceneSound.stopSession(session);
        }
    }

    public static void stopAll() {
        for (Long id : new ArrayList<>(PLAYING.keySet())) stop(id);
    }

    public static Active find(long session) { return PLAYING.get(session); }

    /** Початок кадру гри: просунути годинники й порахувати кадри сесій. */
    public static void renderTick() {
        long now = System.nanoTime();
        double dt = lastNs == 0 ? 0 : Math.min(0.1, (now - lastNs) / 1e9);
        lastNs = now;
        if (PLAYING.isEmpty()) return;
        boolean paused = Minecraft.getInstance().isPaused();
        for (Active a : new ArrayList<>(PLAYING.values())) {
            if (!paused) a.playback.advance(dt);
            if (a.playback.ended()) {
                // серверна сесія чекає STOP (там повернення камери), локальна закінчується сама
                if (a.local || a.playback.variantDoc().loop) { stop(a.playback.id()); continue; }
            }
            a.playback.evaluator().eval(a.playback.time(), a.frame);
            if (a.playback.inPreroll()) a.frame.fade = 1;
        }
    }

    /** Сесія, що зараз веде камеру (остання кінематографічна). */
    public static Active cinematic() {
        Active best = null;
        for (Active a : PLAYING.values()) if (a.cinematic) best = a;
        return best;
    }

    public static boolean cinematicActive() { return cinematic() != null; }

    public static Iterable<Active> active() { return PLAYING.values(); }

    public static boolean anyPlaying() { return !PLAYING.isEmpty(); }

    public static void onDisconnect() {
        stopAll();
        DOCS.clear();
        CATALOG.clear();
        editorFrame = null;
        SceneAssets.clearSession();
        SceneSound.stopAll();
    }
}
