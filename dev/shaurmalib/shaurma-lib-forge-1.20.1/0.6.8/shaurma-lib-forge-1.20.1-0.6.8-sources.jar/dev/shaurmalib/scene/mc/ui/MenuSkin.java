package dev.shaurmalib.scene.mc.ui;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Інтерфейс у стилі Buildprint, але в синій гамі мода. Три «шари», як у Buildprint:
 * <ol>
 *   <li>{@link #window} — зовнішня синя рамка вікна (напівпрозора, крізь неї видно світ);</li>
 *   <li>{@link #pane} — темна врізана панель із чорним контуром (бічна колонка, список);</li>
 *   <li>{@link #button}/{@link #field}/{@link #row} — елементи всередині: чорний контур 1 px, тонка світліша рамка,
 *       тіло, і темна «тінь» знизу/справа, щоб кнопка виглядала об'ємною.</li>
 * </ol>
 * Без заокруглень, градієнтів і світіння. Усі розміри — цілі GUI-пікселі, щоб усе лягало на сітку.
 */
public final class MenuSkin {
    // ── зовнішнє вікно ──
    public static final int OUTLINE = 0xFF000000;
    /** Світла синя рамка вікна (як блакитна обвідка Buildprint, але насиченіша). */
    public static final int FRAME = 0xE62F4F8F;
    public static final int FRAME_HI = 0xFF6F95D8;
    public static final int FRAME_LO = 0xFF1B2F5C;
    public static final int WINDOW = 0xF2121A2E;
    public static final int EDGE = 0xFF4A6BA8;
    public static final int RULE = 0xFF2A3F6B;

    // ── врізана панель ──
    public static final int PANE = 0xFF141B2C;
    public static final int PANE_EDGE = 0xFF263554;

    // ── поля ──
    public static final int FIELD = 0xFF05080F;
    public static final int FIELD_EDGE = 0xFF22314F;
    public static final int FIELD_HOT = 0xFF4A6BA8;
    public static final int FIELD_FOCUS = 0xFF86A9E3;

    // ── кнопки ──
    public static final int BUTTON = 0xFF1E2842;
    public static final int BUTTON_HOT = 0xFF2A3A62;
    public static final int BUTTON_ON = 0xFF3A62A8;
    public static final int BUTTON_ON_HOT = 0xFF4A78C8;
    public static final int BUTTON_OFF = 0xFF141B2C;
    public static final int BUTTON_EDGE = 0xFF34466E;
    public static final int BUTTON_EDGE_HOT = 0xFF86A9E3;
    public static final int BUTTON_EDGE_ON = 0xFF7FA6E8;
    public static final int BUTTON_EDGE_OFF = 0xFF1F2A44;
    /** Тінь знизу/справа всередині кнопки. */
    public static final int BUTTON_SHADE = 0x59000000;
    /** Світлий блік зверху/зліва всередині кнопки. */
    public static final int BUTTON_LIGHT = 0x1AFFFFFF;

    public static final int ROW_HOT = 0xFF1B2A4A;
    public static final int ROW_ON = 0xFF2C66B8;
    public static final int ROW_ALT = 0x14FFFFFF;

    public static final int TITLE = 0xFFFFFFFF;
    public static final int LABEL = 0xFF9DB1D6;
    /** Дрібні заголовки секцій («ВИГЛЯД», «ПОКАЗАТИ»). */
    public static final int SECTION = 0xFF7C93C0;

    /** Сітка: поле між елементами, висота кнопок, поле всередині панелі. */
    public static final int GAP = 4, BTN_H = 14, PAD = 6, TITLE_H = 18;

    /** Висота кнопок у смугах (верхній ряд, панель інструментів): смуга 20 px = 2 + 16 + 2. */
    public static final int BAR_BTN = 16;

    private MenuSkin() {}

    /** Смуга інтерфейсу (верхній ряд, інструменти, статус): рівний фон, світла лінія й чорний контур з боку вмісту. */
    public static void bar(GuiGraphics g, int x, int y, int w, int h, boolean top) {
        g.fill(x, y, x + w, y + h, Theme.RAIL);
        if (!top) { // смуга лежить зверху від вмісту: лінії знизу
            g.fill(x, y + h - 2, x + w, y + h - 1, PANE_EDGE);
            g.fill(x, y + h - 1, x + w, y + h, OUTLINE);
        } else {   // смуга лежить знизу (статус): лінії зверху
            g.fill(x, y, x + w, y + 1, OUTLINE);
            g.fill(x, y + 1, x + w, y + 2, PANE_EDGE);
        }
    }

    /** Кнопка з плавним станом «увімкнено» (on: 0..1) — для анімованих перемикачів розділів. */
    public static void button(GuiGraphics g, int x, int y, int w, int h, boolean hover, boolean held, float on, boolean enabled) {
        button(g, x, y, w, h, hover, held, false, enabled);
        if (on <= 0.01f) return;
        int a = Math.round(0xFF * Math.min(1f, on));
        g.fill(x + 2, y + 2, x + w - 2, y + h - 2, (a << 24) | (BUTTON_ON & 0xFFFFFF));
        g.fill(x + 1, y + 1, x + w - 1, y + 2, (a << 24) | (BUTTON_EDGE_ON & 0xFFFFFF));
        g.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, (a << 24) | (BUTTON_EDGE_ON & 0xFFFFFF));
        g.fill(x + 1, y + 2, x + 2, y + h - 2, (a << 24) | (BUTTON_EDGE_ON & 0xFFFFFF));
        g.fill(x + w - 2, y + 2, x + w - 1, y + h - 2, (a << 24) | (BUTTON_EDGE_ON & 0xFFFFFF));
        g.fill(x + 2, y + 2, x + w - 2, y + 3, (Math.round(0x1A * on) << 24) | 0xFFFFFF);
    }

    private static void outline(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y + 1, x + 1, y + h - 1, color);
        g.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
    }

    // ───────── вікно ─────────

    /** Вікно: чорний контур, синя напівпрозора рамка завтовшки 4 px, тіло лишається під панелями. */
    public static void window(GuiGraphics g, int x, int y, int w, int h) { window(g, x, y, w, h, EDGE); }

    public static void window(GuiGraphics g, int x, int y, int w, int h, int edge) {
        // малі спливаючі вікна й меню: чорний контур, тонка синя рамка, темна панель; вміст можна класти від x+4
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, OUTLINE);
        g.fill(x, y, x + w, y + h, edge == EDGE ? PANE_EDGE : edge);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, PANE);
        g.fill(x + 1, y + 1, x + w - 1, y + 2, 0x14FFFFFF);
    }

    /**
     * Велике вікно екрана в стилі Buildprint: чорний контур, синя рамка з легким градієнтом (світліша зверху),
     * заголовок у смузі {@link #TITLE_H}. Вміст — у {@link #pane}.
     */
    public static void frame(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, OUTLINE);
        g.fillGradient(x, y, x + w, y + h, FRAME_HI & 0xF0FFFFFF, FRAME_LO & 0xF0FFFFFF);
        g.fillGradient(x, y, x + w, y + h, 0x00000000, 0x33000000);
        g.fill(x, y, x + w, y + 1, 0x40FFFFFF);
        sheen(g, x, y, w, 1f, 4200);
    }

    /** Блиск, що пробігає горизонтальною кромкою (рамка вікна, наведена картка). period — мс на один прохід. */
    public static void sheen(GuiGraphics g, int x, int y, int w, float strength, long period) {
        if (Fx.reduced() || w < 40 || strength <= 0.01f) return;
        float ph = (System.currentTimeMillis() % period) / (float) period;
        int len = Math.min(80, w);
        int sx = x + Math.round((w + len) * ph) - len, x0 = Math.max(x, sx), x1 = Math.min(x + w, sx + len);
        for (int i = x0; i < x1; i++) {
            float k = 1 - Math.abs((i - sx) - len / 2f) / (len / 2f);
            g.fill(i, y, i + 1, y + 1, Fx.withAlpha(0xFFFFFF, 0.55f * k * k * strength));
        }
    }

    /** Темна врізана панель: чорний контур, тонка світліша лінія, рівне тіло. */
    public static void pane(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, OUTLINE);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, PANE_EDGE);
        g.fill(x + 2, y + 2, x + w - 2, y + h - 2, PANE);
    }

    /** Колір тіні тексту, як у ванілі (темніший у 4 рази). */
    public static int shadowOf(int c) { return (c & 0xFF000000) | ((c & 0xFCFCFC) >> 2); }

    /**
     * Текст із тінню на тій самій глибині. Прапорець drawString(..., true) зсуває текст ближче до глядача, і текст панелей
     * пробивається крізь вікна й меню, намальовані пізніше, тому тінь малюється вручну.
     */
    public static void text(GuiGraphics g, Font font, String s, int x, int y, int color) {
        g.drawString(font, s, x + 1, y + 1, shadowOf(color), false);
        g.drawString(font, s, x, y, color, false);
    }

    public static void text(GuiGraphics g, Font font, Component s, int x, int y, int color) {
        g.drawString(font, s, x + 1, y + 1, shadowOf(color), false);
        g.drawString(font, s, x, y, color, false);
    }

    /** Заголовок вікна: жирний білий текст з тінню. */
    public static void title(GuiGraphics g, Font font, String text, int x, int y) {
        text(g, font, Component.literal(text).withStyle(ChatFormatting.BOLD), x, y, TITLE);
    }

    /** Текст по вертикальному центру смуги висотою h (у Minecraft шрифт 8 px, тому (h-8)/2). */
    public static int textY(int y, int h) { return y + (h - 8) / 2; }

    /** Дрібний заголовок секції у бічній колонці: «ВИГЛЯД», «СОРТУВАННЯ»… Повертає висоту, яку він займає. */
    public static int section(GuiGraphics g, Font font, String text, int x, int y) {
        text(g, font, text.toUpperCase(java.util.Locale.ROOT), x, y, SECTION);
        return 11;
    }

    // ───────── кнопки ─────────

    /**
     * Кнопка в стилі Buildprint: чорний контур 1 px → світліша рамка 1 px → тіло, зверху блік, знизу й справа тінь.
     * Увімкнена — синя; наведена — світла рамка; натиснута — тіло темнішає й «тінь» перевертається.
     */
    public static void button(GuiGraphics g, int x, int y, int w, int h, boolean hover, boolean held, boolean on, boolean enabled) {
        buttonT(g, x, y, w, h, hover ? 1 : 0, held ? 1 : 0, on ? 1 : 0, enabled);
    }

    /**
     * Кнопка з плавними станами: hov, press, on — 0..1 (наведення, натискання, «увімкнено»). Кольори тіла й рамки
     * змішуються між станами, тому перемикання не «блимає», а перетікає.
     */
    public static void buttonT(GuiGraphics g, int x, int y, int w, int h, float hov, float press, float on, boolean enabled) {
        int face, edge;
        if (!enabled) { face = BUTTON_OFF; edge = BUTTON_EDGE_OFF; }
        else {
            face = Fx.lerp(Fx.lerp(BUTTON, BUTTON_HOT, hov), Fx.lerp(BUTTON_ON, BUTTON_ON_HOT, hov), on);
            edge = Fx.lerp(Fx.lerp(BUTTON_EDGE, BUTTON_EDGE_ON, on), BUTTON_EDGE_HOT, hov);
        }
        g.fill(x, y, x + w, y + h, OUTLINE);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, edge);
        boolean held = press > 0.5f;
        if (h < 14) {
            g.fill(x + 1, y + 1, x + w - 1, y + h - 1, face);
            g.fill(x + 1, y + 1, x + w - 1, y + 2, edge);
            g.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, BUTTON_SHADE);
            return;
        }
        g.fill(x + 2, y + 2, x + w - 2, y + h - 2, face);
        if (!enabled) return;
        if (held) {
            g.fill(x + 2, y + 2, x + w - 2, y + h - 2, BUTTON_SHADE);
        } else {
            g.fill(x + 2, y + 2, x + w - 2, y + 3, BUTTON_LIGHT);
            g.fill(x + 2, y + h - 3, x + w - 2, y + h - 2, BUTTON_SHADE);
            g.fill(x + w - 3, y + 3, x + w - 2, y + h - 3, BUTTON_SHADE);
        }
    }

    /** Текстове/числове поле: майже чорне, чорний контур, у фокусі й при наведенні — світліша внутрішня рамка. */
    public static void field(GuiGraphics g, int x, int y, int w, int h, boolean hover, boolean focused) {
        int edge = focused ? FIELD_FOCUS : hover ? FIELD_HOT : FIELD_EDGE;
        g.fill(x, y, x + w, y + h, OUTLINE);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, edge);
        if (h < 14) g.fill(x + 1, y + 1, x + w - 1, y + h - 1, FIELD);
        else g.fill(x + 2, y + 2, x + w - 2, y + h - 2, FIELD);
    }

    /** Рядок списку: наведений — світлішає, вибраний — синій з чорним контуром. */
    public static void row(GuiGraphics g, int x, int y, int w, int h, boolean hover, boolean selected) {
        rowT(g, x, y, w, h, hover ? 1 : 0, selected ? 1 : 0);
    }

    /** Те саме з плавними hov/sel (0..1): підсвітка наростає й згасає, вибір «вливається». */
    public static void rowT(GuiGraphics g, int x, int y, int w, int h, float hov, float sel) {
        if (hov > 0.01f && sel < 0.99f) {
            float a = hov * (1 - sel);
            g.fill(x, y, x + w, y + h, Fx.mulAlpha(ROW_HOT, a));
            outline(g, x, y, w, h, Fx.mulAlpha(PANE_EDGE, a));
        }
        if (sel > 0.01f) {
            g.fill(x, y, x + w, y + h, Fx.mulAlpha(OUTLINE, sel));
            g.fill(x + 1, y + 1, x + w - 1, y + h - 1, Fx.mulAlpha(BUTTON_EDGE_ON, sel));
            g.fill(x + 2, y + 2, x + w - 2, y + h - 2, Fx.mulAlpha(ROW_ON, sel));
            // світла смужка зліва «виростає» від центру рядка
            int bar = Math.round((h - 4) * sel);
            g.fill(x + 2, y + (h - bar) / 2, x + 4, y + (h - bar) / 2 + bar, Fx.mulAlpha(BUTTON_EDGE_HOT, sel));
        }
    }

    /** Смугастий фон рядка для довгих списків (парні рядки трохи світліші). */
    public static void rowStripe(GuiGraphics g, int x, int y, int w, int h, int index) {
        if ((index & 1) == 1) g.fill(x, y, x + w, y + h, ROW_ALT);
    }

    /** Квадратний чекбокс 10×10 із чорним контуром і галочкою. */
    public static void checkbox(GuiGraphics g, int x, int y, boolean hover, boolean on) { checkboxT(g, x, y, hover ? 1 : 0, on ? 1 : 0); }

    /** Чекбокс із плавними станами: колір заливки перетікає, галочка проявляється «розчерком». */
    public static void checkboxT(GuiGraphics g, int x, int y, float hov, float on) {
        g.fill(x, y, x + 10, y + 10, OUTLINE);
        g.fill(x + 1, y + 1, x + 9, y + 9, Fx.lerp(Fx.lerp(BUTTON_EDGE, BUTTON_EDGE_ON, on), BUTTON_EDGE_HOT, hov));
        g.fill(x + 2, y + 2, x + 8, y + 8, Fx.lerp(FIELD, BUTTON_ON, on));
        if (on > 0.02f) {
            int col = Fx.mulAlpha(0xFFFFFFFF, on);
            int[][] tick = {{2, 4}, {3, 5}, {4, 6}, {5, 5}, {6, 4}, {7, 3}};
            // перші пікселі галочки з'являються раніше, останні — пізніше: виходить «розчерк»
            for (int i = 0; i < tick.length; i++) {
                float k = Fx.clamp01(on * tick.length - i);
                if (k > 0.01f) g.fill(x + tick[i][0], y + tick[i][1], x + tick[i][0] + 1, y + tick[i][1] + 2, Fx.mulAlpha(col, k));
            }
        }
    }

    // ───────── прокрутка ─────────

    /** Ширина смуги прокрутки разом із чорним контуром. */
    public static final int SCROLL_W = 6;

    /**
     * Смуга прокрутки Buildprint: вузька темна доріжка з чорним контуром і світлий повзунок із рамкою.
     * (x, y, h) — праворуч від прокручуваної області; (barY, barH) — повзунок усередині неї.
     */
    public static void scrollbar(GuiGraphics g, int x, int y, int h, int barY, int barH, boolean hover) { scrollbar(g, x, y, h, barY, barH, hover, 1f); }

    /** vis — прозорість смуги: приглушена, поки курсор не над областю, і повна при наведенні чи перетягуванні. */
    public static void scrollbar(GuiGraphics g, int x, int y, int h, int barY, int barH, boolean hover, float vis) {
        g.fill(x, y, x + SCROLL_W, y + h, Fx.mulAlpha(OUTLINE, vis));
        g.fill(x + 1, y + 1, x + SCROLL_W - 1, y + h - 1, Fx.mulAlpha(FIELD, vis));
        int bx = x + 1, bw = SCROLL_W - 2;
        g.fill(bx, barY, bx + bw, barY + barH, Fx.mulAlpha(hover ? BUTTON_EDGE_HOT : BUTTON_EDGE, vis));
        g.fill(bx + 1, barY + 1, bx + bw - 1, barY + barH - 1, Fx.mulAlpha(hover ? BUTTON_HOT : BUTTON, vis));
    }
}
