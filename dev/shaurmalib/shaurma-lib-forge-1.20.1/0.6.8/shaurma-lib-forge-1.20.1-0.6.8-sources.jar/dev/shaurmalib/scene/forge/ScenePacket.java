package dev.shaurmalib.scene.forge;

import dev.shaurmalib.scene.mc.McScene;
import dev.shaurmalib.scene.net.SceneMessage;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.ByteBufOutputStream;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.function.Supplier;

/** Forge-обгортка {@link SceneMessage}: формат дроту — ядра, лоадер лише несе байти. */
public record ScenePacket(SceneMessage message) {

    public static void encode(ScenePacket p, FriendlyByteBuf buf) {
        try (ByteBufOutputStream out = new ByteBufOutputStream(buf)) {
            p.message.write(out);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public static ScenePacket decode(FriendlyByteBuf buf) {
        try (ByteBufInputStream in = new ByteBufInputStream(buf)) {
            return new ScenePacket(SceneMessage.read(in));
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    public static void handle(ScenePacket p, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        if (c.getDirection().getReceptionSide().isClient()) {
            if (!p.message.op.toServer) c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ForgeSceneClient.handle(p.message)));
        } else {
            ServerPlayer sender = c.getSender();
            if (sender != null && p.message.op.toServer) c.enqueueWork(() -> McScene.handle(sender, p.message));
        }
        c.setPacketHandled(true);
    }
}
