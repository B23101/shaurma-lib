package dev.shaurmalib.scene.mc.ui;

import net.minecraft.client.gui.GuiGraphics;

/** Тема з Shaurma Building: темна, синій акцент, «закруглені» кути. Ті самі кольори — один стиль у двох модах. */
public final class Theme {
    public static final int OVERLAY   = 0xB0080A12;
    public static final int WINDOW    = 0xF2121A2E;
    public static final int RAIL      = 0xFF0A1020;
    public static final int PANEL     = 0xFF121A2E;
    public static final int PANEL_HI  = 0xFF1F3158;
    /** Пласка кнопка у спокої — ледь світліша за панель. */
    public static final int BUTTON    = 0xFF1B2748;
    /** Заголовок модульної панелі. */
    public static final int HEADER    = 0xFF18233F;
    public static final int BORDER    = 0xFF2A3F6B;
    public static final int ACCENT    = 0xFF4A9EFF;
    public static final int ACCENT_DK = 0xFF2C66B8;
    public static final int TEXT      = 0xFFF2F6FF;
    public static final int MUTED     = 0xFF9DB1D6;
    public static final int OK        = 0xFF59D185;
    public static final int WARN      = 0xFFF2B84B;
    public static final int DANGER    = 0xFFE5646A;
    /** Осі гізмо — як у Blockbench: X червона, Y зелена, Z синя. */
    public static final int AXIS_X = 0xFFF0475B, AXIS_Y = 0xFF6FD34A, AXIS_Z = 0xFF3D8BFF;

    private Theme() {}

    public static void round(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + h, color);
    }

    public static void roundOutline(GuiGraphics g, int x, int y, int w, int h, int fill, int border) {
        round(g, x, y, w, h, border);
        round(g, x + 1, y + 1, w - 2, h - 2, fill);
    }

    public static int withAlpha(int rgb, int a) { return (a << 24) | (rgb & 0xFFFFFF); }

    public static int lerp(int a, int b, float t) {
        int aa = a >>> 24, ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255;
        int ba = b >>> 24, br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    public static int axis(int i) { return i == 0 ? AXIS_X : i == 1 ? AXIS_Y : AXIS_Z; }
}
