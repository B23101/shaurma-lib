package dev.shaurmalib.scene.mc.editor;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.shaurmalib.anim.math.Mat4;
import dev.shaurmalib.anim.mesh.GeoMesh;
import dev.shaurmalib.scene.doc.Channels;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.eval.SceneRig;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Пряме керування у в'юпорті, як у Shaurma Modeling / Blockbench:
 * <ul>
 *   <li>клік по актору — вибір; клік по вибраному актору — вибір кістки під курсором; клік по іншій кістці — вона;</li>
 *   <li>Ctrl/Shift+клік — додати/прибрати з вибору; тягни по порожньому — рамка вибору;</li>
 *   <li>гізмо інструмента: стрілки переміщення, кільця повороту, кубики масштабу — тягни мишею,
 *       з автоключем пишеться ключ у playhead (кістки — завжди ключами пози).</li>
 * </ul>
 */
final class ViewportTools {

    enum Tool { SELECT, MOVE, ROTATE, SCALE }

    private ViewportTools() {}

    static Tool tool = Tool.MOVE;
    /** Вибрані об'єкти (головний — {@code selObj}). */
    static final Set<String> multi = new LinkedHashSet<>();

    // ── перетягування гізмо / рамки ──
    private static int dragAxis = -1;          // 0 X, 1 Y, 2 Z
    private static boolean dragging, boxing;
    private static double[] boxStart;
    private static double dragT0, dragA0;
    private static Vec3 pivot;
    private static final Map<String, double[]> startVals = new HashMap<>();
    private static float[] startBone;
    private static int hoverAxis = -1;

    // ═════════════════════════ вибір ═════════════════════════

    static boolean isSelected(SceneEditorScreen s, String id) { return id != null && (id.equals(s.selObj) || multi.contains(id)); }

    static void selectOnly(SceneEditorScreen s, String id) {
        multi.clear();
        s.select(id);
        if (id != null) multi.add(id);
    }

    /** Усі вибрані об'єкти (головний першим). */
    static List<SceneObject> selection(SceneEditorScreen s) {
        List<SceneObject> l = new ArrayList<>();
        SceneObject main = s.selected();
        if (main != null) l.add(main);
        for (String id : multi) {
            SceneObject o = s.variant().object(id);
            if (o != null && o != main) l.add(o);
        }
        return l;
    }

    // ═════════════════════════ промінь ═════════════════════════

    record Hit(String object, String bone, double t) {}

    /** Що під курсором: найближчий об'єкт, а для вже вибраного актора — його кістка. */
    static Hit pick(SceneEditorScreen s, double gx, double gy) {
        double[] r = EditorView.ray(gx, gy);
        if (r == null) return null;
        Vec3 o = new Vec3(r[0], r[1], r[2]), d = new Vec3(r[3], r[4], r[5]);
        Hit best = null;
        for (SceneObject obj : s.variant().objects) {
            if (obj.editorHidden || obj.locked) continue;
            double t;
            if (obj.isCamera()) {
                SceneFrame.Cam c = s.evaluator.cameraOf(obj, s.time, null, new SceneFrame.Cam());
                if (s.view.cameraView && obj.id.equals(s.frame.cameraId)) continue;
                t = sphere(o, d, new Vec3(c.x, c.y, c.z), 0.45);
            } else if (obj.kind == SceneObject.Kind.EMPTY) {
                double[] xf = s.evaluator.transform(obj, s.time, new double[7], 0);
                t = sphere(o, d, new Vec3(xf[0], xf[1], xf[2]), 0.35);
            } else {
                SceneFrame.Actor a = s.frame.actor(obj.id);
                if (a == null) a = s.evaluator.actor(obj, s.time);
                // вибраний актор: спершу кістки (клік по руці — рука)
                if (obj.id.equals(s.selObj)) {
                    Hit bh = pickBone(s, obj, a, o, d);
                    if (bh != null && (best == null || bh.t < best.t)) { best = bh; continue; }
                }
                t = actorBox(s, obj, a, o, d);
            }
            if (t >= 0 && (best == null || t < best.t)) best = new Hit(obj.id, null, t);
        }
        return best;
    }

    private static double sphere(Vec3 o, Vec3 d, Vec3 c, double r) {
        Vec3 oc = o.subtract(c);
        double b = oc.dot(d), cc = oc.dot(oc) - r * r, h = b * b - cc;
        if (h < 0) return -1;
        double t = -b - Math.sqrt(h);
        return t >= 0 ? t : -b + Math.sqrt(h);
    }

    /** Габарит актора (у його просторі) — промінь у локальні координати, перетин з коробкою. */
    private static double actorBox(SceneEditorScreen s, SceneObject obj, SceneFrame.Actor a, Vec3 o, Vec3 d) {
        float[] b = bounds(s, obj);
        Matrix4f inv = actorMatrix(a).invert();
        return slab(inv, o, d, b);
    }

    private static final Map<GeoMesh, float[]> BOUNDS = new HashMap<>();

    /** {minX, minY, minZ, maxX, maxY, maxZ} у просторі сітки (блоки). */
    private static float[] bounds(SceneEditorScreen s, SceneObject obj) {
        GeoMesh mesh = obj.modelType == SceneObject.ModelType.PLAYER ? null : s.clips.mesh(obj);
        if (mesh == null) return new float[] { -0.32f, 0, -0.2f, 0.32f, 2.0f, 0.2f };
        return BOUNDS.computeIfAbsent(mesh, m -> {
            float[] b = { Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE };
            for (GeoMesh.MeshBone bone : m.bones) for (GeoMesh.MeshCube c : bone.cubes) for (GeoMesh.Quad q : c.quads) for (int v = 0; v < 4; v++) {
                for (int k = 0; k < 3; k++) { b[k] = Math.min(b[k], q.pos[v * 3 + k]); b[k + 3] = Math.max(b[k + 3], q.pos[v * 3 + k]); }
            }
            if (b[0] > b[3]) return new float[] { -0.5f, 0, -0.5f, 0.5f, 1, 0.5f };
            return b;
        });
    }

    /** Коробки кісток гравця в пікселях відносно півота (ваніль: голова 8³, тулуб 8×12×4, руки/ноги 4×12×4). */
    private static final Map<String, float[]> PLAYER_BOXES = Map.of(
        "head", new float[] { -4, 0, -4, 4, 8, 4 },
        "torso", new float[] { -4, -12, -2, 4, 0, 2 },
        "right_arm", new float[] { -1, -10, -2, 3, 2, 2 },
        "left_arm", new float[] { -3, -10, -2, 1, 2, 2 },
        "right_leg", new float[] { -2, -12, -2, 2, 0, 2 },
        "left_leg", new float[] { -2, -12, -2, 2, 0, 2 });

    private static Hit pickBone(SceneEditorScreen s, SceneObject obj, SceneFrame.Actor a, Vec3 o, Vec3 d) {
        SceneRig rig = s.clips.rig(obj);
        if (rig == null) return null;
        Matrix4f am = actorMatrix(a);
        Hit best = null;
        if (obj.modelType == SceneObject.ModelType.PLAYER) {
            for (Map.Entry<String, float[]> e : PLAYER_BOXES.entrySet()) {
                Mat4 bm = rig.boneMatrix(e.getKey(), a.pose);
                if (bm == null) continue;
                float[] bx = e.getValue();
                Matrix4f inv = new Matrix4f(am).mul(joml(bm)).invert();
                // коробка — у просторі спокою (півот кістки + розміри); поза й обертання кістки — через bm
                float[] local = { bx[0] / 16f, bx[1] / 16f, bx[2] / 16f, bx[3] / 16f, bx[4] / 16f, bx[5] / 16f };
                float[] rest = new float[3];
                rig.bonePivot(e.getKey(), null, rest);
                for (int k = 0; k < 3; k++) { local[k] += rest[k]; local[k + 3] += rest[k]; }
                double t = slab(inv, o, d, local);
                if (t >= 0 && (best == null || t < best.t)) best = new Hit(obj.id, e.getKey(), t);
            }
            return best;
        }
        GeoMesh mesh = s.clips.mesh(obj);
        if (mesh == null) return null;
        for (GeoMesh.MeshBone b : mesh.bones) {
            if (b.cubes.isEmpty() || obj.hiddenBones.contains(b.name)) continue;
            Mat4 bm = rig.boneMatrix(b.name, a.pose);
            if (bm == null) continue;
            Matrix4f inv = new Matrix4f(am).mul(joml(bm)).invert();
            for (GeoMesh.MeshCube c : b.cubes) {
                float[] box = { Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE };
                for (GeoMesh.Quad q : c.quads) for (int v = 0; v < 4; v++) for (int k = 0; k < 3; k++) {
                    box[k] = Math.min(box[k], q.pos[v * 3 + k]);
                    box[k + 3] = Math.max(box[k + 3], q.pos[v * 3 + k]);
                }
                double t = slab(inv, o, d, box);
                if (t >= 0 && (best == null || t < best.t)) best = new Hit(obj.id, b.name, t);
            }
        }
        return best;
    }

    static Matrix4f actorMatrix(SceneFrame.Actor a) {
        return new Matrix4f().translate((float) a.x, (float) a.y, (float) a.z)
            .rotateY((float) Math.toRadians(180 - a.yaw)).rotateX((float) Math.toRadians(a.pitch))
            .rotateZ((float) Math.toRadians(a.roll)).scale(a.scale);
    }

    /** Mat4 ядра (рядковий) → JOML (стовпцевий). */
    static Matrix4f joml(Mat4 m) {
        float[] r = m.m;
        return new Matrix4f(r[0], r[4], r[8], r[12], r[1], r[5], r[9], r[13], r[2], r[6], r[10], r[14], r[3], r[7], r[11], r[15]);
    }

    /** Промінь (світ) → локальний простір, перетин з коробкою; відстань у світових одиницях або -1. */
    private static double slab(Matrix4f inv, Vec3 o, Vec3 d, float[] b) {
        Vector4f lo = inv.transform(new Vector4f((float) o.x, (float) o.y, (float) o.z, 1));
        Vector4f ld = inv.transform(new Vector4f((float) d.x, (float) d.y, (float) d.z, 0));
        double t0 = -1e9, t1 = 1e9;
        double[] oo = { lo.x, lo.y, lo.z }, dd = { ld.x, ld.y, ld.z };
        for (int k = 0; k < 3; k++) {
            double min = Math.min(b[k], b[k + 3]) - 0.02, max = Math.max(b[k], b[k + 3]) + 0.02;
            if (Math.abs(dd[k]) < 1e-9) { if (oo[k] < min || oo[k] > max) return -1; continue; }
            double a = (min - oo[k]) / dd[k], c = (max - oo[k]) / dd[k];
            t0 = Math.max(t0, Math.min(a, c));
            t1 = Math.min(t1, Math.max(a, c));
        }
        if (t1 < Math.max(0, t0)) return -1;
        // афінне перетворення зберігає параметр променя: t у локальному просторі = відстань у світі
        return t0 >= 0 ? t0 : t1;
    }

    // ═════════════════════════ гізмо ═════════════════════════

    /** Точка гізмо: кістка (її півот у світі) або об'єкт. */
    static Vec3 pivotOf(SceneEditorScreen s) {
        SceneObject o = s.selected();
        if (o == null) return null;
        if (o.isCamera()) {
            SceneFrame.Cam c = s.evaluator.cameraOf(o, s.time, null, new SceneFrame.Cam());
            return new Vec3(c.x, c.y, c.z);
        }
        if (s.selBone != null && o.kind != SceneObject.Kind.EMPTY) {
            SceneRig rig = s.clips.rig(o);
            SceneFrame.Actor a = s.evaluator.actor(o, s.time);
            float[] p = new float[3];
            if (rig != null && rig.bonePivot(s.selBone, a.pose, p)) {
                Vector4f w = actorMatrix(a).transform(new Vector4f(p[0], p[1], p[2], 1));
                return new Vec3(w.x, w.y, w.z);
            }
        }
        double[] xf = s.evaluator.transform(o, s.time, new double[7], 0);
        // актор: гізмо на середині тіла, а не в ногах — щоб при наближенні на тулуб воно лишалось у кадрі
        double up = o.kind == SceneObject.Kind.ACTOR ? 0.9 * (xf.length > 6 && xf[6] > 0 ? xf[6] : 1) : 0;
        return new Vec3(xf[0], xf[1] + up, xf[2]);
    }

    private static final Vec3[] AXES = { new Vec3(1, 0, 0), new Vec3(0, 1, 0), new Vec3(0, 0, 1) };

    static double gizmoSize(SceneEditorScreen s, Vec3 p) {
        SceneFrame.Cam c = s.editorCamera();
        return Math.max(0.2, Math.sqrt(Math.pow(p.x - c.x, 2) + Math.pow(p.y - c.y, 2) + Math.pow(p.z - c.z, 2)) * 0.16);
    }

    /** Малювання гізмо у світі (після сутностей). */
    static void drawWorld(SceneEditorScreen s, PoseStack ps, MultiBufferSource buffers, Vec3 cam) {
        if (tool == Tool.SELECT || s.view.cameraView && s.lockCameraToView) return;
        Vec3 p = pivotOf(s);
        if (p == null) return;
        VertexConsumer vc = EditorView.lines(buffers);
        PoseStack.Pose pose = ps.last();
        double size = gizmoSize(s, p);
        int[] col = { Theme.AXIS_X, Theme.AXIS_Y, Theme.AXIS_Z };
        for (int i = 0; i < 3; i++) {
            int c = (dragging && dragAxis == i) || (!dragging && hoverAxis == i) ? 0xFFFFFFFF : col[i];
            if (dragging && dragAxis != i) c = (c & 0x00FFFFFF) | 0x55000000;
            Vec3 a = AXES[i];
            switch (tool) {
                case MOVE, SCALE -> {
                    Vec3 e = p.add(a.scale(size));
                    for (double off = -0.006 * size; off <= 0.0061 * size; off += 0.006 * size) {
                        Vec3 n = i == 1 ? new Vec3(off, 0, 0) : new Vec3(0, off, 0);
                        EditorView.line(vc, pose, cam, p.x + n.x, p.y + n.y, p.z + n.z, e.x + n.x, e.y + n.y, e.z + n.z, c);
                    }
                    double h = size * (tool == Tool.SCALE ? 0.06 : 0.1);
                    if (tool == Tool.SCALE) cube(vc, pose, cam, e, h, c);
                    else cone(vc, pose, cam, e, a, h, c);
                }
                case ROTATE -> ring(vc, pose, cam, p, i, size * 0.9, c);
                default -> { }
            }
        }
    }

    private static void cube(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, Vec3 c, double h, int col) {
        double[][] k = { { -h, -h, -h }, { h, -h, -h }, { h, h, -h }, { -h, h, -h }, { -h, -h, h }, { h, -h, h }, { h, h, h }, { -h, h, h } };
        int[][] e = { { 0, 1 }, { 1, 2 }, { 2, 3 }, { 3, 0 }, { 4, 5 }, { 5, 6 }, { 6, 7 }, { 7, 4 }, { 0, 4 }, { 1, 5 }, { 2, 6 }, { 3, 7 } };
        for (int[] ed : e) EditorView.line(vc, p, cam, c.x + k[ed[0]][0], c.y + k[ed[0]][1], c.z + k[ed[0]][2], c.x + k[ed[1]][0], c.y + k[ed[1]][1], c.z + k[ed[1]][2], col);
    }

    private static void cone(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, Vec3 tip, Vec3 a, double h, int col) {
        Vec3 u = Math.abs(a.y) > 0.9 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
        Vec3 v1 = a.cross(u).normalize(), v2 = a.cross(v1).normalize();
        Vec3 base = tip.subtract(a.scale(h * 1.6));
        for (int i = 0; i < 8; i++) {
            double ang = i * Math.PI / 4;
            Vec3 q = base.add(v1.scale(Math.cos(ang) * h * 0.5)).add(v2.scale(Math.sin(ang) * h * 0.5));
            EditorView.line(vc, p, cam, q.x, q.y, q.z, tip.x, tip.y, tip.z, col);
        }
    }

    private static void ring(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, Vec3 c, int axis, double r, int col) {
        Vec3 prev = null;
        for (int i = 0; i <= 48; i++) {
            Vec3 q = ringPoint(c, axis, r, i * Math.PI * 2 / 48);
            if (prev != null) EditorView.line(vc, p, cam, prev.x, prev.y, prev.z, q.x, q.y, q.z, col);
            prev = q;
        }
    }

    private static Vec3 ringPoint(Vec3 c, int axis, double r, double a) {
        double cs = Math.cos(a) * r, sn = Math.sin(a) * r;
        return switch (axis) {
            case 0 -> c.add(0, cs, sn);
            case 1 -> c.add(cs, 0, sn);
            default -> c.add(cs, sn, 0);
        };
    }

    /** Вісь гізмо під курсором (екранна відстань до стрілки/кільця). */
    static int hover(SceneEditorScreen s, double gx, double gy) {
        if (tool == Tool.SELECT) return -1;
        Vec3 p = pivotOf(s);
        if (p == null) return -1;
        double size = gizmoSize(s, p);
        int best = -1;
        double bd = 7;
        for (int i = 0; i < 3; i++) {
            if (tool == Tool.ROTATE) {
                double[] prev = null;
                for (int k = 0; k <= 32; k++) {
                    Vec3 q = ringPoint(p, i, size * 0.9, k * Math.PI * 2 / 32);
                    double[] sc = EditorView.project(q.x, q.y, q.z);
                    if (sc != null && prev != null) {
                        double d = segDist(gx, gy, prev[0], prev[1], sc[0], sc[1]);
                        if (d < bd) { bd = d; best = i; }
                    }
                    prev = sc;
                }
            } else {
                double[] a = EditorView.project(p.x, p.y, p.z), b = EditorView.project(p.x + AXES[i].x * size, p.y + AXES[i].y * size, p.z + AXES[i].z * size);
                if (a == null || b == null) continue;
                double d = segDist(gx, gy, a[0] + (b[0] - a[0]) * 0.15, a[1] + (b[1] - a[1]) * 0.15, b[0], b[1]);
                if (d < bd) { bd = d; best = i; }
            }
        }
        return best;
    }

    private static double segDist(double px, double py, double ax, double ay, double bx, double by) {
        double dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy;
        double t = l < 1e-9 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l));
        double cx = ax + dx * t - px, cy = ay + dy * t - py;
        return Math.sqrt(cx * cx + cy * cy);
    }

    // ═════════════════════════ миша ═════════════════════════

    /** ЛКМ у в'юпорті натиснули. @return чи забрали подію */
    static boolean press(SceneEditorScreen s, double gx, double gy, boolean ctrl, boolean shift) {
        int axis = hover(s, gx, gy);
        if (axis >= 0 && !s.readOnly) {
            dragAxis = axis;
            dragging = true;
            pivot = pivotOf(s);
            dragT0 = axisParam(gx, gy, pivot, axis);
            dragA0 = angleAround(gx, gy, pivot);
            startVals.clear();
            for (SceneObject o : selection(s)) startVals.put(o.id, new double[] {
                s.value(o, Channels.X), s.value(o, Channels.Y), s.value(o, Channels.Z),
                s.value(o, Channels.YAW), s.value(o, Channels.PITCH), s.value(o, Channels.ROLL), s.value(o, Channels.SCALE) });
            SceneObject o = s.selected();
            startBone = null;
            if (o != null && s.selBone != null) {
                var ch = o.bone(s.selBone);
                startBone = new float[9];
                for (int i = 0; i < 9; i++) startBone[i] = (float) ch.sample(Channels.BONE[i], s.time, i >= 6 ? 1 : 0);
            }
            s.begin(tool == Tool.MOVE ? "Перемістити" : tool == Tool.ROTATE ? "Повернути" : "Масштаб");
            return true;
        }
        Hit h = pick(s, gx, gy);
        if (h == null) {
            if (!ctrl && !shift) { selectOnly(s, null); }
            boxing = true;
            boxStart = new double[] { gx, gy };
            return true;
        }
        if (ctrl || shift) {
            List<String> keep = new ArrayList<>(multi);
            if (!keep.remove(h.object())) { s.select(h.object()); multi.addAll(keep); }
            else {
                String main = h.object().equals(s.selObj) ? (keep.isEmpty() ? null : keep.get(0)) : s.selObj;
                s.select(main);
                multi.clear();
                multi.addAll(keep);
            }
            return true;
        }
        if (h.bone() != null) { String keep = s.selObj; selectOnly(s, keep); s.selBone = h.bone(); return true; }
        selectOnly(s, h.object());
        return true;
    }

    static void drag(SceneEditorScreen s, double gx, double gy) {
        if (!dragging || pivot == null) return;
        boolean fine = net.minecraft.client.gui.screens.Screen.hasShiftDown();
        SceneObject main = s.selected();
        switch (tool) {
            case MOVE -> {
                double delta = axisParam(gx, gy, pivot, dragAxis) - dragT0;
                if (fine) delta *= 0.1;
                if (!net.minecraft.client.gui.screens.Screen.hasControlDown()) delta = Math.round(delta * 16) / 16.0;  // сітка 1/16 бл (Ctrl — вільно)
                if (startBone != null && main != null) {
                    // кістка: світовий зсув → простір сітки актора (пікселі; X дзеркальний)
                    SceneFrame.Actor a = s.evaluator.actor(main, s.time);
                    Vector3f l = new Matrix4f().rotateY((float) Math.toRadians(180 - a.yaw)).invert()
                        .transformDirection(new Vector3f((float) AXES[dragAxis].x, (float) AXES[dragAxis].y, (float) AXES[dragAxis].z)).mul((float) (delta * 16 / Math.max(0.01, a.scale)));
                    var ch = main.bone(s.selBone);
                    ch.getOrCreate("px").set(s.time, startBone[3] - l.x);
                    ch.getOrCreate("py").set(s.time, startBone[4] + l.y);
                    ch.getOrCreate("pz").set(s.time, startBone[5] + l.z);
                    return;
                }
                String[] chs = { Channels.X, Channels.Y, Channels.Z };
                for (SceneObject o : selection(s)) {
                    double[] v = startVals.get(o.id);
                    if (v == null) continue;
                    s.setValue(o, chs[dragAxis], v[dragAxis] + delta);
                }
            }
            case ROTATE -> {
                double da = Mth.wrapDegrees(Math.toDegrees(angleAround(gx, gy, pivot) - dragA0));
                if (fine) da *= 0.2;
                if (!net.minecraft.client.gui.screens.Screen.hasControlDown()) da = Math.round(da / 5) * 5;   // крок 5° (Ctrl — вільно)
                double sign = viewSign(s, dragAxis);
                if (startBone != null && main != null) {
                    var ch = main.bone(s.selBone);
                    ch.getOrCreate(Channels.BONE[dragAxis]).set(s.time, startBone[dragAxis] + da * sign);
                    return;
                }
                String[] chs = { Channels.PITCH, Channels.YAW, Channels.ROLL };
                for (SceneObject o : selection(s)) {
                    double[] v = startVals.get(o.id);
                    if (v == null) continue;
                    s.setAngle(o, chs[dragAxis], v[3 + (dragAxis == 1 ? 0 : dragAxis == 0 ? 1 : 2)] - da * sign);
                }
            }
            case SCALE -> {
                double delta = axisParam(gx, gy, pivot, dragAxis) - dragT0;
                double f = Math.max(0.05, 1 + delta / Math.max(0.2, gizmoSize(s, pivot)));
                if (startBone != null && main != null) {
                    var ch = main.bone(s.selBone);
                    ch.getOrCreate(Channels.BONE[6 + dragAxis]).set(s.time, startBone[6 + dragAxis] * f);
                    return;
                }
                for (SceneObject o : selection(s)) {
                    double[] v = startVals.get(o.id);
                    if (v != null && !o.isCamera()) s.setValue(o, Channels.SCALE, Math.max(0.01, v[6] * f));
                }
            }
            default -> { }
        }
    }

    /** ЛКМ відпущено. */
    static void release(SceneEditorScreen s, double gx, double gy) {
        if (dragging) { dragging = false; dragAxis = -1; s.commit(); return; }
        if (boxing && boxStart != null) {
            boxing = false;
            double x0 = Math.min(boxStart[0], gx), x1 = Math.max(boxStart[0], gx), y0 = Math.min(boxStart[1], gy), y1 = Math.max(boxStart[1], gy);
            if (x1 - x0 < 4 && y1 - y0 < 4) return;
            for (SceneObject o : s.variant().objects) {
                if (o.editorHidden || o.locked) continue;
                Vec3 p;
                if (o.isCamera()) { SceneFrame.Cam c = s.evaluator.cameraOf(o, s.time, null, new SceneFrame.Cam()); p = new Vec3(c.x, c.y, c.z); }
                else { double[] xf = s.evaluator.transform(o, s.time, new double[7], 0); p = new Vec3(xf[0], xf[1] + (o.kind == SceneObject.Kind.ACTOR ? 0.9 : 0), xf[2]); }
                double[] sc = EditorView.project(p.x, p.y, p.z);
                if (sc != null && sc[0] >= x0 && sc[0] <= x1 && sc[1] >= y0 && sc[1] <= y1) {
                    if (s.selObj == null) s.select(o.id);
                    multi.add(o.id);
                }
            }
        }
    }

    static boolean busy() { return dragging || boxing; }

    /** Самотест: GUI-точка об'єкта (актор — на рівні грудей) або центру коробки кістки гравця. */
    static double[] guiPoint(SceneEditorScreen s, String id, String bone) {
        SceneObject obj = s.variant().object(id);
        if (obj == null) return null;
        if (bone == null) {
            if (obj.isCamera()) { SceneFrame.Cam c = s.evaluator.cameraOf(obj, s.time, null, new SceneFrame.Cam()); return EditorView.project(c.x, c.y, c.z); }
            double[] xf = s.evaluator.transform(obj, s.time, new double[7], 0);
            return EditorView.project(xf[0], xf[1] + (obj.kind == SceneObject.Kind.ACTOR ? 1.0 : 0), xf[2]);
        }
        SceneRig rig = s.clips.rig(obj);
        float[] bx = PLAYER_BOXES.get(bone);
        if (rig == null || bx == null) return null;
        SceneFrame.Actor a = s.frame.actor(obj.id);
        if (a == null) a = s.evaluator.actor(obj, s.time);
        Mat4 bm = rig.boneMatrix(bone, a.pose);
        float[] rest = new float[3];
        if (bm == null || !rig.bonePivot(bone, null, rest)) return null;
        Vector4f c = new Matrix4f(actorMatrix(a)).mul(joml(bm)).transform(new Vector4f(
            rest[0] + (bx[0] + bx[3]) / 32f, rest[1] + (bx[1] + bx[4]) / 32f, rest[2] + (bx[2] + bx[5]) / 32f, 1));
        return EditorView.project(c.x, c.y, c.z);
    }

    /** Самотест: знайти на екрані точку, де hover() дає цю вісь (спіраллю від півота). */
    static double[] guiHandle(SceneEditorScreen s, int axis) {
        Vec3 p = pivotOf(s);
        if (p == null) return null;
        double[] c = EditorView.project(p.x, p.y, p.z);
        if (c == null) return null;
        for (int r = 6; r < 220; r += 2)
            for (int k = 0; k < 48; k++) {
                double a = k * Math.PI * 2 / 48, x = c[0] + Math.cos(a) * r, y = c[1] + Math.sin(a) * r;
                if (s.inViewport(x, y) && hover(s, x, y) == axis) return new double[] { x, y };
            }
        return null;
    }

    /** Рамка вибору й підказка гізмо (GUI). */
    static void drawGui(SceneEditorScreen s, Gui gui) {
        if (!dragging && !boxing && s.inViewport(gui.mx, gui.my) && s.menu == null) hoverAxis = hover(s, gui.mx, gui.my);
        else if (!dragging) hoverAxis = -1;
        if (hoverAxis >= 0 && !dragging) {
            gui.cursor(Gui.CUR_HAND);
            String[] ax = { "X", "Y", "Z" };
            gui.tip(Component.literal((tool == Tool.MOVE ? "Тягни — рух по осі " : tool == Tool.ROTATE ? "Тягни — поворот навколо " : "Тягни — масштаб по ") + ax[hoverAxis]
                + "\nShift — точно · Ctrl — без сітки"));
        }
        if (boxing && boxStart != null) {
            int x0 = (int) Math.min(boxStart[0], gui.mx), y0 = (int) Math.min(boxStart[1], gui.my);
            int x1 = (int) Math.max(boxStart[0], gui.mx), y1 = (int) Math.max(boxStart[1], gui.my);
            gui.g.fill(x0, y0, x1, y1, 0x224A9EFF);
            gui.g.renderOutline(x0, y0, Math.max(1, x1 - x0), Math.max(1, y1 - y0), 0xCC4A9EFF);
        }
    }

    // ── математика перетягування ──

    /** Параметр уздовж осі в точці, найближчій до променя миші. */
    private static double axisParam(double gx, double gy, Vec3 p, int axis) {
        double[] r = EditorView.ray(gx, gy);
        if (r == null) return 0;
        Vec3 o = new Vec3(r[0], r[1], r[2]), d = new Vec3(r[3], r[4], r[5]), a = AXES[axis];
        Vec3 w = p.subtract(o);
        double b = a.dot(d), dd = a.dot(w), e = d.dot(w), den = 1 - b * b;
        if (Math.abs(den) < 1e-6) return 0;
        return (b * e - dd) / den;
    }

    /** Кут курсора навколо екранної проєкції точки (радіани). */
    private static double angleAround(double gx, double gy, Vec3 p) {
        double[] c = EditorView.project(p.x, p.y, p.z);
        return c == null ? 0 : Math.atan2(gy - c[1], gx - c[0]);
    }

    /** Знак повороту: кільце «до нас» чи «від нас» (щоб тягнути за годинниковою = повертати за годинниковою). */
    private static double viewSign(SceneEditorScreen s, int axis) {
        SceneFrame.Cam c = s.editorCamera();
        Vec3 look = Vec3.directionFromRotation(c.pitch, c.yaw);
        double d = axis == 0 ? look.x : axis == 1 ? look.y : look.z;
        return d > 0 ? -1 : 1;
    }
}
