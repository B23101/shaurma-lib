package dev.shaurmalib.scene.mc.ui;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/**
 * Невеликий immediate-mode інтерфейс для редактора: віджети описуються щокадру прямо в render(), а стан
 * (фокус, текст поля, прокрутка) живе тут за id. Так панелі Blockbench (десятки полів, що залежать від виділення)
 * пишуться без сотень класів-віджетів і завжди показують актуальні дані моделі.
 *
 * <p>Події миші з екрана ставляться в чергу і «з'їдаються» першим віджетом, під яким курсор. Що лишилося
 * незʼїденим — дістається в'юпорту.
 */
public final class Gui {
    public GuiGraphics g;
    public final Font font = Minecraft.getInstance().font;
    public int mx, my;
    // одноразові події кадру
    private int click = -1, clickX, clickY;
    private boolean dbl;
    private int release = -1;
    private double scroll;
    private boolean clickUsed, scrollUsed;
    private long lastClickTime;
    private int lastClickX, lastClickY;
    // стан між кадрами
    public String active;          // віджет, на якому натиснули і ще не відпустили
    public String focused;         // текстове поле з фокусом
    private final Map<String, StringBuilder> buffers = new HashMap<>();
    private final Map<String, Integer> cursors = new HashMap<>();
    private final Map<String, Integer> anchors = new HashMap<>();
    private final Map<String, Double> scrolls = new HashMap<>();
    private final Map<String, double[]> dragStart = new HashMap<>();
    private final boolean[] down = new boolean[8];
    private Component tooltip;
    private int tooltipX, tooltipY;
    private String lastTooltip;
    private long tooltipAt;
    // превʼю в підказці: іконка, колір або довільний малюнок
    private Icon tipIcon;
    private int tipSwatch;
    private Painter tipPainter;
    private int tipPw, tipPh;
    private long tooltipHiddenAt;

    /** Малювання довільного превʼю всередині підказки / палітри. */
    @FunctionalInterface
    public interface Painter { void paint(GuiGraphics g, int x, int y, int w, int h); }

    // курсори миші: рука над кнопками, I-beam над полями, стрілки зміни розміру
    public static final int CUR_ARROW = 0, CUR_HAND = 1, CUR_IBEAM = 2, CUR_HRESIZE = 3, CUR_VRESIZE = 4;
    private static final long[] CURSOR_HANDLES = new long[5];
    private int cursorWanted, cursorApplied;
    private final Map<String, long[]> ripples = new HashMap<>();
    /** Модальне вікно: панелі під ним не отримують подій. */
    public boolean modal;
    private int scissorDepth;

    // ───────── події з Screen ─────────

    public void onClick(double x, double y, int button) {
        long now = System.currentTimeMillis();
        dbl = button == 0 && now - lastClickTime < 300 && Math.abs(x - lastClickX) < 4 && Math.abs(y - lastClickY) < 4;
        lastClickTime = now;
        lastClickX = (int) x;
        lastClickY = (int) y;
        click = button;
        clickX = (int) x;
        clickY = (int) y;
        clickUsed = false;
        if (button >= 0 && button < down.length) down[button] = true;
        // клік повз текстове поле знімає фокус (і зберігає введене)
        if (focused != null && !focusedHit) commitFocused = focused;
    }

    private boolean focusedHit;
    private String commitFocused;

    public void onRelease(int button) {
        release = button;
        if (button >= 0 && button < down.length) down[button] = false;
    }

    public void onScroll(double d) { scroll += d; scrollUsed = false; }

    public boolean isDown(int button) { return button >= 0 && button < down.length && down[button]; }

    // ───────── кадр ─────────

    // ───────── анімації віджетів (immediate-mode: стан за ключем, невживані прибираються) ─────────

    private final Map<String, float[]> anims = new HashMap<>();
    private final Map<String, Long> pressed = new HashMap<>();
    private final Map<String, Double> numLast = new HashMap<>();
    private long frame, frameNs;
    private float dt;

    /** Плавне значення за ключем: щокадру наближається до target (speed — «частка за секунду»). */
    public float anim(String key, float target, float speed) {
        float[] a = anims.get(key);
        if (a == null || Fx.reduced()) { anims.put(key, new float[]{target, frame}); return target; }
        a[1] = frame;
        a[0] += (target - a[0]) * (1 - (float) Math.exp(-speed * dt));
        if (Math.abs(target - a[0]) < 0.003f) a[0] = target;
        return a[0];
    }

    /** Спалах після кліку (0..1, згасає за 260 мс). */
    private float flash(String key) {
        if (Fx.reduced()) return 0;
        Long t = pressed.get(key);
        if (t == null) return 0;
        float f = 1 - (System.currentTimeMillis() - t) / 260f;
        if (f <= 0) { pressed.remove(key); return 0; }
        return f;
    }

    public void begin(GuiGraphics g, int mx, int my) {
        long ns = System.nanoTime();
        dt = frameNs == 0 ? 0 : Math.min(0.1f, (ns - frameNs) / 1e9f);
        frameNs = ns;
        frame++;
        this.g = g;
        this.mx = mx;
        this.my = my;
        tooltip = null;
        focusedHit = false;
        cursorWanted = CUR_ARROW;
    }

    /** Який курсор показати в цьому кадрі (останній виклик перемагає). */
    public void cursor(int shape) { cursorWanted = shape; }

    private void applyCursor() {
        if (cursorWanted == cursorApplied) return;
        cursorApplied = cursorWanted;
        try {
            long win = Minecraft.getInstance().getWindow().getWindow();
            if (cursorWanted == CUR_ARROW) { GLFW.glfwSetCursor(win, 0L); return; }
            if (CURSOR_HANDLES[cursorWanted] == 0L) {
                int shape = switch (cursorWanted) {
                    case CUR_HAND -> GLFW.GLFW_HAND_CURSOR;
                    case CUR_IBEAM -> GLFW.GLFW_IBEAM_CURSOR;
                    case CUR_HRESIZE -> GLFW.GLFW_HRESIZE_CURSOR;
                    default -> GLFW.GLFW_VRESIZE_CURSOR;
                };
                CURSOR_HANDLES[cursorWanted] = GLFW.glfwCreateStandardCursor(shape);
            }
            GLFW.glfwSetCursor(win, CURSOR_HANDLES[cursorWanted]);
        } catch (Throwable ignored) { /* курсор — лише приємність */ }
    }

    /** Повернути стандартний курсор (при закритті екрана). */
    public void releaseCursor() {
        cursorWanted = CUR_ARROW;
        applyCursor();
    }

    public void tipIcon(Icon icon) { if (tooltip != null) tipIcon = icon; }

    public void tipSwatch(int argb) { if (tooltip != null) tipSwatch = argb | 0xFF000000; }

    public void tipPreview(int w, int h, Painter p) { if (tooltip != null) { tipPainter = p; tipPw = w; tipPh = h; } }

    private void startRipple(String key) { ripples.put(key, new long[]{System.currentTimeMillis(), clickX, clickY}); }

    private void drawRipple(String key, int x, int y, int w, int h, int r, int rgb, float strength) {
        long[] rp = ripples.get(key);
        if (rp == null) return;
        if (Fx.reduced()) { ripples.remove(key); return; }
        float t = (System.currentTimeMillis() - rp[0]) / 450f;
        if (t >= 1) { ripples.remove(key); return; }
        Fx.ripple(g, x, y, w, h, r, rp[1], rp[2], t, rgb, strength);
    }

    /** Чи лишився клік для в'юпорту. */
    public long frameNumber() { return frame; }

    public int pendingClick() { return clickUsed ? -1 : click; }

    public int pendingClickX() { return clickX; }

    public int pendingClickY() { return clickY; }

    /** Map pointer events into a zoomed canvas; restore before rendering other panels. */
    public int[] canvasCoordinates(int x, int y, double scale) {
        int[] previous = {mx, my, clickX, clickY};
        mx = (int) Math.floor((mx - x) / scale);
        my = (int) Math.floor((my - y) / scale);
        clickX = (int) Math.floor((clickX - x) / scale);
        clickY = (int) Math.floor((clickY - y) / scale);
        return previous;
    }

    public void restoreCoordinates(int[] previous) {
        mx = previous[0]; my = previous[1]; clickX = previous[2]; clickY = previous[3];
    }

    public boolean pendingDouble() { return dbl && !clickUsed; }

    public void consumeClick() { clickUsed = true; }

    public double pendingScroll() { return scrollUsed ? 0 : scroll; }

    public void consumeScroll() { scrollUsed = true; }

    public int pendingRelease() { return release; }

    public void end() {
        if (tooltip != null && !(isDown(0) || isDown(1) || isDown(2))) {
            long now = System.currentTimeMillis();
            String identity = tooltip.getString();
            if (!identity.equals(lastTooltip)) { lastTooltip = identity; tooltipAt = now; }
            // затримка перед першою підказкою; якщо щойно була інша — показуємо одразу
            long delay = now - tooltipHiddenAt < 450 ? 0 : 320;
            if (now - tooltipAt >= delay) {
                drawTooltip(Fx.outCubic(Fx.progress(now, tooltipAt + delay, 160)));
                tooltipHiddenAt = now;
            }
        } else if (tooltip != null) {
            lastTooltip = null;
        }
        if (tooltip == null) lastTooltip = null;
        applyCursor();
        tipIcon = null; tipSwatch = 0; tipPainter = null;
        if (commitFocused != null && commitFocused.equals(focused)) { focused = null; }
        commitFocused = null;
        click = -1;
        release = -1;
        scroll = 0;
        dbl = false;
        scrollStack.clear();
        clips.clear();
        if (!isDown(0) && !isDown(1) && !isDown(2)) active = null;
        if (frame % 120 == 0) anims.values().removeIf(a -> a[1] < frame - 120);
    }

    // ───────── базове ─────────

    public boolean hover(int x, int y, int w, int h) { return !modalBlocked() && inClip(mx, my) && mx >= x && my >= y && mx < x + w && my < y + h; }

    // ───────── обрізання вводу ─────────
    // Scissor обрізає лише малювання; без цього невидима (обрізана) частина вмісту панелі ловила б кліки й наведення
    // поверх сусідньої панелі («тицяю у фізику, а міняються повороти»). Тому кожна ділянка з scissor має й clip вводу.
    private final ArrayDeque<int[]> clips = new ArrayDeque<>();

    /** Далі кліки й наведення рахуються лише всередині прямокутника (перетин з попереднім). */
    public void pushClip(int x, int y, int w, int h) {
        int[] c = clips.peek();
        int x0 = x, y0 = y, x1 = x + w, y1 = y + h;
        if (c != null) { x0 = Math.max(x0, c[0]); y0 = Math.max(y0, c[1]); x1 = Math.min(x1, c[2]); y1 = Math.min(y1, c[3]); }
        clips.push(new int[]{x0, y0, x1, y1});
    }

    public void popClip() { clips.poll(); }

    private boolean inClip(double px, double py) {
        int[] c = clips.peek();
        return c == null || (px >= c[0] && py >= c[1] && px < c[2] && py < c[3]);
    }

    private boolean inModal;

    /** Позначити, що зараз малюється модальне вікно (його віджети працюють і при modal=true). */
    public void modalBegin() { inModal = true; }

    public void modalEnd() { inModal = false; }

    private boolean modalBlocked() { return modal && !inModal; }

    /** Клік кнопкою button у прямокутнику (з'їдає подію). */
    public boolean clicked(int x, int y, int w, int h, int button) {
        if (click != button || clickUsed || modalBlocked() || !inClip(clickX, clickY)) return false;
        if (clickX < x || clickY < y || clickX >= x + w || clickY >= y + h) return false;
        clickUsed = true;
        return true;
    }

    public boolean doubleClicked(int x, int y, int w, int h) {
        if (!dbl || !inClip(clickX, clickY)) return false;
        if (clickX < x || clickY < y || clickX >= x + w || clickY >= y + h) return false;
        return true;
    }

    /** Натиснули тут — віджет стає активним, поки кнопку не відпустять (для перетягування). */
    public boolean press(String id, int x, int y, int w, int h, int button) {
        if (clicked(x, y, w, h, button)) { active = id; dragStart.put(id, new double[]{mx, my}); return true; }
        return false;
    }

    public boolean isActive(String id) { return id.equals(active); }

    public double[] dragOrigin(String id) { return dragStart.getOrDefault(id, new double[]{mx, my}); }

    public void tip(Component c) {
        if (c == null) return;
        if (tooltip == null || !tooltip.getString().equals(c.getString())) { tipIcon = null; tipSwatch = 0; tipPainter = null; }
        tooltip = c;
        tooltipX = mx;
        tooltipY = my;
    }

    /**
     * Багата підказка: перший рядок — заголовок (з «[клавіша]» у кінці — малюється плашкою), решта — опис.
     * Ліворуч — превʼю: велика іконка, зразок кольору або довільний малюнок. Тримається в межах екрана.
     */
    private void drawTooltip(float reveal) {
        String[] parts = tooltip.getString().split("\n", 2);
        String title = parts[0].strip(), chip = null;
        int lb = title.lastIndexOf('['), rb = title.lastIndexOf(']');
        if (lb > 0 && rb == title.length() - 1 && rb > lb + 1) { chip = title.substring(lb + 1, rb); title = title.substring(0, lb).strip(); }
        var win = Minecraft.getInstance().getWindow();
        int sw = win.getGuiScaledWidth(), sh = win.getGuiScaledHeight();
        boolean pv = tipIcon != null || tipSwatch != 0 || tipPainter != null;
        // ширина тексту не більша за екран: 190 за замовчуванням, але вужче на малих вікнах
        int maxText = Math.max(60, Math.min(160, sw - 24 - (pv ? (tipPainter != null ? tipPw : 18) + 8 : 0) - 10));
        List<net.minecraft.util.FormattedCharSequence> desc = parts.length > 1 && !parts[1].isBlank()
                ? font.split(Component.literal(parts[1].strip().replace("\n", "  ")), maxText) : List.of();
        boolean preview = tipIcon != null || tipSwatch != 0 || tipPainter != null;
        int pw = tipPainter != null ? tipPw : 18, ph = tipPainter != null ? tipPh : 18;
        int chipW = chip == null ? 0 : font.width(chip) + 8;
        // довгий заголовок переноситься, а не вилазить за рамку; плашка клавіші — лише коли заголовок в один рядок
        List<net.minecraft.util.FormattedCharSequence> head = font.width(title) + (chip == null ? 0 : chipW + 6) > maxText
                ? font.split(Component.literal(title), maxText) : List.of();
        if (!head.isEmpty() && chip != null) { title = title + " [" + chip + "]"; chip = null; chipW = 0; head = font.split(Component.literal(title), maxText); }
        int textW = head.isEmpty() ? font.width(title) + (chip == null ? 0 : chipW + 6) : 0;
        for (var l : head) textW = Math.max(textW, font.width(l));
        for (var l : desc) textW = Math.max(textW, font.width(l));
        textW = Math.min(textW, maxText + chipW + 6);
        int titleH = head.isEmpty() ? 10 : head.size() * 10;
        int textH = titleH + (desc.isEmpty() ? 0 : 4 + desc.size() * 10);
        int w = 10 + (preview ? pw + 8 : 0) + textW;
        int h = Math.max(textH, preview ? ph : 0) + 10;
        // місце: праворуч-знизу від курсора → інакше ліворуч / вище; потім жорстко в межі екрана
        int x = tooltipX + 12, y = tooltipY + 14;
        if (x + w > sw - 4) x = tooltipX - w - 10;
        if (y + h > sh - 4) y = tooltipY - h - 8;
        x = Math.max(4, Math.min(x, sw - w - 4));
        y = Math.max(4, Math.min(y, sh - h - 4));
        y += (int) ((1 - reveal) * 4);
        g.flush();
        g.pose().pushPose();
        g.pose().translate(0, 0, 400);
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1, 1, 1, Math.max(0.02f, reveal));
        MenuSkin.pane(g, x, y, w, h);
        int tx = x + 5;
        if (preview) {
            int by = y + 5;
            MenuSkin.field(g, tx - 1, by - 1, pw + 2, ph + 2, false, false);
            if (tipPainter != null) {
                g.enableScissor(tx, by, tx + pw, by + ph);
                try { tipPainter.paint(g, tx, by, pw, ph); } finally { g.disableScissor(); }
            } else if (tipIcon != null) {
                Icons.draw(g, tipIcon, tx + 3, by + 3, ph - 6, 0xFFFFFFFF);
            } else {
                Fx.rrect(g, tx + 3, by + 3, pw - 6, ph - 6, 2, tipSwatch);
            }
            tx += pw + 8;
        }
        // текст по вертикалі в центрі блоку (коли значок вищий за текст — текст не «залипає» догори)
        int ty = y + 5 + (Math.max(textH, preview ? ph : 0) - textH) / 2;
        if (head.isEmpty()) g.drawString(font, title, tx, ty, Theme.TEXT, false);
        else { int hy = ty; for (var l : head) { g.drawString(font, l, tx, hy, Theme.TEXT, false); hy += 10; } }
        if (chip != null) {
            int cx = tx + font.width(title) + 6;
            MenuSkin.field(g, cx, ty - 3, chipW, 13, false, false);
            g.drawString(font, chip, cx + 4, ty - 1, Theme.ACCENT, false);
        }
        int dy = ty + titleH + 4;
        for (var l : desc) { g.drawString(font, l, tx, dy, Theme.MUTED, false); dy += 10; }
        g.flush();
        g.pose().popPose();
        com.mojang.blaze3d.systems.RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    public void text(Component c, int x, int y, int color) { MenuSkin.text(g, font, c, x, y, color); }

    public void text(String s, int x, int y, int color) { MenuSkin.text(g, font, s, x, y, color); }

    /** Текст, обрізаний по ширині з «…». */
    public void textClip(String s, int x, int y, int w, int color) {
        if (font.width(s) > w) s = font.plainSubstrByWidth(s, Math.max(0, w - font.width("…"))) + "…";
        MenuSkin.text(g, font, s, x, y, color);
    }

    public void panel(int x, int y, int w, int h) { MenuSkin.pane(g, x, y, w, h); }

    public void header(String title, int x, int y, int w) {
        g.fill(x, y, x + w, y + 12, MenuSkin.OUTLINE);
        g.fill(x + 1, y + 1, x + w - 1, y + 12, Theme.HEADER);
        g.fill(x + 1, y + 11, x + w - 1, y + 12, MenuSkin.PANE_EDGE);
        textClip(title.toUpperCase(java.util.Locale.ROOT), x + 5, y + 2, w - 10, MenuSkin.SECTION);
    }

    // ───────── віджети ─────────

    public boolean button(int x, int y, int w, int h, Component label, boolean toggled, Component tip) {
        return button(x, y, w, h, label, toggled, tip, true);
    }

    /** Мінімальні розміри елементів керування (GUI-пікселі): менше — і кнопку важко влучити курсором. */
    public static final int MIN_BUTTON_H = 12, MIN_ICON = 11;

    /**
     * Єдина драбина розмірів: кнопки з текстом — 12 (компактні), 14 (звичайні) або 16 (великі); кнопки-іконки — 12, 14 або
     * 16 (більше 20 не чіпаємо — це спеціальні великі кнопки). Раніше в різних панелях були 11, 13, 15, 17, 18… —
     * поруч це виглядало нерівно. Кнопка лишається по центру свого старого місця.
     */
    public static int buttonHeight(int h) { return h <= 13 ? 12 : h <= 15 ? 14 : 16; }
    public static int iconSize(int s) { return s <= 12 ? 12 : s <= 15 ? 14 : s <= 20 ? 16 : s; }

    public boolean button(int x, int y, int w, int h, Component label, boolean toggled, Component tip, boolean enabled) {
        int nh = buttonHeight(h);
        y += (h - nh) / 2;
        h = nh;
        return flatButton(x, y, w, h, label, toggled, tip, enabled);
    }

    /** Кнопка: квадратна, 1-піксельний контур, без анімацій ({@link MenuSkin}). */
    private boolean flatButton(int x, int y, int w, int h, Component label, boolean toggled, Component tip, boolean enabled) {
        boolean over = hover(x, y, w, h);
        boolean hov = over && enabled;
        boolean held = hov && isDown(0) && clickX >= x && clickY >= y && clickX < x + w && clickY < y + h;
        if (hov) cursor(CUR_HAND);
        // плавні стани: наведення, «увімкнено», натискання; після кліку — короткий світлий спалах
        String k = "b" + x + "," + y;
        float hovT = anim(k + "h", hov ? 1 : 0, 22), onT = anim(k + "o", toggled ? 1 : 0, 16), preT = anim(k + "p", held ? 1 : 0, 45);
        MenuSkin.buttonT(g, x, y, w, h, hovT, preT, onT, enabled);
        float fl = flash(k);
        if (fl > 0 && h >= 12) g.fill(x + 2, y + 2, x + w - 2, y + h - 2, Fx.withAlpha(0xFFFFFF, 0.24f * fl));
        String s = label.getString();
        int tw = font.width(s);
        int tc = enabled ? Fx.lerp(0xFFD6E0F5, 0xFFFFFFFF, Math.max(hovT, onT)) : 0xFF7080A0;
        int ty = y + (h - 8) / 2 + (held ? 1 : 0);
        if (tw > w - 6) textClip(s, x + 3, ty, w - 6, tc);
        else MenuSkin.text(g, font, s, x + (w - tw) / 2, ty, tc);
        if (over) {
            if (tip != null) tip(tip);
            else if (tw > w - 6) tip(label);
        }
        boolean clk = enabled && clicked(x, y, w, h, 0);
        if (clk) pressed.put(k, System.currentTimeMillis());
        return clk;
    }

    /** Кнопка-іконка: пласка (контур лише при наведенні/увімкненні) або завжди в рамці, як кнопки панелі інструментів. */
    private boolean flatIcon(int x, int y, int size, Icon icon, boolean toggled, Component tip, boolean enabled, boolean framed) {
        boolean over = hover(x, y, size, size);
        boolean hov = over && enabled;
        if (hov) cursor(CUR_HAND);
        boolean held = hov && isDown(0);
        String k = "i" + x + "," + y;
        float hv = anim(k + "h", hov ? 1 : 0, 22), onT = anim(k + "o", toggled ? 1 : 0, 16);
        // рамка проявляється плавно (у «пласких» значків — лише при наведенні/увімкненні)
        if (framed || onT > 0.02f || hv > 0.02f) {
            MenuSkin.buttonT(g, x, y, size, size, hv, held ? 1 : 0, onT, enabled);
        }
        // у рамці значок лежить усередині неї (2 px контур + рамка) і по центру; без рамки — на весь розмір
        int in = framed ? Math.max(8, size - 4) : size;
        int off = (size - in) / 2;
        int ic = !enabled ? 0x60FFFFFF : Fx.lerp(0xFFC8D4EE, 0xFFFFFFFF, Math.max(hv, onT));
        // «пружинка»: значок трохи збільшується під курсором і стискається при натисканні;
        // шестерня, «×» і «+» ще й обертаються (при наведенні на чверть оберту, після кліку — повний оберт)
        float sc = 1 + 0.14f * hv - (held ? 0.12f : 0);
        float cx = x + off + in / 2f, cy = y + off + in / 2f;
        boolean spin = icon == Icon.SETTINGS || icon == Icon.CLOSE || icon == Icon.PLUS;
        float rot = spin ? 90f * hv + 360f * (1f - flash(k)) : 0f;
        boolean xf = Math.abs(sc - 1) > 0.01f || (spin && !Fx.reduced());
        if (xf) {
            g.pose().pushPose();
            g.pose().translate(cx, cy, 0);
            if (spin && !Fx.reduced()) g.pose().mulPose(com.mojang.math.Axis.ZP.rotationDegrees(rot));
            g.pose().scale(sc, sc, 1);
            g.pose().translate(-cx, -cy, 0);
        }
        Icons.draw(g, icon, x + off, y + off, in, ic);
        if (xf) g.pose().popPose();
        if (over && tip != null) { tip(tip); tipIcon(icon); }
        boolean clk = enabled && clicked(x, y, size, size, 0);
        if (clk) pressed.put(k, System.currentTimeMillis());
        float fl = flash(k);
        if (fl > 0 && framed) g.fill(x + 2, y + 2, x + size - 2, y + size - 2, Fx.withAlpha(0xFFFFFF, 0.24f * fl));
        return clk;
    }

    /** Кнопка-іконка панелей інструментів: завжди в рамці, значок по центру. */
    public boolean iconButton(int x, int y, int size, Icon icon, boolean toggled, Component tip) { return iconButton(x, y, size, icon, toggled, tip, true); }

    public boolean iconButton(int x, int y, int size, Icon icon, boolean toggled, Component tip, boolean enabled) {
        int ns = iconSize(size);
        return flatIcon(x + (size - ns) / 2, y + (size - ns) / 2, ns, icon, toggled, tip, enabled, true);
    }

    /** Кнопка-іконка: без фону, доки не наведено/не увімкнено (мінімалістично, як панелі Blockbench). */
    public boolean icon(int x, int y, int size, Icon icon, boolean toggled, Component tip) { return icon(x, y, size, icon, toggled, tip, true); }

    public boolean icon(int x, int y, int size, Icon icon, boolean toggled, Component tip, boolean enabled) {
        int ns = iconSize(size);
        x += (size - ns) / 2;
        y += (size - ns) / 2;
        return flatIcon(x, y, ns, icon, toggled, tip, enabled, false);
    }

    /** Shared reversible row feedback for menus and the scene tree. */
    public void animatedRow(String id,int x,int y,int w,int h,boolean selected,boolean hovered) {
        // наведення й вибір наростають/згасають плавно (раніше перемикались миттєво)
        float hv = anim("rh." + id, hovered ? 1 : 0, 24), sv = anim("rs." + id, selected ? 1 : 0, 18);
        MenuSkin.rowT(g, x, y, w, h, hv, sv);
    }

    public boolean checkbox(int x, int y, int w, Component label, boolean value, Component tip) {
        boolean over = hover(x, y - 1, w, 12);
        if (over) cursor(CUR_HAND);
        String k = "c" + x + "," + y;
        float hv = anim(k + "h", over ? 1 : 0, 22), on = anim(k + "o", value ? 1 : 0, 20);
        MenuSkin.checkboxT(g, x, y - 1, hv, on);
        textClip(label.getString(), x + 15, y, w - 15, Fx.lerp(MenuSkin.LABEL, 0xFFFFFFFF, Math.max(hv, on)));
        if (over && tip != null) tip(tip);
        return clicked(x, y - 1, w, 12, 0);
    }

    /** Результат числового поля: значення і фаза (почали тягнути / тягнемо / відпустили чи ввели). */
    public record Num(double value, Phase phase) {
        public enum Phase { NONE, START, CHANGE, COMMIT }
        public boolean live() { return phase == Phase.START || phase == Phase.CHANGE; }
        public boolean any() { return phase != Phase.NONE; }
    }

    /**
     * Числове поле як у Blockbench: тягни мишею вліво-вправо — значення змінюється (Shift — точніше, Ctrl — грубіше),
     * клікни без руху — введи з клавіатури (Enter — застосувати, Esc — скасувати). Підтримує вирази: «8+4», «16/3».
     */
    public Num number(String id, int x, int y, int w, int h, double value, double step, int accent) {
        boolean editing = id.equals(focused);
        boolean hov = hover(x, y, w, h);
        float focus=anim("number.focus."+id,editing?1:0,24);
        float hv=anim("number.hover."+id,hov?1:0,24);
        if (hov || isActive(id)) cursor(editing ? CUR_IBEAM : CUR_HRESIZE);
        MenuSkin.field(g, x, y, w, h, hov, editing);
        // поле осі X/Y/Z: колірна смужка зліва й ледь помітний відтінок — одразу видно, яка це вісь (червона/зелена/синя)
        boolean axisField = accent == Theme.AXIS_X || accent == Theme.AXIS_Y || accent == Theme.AXIS_Z;
        if (axisField) {
            int ins = h < 14 ? 1 : 2;
            g.fill(x + ins, y + ins, x + w - ins, y + h - ins, Theme.withAlpha(accent, 0x16));
            g.fill(x + ins, y + ins, x + ins + 2, y + h - ins, 0xFF000000 | (accent & 0xFFFFFF));
        }
        focusLine(x, y, w, h, focus);
        // значення змінилось ззовні (гізмо, скрипт, інша панель) — поле коротко спалахує кольором осі
        Double prevNum = numLast.put(id, value);
        if (prevNum != null && Math.abs(prevNum - value) > 1e-9 && !editing && !isActive(id)) pressed.put("n" + id, System.currentTimeMillis());
        float nf = flash("n" + id);
        if (nf > 0) {
            int ins2 = h < 14 ? 1 : 2;
            g.fill(x + ins2, y + ins2, x + w - ins2, y + h - ins2, Fx.withAlpha(axisField ? accent : Theme.ACCENT, 0.32f * nf));
        }
        if (numLast.size() > 4000) numLast.clear();
        if (editing) {
            focusedHit |= hover(x, y, w, h) && click == 0;
            StringBuilder b = buffers.computeIfAbsent(id, k -> new StringBuilder(fmt(value)));
            drawEditText(id, b, x + 3, y + (h - 8) / 2, w - 6);
            String commit = takeCommit(id);
            if (commit != null) {
                Double v = Expr.eval(commit);
                return v == null ? new Num(value, Num.Phase.NONE) : new Num(v, Num.Phase.COMMIT);
            }
            return new Num(value, Num.Phase.NONE);
        }
        String s = fmt(value);
        g.drawString(font, s, x + (w - font.width(s)) / 2, y + (h - 8) / 2, Theme.TEXT, false);
        if (hov && !isActive(id)) {
            long win = Minecraft.getInstance().getWindow().getWindow();
            double k = InputConstants.isKeyDown(win, GLFW.GLFW_KEY_LEFT_SHIFT) ? 0.1 : InputConstants.isKeyDown(win, GLFW.GLFW_KEY_LEFT_CONTROL) ? 10 : 1;
            double st = step * k;
            // «−» і «+» на краях поля (видно при наведенні): однакові смуги 9 px усередині рамки, знак по центру смуги
            if (w >= 36) {
                int ins = h < 14 ? 1 : 2, sw = 9;
                int lx = x + ins, rx = x + w - ins - sw, sy = y + ins, sh = h - 2 * ins;
                boolean hl = hover(lx, sy, sw, sh), hr = hover(rx, sy, sw, sh);
                g.fill(lx, sy, lx + sw, sy + sh, Fx.mulAlpha(hl ? 0x50FFFFFF : 0x28FFFFFF, Math.max(0.15f, hv)));
                g.fill(rx, sy, rx + sw, sy + sh, Fx.mulAlpha(hr ? 0x50FFFFFF : 0x28FFFFFF, Math.max(0.15f, hv)));
                int cy = y + h / 2;
                // «−»: 5×1; «+»: 5×1 і 1×5 — малюємо прямокутниками, а не символами шрифту, щоб центр був точним
                int lcx = lx + sw / 2, rcx = rx + sw / 2;
                int mc = hl ? 0xFFFFFFFF : Theme.MUTED, pc = hr ? 0xFFFFFFFF : Theme.MUTED;
                g.fill(lcx - 2, cy, lcx + 3, cy + 1, mc);
                g.fill(rcx - 2, cy, rcx + 3, cy + 1, pc);
                g.fill(rcx, cy - 2, rcx + 1, cy + 3, pc);
                if (clicked(lx, sy, sw, sh, 0)) return new Num(snapStep(value - st, st), Num.Phase.COMMIT);
                if (clicked(rx, sy, sw, sh, 0)) return new Num(snapStep(value + st, st), Num.Phase.COMMIT);
            }
            // колесо миші над полем — крок угору/вниз (Shift — точніше, Ctrl — грубіше)
            if (scroll != 0 && !scrollUsed) {
                scrollUsed = true;
                return new Num(snapStep(value + Math.signum(scroll) * st, st), Num.Phase.COMMIT);
            }
        }
        if (press(id, x, y, w, h, 0)) { drags.put(id, new NumDrag(value)); return new Num(value, Num.Phase.NONE); }
        NumDrag d = drags.get(id);
        if (!isActive(id) || d == null) { drags.remove(id); return new Num(value, Num.Phase.NONE); }
        double dx = mx - dragOrigin(id)[0];
        if (!d.moved && Math.abs(dx) >= 2) d.moved = true;
        if (d.moved) {
            long win = Minecraft.getInstance().getWindow().getWindow();
            double k = InputConstants.isKeyDown(win, GLFW.GLFW_KEY_LEFT_SHIFT) ? 0.1 : InputConstants.isKeyDown(win, GLFW.GLFW_KEY_LEFT_CONTROL) ? 10 : 1;
            double st = step * k;
            double nv = Math.round((d.start + Math.round(dx / 2) * st) / st) * st;
            if (release == 0) { drags.remove(id); active = null; return new Num(nv, Num.Phase.COMMIT); }
            Num.Phase ph = d.started ? Num.Phase.CHANGE : Num.Phase.START;
            d.started = true;
            drawScrubBubble(x, y, w, nv, nv - d.start, accent);
            return new Num(nv, ph);
        }
        if (release == 0) {
            // клік без руху — режим введення з клавіатури
            drags.remove(id);
            active = null;
            focus(id, fmt(value));
        }
        return new Num(value, Num.Phase.NONE);
    }

    /** Плаваюча «бульбашка» над полем, поки значення тягнуть: нове значення і зміна. */
    private void drawScrubBubble(int x, int y, int w, double value, double delta, int accent) {
        String main = fmt(value);
        String d = (delta >= 0 ? "+" : "") + fmt(delta);
        int bw = Math.max(font.width(main) + 12, font.width(d) + 12), bh = 22;
        int bx = Math.max(2, x + w / 2 - bw / 2), by = Math.max(2, y - bh - 5);
        g.pose().pushPose();
        g.pose().translate(0, 0, 350);
        Fx.panel(g, bx, by, bw, bh, 4, accent, 1, 0.5f);
        g.drawString(font, main, bx + (bw - font.width(main)) / 2, by + 3, Theme.TEXT, false);
        g.drawString(font, d, bx + (bw - font.width(d)) / 2, by + 12, delta == 0 ? Theme.MUTED : delta > 0 ? Theme.OK : Theme.WARN, false);
        g.fill(bx + bw / 2 - 2, by + bh, bx + bw / 2 + 2, by + bh + 1, Fx.withAlpha(accent, 0.8f));
        g.pose().popPose();
    }

    private static double snapStep(double v, double st) {
        double r = Math.round(v / st) * st;
        return Math.abs(r) < 1e-9 ? 0 : Math.round(r * 1e6) / 1e6;
    }

    private static final class NumDrag {
        final double start;
        boolean moved, started;
        NumDrag(double start) { this.start = start; }
    }

    private final Map<String, NumDrag> drags = new HashMap<>();

    /** Текстове поле. @return введений текст при Enter/втраті фокусу, інакше null. */
    public String textField(String id, int x, int y, int w, int h, String value, Component placeholder) {
        boolean editing = id.equals(focused);
        boolean hov = hover(x, y, w, h);
        float focus = anim("field.focus." + id, editing ? 1 : 0, 20);
        float fieldHover = anim("field.hover." + id, hov ? 1 : 0, 24);
        if (hov) cursor(CUR_IBEAM);
        MenuSkin.field(g, x, y, w, h, hov, editing);
        focusLine(x, y, w, h, focus);
        if (editing) {
            focusedHit |= hover(x, y, w, h) && click == 0;
            StringBuilder b = buffers.computeIfAbsent(id, k -> new StringBuilder(value));
            drawEditText(id, b, x + 3, y + (h - 8) / 2, w - 6);
            return takeCommit(id);
        }
        if (value.isEmpty() && placeholder != null) textClip(placeholder.getString(), x + 3, y + (h - 8) / 2, w - 6, Theme.MUTED);
        else textClip(value, x + 3, y + (h - 8) / 2, w - 6, Theme.TEXT);
        if (clicked(x, y, w, h, 0)) {
            focus(id, value);
        }
        return null;
    }

    /** Акцентний рядок під полем у фокусі: розростається від центру до країв. */
    private void focusLine(int x, int y, int w, int h, float focus) {
        if (focus <= 0.01f) return;
        int ins = h < 14 ? 1 : 2, half = Math.round((w - 2 * ins) / 2f * focus);
        int cx = x + w / 2;
        g.fill(cx - half, y + h - ins - 1, cx + half, y + h - ins, Fx.withAlpha(Theme.ACCENT, Math.min(1f, focus * 1.2f)));
    }

    /** Живий текст поля (для пошуку, що фільтрує під час набору). */
    public String liveText(String id, String fallback) {
        StringBuilder b = buffers.get(id);
        return id.equals(focused) && b != null ? b.toString() : fallback;
    }

    public void focus(String id, String value) {
        focused = id;
        buffers.put(id, new StringBuilder(value));
        cursors.put(id, value.length());
        anchors.put(id, value.length());
    }

    private final Set<String> commits = new HashSet<>();

    private String takeCommit(String id) {
        if (commits.remove(id) || id.equals(commitFocused)) {
            StringBuilder b = buffers.remove(id);
            if (id.equals(focused)) focused = null;
            return b == null ? null : b.toString();
        }
        return null;
    }

    private void drawEditText(String id, StringBuilder b, int x, int y, int w) {
        int cur = Math.min(cursors.getOrDefault(id, b.length()), b.length());
        String s = b.toString();
        int start = 0;
        while (font.width(s.substring(start, cur)) > w - 4 && start < cur) start++;
        String vis = font.plainSubstrByWidth(s.substring(start), w);
        int anchor = Math.min(anchors.getOrDefault(id, cur), s.length());
        int lo = Math.max(start, Math.min(anchor, cur)), hi = Math.min(start+vis.length(), Math.max(anchor,cur));
        if (hi>lo) g.fill(x+font.width(s.substring(start,lo)),y-1,x+font.width(s.substring(start,hi)),y+9,0x99528DE0);
        g.drawString(font, vis, x, y, Theme.TEXT, false);
        if ((System.currentTimeMillis() / 500) % 2 == 0) {
            int cx = x + font.width(s.substring(start, cur));
            g.fill(cx, y - 1, cx + 1, y + 9, Theme.ACCENT);
        }
    }

    /** @return true, якщо клавішу забрало текстове поле */
    public boolean onKey(int key, int mods) {
        if (focused == null) return false;
        StringBuilder b = buffers.get(focused);
        if (b == null) { focused = null; return false; }
        int cur = Math.min(cursors.getOrDefault(focused, b.length()), b.length());
        boolean ctrl = (mods & GLFW.GLFW_MOD_CONTROL) != 0;
        boolean shift = (mods & GLFW.GLFW_MOD_SHIFT) != 0;
        int anchor = Math.min(anchors.getOrDefault(focused,cur),b.length());
        int lo=Math.min(cur,anchor), hi=Math.max(cur,anchor);
        switch (key) {
            case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER, GLFW.GLFW_KEY_TAB -> commits.add(focused);
            case GLFW.GLFW_KEY_ESCAPE -> { buffers.remove(focused); anchors.remove(focused); focused=null; }
            case GLFW.GLFW_KEY_BACKSPACE, GLFW.GLFW_KEY_DELETE -> {
                if(hi>lo) { b.delete(lo,hi); cur=lo; }
                else if(key==GLFW.GLFW_KEY_BACKSPACE && cur>0) { b.deleteCharAt(cur-1); cur--; }
                else if(key==GLFW.GLFW_KEY_DELETE && cur<b.length()) b.deleteCharAt(cur);
                anchor=cur;
            }
            case GLFW.GLFW_KEY_LEFT -> { cur=!shift && hi>lo?lo:Math.max(0,cur-1); if(!shift) anchor=cur; }
            case GLFW.GLFW_KEY_RIGHT -> { cur=!shift && hi>lo?hi:Math.min(b.length(),cur+1); if(!shift) anchor=cur; }
            case GLFW.GLFW_KEY_HOME -> { cur=0; if(!shift) anchor=cur; }
            case GLFW.GLFW_KEY_END -> { cur=b.length(); if(!shift) anchor=cur; }
            case GLFW.GLFW_KEY_A -> { if(ctrl) { anchor=0; cur=b.length(); } }
            case GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_X -> {
                if(ctrl && hi>lo) {
                    Minecraft.getInstance().keyboardHandler.setClipboard(b.substring(lo,hi));
                    if(key==GLFW.GLFW_KEY_X) { b.delete(lo,hi); cur=lo; anchor=cur; }
                }
            }
            case GLFW.GLFW_KEY_V -> {
                if(ctrl) {
                    String clip=Minecraft.getInstance().keyboardHandler.getClipboard().replaceAll("[\\r\\n\\t]"," ");
                    int room=Math.max(0,256-(b.length()-(hi-lo)));
                    clip=clip.substring(0,Math.min(room,clip.length()));
                    b.replace(lo,hi,clip); cur=lo+clip.length(); anchor=cur;
                }
            }
            default -> { }
        }
        if(focused!=null) { cursors.put(focused,cur); anchors.put(focused,anchor); }
        // поле з фокусом забирає всі клавіші: у редакторі не спрацює ні гаряча клавіша, ні клавіша гри
        return true;
    }

    public boolean onChar(char c) {
        if(focused==null) return false;
        StringBuilder b=buffers.get(focused);
        if(b==null || c<32) return true;
        int cur=Math.min(cursors.getOrDefault(focused,b.length()),b.length());
        int anchor=Math.min(anchors.getOrDefault(focused,cur),b.length());
        int lo=Math.min(cur,anchor),hi=Math.max(cur,anchor);
        if(b.length()-(hi-lo)>=256) return true;
        b.replace(lo,hi,String.valueOf(c));
        cursors.put(focused,lo+1); anchors.put(focused,lo+1);
        return true;
    }

    // ───────── прокрутка ─────────

    /** Початок прокручуваної ділянки; повертає зсув. Вміст треба малювати зі зсувом -offset. */
    /** Прокручувані ділянки, що чекають на колесо: його спершу можуть забрати поля всередині (число під курсором). */
    private final ArrayDeque<Object[]> scrollStack = new ArrayDeque<>();

    private final Map<String, Double> scrollShown = new HashMap<>();

    public int scrollBegin(String id, int x, int y, int w, int h, int contentH) {
        double max = Math.max(0, contentH - h);
        double target = Math.max(0, Math.min(max, scrolls.getOrDefault(id, 0.0)));
        scrolls.put(id, target);
        double shown = scrollShown.getOrDefault(id, target);
        if (Fx.reduced() || Math.abs(shown - target) < 0.4) shown = target;
        else shown += (target - shown) * (1 - Math.exp(-20 * Math.max(dt, 0.001f)));
        shown = Math.max(0, Math.min(max, shown));
        scrollShown.put(id, shown);
        scrollStack.push(new Object[]{id, hover(x, y, w, h), (int) max, x, y, w, h, contentH});
        g.enableScissor(x, y, x + w, y + h);
        scissorDepth++;
        pushClip(x, y, w, h);
        return (int) Math.round(shown);
    }

    public void scrollEnd() {
        Object[] r = scrollStack.poll();
        if (r != null) {
            String id = (String) r[0];
            int max = (int) r[2], x = (int) r[3], y = (int) r[4], w = (int) r[5], h = (int) r[6], contentH = (int) r[7];
            if (max > 0) {
                double off = scrollShown.getOrDefault(id, 0.0);
                // тінь по краях показує, що за межею є ще вміст
                int barH = Math.max(14, h * h / contentH);
                int barY = y + (int) ((h - barH) * (off / Math.max(1, max)));
                boolean hovBar = hover(x + w - MenuSkin.SCROLL_W, barY, MenuSkin.SCROLL_W, barH);
                String sid = "sb." + id;
                // ловимо клік лише тут — після вмісту, тож кнопки біля краю панелі не втрачають кліки
                if (press(sid, x + w - MenuSkin.SCROLL_W, barY, MenuSkin.SCROLL_W, barH, 0)) dragStart.put(sid, new double[]{my - barY, 0});
                boolean dragging = isActive(sid);
                if (dragging) {
                    double grab = dragStart.get(sid)[0];
                    double f = (my - grab - y) / Math.max(1.0, h - barH);
                    double nt = Math.max(0, Math.min(max, f * max));
                    scrolls.put(id, nt);
                    scrollShown.put(id, nt);
                    barY = y + (int) ((h - barH) * (nt / Math.max(1, max)));
                }
                if (hovBar || dragging) cursor(CUR_HAND);
                float sbVis = anim("sbv." + id, hovBar || dragging || (boolean) r[1] ? 1f : 0.4f, 10);
                MenuSkin.scrollbar(g, x + w - MenuSkin.SCROLL_W, y, h, barY, barH, hovBar || dragging, sbVis);
            }
        }
        popClip();
        if (scissorDepth > 0) { g.disableScissor(); scissorDepth--; }
        // колесо ніхто всередині не забрав — прокручуємо ділянку (плавно доїжджає до цілі)
        if (r != null && (boolean) r[1] && scroll != 0 && !scrollUsed) {
            scrollUsed = true;
            String id = (String) r[0];
            scrolls.put(id, Math.max(0, Math.min((int) r[2], scrolls.getOrDefault(id, 0.0) - scroll * 26)));
        }
    }

    public void scrollTo(String id, double off) { scrolls.put(id, off); }

    /** Поточна ціль прокрутки (куди доїжджає ділянка). */
    public double scrollTarget(String id) { return scrolls.getOrDefault(id, 0.0); }

    /** Миттєво (без анімації) поставити прокрутку. */
    public void scrollJump(String id, double off) { scrolls.put(id, off); scrollShown.put(id, off); }

    public static String fmt(double v) {
        if (Math.abs(v - Math.rint(v)) < 1e-6) return String.valueOf((long) Math.rint(v));
        String s = String.format(Locale.ROOT, "%.3f", v);
        s = s.replaceAll("0+$", "");
        return s.endsWith(".") ? s.substring(0, s.length() - 1) : s;
    }
}
