package dev.shaurmalib.scene.mc.mixin;

import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.mc.client.SceneCamera;
import net.minecraft.client.Camera;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Камера сцени/редактора поверх ванільної (після камери анімацій — пріоритет вищий). */
@Mixin(value = Camera.class, priority = 1100)
public abstract class MixinSceneCamera {

    @Shadow protected abstract void setPosition(Vec3 pos);
    @Shadow protected abstract void setRotation(float yRot, float xRot);

    @Inject(method = "setup", at = @At("TAIL"))
    private void shaurma$scene$camera(BlockGetter level, Entity entity, boolean detached, boolean mirrored, float partial, CallbackInfo ci) {
        SceneFrame.Cam c = SceneCamera.pose(partial);
        if (c == null) return;
        setRotation(c.yaw, c.pitch);
        setPosition(new Vec3(c.x, c.y, c.z));
    }
}
