package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.api.SceneDefinition;
import dev.shaurmalib.scene.api.SceneRegistry;
import dev.shaurmalib.scene.mc.client.SceneClient;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Вибір сцени для редагування: лише сцени, які зареєстрував мод (каталог з сервера — ревізія у світі,
 * чи є право редагувати). Відкривається клавішею редактора сцен або {@code /scene edit <id>}.
 */
public final class ScenePickerScreen extends Screen {

    private final Gui gui = new Gui();

    public ScenePickerScreen() { super(Component.literal("Сцени")); }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        g.fill(0, 0, width, height, 0x88000000);
        gui.begin(g, mx, my);
        int w = Math.min(360, width - 20), x = (width - w) / 2;
        var cat = SceneClient.catalog();
        int rows = Math.max(1, SceneRegistry.all().size());
        int h = Math.min(height - 20, 40 + rows * 30);
        int y = (height - h) / 2;
        MenuSkin.window(g, x, y, w, h);
        gui.text("Редактор сцен — оберіть сцену", x + 8, y + 7, MenuSkin.TITLE);
        int cy = y + 24;
        if (SceneRegistry.all().isEmpty()) gui.text("Жоден мод не зареєстрував сцен", x + 8, cy + 4, Theme.MUTED);
        for (SceneDefinition d : SceneRegistry.all()) {
            String info = "не змонтована";
            boolean editable = false;
            for (String s : cat) {
                String[] p = s.split("\\|");
                if (p.length == 3 && p[0].equals(d.id)) {
                    int rev = Integer.parseInt(p[1]);
                    info = rev < 0 ? "порожня" : "ревізія " + rev;
                    editable = "1".equals(p[2]);
                }
            }
            boolean hov = gui.hover(x + 6, cy, w - 12, 26);
            g.fill(x + 6, cy, x + w - 6, cy + 26, hov ? MenuSkin.ROW_HOT : MenuSkin.PANE);
            gui.text(d.title, x + 12, cy + 4, Theme.TEXT);
            gui.textClip(d.id + " · " + info + " · слоти: " + d.slots.size(), x + 12, cy + 15, w - 100, Theme.MUTED);
            if (gui.button(x + w - 76, cy + 6, 64, 14, Component.literal(editable ? "Редагувати" : "Немає прав"), false, null, editable)) {
                SceneClient.requestEdit(d.id);
            }
            cy += 30;
        }
        gui.end();
    }

    @Override public boolean mouseClicked(double x, double y, int b) { gui.onClick(x, y, b); return true; }

    @Override public boolean mouseReleased(double x, double y, int b) { gui.onRelease(b); return true; }
}
