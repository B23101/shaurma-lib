package dev.shaurmalib.scene.mc.client;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.properties.Property;
import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.entity.SkullBlockEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Скін актора за політикою об'єкта: стандартний, гравця зі слота (за UUID / текстурою з сервера),
 * конкретного профілю (нік — з табу або Mojang), текстура-ассет або гравець, який ДИВИТЬСЯ сцену.
 */
public final class SceneSkins {

    private SceneSkins() {}

    public record Skin(ResourceLocation texture, boolean slim) {}

    private static final Map<String, Skin> CACHE = new HashMap<>();
    private static final Map<String, GameProfile> PROFILES = new HashMap<>();

    public static Skin resolve(SceneObject o, SceneBindings.Binding binding, SceneDoc doc) {
        Skin s = switch (o.skinMode) {
            case SLOT -> binding == null ? null : ofBinding(binding);
            case VIEWER -> viewer();
            case PROFILE -> o.skinValue == null ? null : ofName(o.skinValue);
            case TEXTURE -> {
                ResourceLocation rl = o.skinValue == null ? null
                    : o.skinValue.contains(":") ? ResourceLocation.tryParse(o.skinValue) : SceneAssets.texture(doc, o.skinValue);
                yield rl == null ? null : new Skin(rl, Boolean.TRUE.equals(o.slim));
            }
            case DEFAULT -> binding != null && o.modelType == SceneObject.ModelType.PLAYER ? ofBinding(binding) : null;
        };
        if (s == null) {
            UUID id = binding != null && binding.uuid != null ? binding.uuid : new UUID(0, o.id.hashCode());
            s = new Skin(DefaultPlayerSkin.getDefaultSkin(id), "slim".equals(DefaultPlayerSkin.getSkinModelName(id)));
        }
        if (o.slim != null && s.slim != o.slim) s = new Skin(s.texture, o.slim);
        return s;
    }

    public static Skin viewer() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return null;
        return new Skin(mc.player.getSkinTextureLocation(), "slim".equals(mc.player.getModelName()));
    }

    public static Skin ofBinding(SceneBindings.Binding b) {
        if (b.uuid != null) {
            Minecraft mc = Minecraft.getInstance();
            PlayerInfo info = mc.getConnection() == null ? null : mc.getConnection().getPlayerInfo(b.uuid);
            if (info != null) return new Skin(info.getSkinLocation(), b.slim != null ? b.slim : "slim".equals(info.getModelName()));
        }
        if (b.skinTexture != null) {
            String key = "tex:" + b.skinTexture.hashCode();
            Skin cached = CACHE.get(key);
            if (cached != null) return cached;
            GameProfile p = new GameProfile(b.uuid == null ? UUID.randomUUID() : b.uuid, b.name == null ? "scene" : b.name);
            p.getProperties().put("textures", new Property("textures", b.skinTexture, b.skinSignature));
            Skin s = fromProfile(p, b.slim);
            if (s != null) CACHE.put(key, s);
            return s;
        }
        return b.name != null ? ofName(b.name) : null;
    }

    public static Skin ofName(String name) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.getConnection() != null) {
            PlayerInfo info = mc.getConnection().getPlayerInfo(name);
            if (info != null) return new Skin(info.getSkinLocation(), "slim".equals(info.getModelName()));
        }
        String key = "name:" + name.toLowerCase(java.util.Locale.ROOT);
        Skin cached = CACHE.get(key);
        if (cached != null) return cached;
        GameProfile p = PROFILES.get(key);
        if (p == null) {
            PROFILES.put(key, new GameProfile(null, name));
            SkullBlockEntity.updateGameprofile(new GameProfile(null, name), full -> PROFILES.put(key, full));
            return null;
        }
        if (p.getId() == null) return null;
        Skin s = fromProfile(p, null);
        if (s != null) CACHE.put(key, s);
        return s;
    }

    private static Skin fromProfile(GameProfile p, Boolean slim) {
        Minecraft mc = Minecraft.getInstance();
        Map<MinecraftProfileTexture.Type, MinecraftProfileTexture> tex = mc.getSkinManager().getInsecureSkinInformation(p);
        MinecraftProfileTexture skin = tex.get(MinecraftProfileTexture.Type.SKIN);
        if (skin == null) return null;
        ResourceLocation rl = mc.getSkinManager().registerTexture(skin, MinecraftProfileTexture.Type.SKIN);
        boolean s = slim != null ? slim : "slim".equals(skin.getMetadata("model"));
        return new Skin(rl, s);
    }
}
