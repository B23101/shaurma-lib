package dev.shaurmalib.scene.mc.client;

import dev.shaurmalib.scene.eval.SceneFrame;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Оверлеї й ефекти, які можна ставити на таймлайн. Мод реєструє свої ({@code maniac:victory_title}),
 * редактор показує їх у списку, сцена кличе з прогресом/непрозорістю/інтенсивністю кадру.
 *
 * <pre>{@code
 * SceneOverlays.overlay("maniac:victory_title", "Титул перемоги", (g, w, h, o, alpha) -> VictoryTitleFx.draw(g, w, h, o.local, alpha));
 * SceneOverlays.effect("maniac:blood_edges", "Кров по краях", (g, w, h, e) -> HudFx.edgeFrame(g, w, h, 0x7A0000, (float) e.intensity * 0.6f, 0.2f));
 * }</pre>
 */
public final class SceneOverlays {

    private SceneOverlays() {}

    @FunctionalInterface
    public interface OverlayRenderer {
        /** @param alpha непрозорість з урахуванням появи/зникнення й кривої opacity */
        void render(GuiGraphics g, int w, int h, SceneFrame.Overlay o, float alpha);
    }

    @FunctionalInterface
    public interface EffectRenderer {
        void render(GuiGraphics g, int w, int h, SceneFrame.Effect e);
    }

    public record Entry<T>(String id, String title, T renderer) {}

    private static final Map<String, Entry<OverlayRenderer>> OVERLAYS = new LinkedHashMap<>();
    private static final Map<String, Entry<EffectRenderer>> EFFECTS = new LinkedHashMap<>();

    public static void overlay(String id, String title, OverlayRenderer r) { OVERLAYS.put(id, new Entry<>(id, title, r)); }

    public static void effect(String id, String title, EffectRenderer r) { EFFECTS.put(id, new Entry<>(id, title, r)); }

    public static Collection<Entry<OverlayRenderer>> overlays() { return OVERLAYS.values(); }

    public static Collection<Entry<EffectRenderer>> effects() { return EFFECTS.values(); }

    public static OverlayRenderer overlay(String id) { Entry<OverlayRenderer> e = OVERLAYS.get(id); return e == null ? null : e.renderer; }

    public static EffectRenderer effect(String id) { Entry<EffectRenderer> e = EFFECTS.get(id); return e == null ? null : e.renderer; }

    static {
        // ── вбудовані оверлеї ──
        overlay("shaurma_lib:title", "Титул (текст)", (g, w, h, o, a) -> {
            String text = String.valueOf(o.params.getOrDefault("text", "ТИТУЛ"));
            String sub = o.params.containsKey("subtitle") ? String.valueOf(o.params.get("subtitle")) : null;
            int color = (int) num(o.params.get("color"), 0xFFFFFF);
            float s = (float) (o.scale * 3);
            var font = Minecraft.getInstance().font;
            g.pose().pushPose();
            g.pose().translate(w * o.x, h * o.y, 0);
            g.pose().scale(s, s, 1);
            int tw = font.width(text);
            g.drawString(font, Component.literal(text), -tw / 2, -4, argb(a, color), true);
            g.pose().popPose();
            if (sub != null) {
                int sw = font.width(sub);
                g.drawString(font, sub, (int) (w * o.x) - sw / 2, (int) (h * o.y + 6 * s), argb(a * 0.85f, 0xDDDDDD), true);
            }
        });
        overlay("shaurma_lib:subtitle", "Субтитр", (g, w, h, o, a) -> {
            String text = String.valueOf(o.params.getOrDefault("text", "..."));
            var font = Minecraft.getInstance().font;
            int tw = font.width(text);
            int x = (int) (w * o.x) - tw / 2, y = (int) (h * (o.y == 0.5 ? 0.82 : o.y));
            g.fill(x - 4, y - 3, x + tw + 4, y + 11, argb(a * 0.55f, 0));
            g.drawString(font, text, x, y, argb(a, 0xFFFFFF), false);
        });

        // ── вбудовані ефекти (2D, працюють з будь-якими шейдерпаками) ──
        effect("shaurma_lib:vignette", "Віньєтка", (g, w, h, e) -> {
            int c = (int) num(e.params.get("color"), 0);
            float in = (float) e.intensity;
            int d = Math.max(8, (int) (Math.min(w, h) * 0.22));
            for (int i = 0; i < 6; i++) {
                float k = in * (1 - i / 6f) * 0.35f;
                int t = d * (i + 1) / 6;
                g.fill(0, 0, w, t / 3, argb(k, c));
                g.fill(0, h - t / 3, w, h, argb(k, c));
                g.fill(0, 0, t / 2, h, argb(k, c));
                g.fill(w - t / 2, 0, w, h, argb(k, c));
            }
        });
        effect("shaurma_lib:tint", "Тонування кольором", (g, w, h, e) ->
            g.fill(0, 0, w, h, argb((float) (e.intensity * num(e.params.get("alpha"), 0.35)), (int) num(e.params.get("color"), 0x7A0000))));
        effect("shaurma_lib:darkness", "Затемнення", (g, w, h, e) -> g.fill(0, 0, w, h, argb((float) e.intensity, 0)));
        effect("shaurma_lib:flash", "Спалах", (g, w, h, e) -> g.fill(0, 0, w, h, argb((float) e.intensity, (int) num(e.params.get("color"), 0xFFF4E0))));
        effect("shaurma_lib:grain", "Плівкове зерно", (g, w, h, e) -> {
            java.util.Random r = new java.util.Random(System.nanoTime() / 40_000_000L);
            int n = (int) (w * h / 900 * e.intensity);
            for (int i = 0; i < n; i++) {
                int x = r.nextInt(Math.max(1, w)), y = r.nextInt(Math.max(1, h));
                g.fill(x, y, x + 1, y + 1, argb(0.25f, r.nextBoolean() ? 0xFFFFFF : 0));
            }
        });
    }

    static double num(Object o, double def) {
        if (o instanceof Number n) return n.doubleValue();
        if (o instanceof String s) {
            try { return s.startsWith("#") ? Integer.parseInt(s.substring(1), 16) : Double.parseDouble(s); } catch (NumberFormatException e) { return def; }
        }
        return def;
    }

    static int argb(float a, int rgb) {
        int ai = Math.max(0, Math.min(255, Math.round(a * 255f)));
        return (ai << 24) | (rgb & 0xFFFFFF);
    }
}
