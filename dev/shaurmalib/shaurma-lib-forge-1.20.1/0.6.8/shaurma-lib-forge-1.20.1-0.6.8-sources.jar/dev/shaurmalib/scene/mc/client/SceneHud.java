package dev.shaurmalib.scene.mc.client;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.shaurmalib.scene.doc.Transition;
import dev.shaurmalib.scene.eval.SceneFrame;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.Random;

/**
 * Композитор поверх кадру: ефекти, оверлеї, ефекти склейок (технологія мафії: dip, flash, glitch,
 * shutter, wipe, zoom-punch, crossfade зі знімком кадру), кіно-смуги, затемнення входу/виходу.
 * Порядок шарів: ефекти → оверлеї → склейка → смуги → fade.
 */
public final class SceneHud {

    private SceneHud() {}

    private static DynamicTexture snapTex;
    private static ResourceLocation snapId;
    private static int snapW, snapH;
    private static boolean wantSnap;
    private static Transition.Type lastFx;
    private static double lastU;

    /** Перед HUD (чистий кадр світу): зробити знімок для CROSSFADE, якщо склейка от-от. */
    public static void beforeHud() {
        if (!wantSnap) return;
        wantSnap = false;
        try {
            NativeImage img = Screenshot.takeScreenshot(Minecraft.getInstance().getMainRenderTarget());
            releaseSnap();
            snapW = img.getWidth();
            snapH = img.getHeight();
            snapTex = new DynamicTexture(img);
            snapId = Minecraft.getInstance().getTextureManager().register("shaurma_scene_snap", snapTex);
        } catch (RuntimeException e) {
            releaseSnap();
        }
    }

    private static void releaseSnap() {
        if (snapId != null) Minecraft.getInstance().getTextureManager().release(snapId);
        snapId = null;
        snapTex = null;
    }

    /** HUD кадру сесії, що веде камеру (і оверлеї/ефекти всіх сесій). */
    public static void render(GuiGraphics g, float partial) {
        SceneClient.Active cine = SceneClient.cinematic();
        int w = g.guiWidth(), h = g.guiHeight();
        for (SceneClient.Active a : SceneClient.active()) {
            if (a.playback.inPreroll()) continue;
            layers(g, w, h, a.frame);
        }
        if (cine != null) composite(g, w, h, cine.frame, true);
    }

    /** Ефекти та оверлеї кадру (також для превʼю в редакторі). */
    public static void layers(GuiGraphics g, int w, int h, SceneFrame f) {
        for (SceneFrame.Effect e : f.effects) {
            SceneOverlays.EffectRenderer r = SceneOverlays.effect(e.id);
            if (r != null && e.intensity > 0.002) try { r.render(g, w, h, e); } catch (RuntimeException ignored) { }
        }
        for (SceneFrame.Overlay o : f.overlays) {
            SceneOverlays.OverlayRenderer r = SceneOverlays.overlay(o.id);
            if (r == null) continue;
            float alpha = (float) (o.opacity * Math.min(ease(o.enter), ease(o.exit)));
            if (alpha <= 0.003f) continue;
            g.pose().pushPose();
            double appear = Math.min(o.enter, o.exit);
            String kind = o.enter < 1 ? o.enterType : o.exitType;
            if ("slide".equals(kind)) g.pose().translate(0, (1 - ease(appear)) * h * 0.08, 0);
            else if ("scale".equals(kind)) {
                float s = (float) (0.7 + 0.3 * ease(appear));
                g.pose().translate(w * o.x, h * o.y, 0);
                g.pose().scale(s, s, 1);
                g.pose().translate(-w * o.x, -h * o.y, 0);
            }
            try { r.render(g, w, h, o, alpha); } catch (RuntimeException ignored) { }
            g.pose().popPose();
        }
    }

    /** Склейки, смуги, затемнення. @param live false — превʼю редактора (без знімка кадру) */
    public static void composite(GuiGraphics g, int w, int h, SceneFrame f, boolean live) {
        if (f.fx != null) fx(g, w, h, f, live);
        else if (live && lastFx == Transition.Type.CROSSFADE) releaseSnap();
        lastFx = f.fx;
        lastU = f.fxU;
        int bar = (int) Math.round(h * f.letterbox);
        if (bar > 0) {
            g.fill(0, 0, w, bar, 0xFF000000);
            g.fill(0, h - bar, w, h, 0xFF000000);
        }
        if (f.fade > 0.002) g.fill(0, 0, w, h, argb((float) f.fade, 0));
    }

    private static void fx(GuiGraphics g, int w, int h, SceneFrame f, boolean live) {
        float u = (float) f.fxU;
        switch (f.fx) {
            case FADE_BLACK -> fill(g, w, h, 0, smooth(bump(u)));
            case DIP_COLOR -> fill(g, w, h, f.fxColor, smooth(bump(u)));
            case FLASH -> {
                float a = u < 0.18f ? u / 0.18f : (float) Math.pow(1f - (u - 0.18f) / 0.82f, 1.6);
                fill(g, w, h, f.fxColor == 0 ? 0xFFF4E0 : f.fxColor, a);
            }
            case SHUTTER -> {
                int half = Math.round(h / 2f * smooth(bump(u)));
                g.fill(0, 0, w, half, 0xFF000000);
                g.fill(0, h - half, w, h, 0xFF000000);
                if (half > 2 && half < h / 2 - 2) {
                    g.fill(0, half, w, half + 1, argb(0.55f, 0xFFFFFF));
                    g.fill(0, h - half - 1, w, h - half, argb(0.55f, 0xFFFFFF));
                }
            }
            case WIPE -> {
                int left, right;
                if (u < 0.5f) { left = 0; right = Math.round(w * smooth(u / 0.5f)); }
                else { left = Math.round(w * smooth((u - 0.5f) / 0.5f)); right = w; }
                g.fill(left, 0, right, h, 0xFF000000);
                int edge = u < 0.5f ? right : left;
                g.fill(Math.max(0, edge - 2), 0, Math.min(w, edge + 2), h, argb(0.85f, 0xFFFFFF));
            }
            case GLITCH -> glitch(g, w, h, bump(u));
            case ZOOM_PUNCH -> fill(g, w, h, 0xFFFFFF, 0.5f * smooth(bump(u)) * smooth(bump(u)));
            case WHIP_PAN -> {
                float k = bump(u);
                Random r = new Random(7);
                for (int i = 0; i < 40 * k; i++) {
                    int y = r.nextInt(Math.max(1, h)), len = (int) (w * (0.3 + 0.7 * r.nextFloat()) * k);
                    int x = r.nextInt(Math.max(1, w));
                    g.fill(x - len / 2, y, x + len / 2, y + 1 + r.nextInt(3), argb(0.25f * k, 0xFFFFFF));
                }
                fill(g, w, h, 0, 0.35f * k * k);
            }
            case CROSSFADE -> {
                if (!live) { fill(g, w, h, 0, 0.25f * bump(u)); break; }
                if (u < 0.5f && u > 0.38f) wantSnap = true;               // кілька кадрів поспіль «фотографуємо» — лишається останній
                if (u >= 0.5f && snapId != null) {
                    float a = 1f - smooth((u - 0.5f) / 0.5f);
                    RenderSystem.enableBlend();
                    RenderSystem.defaultBlendFunc();
                    RenderSystem.setShaderColor(1f, 1f, 1f, a);
                    g.blit(snapId, 0, 0, w, h, 0f, 0f, snapW, snapH, snapW, snapH);
                    RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
                }
            }
            default -> { }
        }
    }

    private static void glitch(GuiGraphics g, int w, int h, float k) {
        Random r = new Random((System.currentTimeMillis() / 45L) * 7919L);
        int strips = 5 + Math.round(18 * k);
        int[] pal = { 0x00E5FF, 0xFF2BD6, 0x000000, 0xFFFFFF, 0x1AFF6A };
        for (int i = 0; i < strips; i++) {
            int y = r.nextInt(Math.max(1, h)), sh = 2 + r.nextInt(Math.max(3, Math.round(h * 0.06f * k) + 3));
            int x0 = r.nextInt(Math.max(1, w / 3)) - w / 8, x1 = w - r.nextInt(Math.max(1, w / 3)) + w / 8;
            g.fill(Math.max(0, x0), y, Math.min(w, x1), Math.min(h, y + sh), argb(0.30f + 0.55f * k, pal[r.nextInt(pal.length)]));
        }
        fill(g, w, h, 0, 0.55f * k * k * k);
    }

    private static void fill(GuiGraphics g, int w, int h, int rgb, float a) {
        if (a > 0.003f) g.fill(0, 0, w, h, argb(a, rgb));
    }

    static int argb(float a, int rgb) { return SceneOverlays.argb(a, rgb); }

    private static float bump(float u) { return 1f - Math.abs(2f * u - 1f); }

    private static float smooth(float t) { t = Math.max(0f, Math.min(1f, t)); return t * t * (3f - 2f * t); }

    private static double ease(double t) { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); }
}
