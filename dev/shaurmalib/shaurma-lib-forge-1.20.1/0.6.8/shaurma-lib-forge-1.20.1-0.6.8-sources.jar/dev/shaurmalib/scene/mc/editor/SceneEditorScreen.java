package dev.shaurmalib.scene.mc.editor;

import com.mojang.blaze3d.platform.InputConstants;
import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.api.SceneDefinition;
import dev.shaurmalib.scene.api.SceneRegistry;
import dev.shaurmalib.scene.doc.Channels;
import dev.shaurmalib.scene.doc.Clip;
import dev.shaurmalib.scene.doc.KeyChannel;
import dev.shaurmalib.scene.doc.Marker;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.doc.Track;
import dev.shaurmalib.scene.edit.EditOps;
import dev.shaurmalib.scene.edit.History;
import dev.shaurmalib.scene.edit.SceneValidator;
import dev.shaurmalib.scene.eval.SceneEvaluator;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.io.SceneCodec;
import dev.shaurmalib.scene.mc.client.SceneAssets;
import dev.shaurmalib.scene.mc.client.SceneCamera;
import dev.shaurmalib.scene.mc.client.SceneClient;
import dev.shaurmalib.scene.mc.client.SceneClips;
import dev.shaurmalib.scene.mc.client.SceneHud;
import dev.shaurmalib.scene.mc.client.SceneRender;
import dev.shaurmalib.scene.mc.client.SceneSound;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import dev.shaurmalib.scene.mc.ui.Toasts;
import dev.shaurmalib.scene.net.SceneMessage;
import dev.shaurmalib.scene.net.SceneNetwork;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Редактор зареєстрованої сцени прямо у світі. Компонування як у Blender/монтажці: в'юпорт у центрі
 * (сам світ), зліва Outliner/Ассети/Слоти, справа Властивості, знизу Таймлайн (кліпи / Dope Sheet / Graph).
 *
 * <p>Клавіші: Space — грати/пауза, ←/→ — кадр, Shift+←/→ — секунда, Home/End — початок/кінець, K — ключ,
 * G/R/S — рух/поворот/масштаб (X/Y/Z — вісь, ЛКМ/Enter — так, ПКМ/Esc — скасувати), Numpad 0 — вид з камери,
 * Ctrl+Numpad 0 — камера = вигляд, Numpad 1/3/7 — види, F — до вибраного, Ctrl+Z/Y — історія, Ctrl+S — зберегти,
 * Ctrl+D — дублювати, Delete — видалити, M — мітка, ПКМ+WASD/QE — політ.
 */
public final class SceneEditorScreen extends Screen {

    // ── документ ──
    SceneDoc doc;
    String variantId;
    final SceneDefinition def;
    final boolean readOnly;
    final String lockedBy;
    final History history = new History();
    final Gui gui = new Gui();
    final EditorView view = new EditorView();

    /** Для автотестів: вид з камери сцени. */
    public void cameraView(boolean on) { if (on) view.cameraView = true; else leaveCameraView(); }

    public double time() { return time; }
    SceneClips clips;
    SceneEvaluator evaluator;
    final SceneFrame frame = new SceneFrame();
    List<SceneValidator.Issue> issues = List.of();

    // ── час ──
    double time;
    public boolean playing;
    boolean loopPlayback = true;

    // ── вибір ──
    String selObj, selBone;
    Track selTrack;
    Clip selClip;
    Marker selMarker;

    // ── перемикачі ──
    boolean autoKey = true, lockCameraToView, showGizmos = true, snapping = true;
    int previewCount = 3;
    boolean previewSlots = true;
    int leftTab;       // лишилось для сумісності: ліва смуга тепер модульна (SceneDock)
    /** Відкрите випадне меню верхнього рядка («Файл», «Правка»…), null — закрите. */
    String menu;
    /** Підписи над об'єктами у в'юпорті: вимкнено, бо займають багато місця (Вигляд → «Назви над об'єктами»). */
    boolean showLabels;
    /** Іде збереження на сервер (жовта точка у верхньому рядку). */
    boolean saving;
    public int timelineMode;  // 0 кліпи, 1 dope sheet, 2 graph

    // ── розкладка ──
    static final int TOP = 20;
    int leftW = 150, rightW = 176, timelineH = 196;
    int vx, vy, vw, vh;

    // ── модальна трансформація (G/R/S) ──
    char modal;
    int modalAxis = -1;
    double modalStartMx, modalStartMy;
    SceneDoc modalBackup;

    // ── миша в'юпорту ──
    private int viewDrag = -1;
    private boolean flyMode;
    private long lastNs;
    private long lastDraft, lastValidate, lastViewSync;
    private final Set<String> uploaded = new HashSet<>();
    private boolean saveForce;
    private Vec3 origin;
    private boolean anchored;
    String status = "";

    public SceneEditorScreen(SceneDoc doc, boolean readOnly, String lockedBy) {
        super(Component.literal("Scene Editor"));
        this.doc = doc;
        this.def = SceneRegistry.get(doc.id);
        this.readOnly = readOnly;
        this.lockedBy = lockedBy;
        this.variantId = doc.variant(null).id;
        for (SceneDoc.Asset a : doc.assets.values()) uploaded.add(a.sha256);
        rebuild();
    }

    // ═════════════════════════ стан ═════════════════════════

    public SceneDoc.Variant variant() { return doc.variant(variantId); }

    SceneObject selected() { return variant().object(selObj); }

    void rebuild() {
        clips = new SceneClips(doc);
        evaluator = new SceneEvaluator(doc, variant(), mockBindings()).clips(clips).editor(true);
        SceneClient.editorClips = clips;
        SceneRender.editorDoc = doc;
    }

    /** Прив'язки превʼю: у слотах — сам редактор (скільки «гравців» — previewCount). */
    SceneBindings mockBindings() {
        SceneBindings b = new SceneBindings();
        if (!previewSlots || def == null) return b;
        var p = Minecraft.getInstance().player;
        if (p == null) return b;
        SceneBindings.Binding me = SceneBindings.Binding.player(p.getUUID(), p.getGameProfile().getName()).at(p.getX(), p.getY(), p.getZ());
        for (SceneDefinition.Slot s : def.slots) {
            switch (s.kind()) {
                case PLAYER, ENTITY -> b.bind(s.name(), me);
                case PLAYERS -> { for (int i = 0; i < Math.min(previewCount, s.max()); i++) b.bind(s.name(), me); }
                case VALUE -> b.bind(s.name(), SceneBindings.Binding.value(s.title()));
            }
        }
        return b;
    }

    /** Дія з історією: begin → зміна → commit. */
    void edit(String label, Runnable change) {
        if (readOnly) { toast("Лише перегляд: сцену редагує " + lockedBy); return; }
        history.begin(doc, label);
        change.run();
        history.commit(doc);
    }

    void begin(String label) { if (!readOnly) history.begin(doc, label); }

    void commit() { history.commit(doc); }

    public void replaceDoc(SceneDoc d) {
        if (d == null) return;
        doc = d;
        if (doc.variants.get(variantId) == null) variantId = doc.variant(null).id;
        rebuild();
    }

    void toast(String s) { Toasts.info(Component.literal(s)); status = s; }

    double fps() { return doc.fps <= 0 ? 20 : doc.fps; }

    double length() { return variant().length; }

    public void seek(double t) {
        time = Mth.clamp(t, 0, length());
        SceneSound.stopSession(EDITOR_SESSION);
    }

    static final long EDITOR_SESSION = Long.MIN_VALUE + 7;

    // ═════════════════════════ життєвий цикл ═════════════════════════

    @Override
    protected void init() {
        var mc = Minecraft.getInstance();
        if (origin == null && mc.player != null) {
            origin = mc.player.getEyePosition();
            view.reset(origin, mc.player.getYRot());
            SceneObject first = null;
            for (SceneObject o : variant().objects) if (o.kind != SceneObject.Kind.CAMERA) { first = o; break; }
            if (doc.home != null) {
                // точка редагування: відкриваємось звідти, сервер уже тримає там якір (чанки сцени завантажені)
                goHome();
                origin = new Vec3(doc.home[0], doc.home[1], doc.home[2]);
                anchored = true;
            } else if (first != null) view.focus(first.x, first.y + 1, first.z, 2);
        }
        SceneCamera.editor = new SceneCamera.EditorCam() {
            @Override public SceneFrame.Cam camera(float partial) { return editorCamera(); }
            @Override public boolean hideHand() { return true; }
        };
        SceneClient.editorListener = this::onServer;
        loadDraftHint();
    }

    @Override
    public void removed() {
        SceneCamera.editor = null;
        SceneRender.onion.clear();
        if (recording == this) return;       // запис: редактор лише «відійшов», щоб гравець рухався у світі
        SceneClient.editorFrame = null;
        SceneClient.editorClips = null;
        SceneClient.editorListener = null;
        SceneRender.editorDoc = null;
        SceneSound.stopSession(EDITOR_SESSION);
        writeDraft();
        SceneNetwork.Holder.get().toServer(SceneMessage.of(SceneMessage.Op.RELEASE).scene(doc.id));
    }

    @Override public boolean isPauseScreen() { return false; }

    @Override public boolean shouldCloseOnEsc() { return modal == 0 && menu == null && !Popup.isOpen() && gui.focused == null; }

    @Override
    public void onClose() {
        if (history.dirty() && !readOnly && !confirmClose) {
            confirmClose = true;
            toast("Є незбережені зміни: Esc ще раз — вийти без збереження, Ctrl+S — зберегти");
            return;
        }
        super.onClose();
    }

    private boolean confirmClose;

    // ═════════════════════════ запис руху (як Recorder у BBS) ═════════════════════════

    /** Редактор, що зараз записує актора (екран закрито, гравець рухається у світі). */
    private static SceneEditorScreen recording;
    private String recActor;
    private double recStart, recPrevYaw = Double.NaN;
    private int recCountdown;
    private boolean recKeyDown;
    public boolean onion = true;

    /**
     * Ctrl+R: записати рух вибраного актора з гравця — позиція, поворот тіла, голова відносно тіла, погляд,
     * присід — щотіку (20/с), поки сцена грає з playhead: інші актори, камери й звук видно навколо.
     * Перед стартом — 3 с відліку, гравця ставить на місце актора. R — стоп; потім зайві ключі прибираються.
     */
    public void startRecording() {
        SceneObject o = selected();
        if (o == null || o.kind != SceneObject.Kind.ACTOR) { toast("Виберіть актора для запису"); return; }
        if (readOnly) { toast("Лише перегляд"); return; }
        history.begin(doc, "Запис руху " + o.name);
        double end = variant().workOut > variant().workIn ? variant().workOut : length();
        for (String ch : new String[] { Channels.X, Channels.Y, Channels.Z, Channels.YAW, Channels.HEAD_YAW, Channels.HEAD_PITCH, Channels.SNEAK }) {
            KeyChannel k = o.channels.get(ch);
            if (k != null) k.keys().removeIf(key -> key.t >= time - 1e-6 && key.t <= end + 1e-6);
        }
        double[] xf = evaluator.transform(o, time, new double[7], 0);
        recording = this;
        recActor = o.id;
        recStart = time;
        recCountdown = 60;
        recPrevYaw = Double.NaN;
        playing = false;
        SceneNetwork.Holder.get().toServer(SceneMessage.of(SceneMessage.Op.RELEASE).scene(doc.id));
        var mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.connection.sendCommand(String.format(java.util.Locale.ROOT, "tp @s %.3f %.3f %.3f %.1f 0", xf[0], xf[1], xf[2], xf[3]));
        anchored = false;
        mc.setScreen(null);
    }

    public static boolean isRecording() { return recording != null; }

    /** Для автотестів: зупинити запис, як клавішею R. */
    public static void stopRecordingNow() { if (recording != null) recording.stopRecording(true); }

    /** Клієнтський тік: відлік, семпл гравця, стоп за R або в кінці зони. */
    public static void recordTick() {
        SceneEditorScreen s = recording;
        if (s == null) return;
        var mc = Minecraft.getInstance();
        if (mc.player == null) { recording = null; return; }
        boolean r = mc.screen == null && InputConstants.isKeyDown(mc.getWindow().getWindow(), GLFW.GLFW_KEY_R);
        boolean pressed = r && !s.recKeyDown;
        s.recKeyDown = r;
        if (s.recCountdown > 0) {
            if (pressed) { s.stopRecording(false); return; }
            s.recCountdown--;
            return;
        }
        SceneObject o = s.variant().object(s.recActor);
        if (o == null) { s.stopRecording(false); return; }
        var p = mc.player;
        double yaw = p.yBodyRot;
        if (!Double.isNaN(s.recPrevYaw)) yaw = s.recPrevYaw + Mth.wrapDegrees(yaw - s.recPrevYaw);
        s.recPrevYaw = yaw;
        double t = s.time;
        key(o, Channels.X, t, p.getX());
        key(o, Channels.Y, t, p.getY());
        key(o, Channels.Z, t, p.getZ());
        key(o, Channels.YAW, t, yaw);
        key(o, Channels.HEAD_YAW, t, Mth.wrapDegrees(p.yHeadRot - p.yBodyRot));
        key(o, Channels.HEAD_PITCH, t, p.getXRot());
        o.channels.getOrCreate(Channels.SNEAK).set(t, p.isCrouching() ? 1 : 0);
        double end = s.variant().workOut > s.variant().workIn ? s.variant().workOut : s.length();
        s.time = Math.min(end, t + 0.05 * s.evaluator.speedAt(t));
        if (pressed || s.time >= end - 1e-6) s.stopRecording(true);
    }

    private static void key(SceneObject o, String ch, double t, double v) {
        o.channels.getOrCreate(ch).set(t, v).interp = KeyChannel.Interp.LINEAR;
    }

    /** Кадр гри під час запису: решта сцени грає навколо гравця. */
    public static void recordFrame() {
        SceneEditorScreen s = recording;
        if (s == null) return;
        s.evaluator.eval(s.time, s.frame);
        s.frame.actors.removeIf(a -> a.object.id.equals(s.recActor));
        SceneClient.editorFrame = s.frame;
        SceneSound.update(EDITOR_SESSION, s.doc, s.frame, s.recCountdown <= 0);
    }

    public static void recordHud(GuiGraphics g) {
        SceneEditorScreen s = recording;
        if (s == null) return;
        var font = Minecraft.getInstance().font;
        String txt = s.recCountdown > 0 ? "ЗАПИС ЧЕРЕЗ " + (s.recCountdown / 20 + 1) + "…  (R — скасувати)"
            : "● ЗАПИС " + s.fmtTime(s.time) + "  ·  R — стоп";
        int w = font.width(txt) + 16, x = (g.guiWidth() - w) / 2;
        g.fill(x, 8, x + w, 24, 0xCC000000);
        g.drawString(font, txt, x + 8, 12, s.recCountdown > 0 ? 0xFFF2B84B : ((System.currentTimeMillis() / 400) % 2 == 0 ? 0xFFE5383B : 0xFFFF8080), false);
    }

    private void stopRecording(boolean keep) {
        recording = null;
        SceneObject o = variant().object(recActor);
        if (!keep) {
            SceneDoc back = history.cancel();
            if (back != null) { back.id = doc.id; back.revision = doc.revision; replaceDoc(back); }
        } else if (o != null) {
            int before = EditOps.allKeys(o).size();
            for (String ch : new String[] { Channels.X, Channels.Y, Channels.Z, Channels.YAW, Channels.HEAD_YAW, Channels.HEAD_PITCH })
                reduce(o.channels.get(ch), ch.equals(Channels.X) || ch.equals(Channels.Y) || ch.equals(Channels.Z) ? 0.01 : 0.6);
            reduce(o.channels.get(Channels.SNEAK), 0.01);
            history.commit(doc);
            status = "Записано " + fmtTime(time - recStart) + ", ключів " + EditOps.allKeys(o).size() + " (з " + before + ")";
        }
        SceneSound.stopSession(EDITOR_SESSION);
        double from = recStart;
        Minecraft.getInstance().setScreen(this);
        seek(from);
        toast(keep ? status : "Запис скасовано");
    }

    /** Прибрати ключі, які лінійна інтерполяція сусідів і так дає з точністю tol (менше ключів — легше правити). */
    static void reduce(KeyChannel ch, double tol) {
        if (ch == null || ch.size() < 3) return;
        List<KeyChannel.Key> keys = ch.keys();
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int i = 1; i < keys.size() - 1; i++) {
                KeyChannel.Key a = keys.get(i - 1), k = keys.get(i), b = keys.get(i + 1);
                double f = (k.t - a.t) / Math.max(1e-9, b.t - a.t);
                if (Math.abs(a.v + (b.v - a.v) * f - k.v) <= tol) { keys.remove(i); changed = true; i--; }
            }
        }
        ch.sort();
    }

    // ═════════════════════════ запекти кліп у ключі пози (BBS «animation → pose») ═════════════════════════

    /** Кадри кліпу анімації стають ключами кісток (зсув відносно пози без кліпу), кліп вимикається — далі правиш руками. */
    public void bakeClip(Track t, Clip c) {
        SceneObject o = variant().object(t.target);
        if (o == null) return;
        edit("Запекти " + c.ref, () -> {
            java.util.Map<String, Channels> saved = new java.util.LinkedHashMap<>(o.bones);
            o.bones.clear();
            SceneEvaluator ev = new SceneEvaluator(doc, variant(), mockBindings()).clips(clips);
            double step = 2 / fps();
            java.util.Map<String, Channels> out = new java.util.LinkedHashMap<>();
            boolean wasMuted = c.muted;
            for (double tt = c.start; tt <= c.end() + 1e-6; tt += step) {
                c.muted = false;
                java.util.Map<String, float[]> with = copy(ev.actor(o, tt + 1e-7).pose);
                c.muted = true;
                java.util.Map<String, float[]> without = copy(ev.actor(o, tt + 2e-7).pose);
                for (var e : with.entrySet()) {
                    float[] base = without.getOrDefault(e.getKey(), dev.shaurmalib.scene.eval.ActorPoser.rest());
                    Channels bc = out.computeIfAbsent(e.getKey(), k -> new Channels());
                    for (int i = 0; i < 9; i++) {
                        double d = i < 6 ? e.getValue()[i] - base[i] : (Math.abs(base[i]) < 1e-6 ? 1 : e.getValue()[i] / base[i]);
                        if (Math.abs(d - (i < 6 ? 0 : 1)) > 1e-3 || bc.has(Channels.BONE[i])) bc.getOrCreate(Channels.BONE[i]).set(tt, d);
                    }
                }
            }
            c.muted = wasMuted;
            o.bones.putAll(saved);
            for (var e : out.entrySet()) {
                Channels dst = o.bone(e.getKey());
                for (var ch : e.getValue().map().entrySet()) {
                    reduce(ch.getValue(), 0.3);
                    boolean scale = ch.getKey().startsWith("s");
                    KeyChannel target = dst.getOrCreate(ch.getKey());
                    for (KeyChannel.Key k : ch.getValue().keys()) {
                        double cur = target.isEmpty() ? (scale ? 1 : 0) : target.sample(k.t);
                        target.set(k.t, scale ? cur * k.v : cur + k.v);
                    }
                }
            }
            c.muted = true;
        });
        toast("Кліп запечено в ключі пози — правте їх (кліп вимкнено)");
    }

    private static java.util.Map<String, float[]> copy(java.util.Map<String, float[]> m) {
        java.util.Map<String, float[]> c = new java.util.HashMap<>();
        for (var e : m.entrySet()) c.put(e.getKey(), e.getValue().clone());
        return c;
    }

    /** Onion skin (BBS): напівпрозорі копії вибраного актора в сусідніх ключах. */
    private void onionSkin() {
        SceneRender.onion.clear();
        SceneObject o = selected();
        if (!onion || o == null || o.kind != SceneObject.Kind.ACTOR || playing) return;
        java.util.TreeSet<Double> times = new java.util.TreeSet<>();
        for (KeyChannel.Key k : EditOps.allKeys(o)) times.add(Math.round(k.t * 1000) / 1000.0);
        List<Double> pick = new ArrayList<>();
        Double a = times.lower(time - 1e-3), b = times.higher(time + 1e-3);
        if (a != null) { pick.add(a); Double a2 = times.lower(a - 1e-3); if (a2 != null) pick.add(a2); }
        if (b != null) { pick.add(b); Double b2 = times.higher(b + 1e-3); if (b2 != null) pick.add(b2); }
        if (pick.isEmpty()) return;
        SceneEvaluator ev = new SceneEvaluator(doc, variant(), mockBindings()).clips(clips).editor(true);
        for (double t : pick) if (t >= 0 && t <= length()) SceneRender.onion.add(new SceneRender.Ghost(ev.actor(o, t), t < time ? 0x5A9EFF : 0x59D185));
    }

    /** Камера, яку бачить гра, поки відкритий редактор. */
    SceneFrame.Cam editorCamera() {
        float dt = (float) Math.min(0.1, (System.nanoTime() - camNs) / 1e9);
        camNs = System.nanoTime();
        if (view.cameraView && frame.hasCamera) return frame.camera;
        return view.eye(Math.max(dt, 0.001f));
    }

    private long camNs = System.nanoTime();

    // ═════════════════════════ сервер ═════════════════════════

    private void onServer(SceneMessage m) {
        if (m.op == SceneMessage.Op.RESULT) {
            if (m.a != null && m.a.startsWith("asset:")) return;
            saving = false;
            if (m.flags == 0 && doc.id.equals(m.scene)) {
                doc.revision = m.revision;
                SceneClient.putDoc(doc);
                history.markSaved();
                deleteDraft();
                saveForce = false;
                toast(m.a);
            } else if (m.flags == 2) {
                saveForce = true;
                toast(m.a + " — Ctrl+S ще раз, щоб перезаписати");
            } else toast(m.a == null ? "Помилка" : m.a);
        } else if (m.op == SceneMessage.Op.EDIT_OPEN && !doc.id.equals(m.scene)) {
            dev.shaurmalib.scene.mc.client.SceneEditorHook.open(m);
        }
    }

    public void save() {
        if (readOnly) { toast("Лише перегляд"); return; }
        issues = SceneValidator.validate(doc, def, clips);
        for (SceneDoc.Asset a : doc.assets.values()) {
            if (uploaded.add(a.sha256)) SceneAssets.upload(doc.id, a);
        }
        byte[] gz = SceneMessage.gzip(SceneCodec.write(doc, false).getBytes(StandardCharsets.UTF_8));
        SceneMessage t = SceneMessage.of(SceneMessage.Op.SAVE);
        t.scene = doc.id;
        t.revision = doc.revision;
        t.flags = saveForce ? 1 : 0;
        for (SceneMessage m : SceneMessage.split(t, gz, SceneMessage.C2S_CHUNK)) SceneNetwork.Holder.get().toServer(m);
        writeDraft();
        status = "Збереження…";
        saving = true;
    }

    /** Тест на сервері: справжній запуск для себе (камера-якір, чанки, синхронізація). */
    void testOnServer() {
        if (history.dirty()) { toast("Спершу збережіть (Ctrl+S) — сервер грає збережену ревізію"); return; }
        SceneMessage m = SceneMessage.of(SceneMessage.Op.PREVIEW).scene(doc.id);
        m.variant = variantId;
        m.time = time >= length() - 0.05 ? 0 : time;
        SceneNetwork.Holder.get().toServer(m);
        onClose();
        confirmClose = false;
    }

    // ── чернетка ──

    private Path draftPath() {
        return Minecraft.getInstance().gameDirectory.toPath().resolve("shaurma_scene").resolve("drafts").resolve(doc.id.replace(':', '_').replace('/', '_') + ".json");
    }

    void writeDraft() {
        if (!history.dirty() || readOnly) return;
        try {
            Files.createDirectories(draftPath().getParent());
            Files.writeString(draftPath(), SceneCodec.write(doc, true), StandardCharsets.UTF_8);
        } catch (Exception ignored) { }
    }

    private void deleteDraft() { try { Files.deleteIfExists(draftPath()); } catch (Exception ignored) { } }

    boolean draftAvailable;

    private void loadDraftHint() {
        draftAvailable = Files.isRegularFile(draftPath()) && !readOnly;
        if (draftAvailable) status = "Є незбережена чернетка — «Відновити» вгорі";
    }

    void restoreDraft() {
        try {
            SceneDoc d = SceneCodec.read(Files.readString(draftPath(), StandardCharsets.UTF_8));
            d.id = doc.id;
            d.revision = doc.revision;
            history.begin(doc, "Відновити чернетку");
            replaceDoc(d);
            history.commit(doc);
            history.markDirty();
            draftAvailable = false;
            toast("Чернетку відновлено");
        } catch (Exception e) {
            toast("Чернетка пошкоджена: " + e.getMessage());
        }
    }

    // ═════════════════════════ кадр ═════════════════════════

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        long now = System.nanoTime();
        double dt = lastNs == 0 ? 0 : Math.min(0.1, (now - lastNs) / 1e9);
        lastNs = now;
        tickTime(dt);
        flyTick(dt);
        evaluator.eval(time, frame);
        SceneClient.editorFrame = frame;
        SceneSound.update(EDITOR_SESSION, doc, frame, playing);
        onionSkin();
        if (now - lastValidate > 1_000_000_000L) { issues = SceneValidator.validate(doc, def, clips); lastValidate = now; }
        if (now - lastDraft > 30_000_000_000L) { writeDraft(); lastDraft = now; }
        syncView(now);

        int w = width, h = height;
        // розкладка під масштаб GUI: на великому масштабі (мало GUI-пікселів) панелі вужчі, в'юпорт лишається головним
        leftW = Mth.clamp(w / 5, 104, 150);
        rightW = Mth.clamp(w / 4, 124, 176);
        timelineH = Mth.clamp((int) (h * 0.36), 74, 196);
        vx = leftW; vy = TOP; vw = w - leftW - rightW; vh = h - TOP - timelineH;
        gui.modal = Popup.isOpen() || menu != null;
        gui.begin(g, mx, my);

        // превʼю кадру в'юпорта: вид з камери — ефекти, оверлеї, склейки й смуги, як у грі
        if (view.cameraView && frame.hasCamera) {
            g.enableScissor(vx, vy, vx + vw, vy + vh);
            g.pose().pushPose();
            g.pose().translate(vx, vy, 0);
            SceneHud.layers(g, vw, vh, frame);
            SceneHud.composite(g, vw, vh, frame, false);
            g.pose().popPose();
            g.disableScissor();
            safeFrame(g);
        }
        if (showLabels) EditorOverlay.labels(this, g);

        // ті самі модульні панелі, що в Shaurma Modeling: заголовок зі стрілкою, згортання, роздільники
        LeftPanel.render(this, gui, 0, TOP, leftW, h - TOP - timelineH);
        Properties.render(this, gui, w - rightW, TOP, rightW, h - TOP - timelineH);
        TimelinePanel.render(this, gui, 0, h - timelineH, w, timelineH);
        TopBar.render(this, gui, 0, 0, w, TOP);
        viewportInput();
        TopBar.renderMenu(this, gui);
        if (modal != 0) modalHud(g);
        Popup.render(gui, w, h);
        Toasts.render(g, w, TOP + 4);
        gui.end();
    }

    private void tickTime(double dt) {
        if (!playing) return;
        SceneDoc.Variant v = variant();
        double end = v.workOut > v.workIn ? v.workOut : v.length;
        double start = v.workOut > v.workIn ? v.workIn : 0;
        time += dt * evaluator.speedAt(time);
        if (time >= end) {
            if (loopPlayback || v.loop) { time = start; SceneSound.stopSession(EDITOR_SESSION); }
            else { time = end; playing = false; }
        }
    }

    /** Рамка безпечної зони й сітка третин у виді з камери. */
    private void safeFrame(GuiGraphics g) {
        int c = 0x55FFFFFF;
        int ix = vx + vw / 3, iy = vy + vh / 3;
        g.fill(ix, vy, ix + 1, vy + vh, 0x22FFFFFF);
        g.fill(vx + vw * 2 / 3, vy, vx + vw * 2 / 3 + 1, vy + vh, 0x22FFFFFF);
        g.fill(vx, iy, vx + vw, iy + 1, 0x22FFFFFF);
        g.fill(vx, vy + vh * 2 / 3, vx + vw, vy + vh * 2 / 3 + 1, 0x22FFFFFF);
        int mx = (int) (vw * 0.05), my = (int) (vh * 0.05);
        g.renderOutline(vx + mx, vy + my, vw - 2 * mx, vh - 2 * my, c);
        gui.text("КАМЕРА · " + (frame.cameraId == null ? "" : name(variant().object(frame.cameraId))), vx + 6, vy + vh - 12, 0xFFF2B84B);
    }

    String name(SceneObject o) { return o == null ? "—" : o.name; }

    /** H: повернутись у точку редагування. */
    public void goHome() {
        if (doc.home == null) { toast("Точку редагування не задано (⌂ угорі або /scene home " + doc.id + ")"); return; }
        SceneFrame.Cam c = new SceneFrame.Cam();
        c.x = doc.home[0]; c.y = doc.home[1]; c.z = doc.home[2]; c.yaw = (float) doc.home[3]; c.pitch = (float) doc.home[4];
        if (view.cameraView) view.cameraView = false;
        view.matchCamera(c);
    }

    /** ⌂: точка редагування = поточний вид редактора (збережеться зі сценою). */
    public void setHomeHere() {
        SceneFrame.Cam e = view.cameraView && frame.hasCamera ? frame.camera : view.eye(1);
        var mc = Minecraft.getInstance();
        String dim = mc.level == null ? null : mc.level.dimension().location().toString();
        edit("Точка редагування", () -> { doc.home = new double[] { e.x, e.y, e.z, e.yaw, e.pitch }; doc.homeDim = dim; });
        toast("Точка редагування тут — редактор відкриватиметься звідси після збереження");
    }

    /** Камера редактора далеко від гравця — попросити сервер тримати чанки навколо неї. */
    private void syncView(long now) {
        if (origin == null || now - lastViewSync < 500_000_000L) return;
        lastViewSync = now;
        SceneFrame.Cam c = editorCamera();
        double d = Math.hypot(c.x - origin.x, c.z - origin.z);
        if (d < 48 && !anchored) return;
        anchored = true;
        SceneMessage m = SceneMessage.of(SceneMessage.Op.VIEW).scene(doc.id);
        m.a = String.format(java.util.Locale.ROOT, "%.2f,%.2f,%.2f,%.1f,%.1f", c.x, c.y, c.z, c.yaw, c.pitch);
        m.b = doc.homeDim != null ? doc.homeDim : variant().dimension;
        SceneNetwork.Holder.get().toServer(m);
    }

    // ═════════════════════════ в'юпорт ═════════════════════════

    boolean inViewport(double x, double y) { return x >= vx && y >= vy && x < vx + vw && y < vy + vh; }

    private void viewportInput() {
        int c = gui.pendingClick();
        if (c < 0 || !inViewport(gui.pendingClickX(), gui.pendingClickY())) return;
        if (modal != 0) { gui.consumeClick(); if (c == 0) confirmModal(); else cancelModal(); return; }
        if (c == 0) {
            String hit = EditorOverlay.pick(this, gui.pendingClickX(), gui.pendingClickY());
            select(hit);
            gui.consumeClick();
        }
    }

    public void select(String objectId) {
        selObj = objectId;
        selBone = null;
        selClip = null;
        selTrack = null;
        selMarker = null;
    }

    void selectClip(Track t, Clip c) {
        selTrack = t;
        selClip = c;
        selMarker = null;
        if (t.type == Track.Type.ANIMATION && t.target != null) selObj = t.target;
        else if (t.type == Track.Type.CAMERA && c != null && c.ref != null) selObj = c.ref;
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        gui.onClick(x, y, button);
        if (inViewport(x, y) && modal == 0 && menu == null && !Popup.isOpen()) {
            if (button == 2) viewDrag = 2;
            else if (button == 1) { viewDrag = 1; flyMode = true; }
        }
        return true;
    }

    @Override
    public boolean mouseReleased(double x, double y, int button) {
        gui.onRelease(button);
        if (button == viewDrag) viewDrag = -1;
        if (button == 1) flyMode = false;
        return true;
    }

    @Override
    public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        if (viewDrag == 2 && button == 2) {
            if (view.cameraView && lockCameraToView) { cameraNudge(dx, dy, hasShiftDown()); return true; }
            if (view.cameraView) { leaveCameraView(); }
            if (hasShiftDown()) view.pan(dx, dy); else view.orbit(dx, dy);
            return true;
        }
        if (viewDrag == 1 && button == 1) {
            if (view.cameraView && lockCameraToView) { cameraNudge(dx, dy, false); return true; }
            if (view.cameraView) leaveCameraView();
            view.look(dx, dy);
            return true;
        }
        return true;
    }

    @Override
    public void mouseMoved(double x, double y) {
        if (modal != 0) modalMove(x, y);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double delta) {
        if (inViewport(x, y) && menu == null && !Popup.isOpen()) {
            if (flyMode) { view.flySpeed = Mth.clamp(view.flySpeed * (delta > 0 ? 1.2 : 1 / 1.2), 0.5, 120); status = String.format("Швидкість польоту %.1f", view.flySpeed); }
            else if (view.cameraView && lockCameraToView) cameraDolly(delta);
            else { if (view.cameraView) leaveCameraView(); view.zoom(delta); }
            return true;
        }
        gui.onScroll(delta);
        return true;
    }

    private void flyTick(double dt) {
        if (!flyMode || dt <= 0) return;
        long win = Minecraft.getInstance().getWindow().getWindow();
        double f = (down(win, GLFW.GLFW_KEY_W) ? 1 : 0) - (down(win, GLFW.GLFW_KEY_S) ? 1 : 0);
        double r = (down(win, GLFW.GLFW_KEY_D) ? 1 : 0) - (down(win, GLFW.GLFW_KEY_A) ? 1 : 0);
        double u = (down(win, GLFW.GLFW_KEY_E) ? 1 : 0) - (down(win, GLFW.GLFW_KEY_Q) ? 1 : 0);
        if (f == 0 && r == 0 && u == 0) return;
        double boost = hasShiftDown() ? 3 : 1;
        if (view.cameraView && lockCameraToView) { cameraFly(f * boost, r * boost, u * boost, dt); return; }
        if (view.cameraView) leaveCameraView();
        view.fly(f * boost, r * boost, u * boost, dt);
    }

    private static boolean down(long win, int key) { return InputConstants.isKeyDown(win, key); }

    void leaveCameraView() {
        if (frame.hasCamera) view.matchCamera(frame.camera);
        view.cameraView = false;
    }

    // ── «Камера за видом» (Blender Lock Camera to View): навігація рухає саму камеру сцени ──

    private SceneObject activeCamera() {
        return frame.cameraId == null ? null : variant().object(frame.cameraId);
    }

    private void cameraNudge(double dx, double dy, boolean pan) {
        SceneObject c = activeCamera();
        if (c == null) return;
        begin("Камера за видом");
        SceneFrame.Cam cur = new SceneFrame.Cam().set(frame.camera);
        if (pan) {
            double ry = Math.toRadians(cur.yaw);
            double k = 0.02;
            cur.x += -Math.cos(ry) * -dx * k;
            cur.z += -Math.sin(ry) * -dx * k;
            cur.y += dy * k;
        } else {
            cur.yaw += (float) (dx * 0.25);
            cur.pitch = (float) Mth.clamp(cur.pitch + dy * 0.25, -89.9, 89.9);
        }
        writeCamera(c, cur);
        commit();
    }

    private void cameraFly(double f, double r, double u, double dt) {
        SceneObject c = activeCamera();
        if (c == null) return;
        begin("Камера за видом");
        SceneFrame.Cam cur = new SceneFrame.Cam().set(frame.camera);
        Vec3 look = Vec3.directionFromRotation(cur.pitch, cur.yaw);
        double ry = Math.toRadians(cur.yaw);
        double s = view.flySpeed * dt;
        cur.x += (look.x * f - Math.cos(ry) * r) * s;
        cur.y += (look.y * f + u) * s;
        cur.z += (look.z * f - Math.sin(ry) * r) * s;
        writeCamera(c, cur);
        commit();
    }

    private void cameraDolly(double delta) {
        SceneObject c = activeCamera();
        if (c == null) return;
        begin("Камера: наїзд");
        SceneFrame.Cam cur = new SceneFrame.Cam().set(frame.camera);
        Vec3 look = Vec3.directionFromRotation(cur.pitch, cur.yaw);
        cur.x += look.x * delta * 0.5; cur.y += look.y * delta * 0.5; cur.z += look.z * delta * 0.5;
        writeCamera(c, cur);
        commit();
    }

    /** Записати позу камери: ключі (автоключ або вже є ключі) або базу. Шлях і look-at не чіпаємо. */
    void writeCamera(SceneObject c, SceneFrame.Cam p) {
        setValue(c, Channels.X, p.x);
        setValue(c, Channels.Y, p.y);
        setValue(c, Channels.Z, p.z);
        setAngle(c, Channels.YAW, p.yaw);
        setAngle(c, Channels.PITCH, p.pitch);
        setAngle(c, Channels.ROLL, p.roll);
    }

    /** Камера = вигляд редактора (Ctrl+Numpad 0): виставити вибрану/активну камеру за поточним видом і поставити ключ. */
    public void cameraToView() {
        SceneObject c = selected() != null && selected().isCamera() ? selected() : activeCamera();
        if (c == null) { toast("Виберіть камеру"); return; }
        SceneFrame.Cam e = view.eye(1);
        edit("Камера = вигляд", () -> {
            boolean keyed = c.channels.has(Channels.X) || autoKey;
            if (keyed) EditOps.keyTransform(c, time, e.x, e.y, e.z, e.yaw, e.pitch, 0);
            else { c.x = e.x; c.y = e.y; c.z = e.z; c.yaw = e.yaw; c.pitch = e.pitch; c.roll = 0; }
        });
        view.cameraView = true;
    }

    // ── запис значень з урахуванням ключів ──

    /** Значення каналу: є ключі або автоключ — ключ у playhead, інакше база об'єкта. */
    void setValue(SceneObject o, String ch, double v) {
        if (o.channels.has(ch) || autoKey) { o.channels.getOrCreate(ch).set(time, v); return; }
        switch (ch) {
            case Channels.X -> o.x = v;
            case Channels.Y -> o.y = v;
            case Channels.Z -> o.z = v;
            case Channels.YAW -> o.yaw = (float) v;
            case Channels.PITCH -> o.pitch = (float) v;
            case Channels.ROLL -> o.roll = (float) v;
            case Channels.SCALE -> o.scale = (float) v;
            case Channels.FOV -> o.fov = (float) v;
            default -> o.channels.getOrCreate(ch).set(time, v);
        }
    }

    void setAngle(SceneObject o, String ch, double v) {
        KeyChannel k = o.channels.get(ch);
        if (k != null && !k.isEmpty()) {
            double prev = k.sample(time);
            v = prev + Mth.wrapDegrees(v - prev);
        }
        setValue(o, ch, v);
    }

    double value(SceneObject o, String ch) {
        double base = switch (ch) {
            case Channels.X -> o.x; case Channels.Y -> o.y; case Channels.Z -> o.z;
            case Channels.YAW -> o.yaw; case Channels.PITCH -> o.pitch; case Channels.ROLL -> o.roll;
            case Channels.SCALE -> o.scale; case Channels.FOV -> o.fov;
            default -> Channels.defaultOf(ch);
        };
        return o.channels.sample(ch, time, base);
    }

    /** K: ключ на всі канали трансформу вибраного (або кістки) у playhead. */
    void keyAll() {
        SceneObject o = selected();
        if (o == null) return;
        edit("Ключ", () -> {
            if (selBone != null) {
                var ch = o.bone(selBone);
                for (int i = 0; i < 9; i++) ch.getOrCreate(Channels.BONE[i]).set(time, ch.sample(Channels.BONE[i], time, i >= 6 ? 1 : 0));
                return;
            }
            for (String c : Channels.TRANSFORM) o.channels.getOrCreate(c).set(time, value(o, c));
            if (o.isCamera()) o.channels.getOrCreate(Channels.FOV).set(time, value(o, Channels.FOV));
        });
        toast("Ключ на " + fmtTime(time));
    }

    String fmtTime(double t) {
        int f = (int) Math.round(t * fps());
        int s = (int) (f / fps());
        return String.format("%d:%02d.%02d", s / 60, s % 60, (int) (f - s * fps()));
    }

    // ═════════════════════════ G / R / S ═════════════════════════

    void startModal(char kind) {
        SceneObject o = selected();
        if (o == null || readOnly || o.locked) return;
        modal = kind;
        modalAxis = -1;
        modalStartMx = gui.mx;
        modalStartMy = gui.my;
        modalBackup = SceneCodec.read(SceneCodec.write(doc, false));
        history.begin(doc, kind == 'G' ? "Перемістити" : kind == 'R' ? "Повернути" : "Масштаб");
    }

    private void modalMove(double mx, double my) {
        SceneObject o = selected();
        if (o == null) return;
        SceneDoc.Variant bv = modalBackup.variant(variantId);
        SceneObject b = bv.object(o.id);
        if (b == null) return;
        double dx = mx - modalStartMx, dy = my - modalStartMy;
        double fine = hasShiftDown() ? 0.1 : 1;
        // повернутись до стану на старті модалу, потім застосувати зсув
        o.channels.map().clear();
        for (var e : b.channels.map().entrySet()) o.channels.map().put(e.getKey(), e.getValue().copy());
        o.bones.clear();
        for (var e : b.bones.entrySet()) o.bones.put(e.getKey(), e.getValue().copy());
        o.x = b.x; o.y = b.y; o.z = b.z; o.yaw = b.yaw; o.pitch = b.pitch; o.roll = b.roll; o.scale = b.scale;
        if (selBone != null) { modalBone(o, dx * fine, dy * fine); return; }
        SceneFrame.Cam e = view.eye(1);
        double dist = Math.max(1, Math.sqrt(Math.pow(value(o, Channels.X) - e.x, 2) + Math.pow(value(o, Channels.Y) - e.y, 2) + Math.pow(value(o, Channels.Z) - e.z, 2)));
        switch (modal) {
            case 'G' -> {
                double k = dist * 0.0028 * fine;
                double ry = Math.toRadians(view.cameraView && frame.hasCamera ? frame.camera.yaw : view.yaw);
                double rx = -Math.cos(ry), rz = -Math.sin(ry);
                double mxw = rx * -dx * k, mzw = rz * -dx * k, myw = -dy * k;
                if (modalAxis == 0) { mxw = (Math.abs(rx) > Math.abs(rz) ? Math.signum(rx) * -dx : -dy) * k; mzw = 0; myw = 0; }
                if (modalAxis == 1) { mxw = 0; mzw = 0; myw = -dy * k; }
                if (modalAxis == 2) { mzw = (Math.abs(rz) > Math.abs(rx) ? Math.signum(rz) * -dx : -dy) * k; mxw = 0; myw = 0; }
                setValue(o, Channels.X, value(o, Channels.X) + mxw);
                setValue(o, Channels.Y, value(o, Channels.Y) + myw);
                setValue(o, Channels.Z, value(o, Channels.Z) + mzw);
            }
            case 'R' -> {
                String ch = modalAxis == 0 ? Channels.PITCH : modalAxis == 2 ? Channels.ROLL : Channels.YAW;
                setAngle(o, ch, value(o, ch) + dx * 0.5 * fine);
            }
            case 'S' -> setValue(o, Channels.SCALE, Math.max(0.01, value(o, Channels.SCALE) * Math.exp(dx * 0.01 * fine)));
            default -> { }
        }
    }

    private void modalBone(SceneObject o, double dx, double dy) {
        var ch = o.bone(selBone);
        int base = modal == 'G' ? 3 : modal == 'R' ? 0 : 6;
        int axis = modalAxis < 0 ? (modal == 'R' ? 0 : 1) : modalAxis;
        String name = Channels.BONE[base + axis];
        double cur = ch.sample(name, time, base == 6 ? 1 : 0);
        double v = switch (modal) {
            case 'G' -> cur + (axis == 1 ? -dy : dx) * 0.05;
            case 'R' -> cur + dx * 0.5;
            default -> Math.max(0, cur * Math.exp(dx * 0.01));
        };
        ch.getOrCreate(name).set(time, v);
    }

    void confirmModal() {
        modal = 0;
        history.commit(doc);
        modalBackup = null;
    }

    void cancelModal() {
        modal = 0;
        SceneDoc back = history.cancel();
        if (back != null) { back.id = doc.id; back.revision = doc.revision; replaceDoc(back); }
        modalBackup = null;
    }

    private void modalHud(GuiGraphics g) {
        String what = switch (modal) { case 'G' -> "Переміщення"; case 'R' -> "Поворот"; default -> "Масштаб"; };
        String ax = modalAxis < 0 ? "вільно" : "XYZ".charAt(modalAxis) + "";
        String s = what + " · вісь: " + ax + " · X/Y/Z — вісь, Shift — точно, ЛКМ/Enter — так, ПКМ/Esc — скасувати";
        int w = font.width(s) + 12;
        g.fill(vx + 6, vy + 6, vx + 6 + w, vy + 20, 0xCC000000);
        g.drawString(font, s, vx + 12, vy + 9, Theme.WARN, false);
    }

    // ═════════════════════════ клавіші ═════════════════════════

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (gui.onKey(key, mods)) return true;
        boolean ctrl = (mods & GLFW.GLFW_MOD_CONTROL) != 0, shift = (mods & GLFW.GLFW_MOD_SHIFT) != 0;
        if (modal != 0) {
            switch (key) {
                case GLFW.GLFW_KEY_X -> modalAxis = modalAxis == 0 ? -1 : 0;
                case GLFW.GLFW_KEY_Y -> modalAxis = modalAxis == 1 ? -1 : 1;
                case GLFW.GLFW_KEY_Z -> modalAxis = modalAxis == 2 ? -1 : 2;
                case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> confirmModal();
                case GLFW.GLFW_KEY_ESCAPE -> cancelModal();
                default -> { }
            }
            if (modal != 0) modalMove(gui.mx, gui.my);
            return true;
        }
        if (menu != null && key == GLFW.GLFW_KEY_ESCAPE) { menu = null; return true; }
        if (Popup.isOpen() && key == GLFW.GLFW_KEY_ESCAPE) { Popup.close(); return true; }
        if (key != GLFW.GLFW_KEY_ESCAPE) confirmClose = false;
        if (flyMode && (key == GLFW.GLFW_KEY_W || key == GLFW.GLFW_KEY_A || key == GLFW.GLFW_KEY_S || key == GLFW.GLFW_KEY_D || key == GLFW.GLFW_KEY_Q || key == GLFW.GLFW_KEY_E)) return true;
        double frameStep = 1 / fps();
        switch (key) {
            case GLFW.GLFW_KEY_SPACE -> { playing = !playing; if (!playing) SceneSound.stopSession(EDITOR_SESSION); return true; }
            case GLFW.GLFW_KEY_LEFT -> { seek(time - (shift ? 1 : frameStep)); return true; }
            case GLFW.GLFW_KEY_RIGHT -> { seek(time + (shift ? 1 : frameStep)); return true; }
            case GLFW.GLFW_KEY_UP -> { jumpKey(true); return true; }
            case GLFW.GLFW_KEY_DOWN -> { jumpKey(false); return true; }
            case GLFW.GLFW_KEY_HOME -> { seek(variant().workOut > variant().workIn ? variant().workIn : 0); return true; }
            case GLFW.GLFW_KEY_END -> { seek(variant().workOut > variant().workIn ? variant().workOut : length()); return true; }
            case GLFW.GLFW_KEY_K, GLFW.GLFW_KEY_I -> {
                if (ctrl && key == GLFW.GLFW_KEY_I) { if (!readOnly) LeftPanel.importDialog(this); return true; }   // Ctrl+I — імпорт файлу
                keyAll();
                return true;
            }
            case GLFW.GLFW_KEY_G -> { startModal('G'); return true; }
            case GLFW.GLFW_KEY_R -> { if (ctrl) startRecording(); else startModal('R'); return true; }
            case GLFW.GLFW_KEY_M -> { addMarker(); return true; }
            case GLFW.GLFW_KEY_H -> { goHome(); return true; }
            case GLFW.GLFW_KEY_F, GLFW.GLFW_KEY_KP_DECIMAL -> { focusSelected(); return true; }
            case GLFW.GLFW_KEY_KP_0 -> {
                if (ctrl) cameraToView();
                else if (view.cameraView) leaveCameraView();
                else view.cameraView = true;
                return true;
            }
            case GLFW.GLFW_KEY_KP_1 -> { leaveIfCam(); view.snap(ctrl ? 9 : 1); return true; }
            case GLFW.GLFW_KEY_KP_3 -> { leaveIfCam(); view.snap(3); return true; }
            case GLFW.GLFW_KEY_KP_7 -> { leaveIfCam(); view.snap(7); return true; }
            case GLFW.GLFW_KEY_DELETE, GLFW.GLFW_KEY_X -> { if (key == GLFW.GLFW_KEY_DELETE || !ctrl) deleteSelection(); return true; }
            case GLFW.GLFW_KEY_TAB -> { timelineMode = (timelineMode + 1) % 3; return true; }
            default -> { }
        }
        if (ctrl) {
            switch (key) {
                case GLFW.GLFW_KEY_Z -> { replaceDoc(shift ? history.redo(doc) : history.undo(doc)); return true; }
                case GLFW.GLFW_KEY_Y -> { replaceDoc(history.redo(doc)); return true; }
                case GLFW.GLFW_KEY_S -> { save(); return true; }
                case GLFW.GLFW_KEY_D -> { duplicateSelection(); return true; }
                default -> { }
            }
        } else if (key == GLFW.GLFW_KEY_S) { if (selClip != null && timelineMode == 0) splitClip(); else startModal('S'); return true; }
        return super.keyPressed(key, scan, mods);
    }

    private void leaveIfCam() { if (view.cameraView) leaveCameraView(); }

    /** Перетягнути файл з провідника у вікно: bbmodel / png / wav / ogg / mp3 імпортуються як ассети (звук ще й лягає на таймлайн). */
    @Override
    public void onFilesDrop(List<Path> paths) {
        if (readOnly) { toast("Лише перегляд"); return; }
        LeftPanel.importPaths(this, paths, true);
    }

    @Override
    public boolean charTyped(char c, int mods) {
        return gui.onChar(c) || super.charTyped(c, mods);
    }

    // ═════════════════════════ дії ═════════════════════════

    void jumpKey(boolean next) {
        SceneObject o = selected();
        double best = next ? Double.MAX_VALUE : -Double.MAX_VALUE;
        List<Double> ts = new ArrayList<>();
        if (o != null) for (KeyChannel.Key k : EditOps.allKeys(o)) ts.add(k.t);
        for (Track t : variant().tracks) for (Clip c : t.clips) { ts.add(c.start); ts.add(c.end()); }
        for (Marker m : variant().markers) ts.add(m.time);
        for (double t : ts) {
            if (next && t > time + 1e-4 && t < best) best = t;
            if (!next && t < time - 1e-4 && t > best) best = t;
        }
        if (Math.abs(best) != Double.MAX_VALUE) seek(best);
    }

    void addMarker() {
        edit("Мітка", () -> {
            Marker m = new Marker(SceneDoc.newId(), "marker_" + (variant().markers.size() + 1), time);
            variant().markers.add(m);
            selMarker = m;
            selClip = null;
        });
    }

    void focusSelected() {
        SceneObject o = selected();
        if (o == null) return;
        leaveIfCam();
        double[] xf = evaluator.transform(o, time, new double[7], 0);
        view.focus(xf[0], xf[1] + (o.kind == SceneObject.Kind.ACTOR ? 1 : 0), xf[2], o.kind == SceneObject.Kind.ACTOR ? 1.2 : 0.8);
    }

    void deleteSelection() {
        if (selClip != null && selTrack != null) {
            Track t = selTrack;
            Clip c = selClip;
            edit("Видалити кліп", () -> { if (hasShiftDown()) EditOps.rippleDelete(t, c); else t.clips.remove(c); });
            selClip = null;
            return;
        }
        if (selMarker != null) {
            Marker m = selMarker;
            edit("Видалити мітку", () -> variant().markers.remove(m));
            selMarker = null;
            return;
        }
        SceneObject o = selected();
        if (o == null) return;
        if (timelineMode != 0 && EditOps.allKeys(o).stream().anyMatch(k -> k.selected)) {
            edit("Видалити ключі", () -> EditOps.deleteSelectedKeys(o));
            return;
        }
        if (o.locked) { toast(o.name + " заблоковано"); return; }
        edit("Видалити " + o.name, () -> EditOps.remove(variant(), o));
        selObj = null;
    }

    void duplicateSelection() {
        if (selClip != null && selTrack != null) {
            Track t = selTrack;
            Clip c = selClip;
            edit("Дублювати кліп", () -> selClip = EditOps.duplicate(t, c));
            return;
        }
        SceneObject o = selected();
        if (o == null) return;
        edit("Дублювати " + o.name, () -> selObj = EditOps.duplicate(variant(), o).id);
    }

    void splitClip() {
        if (selClip == null || selTrack == null) return;
        Track t = selTrack;
        Clip c = selClip;
        edit("Розрізати", () -> { Clip r = EditOps.split(t, c, time); if (r != null) selClip = r; });
    }

    // ── створення ──

    public SceneObject addCamera() {
        SceneFrame.Cam e = view.cameraView && frame.hasCamera ? frame.camera : view.eye(1);
        SceneObject c = new SceneObject(SceneDoc.newId(), "Камера " + (count(SceneObject.Kind.CAMERA) + 1), SceneObject.Kind.CAMERA);
        c.x = e.x; c.y = e.y; c.z = e.z; c.yaw = e.yaw; c.pitch = e.pitch; c.fov = 70;
        c.color = 0xF2B84B;
        edit("Додати камеру", () -> {
            variant().objects.add(c);
            // у монтаж: на перший трек камер від playhead до наступного кліпу (або +3 с)
            Track t = null;
            for (Track x : variant().tracks) if (x.type == Track.Type.CAMERA) { t = x; break; }
            if (t == null) { t = new Track(SceneDoc.newId(), "Камери", Track.Type.CAMERA); variant().tracks.add(0, t); }
            double start = time, end = Math.min(length(), time + 3);
            for (Clip x : t.clips) {
                if (x.covers(start)) start = x.end();
                if (x.start > start && x.start < end) end = x.start;
            }
            if (end - start > 0.1) {
                Clip clip = new Clip(SceneDoc.newId(), start, end - start, c.id);
                t.clips.add(clip);
                t.sort();
            }
        });
        select(c.id);
        return c;
    }

    public SceneObject addActor(SceneObject.ModelType type, String model) {
        SceneObject a = new SceneObject(SceneDoc.newId(), type == SceneObject.ModelType.PLAYER ? "Гравець " + (count(SceneObject.Kind.ACTOR) + 1) : "Модель", SceneObject.Kind.ACTOR);
        a.modelType = type;
        a.model = model;
        double[] spot = spawnSpot();
        a.x = spot[0]; a.y = spot[1]; a.z = spot[2];
        a.yaw = (float) Mth.wrapDegrees(view.yaw + 180);
        a.color = type == SceneObject.ModelType.PLAYER ? 0x59D185 : 0xB07CFF;
        if (type == SceneObject.ModelType.ASSET) {
            SceneDoc.Asset as = doc.assets.get(model);
            if (as != null) a.name = as.name.replaceFirst("\\.[^.]+$", "");
        }
        edit("Додати актора", () -> variant().objects.add(a));
        select(a.id);
        return a;
    }

    SceneObject addEmpty() {
        SceneObject e = new SceneObject(SceneDoc.newId(), "Точка " + (count(SceneObject.Kind.EMPTY) + 1), SceneObject.Kind.EMPTY);
        double[] spot = spawnSpot();
        e.x = spot[0]; e.y = spot[1]; e.z = spot[2];
        e.color = 0x9DB1D6;
        edit("Додати точку", () -> variant().objects.add(e));
        select(e.id);
        return e;
    }

    /** Де поставити новий об'єкт: точка під центром в'юпорта на блоках світу, інакше точка орбіти. */
    private double[] spawnSpot() {
        double[] r = EditorView.ray(vx + vw / 2.0, vy + vh / 2.0);
        var mc = Minecraft.getInstance();
        if (r != null && mc.level != null && mc.player != null) {
            Vec3 a = new Vec3(r[0], r[1], r[2]), b = a.add(r[3] * 64, r[4] * 64, r[5] * 64);
            var hit = mc.level.clip(new net.minecraft.world.level.ClipContext(a, b, net.minecraft.world.level.ClipContext.Block.COLLIDER,
                net.minecraft.world.level.ClipContext.Fluid.NONE, mc.player));
            if (hit.getType() != net.minecraft.world.phys.HitResult.Type.MISS) {
                Vec3 l = hit.getLocation();
                return new double[] { Math.round(l.x * 4) / 4.0, l.y, Math.round(l.z * 4) / 4.0 };
            }
        }
        return new double[] { view.px, view.py, view.pz };
    }

    int count(SceneObject.Kind k) {
        int n = 0;
        for (SceneObject o : variant().objects) if (o.kind == k) n++;
        return n;
    }

    Track addTrack(Track.Type type, String target) {
        String name = switch (type) {
            case CAMERA -> "Камери"; case ANIMATION -> "Анімація"; case AUDIO -> "Звук"; case OVERLAY -> "Оверлей";
            case EFFECT -> "Ефект"; case TIME -> "Час";
        };
        Track t = new Track(SceneDoc.newId(), name, type);
        t.target = target;
        edit("Новий трек", () -> variant().tracks.add(t));
        return t;
    }

    Clip addClip(Track t, String ref, double length) {
        Clip c = new Clip(SceneDoc.newId(), time, Math.max(0.1, length), ref);
        if (t.type == Track.Type.ANIMATION) {
            var ac = clips.clip(ref);
            if (ac != null && ac.length() > 0) { c.sourceLength = ac.length(); c.length = ac.length(); }
            c.blendIn = 0.15;
            c.blendOut = 0.15;
        }
        if (t.type == Track.Type.AUDIO) {
            SceneDoc.Asset a = doc.assets.get(ref);
            if (a != null && a.duration > 0) { c.sourceLength = a.duration; c.length = a.duration; }
            c.end = Clip.End.STOP;
        }
        if (t.type == Track.Type.TIME) { c.params.put("speed", 0.3); c.blendIn = 0.4; c.blendOut = 0.4; }
        if (t.type == Track.Type.OVERLAY) { c.params.put("enter", "fade"); c.params.put("exit", "fade"); }
        c.length = Math.min(c.length, Math.max(0.1, length() - time));
        edit("Новий кліп", () -> {
            t.clips.add(c);
            if (!t.type.overlap) EditOps.resolveOverlap(t, c);
            t.sort();
        });
        selectClip(t, c);
        return c;
    }

    @Override
    public void tick() {
        if (!readOnly && history.dirty()) status = status.isEmpty() ? "● не збережено" : status;
    }

    public SceneDoc doc() { return doc; }

    static void open(SceneDoc doc, boolean readOnly, String by) {
        Minecraft.getInstance().setScreen(new SceneEditorScreen(doc, readOnly, by));
    }

    /** Колір кліпу за типом треку. */
    static int clipColor(Track.Type t) {
        return switch (t) {
            case CAMERA -> 0xFFF2B84B;
            case ANIMATION -> 0xFF59D185;
            case AUDIO -> 0xFF4A9EFF;
            case OVERLAY -> 0xFFB07CFF;
            case EFFECT -> 0xFFE5646A;
            case TIME -> 0xFF39C5BB;
        };
    }

    static Icon trackIcon(Track.Type t) {
        return switch (t) {
            case CAMERA -> Icon.ZOOM;
            case ANIMATION -> Icon.ANIMATE;
            case AUDIO -> Icon.VOLUME;
            case OVERLAY -> Icon.LAYOUT_RESET;
            case EFFECT -> Icon.WAND;
            case TIME -> Icon.LOOP;
        };
    }

    static int panelBg() { return MenuSkin.PANE; }
}
