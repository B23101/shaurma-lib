package dev.shaurmalib.scene.mc.ui;

/** Обчислення простих виразів у числових полях (+ - * / і дужки), як у Blockbench: «8+4», «16/3». */
public final class Expr {
    private final String s;
    private int i;

    private Expr(String s) { this.s = s.replace(',', '.').replace(" ", ""); }

    public static Double eval(String s) {
        try {
            Expr e = new Expr(s);
            double v = e.sum();
            if (e.i != e.s.length() || !Double.isFinite(v)) return null;
            return v;
        } catch (RuntimeException ex) {
            return null;
        }
    }

    private double sum() {
        double v = prod();
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '+') { i++; v += prod(); } else if (c == '-') { i++; v -= prod(); } else break;
        }
        return v;
    }

    private double prod() {
        double v = unary();
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == '*') { i++; v *= unary(); } else if (c == '/') { i++; v /= unary(); } else break;
        }
        return v;
    }

    private double unary() {
        if (i < s.length() && s.charAt(i) == '-') { i++; return -unary(); }
        if (i < s.length() && s.charAt(i) == '(') { i++; double v = sum(); i++; return v; }
        int st = i;
        while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.' || s.charAt(i) == 'e')) i++;
        return Double.parseDouble(s.substring(st, i));
    }
}
