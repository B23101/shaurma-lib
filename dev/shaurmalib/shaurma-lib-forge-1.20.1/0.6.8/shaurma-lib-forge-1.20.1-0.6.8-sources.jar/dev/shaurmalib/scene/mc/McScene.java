package dev.shaurmalib.scene.mc;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.api.SceneDefinition;
import dev.shaurmalib.scene.api.SceneRegistry;
import dev.shaurmalib.scene.net.SceneMessage;
import dev.shaurmalib.scene.server.SceneServer;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

/**
 * Серверний клей рушія сцен для ванілі (без лоадера): старт/стоп сервера, тік, вихід гравця,
 * команда {@code /scene}, вхідні повідомлення. Лоадер лише кличе ці методи зі своїх подій.
 * Для режимів — {@link #bind(ServerPlayer)} (прив'язка гравця зі скіном для слота).
 */
public final class McScene {

    private McScene() {}

    private static McSceneHost host;

    public static void onServerStarted(MinecraftServer server) {
        host = new McSceneHost(server);
        SceneServer.start(host);
    }

    public static void onServerStopping() {
        SceneServer.stopServer();
        if (host != null) host.shutdown();
        host = null;
    }

    public static void tick() {
        SceneServer s = SceneServer.get();
        if (s != null) s.tick();
    }

    public static void onLeave(ServerPlayer p) {
        SceneServer s = SceneServer.get();
        if (s != null) s.onLeave(p.getUUID());
        if (host != null) host.onLogout(p);
    }

    public static void handle(ServerPlayer from, SceneMessage m) {
        SceneServer s = SceneServer.get();
        if (s != null && m.op.toServer) s.handle(from.getUUID(), m);
    }

    /** Прив'язка гравця для слота: UUID, нік, скін (текстура профілю), позиція. */
    public static SceneBindings.Binding bind(ServerPlayer p) { return McSceneHost.of(p); }

    public static List<SceneBindings.Binding> bind(Collection<ServerPlayer> ps) {
        List<SceneBindings.Binding> l = new ArrayList<>();
        for (ServerPlayer p : ps) l.add(bind(p));
        return l;
    }

    // ═════════════════════════ /scene ═════════════════════════

    public static LiteralArgumentBuilder<CommandSourceStack> command() {
        return Commands.literal("scene")
            .requires(s -> s.hasPermission(2))
            .then(Commands.literal("list").executes(McScene::list))
            .then(Commands.literal("edit")
                .then(Commands.argument("id", ResourceLocationArgument.id()).suggests((c, b) -> SharedSuggestionProvider.suggest(ids(), b))
                    .executes(c -> {
                        ServerPlayer p = c.getSource().getPlayerOrException();
                        handle(p, SceneMessage.of(SceneMessage.Op.EDIT).scene(ResourceLocationArgument.getId(c, "id").toString()));
                        return 1;
                    })))
            .then(Commands.literal("home")
                .then(Commands.argument("id", ResourceLocationArgument.id()).suggests((c, b) -> SharedSuggestionProvider.suggest(ids(), b))
                    .executes(c -> home(c, false))
                    .then(Commands.literal("clear").executes(c -> home(c, true)))))
            .then(Commands.literal("play")
                .then(Commands.argument("id", ResourceLocationArgument.id()).suggests((c, b) -> SharedSuggestionProvider.suggest(ids(), b))
                    .executes(c -> play(c, List.of(c.getSource().getPlayerOrException()), null))
                    .then(Commands.argument("targets", EntityArgument.players())
                        .executes(c -> play(c, EntityArgument.getPlayers(c, "targets"), null))
                        .then(Commands.argument("variant", StringArgumentType.word())
                            .executes(c -> play(c, EntityArgument.getPlayers(c, "targets"), StringArgumentType.getString(c, "variant")))))))
            .then(Commands.literal("stop")
                .executes(c -> stop(List.of(c.getSource().getPlayerOrException())))
                .then(Commands.argument("targets", EntityArgument.players()).executes(c -> stop(EntityArgument.getPlayers(c, "targets")))));
    }

    private static List<String> ids() {
        List<String> l = new ArrayList<>();
        for (SceneDefinition d : SceneRegistry.all()) l.add(d.id);
        return l;
    }

    private static int list(CommandContext<CommandSourceStack> c) {
        SceneServer s = SceneServer.get();
        if (SceneRegistry.all().isEmpty()) { c.getSource().sendSuccess(() -> Component.literal("Жоден мод не зареєстрував сцен"), false); return 0; }
        for (SceneDefinition d : SceneRegistry.all()) {
            var doc = s == null ? null : s.doc(d.id);
            String st = doc == null ? "§7не змонтована" : "§aревізія " + doc.revision + " · " + doc.variants.size() + " варіант(ів)";
            c.getSource().sendSuccess(() -> Component.literal("§f" + d.id + " §8— §f" + d.title + " §8· " + st), false);
        }
        return 1;
    }

    private static int play(CommandContext<CommandSourceStack> c, Collection<ServerPlayer> targets, String variant) throws CommandSyntaxException {
        SceneServer s = SceneServer.get();
        String id = ResourceLocationArgument.getId(c, "id").toString();
        if (s == null || !s.hasContent(id)) { c.getSource().sendFailure(Component.literal("Сцена " + id + " порожня або не існує")); return 0; }
        SceneBindings b = new SceneBindings();
        SceneDefinition def = SceneRegistry.get(id);
        List<SceneBindings.Binding> all = bind(targets);
        if (def != null) for (SceneDefinition.Slot slot : def.slots) {
            switch (slot.kind()) {
                case PLAYER, ENTITY -> { if (!all.isEmpty()) b.bind(slot.name(), all.get(0)); }
                case PLAYERS -> b.bindAll(slot.name(), all.subList(0, Math.min(all.size(), slot.max())));
                case VALUE -> b.bind(slot.name(), SceneBindings.Binding.value(slot.title()));
            }
        }
        List<UUID> viewers = new ArrayList<>();
        for (ServerPlayer p : targets) viewers.add(p.getUUID());
        long sid = s.play(id, variant, b, viewers, SceneServer.PlayOptions.defaults());
        c.getSource().sendSuccess(() -> Component.literal(sid == 0 ? "Не вдалося запустити " + id : "Сцена " + id + " запущена (" + targets.size() + ")"), true);
        return sid == 0 ? 0 : 1;
    }

    /** {@code /scene home <id>} — точка редагування = очі гравця (позиція, кути, вимір); {@code clear} — прибрати. */
    private static int home(CommandContext<CommandSourceStack> c, boolean clear) throws CommandSyntaxException {
        SceneServer s = SceneServer.get();
        ServerPlayer p = c.getSource().getPlayerOrException();
        String id = ResourceLocationArgument.getId(c, "id").toString();
        if (s == null) return 0;
        try {
            double[] h = clear ? null : new double[] { p.getX(), p.getEyeY(), p.getZ(), p.getYRot(), p.getXRot() };
            var d = s.setHome(id, h, p.level().dimension().location().toString(), p.getGameProfile().getName());
            c.getSource().sendSuccess(() -> Component.literal(clear ? "Точку редагування " + id + " прибрано"
                : String.format(java.util.Locale.ROOT, "Точка редагування %s: %.1f %.1f %.1f (%s), ревізія %d — редактор відкриватиметься звідси",
                    id, h[0], h[1], h[2], d.homeDim, d.revision)), true);
            return 1;
        } catch (java.io.IOException e) {
            c.getSource().sendFailure(Component.literal(e.getMessage()));
            return 0;
        }
    }

    private static int stop(Collection<ServerPlayer> targets) {
        SceneServer s = SceneServer.get();
        if (s != null) for (ServerPlayer p : targets) s.stopFor(p.getUUID());
        return targets.size();
    }
}
