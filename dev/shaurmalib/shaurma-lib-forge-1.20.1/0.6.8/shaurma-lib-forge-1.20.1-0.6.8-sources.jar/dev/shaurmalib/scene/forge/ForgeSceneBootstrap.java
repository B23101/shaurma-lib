package dev.shaurmalib.scene.forge;

import dev.shaurmalib.scene.mc.McScene;
import dev.shaurmalib.scene.net.SceneMessage;
import dev.shaurmalib.scene.net.SceneNetwork;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.UUID;

/**
 * Forge-клей рушія сцен: події сервера → {@link McScene}, мережа → {@link SceneNetwork}, клієнт —
 * {@link ForgeSceneClient}. Викликається з конструктора мода бібліотеки і з реєстрації каналу.
 */
public final class ForgeSceneBootstrap {

    private ForgeSceneBootstrap() {}

    private static net.minecraft.server.MinecraftServer server;

    public static void init(IEventBus modBus) {
        MinecraftForge.EVENT_BUS.addListener((ServerStartedEvent e) -> { server = e.getServer(); McScene.onServerStarted(e.getServer()); });
        MinecraftForge.EVENT_BUS.addListener((ServerStoppingEvent e) -> { McScene.onServerStopping(); server = null; });
        MinecraftForge.EVENT_BUS.addListener((TickEvent.ServerTickEvent e) -> { if (e.phase == TickEvent.Phase.END) McScene.tick(); });
        // повернути гравця з якоря камери ДО збереження його даних
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGHEST, (PlayerEvent.PlayerLoggedOutEvent e) -> {
            if (e.getEntity() instanceof ServerPlayer p) McScene.onLeave(p);
        });
        MinecraftForge.EVENT_BUS.addListener((RegisterCommandsEvent e) -> e.getDispatcher().register(McScene.command()));
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ForgeSceneClient.init(modBus));
    }

    /** Один двонаправлений пакет на спільному каналі бібліотеки. @return наступний вільний id */
    public static int registerPackets(SimpleChannel channel, int id) {
        channel.registerMessage(id, ScenePacket.class, ScenePacket::encode, ScenePacket::decode, ScenePacket::handle);
        SceneNetwork.Holder.set(new SceneNetwork() {
            @Override public void toPlayer(UUID player, SceneMessage m) {
                ServerPlayer p = server == null ? null : server.getPlayerList().getPlayer(player);
                if (p != null) channel.send(PacketDistributor.PLAYER.with(() -> p), new ScenePacket(m));
            }
            @Override public void toServer(SceneMessage m) { channel.sendToServer(new ScenePacket(m)); }
        });
        return id + 1;
    }
}
