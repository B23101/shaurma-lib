package dev.shaurmalib.scene.mc.ui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;

/** Лінії й трикутники довільного нахилу в GUI (гізмо, контури UV) — GuiGraphics уміє лише прямокутники. */
public final class Draw2D {
    private Draw2D() {}

    public static void line(GuiGraphics g, double x1, double y1, double x2, double y2, float width, int color) {
        double dx = x2 - x1, dy = y2 - y1, len = Math.sqrt(dx * dx + dy * dy);
        if (len < 1e-6) return;
        double nx = -dy / len * width / 2, ny = dx / len * width / 2;
        quad(g, x1 + nx, y1 + ny, x2 + nx, y2 + ny, x2 - nx, y2 - ny, x1 - nx, y1 - ny, color);
    }

    public static void quad(GuiGraphics g, double ax, double ay, double bx, double by, double cx, double cy, double dx, double dy, int color) {
        Matrix4f m = g.pose().last().pose();
        float a = (color >>> 24) / 255f, r = (color >> 16 & 255) / 255f, gr = (color >> 8 & 255) / 255f, b = (color & 255) / 255f;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        bb.vertex(m, (float) ax, (float) ay, 0).color(r, gr, b, a).endVertex();
        bb.vertex(m, (float) bx, (float) by, 0).color(r, gr, b, a).endVertex();
        bb.vertex(m, (float) cx, (float) cy, 0).color(r, gr, b, a).endVertex();
        bb.vertex(m, (float) dx, (float) dy, 0).color(r, gr, b, a).endVertex();
        BufferUploader.drawWithShader(bb.end());
        RenderSystem.enableCull();
    }

    public static void triangle(GuiGraphics g, double ax, double ay, double bx, double by, double cx, double cy, int color) {
        quad(g, ax, ay, bx, by, cx, cy, cx, cy, color);
    }

    /** Точка-ручка (квадрат з обводкою). */
    public static void dot(GuiGraphics g, double x, double y, int r, int color) {
        int ix = (int) Math.round(x), iy = (int) Math.round(y);
        g.fill(ix - r - 1, iy - r - 1, ix + r + 1, iy + r + 1, 0xFF000000);
        g.fill(ix - r, iy - r, ix + r, iy + r, color);
    }

    public static void rectOutline(GuiGraphics g, int x, int y, int w, int h, int color) {
        g.fill(x, y, x + w, y + 1, color);
        g.fill(x, y + h - 1, x + w, y + h, color);
        g.fill(x, y, x + 1, y + h, color);
        g.fill(x + w - 1, y, x + w, y + h, color);
    }

    /** Відстань від точки до відрізка (для «влучання» в лінію гізмо). */
    public static double distToSegment(double px, double py, double ax, double ay, double bx, double by) {
        double dx = bx - ax, dy = by - ay, l2 = dx * dx + dy * dy;
        double t = l2 < 1e-9 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l2));
        double qx = ax + t * dx - px, qy = ay + t * dy - py;
        return Math.sqrt(qx * qx + qy * qy);
    }
}
