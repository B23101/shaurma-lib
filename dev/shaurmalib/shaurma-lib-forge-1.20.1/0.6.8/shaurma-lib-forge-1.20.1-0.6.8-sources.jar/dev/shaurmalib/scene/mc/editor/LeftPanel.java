package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.anim.ShaurmaAnim;
import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.scene.api.SceneDefinition;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.doc.Track;
import dev.shaurmalib.scene.edit.SceneValidator;
import dev.shaurmalib.scene.eval.SceneRig;
import dev.shaurmalib.scene.mc.client.SceneAssets;
import dev.shaurmalib.scene.mc.client.SceneOverlays;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.Icons;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.tinyfd.TinyFileDialogs;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Ліва панель: Outliner (об'єкти й кістки), Ассети (імпорт, моделі, звуки, анімації, оверлеї, ефекти), Слоти й перевірка. */
final class LeftPanel {

    private LeftPanel() {}

    private static final int ROW = 13;
    private static String expanded;
    /** Звук, який зараз тягнуть з панелі на таймлайн (відпустити над доріжкою — кліп саме там). */
    private static SceneDoc.Asset dragAsset;

    static SceneDoc.Asset dragAsset() { return dragAsset; }

    static void clearDrag() { dragAsset = null; }
    private static String search = "";

    /** Три модульні панелі — як «Об'єкти / Текстури / Анімація» в Shaurma Modeling: заголовок зі стрілкою, згортання, роздільники. */
    private static final List<SceneDock.Panel> PANELS = List.of(
        new SceneDock.Panel("outliner", "Сцена", Icon.CUBE, 0.38, LeftPanel::outliner),
        new SceneDock.Panel("assets", "Ассети й медіа", Icon.IMPORT, 0.42, LeftPanel::assets),
        new SceneDock.Panel("slots", "Слоти й перевірка", Icon.LAYOUT_RESET, 0.20, LeftPanel::slots));

    static void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        SceneDock.render(s, gui, PANELS, true, x, y, w, h);
    }

    // ═════════════════════════ Outliner ═════════════════════════

    static void outliner(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        List<SceneObject> objs = s.variant().objects;
        int content = 0;
        for (SceneObject o : objs) {
            content += ROW;
            if (o.id.equals(expanded)) {
                SceneRig r = s.clips.rig(o);
                if (r != null) content += r.size() * ROW;
            }
        }
        int off = gui.scrollBegin("outliner", x, y, w, h, content + 30);
        int cy = y - off;
        if (objs.isEmpty()) gui.textClip("Порожньо: «+ Камера», «+ Гравець» угорі", x + 6, cy + 4, w - 12, Theme.MUTED);
        for (SceneObject o : objs) {
            boolean sel = o.id.equals(s.selObj) && s.selBone == null;
            boolean hov = gui.hover(x, cy, w, ROW);
            if (sel || hov) gui.g.fill(x + 1, cy, x + w - 1, cy + ROW, sel ? MenuSkin.ROW_ON : MenuSkin.ROW_HOT);
            int ix = x + 4;
            boolean hasRig = o.kind == SceneObject.Kind.ACTOR || o.kind == SceneObject.Kind.PROP;
            if (hasRig) {
                Icons.draw(gui.g, o.id.equals(expanded) ? Icon.CHEVRON_DOWN : Icon.CHEVRON_RIGHT, ix, cy, ROW, Theme.MUTED);
                if (gui.clicked(ix, cy, 10, ROW, 0)) expanded = o.id.equals(expanded) ? null : o.id;
            }
            ix += 11;
            gui.g.fill(ix, cy + 4, ix + 4, cy + 9, 0xFF000000 | o.color);
            Icons.draw(gui.g, icon(o), ix + 5, cy, ROW, Theme.TEXT);
            String label = o.name + (o.slot != null ? " ⟨" + o.slot + (o.slotIndex > 0 ? "#" + o.slotIndex : "") + "⟩" : "");
            gui.textClip(label, ix + 19, cy + 3, w - (ix - x) - 50, o.editorHidden ? Theme.MUTED : Theme.TEXT);
            if (gui.icon(x + w - 28, cy, ROW, o.editorHidden ? Icon.EYE_OFF : Icon.EYE, !o.editorHidden, Component.literal("Показати в редакторі"))) {
                s.edit("Видимість", () -> o.editorHidden = !o.editorHidden);
            }
            if (gui.icon(x + w - 15, cy, ROW, o.locked ? Icon.LOCK : Icon.UNLOCK, o.locked, Component.literal("Заблокувати від змін і вибору у в'юпорті"))) {
                s.edit("Блокування", () -> o.locked = !o.locked);
            }
            if (gui.doubleClicked(x, cy, w - 30, ROW)) { s.select(o.id); s.focusSelected(); }
            if (gui.clicked(x, cy, w - 30, ROW, 0)) s.select(o.id);
            if (gui.clicked(x, cy, w, ROW, 1)) context(s, o, gui.mx, gui.my);
            cy += ROW;
            if (o.id.equals(expanded)) {
                SceneRig r = s.clips.rig(o);
                if (r != null) for (int i = 0; i < r.size(); i++) {
                    String bone = r.bone(i);
                    int depth = 0;
                    for (int p = r.parent(i); p >= 0 && depth < 12; p = r.parent(p)) depth++;
                    boolean bsel = o.id.equals(s.selObj) && bone.equals(s.selBone);
                    if (bsel || gui.hover(x, cy, w, ROW)) gui.g.fill(x + 1, cy, x + w - 1, cy + ROW, bsel ? MenuSkin.ROW_ON : MenuSkin.ROW_HOT);
                    String lbl = o.boneLabels.get(bone);
                    boolean hidden = o.hiddenBones.contains(bone);
                    gui.textClip((o.bones.containsKey(bone) && !o.bones.get(bone).isEmpty() ? "◆ " : "") + bone + (lbl != null ? "  [" + lbl + "]" : ""),
                        x + 20 + depth * 6, cy + 3, w - 40 - depth * 6, hidden ? Theme.MUTED : 0xFFB9C8E6);
                    if (gui.icon(x + w - 15, cy, ROW, hidden ? Icon.EYE_OFF : Icon.EYE, !hidden, Component.literal("Сховати кістку (з дітьми)"))) {
                        s.edit("Кістка", () -> { if (!o.hiddenBones.remove(bone)) o.hiddenBones.add(bone); });
                    }
                    if (gui.clicked(x, cy, w - 16, ROW, 0)) { s.select(o.id); s.selBone = bone; }
                    cy += ROW;
                }
                else { gui.textClip("модель ще вантажиться…", x + 20, cy + 3, w - 24, Theme.MUTED); cy += ROW; }
            }
        }
        gui.scrollEnd();
    }

    static Icon icon(SceneObject o) {
        return switch (o.kind) {
            case CAMERA -> Icon.ZOOM;
            case ACTOR -> o.modelType == SceneObject.ModelType.PLAYER ? Icon.PLAYERS : Icon.CUBE;
            case PROP -> Icon.CUBE;
            case EMPTY -> Icon.PIVOT;
        };
    }

    private static void context(SceneEditorScreen s, SceneObject o, int mx, int my) {
        s.select(o.id);
        List<Popup.Item> items = new ArrayList<>();
        items.add(Popup.item("До вибраного (F)", s::focusSelected));
        items.add(Popup.item("Дублювати (Ctrl+D)", s::duplicateSelection));
        if (o.kind == SceneObject.Kind.ACTOR || o.kind == SceneObject.Kind.PROP) {
            items.add(Popup.item("+ Трек анімації", () -> s.addTrack(Track.Type.ANIMATION, o.id)));
        }
        if (o.isCamera()) {
            items.add(Popup.item("Камера = вигляд (Ctrl+Num0)", s::cameraToView));
            items.add(Popup.item("Дивитись крізь камеру", () -> { s.view.cameraView = true; }));
        }
        items.add(Popup.item("Зняти батька", () -> s.edit("Батько", () -> { o.parent = null; o.parentBone = null; }), o.parent != null));
        items.add(Popup.item("Видалити", s::deleteSelection));
        Popup.open(o.name, mx, my, items);
    }

    // ═════════════════════════ Ассети ═════════════════════════

    static void assets(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        int off = gui.scrollBegin("assets", x, y, w, h, assetsHeight(s));
        int cy = y - off + 2;
        if (gui.button(x + 4, cy, w - 8, 14, Component.literal("Імпорт файлу…"), false,
            Component.literal(".bbmodel / .geo.json — модель (з анімаціями), .png — текстура, .wav / .ogg / .mp3 — звук. Лежить у папці світу, не в ресурсах мода"), !s.readOnly)) {
            importDialog(s);
        }
        cy += 18;
        String q = gui.textField("asset.search", x + 4, cy, w - 8, 13, search, Component.literal("пошук…"));
        if (q != null) search = q;
        String filter = gui.liveText("asset.search", search).toLowerCase(Locale.ROOT);
        cy += 17;

        gui.header("Ассети світу", x + 2, cy, w - 4);
        cy += 14;
        if (s.doc.assets.isEmpty()) { gui.textClip("ще нічого не імпортовано", x + 6, cy, w - 12, Theme.MUTED); cy += ROW; }
        for (SceneDoc.Asset a : s.doc.assets.values()) {
            if (!filter.isEmpty() && !a.name.toLowerCase(Locale.ROOT).contains(filter)) continue;
            boolean ready = SceneAssets.has(a);
            if (gui.hover(x, cy, w, ROW)) gui.g.fill(x + 1, cy, x + w - 1, cy + ROW, MenuSkin.ROW_HOT);
            Icon ic = switch (a.type) { case MODEL -> Icon.CUBE; case TEXTURE -> Icon.TEXTURE; case AUDIO -> Icon.VOLUME; default -> Icon.FOLDER; };
            Icons.draw(gui.g, ic, x + 4, cy, ROW, ready ? Theme.TEXT : Theme.DANGER);
            String extra = a.type == SceneDoc.Asset.Type.AUDIO ? String.format(" %.1fс", a.duration) : a.width > 0 ? " " + a.width + "×" + a.height : "";
            gui.textClip(a.name + extra, x + 18, cy + 3, w - 50, ready ? Theme.TEXT : Theme.DANGER);
            if (gui.icon(x + w - 15, cy, ROW, Icon.PLUS, false, Component.literal(switch (a.type) {
                case MODEL -> "Додати актора з цією моделлю";
                case AUDIO -> "Звук на таймлайн у playhead";
                case TEXTURE -> "Текстура / скін вибраному актору";
                default -> "—";
            }))) useAsset(s, a);
            if (a.type == SceneDoc.Asset.Type.AUDIO && ready && !s.readOnly) {
                if (gui.hover(x, cy, w - 18, ROW)) gui.tip(Component.literal("Тягни на звуковий трек таймлайну — кліп з'явиться там, де відпустиш"));
                if (gui.press("assetdrag." + a.id, x, cy, w - 18, ROW, 0)) dragAsset = a;
            }
            if (gui.clicked(x, cy, w - 16, ROW, 1)) {
                Popup.open(a.name, gui.mx, gui.my, List.of(Popup.item("Видалити з документа", () -> s.edit("Ассет", () -> s.doc.assets.remove(a.id)))));
            }
            cy += ROW;
            if (a.type == SceneDoc.Asset.Type.MODEL) {
                SceneAssets.Model m = SceneAssets.model(s.doc, a.id);
                if (m != null) for (String warn : m.warnings) { gui.textClip("⚠ " + warn, x + 18, cy + 2, w - 22, Theme.WARN); cy += 11; }
            }
        }

        if (s.def != null && !s.def.resourceModels.isEmpty()) {
            cy += 4;
            gui.header("Моделі мода", x + 2, cy, w - 4);
            cy += 14;
            for (String id : s.def.resourceModels) {
                gui.textClip(id, x + 6, cy + 3, w - 24, Theme.TEXT);
                if (gui.icon(x + w - 15, cy, ROW, Icon.PLUS, false, Component.literal("Додати актора"))) s.addActor(SceneObject.ModelType.RESOURCE, id);
                cy += ROW;
            }
        }

        // анімації під вибраного актора
        SceneObject sel = s.selected();
        cy += 4;
        gui.header("Анімації" + (sel != null && sel.kind != SceneObject.Kind.CAMERA ? " → " + sel.name : ""), x + 2, cy, w - 4);
        cy += 14;
        if (sel == null || sel.kind == SceneObject.Kind.CAMERA || sel.kind == SceneObject.Kind.EMPTY) {
            gui.textClip("виберіть актора", x + 6, cy + 2, w - 12, Theme.MUTED);
            cy += ROW;
        } else {
            for (String id : animationsFor(s, sel)) {
                if (!filter.isEmpty() && !id.toLowerCase(Locale.ROOT).contains(filter)) continue;
                AnimationClip c = s.clips.clip(id);
                gui.textClip(id + (c != null ? String.format(" · %.1fс", c.length()) : ""), x + 6, cy + 3, w - 40, Theme.TEXT);
                if (gui.icon(x + w - 28, cy, ROW, Icon.LOOP, id.equals(sel.idle), Component.literal("Зробити idle (зациклено під усім)"))) {
                    s.edit("Idle", () -> sel.idle = id.equals(sel.idle) ? null : id);
                }
                if (gui.icon(x + w - 15, cy, ROW, Icon.PLUS, false, Component.literal("Кліп на трек анімації актора у playhead"))) addAnimation(s, sel, id);
                cy += ROW;
            }
        }

        cy += 4;
        gui.header("Оверлеї", x + 2, cy, w - 4);
        cy += 14;
        for (var e : SceneOverlays.overlays()) {
            gui.textClip(e.title(), x + 6, cy + 3, w - 24, Theme.TEXT);
            if (gui.icon(x + w - 15, cy, ROW, Icon.PLUS, false, Component.literal(e.id()))) addMedia(s, Track.Type.OVERLAY, e.id(), 3);
            cy += ROW;
        }
        cy += 4;
        gui.header("Ефекти", x + 2, cy, w - 4);
        cy += 14;
        for (var e : SceneOverlays.effects()) {
            gui.textClip(e.title(), x + 6, cy + 3, w - 24, Theme.TEXT);
            if (gui.icon(x + w - 15, cy, ROW, Icon.PLUS, false, Component.literal(e.id()))) addMedia(s, Track.Type.EFFECT, e.id(), 2);
            cy += ROW;
        }
        if (gui.button(x + 4, cy + 4, w - 8, 14, Component.literal("+ Сповільнення (slow-mo)"), false, Component.literal("Кліп TIME: швидкість часу з плавним входом/виходом"))) {
            addMedia(s, Track.Type.TIME, null, 2);
        }
        gui.scrollEnd();
    }

    private static int assetsHeight(SceneEditorScreen s) {
        int n = 40 + s.doc.assets.size() * 15 + 200 + SceneOverlays.overlays().size() * ROW + SceneOverlays.effects().size() * ROW;
        SceneObject sel = s.selected();
        if (sel != null) n += animationsFor(s, sel).size() * ROW;
        if (s.def != null) n += s.def.resourceModels.size() * ROW + 20;
        return n;
    }

    /** Кліпи, що підходять ригу актора: гравець — кліпи ригу player, модель — її власні (asset/ресурс). */
    static List<String> animationsFor(SceneEditorScreen s, SceneObject o) {
        List<String> out = new ArrayList<>();
        if (o.modelType == SceneObject.ModelType.ASSET) {
            SceneAssets.Model m = SceneAssets.model(s.doc, o.model);
            if (m != null) out.addAll(m.clips.keySet());
        }
        for (AnimationClip c : ShaurmaAnim.clips().all()) {
            boolean fits = switch (o.modelType) {
                case PLAYER -> "player".equals(c.rig());
                case RESOURCE -> o.model != null && c.id().startsWith(o.model.replaceAll("^([^:]+):.*$", "$1") + ":") && !"player".equals(c.rig());
                default -> false;
            };
            if (fits) out.add(c.id());
        }
        out.sort(String::compareTo);
        return out;
    }

    static void addAnimation(SceneEditorScreen s, SceneObject actor, String clip) {
        Track t = null;
        for (Track x : s.variant().animationTracks(actor.id)) t = x;
        if (t == null) t = s.addTrack(Track.Type.ANIMATION, actor.id);
        s.addClip(t, clip, 2);
    }

    static void addMedia(SceneEditorScreen s, Track.Type type, String ref, double len) {
        Track t = null;
        for (Track x : s.variant().tracks(type)) t = x;
        if (t == null) t = s.addTrack(type, null);
        s.addClip(t, ref, len);
    }

    private static void useAsset(SceneEditorScreen s, SceneDoc.Asset a) {
        switch (a.type) {
            case MODEL -> s.addActor(SceneObject.ModelType.ASSET, a.id);
            case AUDIO -> addMedia(s, Track.Type.AUDIO, a.id, Math.max(1, a.duration));
            case TEXTURE -> {
                SceneObject o = s.selected();
                if (o == null) { s.toast("Виберіть актора"); return; }
                s.edit("Текстура", () -> {
                    if (o.modelType == SceneObject.ModelType.PLAYER) { o.skinMode = SceneObject.SkinMode.TEXTURE; o.skinValue = a.id; }
                    else o.texture = a.id;
                });
            }
            default -> { }
        }
    }

    static void importDialog(SceneEditorScreen s) {
        Thread t = new Thread(() -> {
            String result;
            try (MemoryStack st = MemoryStack.stackPush()) {
                String[] pats = { "*.bbmodel", "*.json", "*.png", "*.wav", "*.ogg", "*.mp3" };
                PointerBuffer f = st.mallocPointer(pats.length);
                for (String p : pats) f.put(st.UTF8(p));
                f.flip();
                result = TinyFileDialogs.tinyfd_openFileDialog("Імпорт у сцену", "", f, "Моделі, текстури, звуки", true);
            }
            if (result == null) return;
            List<Path> paths = new ArrayList<>();
            for (String p : result.split("\\|")) paths.add(Path.of(p));
            Minecraft.getInstance().execute(() -> importPaths(s, paths, false));
        }, "shaurma-scene-import");
        t.setDaemon(true);
        t.start();
    }

    /**
     * Імпорт файлів як ассетів. {@code dropped} — файл кинули у вікно (drag-and-drop): звук одразу кладеться на звуковий
     * трек у playhead, як у відеомонтажці; через «Імпорт» звук лише потрапляє в ассети.
     */
    static void importPaths(SceneEditorScreen s, List<Path> paths, boolean dropped) {
        for (Path p : paths) {
            try {
                SceneDoc.Asset a = SceneAssets.importFile(p);
                s.edit("Імпорт " + a.name, () -> s.doc.assets.put(a.id, a));
                SceneAssets.upload(s.doc.id, a);
                s.toast("Імпортовано: " + a.name);
                if (dropped && a.type == SceneDoc.Asset.Type.AUDIO) useAsset(s, a);
            } catch (Exception e) {
                s.toast("Не вдалося імпортувати " + p.getFileName() + ": " + e.getMessage());
            }
        }
    }

    // ═════════════════════════ Слоти й перевірка ═════════════════════════

    static void slots(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        int off = gui.scrollBegin("slots", x, y, w, h, 400 + s.issues.size() * 24);
        int cy = y - off + 2;
        if (gui.checkbox(x + 6, cy + 2, w - 12, Component.literal("Превʼю: у слотах — я"), s.previewSlots,
            Component.literal("Вимкніть, щоб побачити сцену «як без гравців» (актори слотів ховаються)"))) { s.previewSlots = !s.previewSlots; s.rebuild(); }
        cy += 16;
        gui.text("Гравців у списках:", x + 6, cy + 3, Theme.MUTED);
        var n = gui.number("preview.count", x + w - 46, cy, 40, 13, s.previewCount, 1, Theme.ACCENT);
        if (n.any()) { s.previewCount = (int) Math.max(0, Math.min(16, Math.round(n.value()))); s.rebuild(); }
        cy += 18;
        gui.header("Слоти режиму", x + 2, cy, w - 4);
        cy += 14;
        if (s.def == null || s.def.slots.isEmpty()) { gui.textClip("режим не оголосив слотів", x + 6, cy + 2, w - 12, Theme.MUTED); cy += ROW; }
        else for (SceneDefinition.Slot sl : s.def.slots) {
            int users = 0;
            for (SceneObject o : s.variant().objects) if (sl.name().equals(o.slot)) users++;
            gui.textClip(sl.title() + " · " + sl.name() + (sl.kind() == SceneDefinition.SlotKind.PLAYERS ? " (до " + sl.max() + ")" : ""), x + 6, cy + 2, w - 30, Theme.TEXT);
            gui.textClip(users == 0 ? "—" : String.valueOf(users), x + w - 22, cy + 2, 18, users == 0 ? Theme.WARN : Theme.OK);
            cy += 12;
            if (!sl.description().isEmpty()) { gui.textClip(sl.description(), x + 10, cy, w - 14, Theme.MUTED); cy += 11; }
        }
        if (s.def != null && !s.def.events.isEmpty()) {
            cy += 4;
            gui.header("Події (мітки)", x + 2, cy, w - 4);
            cy += 14;
            for (String e : s.def.events) { gui.textClip(e, x + 6, cy + 2, w - 12, 0xFFF2B84B); cy += 12; }
        }
        cy += 4;
        gui.header("Перевірка (" + s.issues.size() + ")", x + 2, cy, w - 4);
        cy += 14;
        if (s.issues.isEmpty()) { gui.textClip("✔ Проблем немає", x + 6, cy + 2, w - 12, Theme.OK); cy += ROW; }
        for (SceneValidator.Issue i : s.issues) {
            boolean err = i.level() == SceneValidator.Level.ERROR;
            boolean hov = gui.hover(x, cy, w, 22);
            if (hov) gui.g.fill(x + 1, cy, x + w - 1, cy + 22, MenuSkin.ROW_HOT);
            gui.textClip((err ? "✖ " : "⚠ ") + i.message(), x + 6, cy + 2, w - 10, err ? Theme.DANGER : Theme.WARN);
            gui.textClip(i.variant() == null ? "уся сцена" : "варіант " + i.variant(), x + 14, cy + 12, w - 18, Theme.MUTED);
            if (gui.clicked(x, cy, w, 22, 0) && i.objectId() != null) {
                if (i.variant() != null) { s.variantId = i.variant(); s.rebuild(); }
                s.select(i.objectId());
            }
            cy += 24;
        }
        gui.scrollEnd();
    }
}
