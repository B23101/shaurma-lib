package dev.shaurmalib.scene.mc.client;

import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.io.AudioPcm;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.AL11;
import org.lwjgl.system.MemoryUtil;

import java.nio.ShortBuffer;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Звукові кліпи сцени через OpenAL (контекст ванільного рушія звуку): WAV/OGG/MP3 зі світу, гучність
 * з кривої gain і fade, зсув у джерелі (trim), просторові джерела за об'єктом. Позиція в джерелі
 * синхронізується з таймлайном — перемотка в редакторі одразу чутна, розбіжність >120 мс — підтягується.
 * {@code sound:minecraft:...} — ванільні звуки, грають разово на старті кліпу.
 */
public final class SceneSound {

    private SceneSound() {}

    private static final class Voice {
        int source, buffer;
        String key;
        boolean stereo;
        long session;
        int seen;
    }

    private static final Map<String, Voice> VOICES = new HashMap<>();
    private static final Map<String, Integer> BUFFERS = new HashMap<>();
    private static final Set<String> FIRED = new HashSet<>();
    private static int frameNo;

    /** Синхронізувати звук з кадром сесії (кожен кадр гри). */
    public static void update(long session, SceneDoc doc, SceneFrame frame, boolean playing) {
        frameNo++;
        float master = Minecraft.getInstance().options.getSoundSourceVolume(SoundSource.MASTER)
            * Minecraft.getInstance().options.getSoundSourceVolume(SoundSource.RECORDS);
        for (SceneFrame.Audio a : frame.audio) {
            String key = session + "/" + a.clip.id;
            if (a.ref.startsWith("sound:")) {
                if (playing && a.sourceTime - a.clip.in < 0.15 && FIRED.add(key)) vanilla(a.ref.substring(6), (float) a.gain, (float) a.pitch);
                continue;
            }
            Voice v = VOICES.get(key);
            if (v == null) {
                AudioPcm pcm = SceneAssets.audio(doc, a.ref);
                if (pcm == null) continue;
                v = new Voice();
                v.key = key;
                v.session = session;
                v.stereo = pcm.channels > 1 && a.position == null;
                v.buffer = buffer(doc.assets.get(a.ref).sha256 + (v.stereo ? "s" : "m"), v.stereo ? pcm : pcm.mono());
                if (v.buffer == 0) continue;
                v.source = AL10.alGenSources();
                AL10.alSourcei(v.source, AL10.AL_BUFFER, v.buffer);
                AL10.alSourcei(v.source, AL10.AL_LOOPING, a.loop ? AL10.AL_TRUE : AL10.AL_FALSE);
                VOICES.put(key, v);
            }
            v.seen = frameNo;
            int src = v.source;
            AL10.alSourcef(src, AL10.AL_GAIN, (float) Math.max(0, Math.min(4, a.gain)) * master);
            AL10.alSourcef(src, AL10.AL_PITCH, (float) Math.max(0.25, Math.min(4, a.pitch)));
            if (a.position == null) {
                AL10.alSourcei(src, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
                AL10.alSource3f(src, AL10.AL_POSITION, 0, 0, 0);
            } else {
                AL10.alSourcei(src, AL10.AL_SOURCE_RELATIVE, AL10.AL_FALSE);
                AL10.alSource3f(src, AL10.AL_POSITION, (float) a.position[0], (float) a.position[1], (float) a.position[2]);
                AL10.alSourcef(src, AL10.AL_REFERENCE_DISTANCE, 4f);
                AL10.alSourcef(src, AL10.AL_MAX_DISTANCE, 64f);
            }
            int state = AL10.alGetSourcei(src, AL10.AL_SOURCE_STATE);
            if (!playing) {
                if (state == AL10.AL_PLAYING) AL10.alSourcePause(src);
                continue;
            }
            float pos = AL10.alGetSourcef(src, AL11.AL_SEC_OFFSET);
            if (state != AL10.AL_PLAYING || Math.abs(pos - a.sourceTime) > 0.12) {
                AL10.alSourcef(src, AL11.AL_SEC_OFFSET, (float) Math.max(0, a.sourceTime));
                if (state != AL10.AL_PLAYING) AL10.alSourcePlay(src);
            }
        }
        // кліпи, що вийшли з-під playhead, — стоп
        for (Iterator<Voice> it = VOICES.values().iterator(); it.hasNext(); ) {
            Voice v = it.next();
            if (v.session == session && v.seen != frameNo) { free(v); it.remove(); }
        }
        if (!playing) FIRED.removeIf(k -> k.startsWith(session + "/"));
    }

    private static void vanilla(String id, float gain, float pitch) {
        ResourceLocation rl = ResourceLocation.tryParse(id);
        SoundEvent ev = rl == null ? null : BuiltInRegistries.SOUND_EVENT.get(rl);
        if (ev == null && rl != null) ev = SoundEvent.createVariableRangeEvent(rl);
        if (ev != null) Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ev, pitch, gain));
    }

    private static int buffer(String key, AudioPcm pcm) {
        Integer b = BUFFERS.get(key);
        if (b != null) return b;
        int buf = AL10.alGenBuffers();
        ShortBuffer sb = MemoryUtil.memAllocShort(pcm.samples.length);
        try {
            sb.put(pcm.samples).flip();
            AL10.alBufferData(buf, pcm.channels > 1 ? AL10.AL_FORMAT_STEREO16 : AL10.AL_FORMAT_MONO16, sb, pcm.rate);
        } finally {
            MemoryUtil.memFree(sb);
        }
        if (AL10.alGetError() != AL10.AL_NO_ERROR) { AL10.alDeleteBuffers(buf); return 0; }
        BUFFERS.put(key, buf);
        return buf;
    }

    private static void free(Voice v) {
        AL10.alSourceStop(v.source);
        AL10.alDeleteSources(v.source);
    }

    public static void stopSession(long session) {
        for (Iterator<Voice> it = VOICES.values().iterator(); it.hasNext(); ) {
            Voice v = it.next();
            if (v.session == session) { free(v); it.remove(); }
        }
        FIRED.removeIf(k -> k.startsWith(session + "/"));
    }

    public static void stopAll() {
        for (Voice v : VOICES.values()) free(v);
        VOICES.clear();
        FIRED.clear();
        for (int b : BUFFERS.values()) AL10.alDeleteBuffers(b);
        BUFFERS.clear();
    }
}
