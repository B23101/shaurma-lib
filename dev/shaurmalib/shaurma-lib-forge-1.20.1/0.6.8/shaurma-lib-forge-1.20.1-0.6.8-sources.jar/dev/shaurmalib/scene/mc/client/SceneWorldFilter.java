package dev.shaurmalib.scene.mc.client;

import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.mc.editor.SceneEditorScreen;
import net.minecraft.client.Minecraft;

/**
 * «Лише світ»: поки грає кіно-сцена з цим режимом (або в редакторі увімкнено вид з камери) — сховати сутності,
 * партікли й погоду. Актори сцени малює {@link SceneRender} окремо, тож вони лишаються. Нічого у світі не змінює.
 */
public final class SceneWorldFilter {

    private SceneWorldFilter() {}

    private static SceneFrame frame() {
        SceneClient.Active a = SceneClient.cinematic();
        if (a != null) return a.frame;
        if (SceneClient.editorFrame != null && Minecraft.getInstance().screen instanceof SceneEditorScreen e && e.isCameraView())
            return SceneClient.editorFrame;
        return null;
    }

    public static boolean hideEntities() { SceneFrame f = frame(); return f != null && f.hideEntities; }

    public static boolean hideParticles() { SceneFrame f = frame(); return f != null && f.hideParticles; }

    public static boolean hideWeather() { SceneFrame f = frame(); return f != null && f.hideWeather; }
}
