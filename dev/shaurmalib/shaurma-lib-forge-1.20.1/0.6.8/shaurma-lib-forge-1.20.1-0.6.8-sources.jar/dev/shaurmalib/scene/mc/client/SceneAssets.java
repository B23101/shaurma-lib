package dev.shaurmalib.scene.mc.client;

import com.mojang.blaze3d.platform.NativeImage;
import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.anim.mesh.GeoMesh;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.eval.SceneRig;
import dev.shaurmalib.scene.io.AudioPcm;
import dev.shaurmalib.scene.io.BBModelReader;
import dev.shaurmalib.scene.net.SceneMessage;
import dev.shaurmalib.scene.net.SceneNetwork;
import dev.shaurmalib.scene.store.SceneStore;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.stb.STBVorbis;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Клієнтський кеш ассетів сцен ({@code .minecraft/shaurma_scene/cache/<sha256>.<ext>}): байти з сервера
 * лягають на диск за хешем (наступного разу не качаються), а звідси — розібрані моделі, текстури
 * (DynamicTexture), анімації .bbmodel і PCM звуків (wav — ядро, ogg — stb_vorbis, mp3 — JLayer).
 */
public final class SceneAssets {

    private SceneAssets() {}

    public static final class Model {
        public GeoMesh mesh;
        public SceneRig rig;
        public ResourceLocation texture;
        public int texW = 16, texH = 16;
        public final Map<String, AnimationClip> clips = new HashMap<>();
        public final Map<String, Double> animations = new HashMap<>();
        public List<String> warnings = List.of();
    }

    private static SceneStore cache;
    private static final Map<String, Model> MODELS = new HashMap<>();
    private static final Map<String, ResourceLocation> TEXTURES = new HashMap<>();
    private static final Map<String, AudioPcm> AUDIO = new HashMap<>();
    private static final Set<String> REQUESTED = new HashSet<>(), FAILED = new HashSet<>();
    private static final SceneMessage.Assembler ASM = new SceneMessage.Assembler(SceneStore.MAX_ASSET);

    public static SceneStore cache() {
        if (cache == null) cache = new SceneStore(Minecraft.getInstance().gameDirectory.toPath().resolve("shaurma_scene").resolve("cache"));
        return cache;
    }

    public static boolean has(SceneDoc.Asset a) { return a != null && cache().hasAsset(a.sha256, a.ext); }

    /** Попросити сервер про відсутні ассети документа (один раз на хеш). */
    public static void ensure(SceneDoc doc) {
        if (doc == null) return;
        for (SceneDoc.Asset a : doc.assets.values()) request(a.sha256, a.ext);
    }

    public static void request(String sha, String ext) {
        if (sha == null || cache().hasAsset(sha, ext) || !REQUESTED.add(sha)) return;
        SceneMessage m = SceneMessage.of(SceneMessage.Op.REQ_ASSET);
        m.a = sha;
        m.b = ext;
        SceneNetwork.Holder.get().toServer(m);
    }

    /** Шматок ассета з сервера. */
    public static void accept(SceneMessage m) {
        byte[] body = ASM.accept(m.a, m);
        if (body == null) return;
        try {
            if (!SceneStore.sha256(body).equals(m.a)) return;
            cache().putAsset(body, m.b);
        } catch (IOException e) {
            System.err.println("[shaurma_scene] кеш ассета: " + e);
        }
    }

    public static byte[] bytes(SceneDoc.Asset a) {
        try { return a == null ? null : cache().asset(a.sha256, a.ext); } catch (IOException e) { return null; }
    }

    /** Модель-ассет (.bbmodel або .geo.json); null — ще не прийшла. */
    public static Model model(SceneDoc doc, String assetId) {
        SceneDoc.Asset a = doc == null ? null : doc.assets.get(assetId);
        if (a == null) return null;
        Model m = MODELS.get(a.sha256);
        if (m != null || FAILED.contains(a.sha256)) return m;
        byte[] data = bytes(a);
        if (data == null) { request(a.sha256, a.ext); return null; }
        try {
            m = new Model();
            String json = new String(data, StandardCharsets.UTF_8);
            if (a.ext.equals("bbmodel")) {
                BBModelReader.Result r = BBModelReader.read(json, assetId);
                m.mesh = r.mesh;
                m.texW = r.textureWidth;
                m.texH = r.textureHeight;
                if (!r.textures.isEmpty()) m.texture = texture("bb_" + a.sha256, r.textures.get(0));
                for (AnimationClip c : r.clips) m.clips.put(c.id(), c);
                m.animations.putAll(r.animations);
                m.warnings = r.warnings;
            } else {
                m.mesh = GeoMesh.parse(json);
            }
            m.rig = SceneRig.of(assetId, m.mesh);
            MODELS.put(a.sha256, m);
            return m;
        } catch (RuntimeException e) {
            System.err.println("[shaurma_scene] модель " + a.name + ": " + e);
            FAILED.add(a.sha256);
            return null;
        }
    }

    /** Текстура-ассет світу. */
    public static ResourceLocation texture(SceneDoc doc, String assetId) {
        SceneDoc.Asset a = doc == null ? null : doc.assets.get(assetId);
        if (a == null) return null;
        ResourceLocation rl = TEXTURES.get(a.sha256);
        if (rl != null || FAILED.contains(a.sha256)) return rl;
        byte[] data = bytes(a);
        if (data == null) { request(a.sha256, a.ext); return null; }
        return texture(a.sha256, data);
    }

    private static ResourceLocation texture(String key, byte[] png) {
        ResourceLocation rl = TEXTURES.get(key);
        if (rl != null) return rl;
        try {
            NativeImage img = NativeImage.read(new ByteArrayInputStream(png));
            rl = Minecraft.getInstance().getTextureManager().register("shaurma_scene_" + key.substring(0, Math.min(16, key.length())), new DynamicTexture(img));
            TEXTURES.put(key, rl);
            return rl;
        } catch (IOException | RuntimeException e) {
            FAILED.add(key);
            return null;
        }
    }

    /** PCM звуку-ассета (wav/ogg/mp3); null — ще не прийшов або не декодується. */
    public static AudioPcm audio(SceneDoc doc, String assetId) {
        SceneDoc.Asset a = doc == null ? null : doc.assets.get(assetId);
        if (a == null) return null;
        AudioPcm p = AUDIO.get(a.sha256);
        if (p != null || FAILED.contains(a.sha256)) return p;
        byte[] data = bytes(a);
        if (data == null) { request(a.sha256, a.ext); return null; }
        try {
            p = decode(data, a.ext);
            AUDIO.put(a.sha256, p);
            return p;
        } catch (RuntimeException | IOException e) {
            System.err.println("[shaurma_scene] звук " + a.name + ": " + e);
            FAILED.add(a.sha256);
            return null;
        }
    }

    public static AudioPcm decode(byte[] data, String ext) throws IOException {
        if (AudioPcm.isWav(data)) return AudioPcm.wav(data);
        if (data.length > 4 && data[0] == 'O' && data[1] == 'g' && data[2] == 'g' && data[3] == 'S') return ogg(data);
        if ("mp3".equals(ext) || (data.length > 3 && ((data[0] == 'I' && data[1] == 'D' && data[2] == '3') || ((data[0] & 0xFF) == 0xFF && (data[1] & 0xE0) == 0xE0)))) return Mp3.decode(data);
        throw new IOException("невідомий формат звуку (потрібно wav, ogg або mp3)");
    }

    private static AudioPcm ogg(byte[] data) throws IOException {
        ByteBuffer in = MemoryUtil.memAlloc(data.length);
        try (MemoryStack st = MemoryStack.stackPush()) {
            in.put(data).flip();
            IntBuffer ch = st.mallocInt(1), rate = st.mallocInt(1);
            ShortBuffer pcm = STBVorbis.stb_vorbis_decode_memory(in, ch, rate);
            if (pcm == null) throw new IOException("OGG не декодується");
            try {
                short[] s = new short[pcm.remaining()];
                pcm.get(s);
                return new AudioPcm(s, ch.get(0), rate.get(0));
            } finally {
                MemoryUtil.memFree(pcm);
            }
        } finally {
            MemoryUtil.memFree(in);
        }
    }

    /** Ім'я файлу → тип ассета. */
    public static SceneDoc.Asset.Type typeOf(String ext) {
        return switch (ext) {
            case "bbmodel", "json" -> SceneDoc.Asset.Type.MODEL;
            case "png" -> SceneDoc.Asset.Type.TEXTURE;
            case "wav", "ogg", "mp3" -> SceneDoc.Asset.Type.AUDIO;
            default -> SceneDoc.Asset.Type.OTHER;
        };
    }

    /** Покласти локальний файл у кеш (імпорт у редакторі) і повернути опис ассета. */
    public static SceneDoc.Asset importFile(Path file) throws IOException {
        byte[] data = Files.readAllBytes(file);
        if (data.length > SceneStore.MAX_ASSET) throw new IOException("файл більший за " + (SceneStore.MAX_ASSET >> 20) + " МБ");
        String name = file.getFileName().toString();
        String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1).toLowerCase(java.util.Locale.ROOT) : "bin";
        if (name.toLowerCase(java.util.Locale.ROOT).endsWith(".geo.json")) ext = "json";
        SceneDoc.Asset a = new SceneDoc.Asset();
        a.id = SceneDoc.newId();
        a.name = name;
        a.ext = SceneStore.safeExt(ext);
        a.type = typeOf(a.ext);
        a.size = data.length;
        a.sha256 = cache().putAsset(data, a.ext);
        if (a.type == SceneDoc.Asset.Type.AUDIO) {
            AudioPcm p = decode(data, a.ext);
            a.duration = p.duration();
            AUDIO.put(a.sha256, p);
        } else if (a.type == SceneDoc.Asset.Type.TEXTURE) {
            try (NativeImage img = NativeImage.read(new ByteArrayInputStream(data))) { a.width = img.getWidth(); a.height = img.getHeight(); }
        } else if (a.type == SceneDoc.Asset.Type.MODEL) {
            String json = new String(data, StandardCharsets.UTF_8);
            if (a.ext.equals("bbmodel")) BBModelReader.read(json, a.id); else GeoMesh.parse(json);   // кривий файл — виняток тут, а не в сцені
        }
        return a;
    }

    /** Надіслати ассет на сервер шматками (редактор, перед збереженням). */
    public static void upload(String scene, SceneDoc.Asset a) {
        byte[] data = bytes(a);
        if (data == null) return;
        SceneMessage t = SceneMessage.of(SceneMessage.Op.UPLOAD);
        t.scene = scene;
        t.a = a.sha256;
        t.b = a.ext;
        for (SceneMessage m : SceneMessage.split(t, data, SceneMessage.C2S_CHUNK)) SceneNetwork.Holder.get().toServer(m);
    }

    public static void clearSession() {
        REQUESTED.clear();
        FAILED.clear();
    }
}
