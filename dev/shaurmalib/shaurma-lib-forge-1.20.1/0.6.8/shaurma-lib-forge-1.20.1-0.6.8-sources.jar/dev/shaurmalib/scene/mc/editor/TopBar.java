package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.doc.Track;
import dev.shaurmalib.scene.io.SceneCodec;
import dev.shaurmalib.scene.mc.ui.Fx;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;

/**
 * Верхній рядок — як у Shaurma Modeling: меню словами зліва («Файл», «Правка», «Створити», «Вигляд», «Сцена», «?»)
 * з випадними списками (гаряча клавіша сірим праворуч), вкладки варіантів сцени праворуч і точка стану збереження.
 */
final class TopBar {

    private TopBar() {}

    record Item(String label, String key, Runnable run, BooleanSupplier enabled, BooleanSupplier checked) {
        static Item sep() { return new Item("-", null, null, null, null); }
    }

    private static final String[] MENUS = { "Файл", "Правка", "Створити", "Вигляд", "Сцена", "?" };
    private static final Map<String, int[]> RECTS = new HashMap<>();
    private static long openedAt;

    static void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        MenuSkin.bar(gui.g, x, y, w, h, false);
        int by = y + 2, bh = MenuSkin.BAR_BTN;
        int cx = x + 4;
        for (String m : MENUS) {
            Component lbl = Component.literal(m);
            int bw = gui.font.width(lbl) + 8;
            RECTS.put(m, new int[] { cx, by, bw, bh });
            boolean open = m.equals(s.menu);
            if (gui.button(cx, by, bw, bh, lbl, open, null)) { s.menu = open ? null : m; openedAt = System.currentTimeMillis(); }
            cx += bw + 2;
        }

        // праворуч: вкладки варіантів (як вкладки проєктів у Modeling) і точка стану збереження
        int right = x + w - 4;
        List<SceneDoc.Variant> vs = new ArrayList<>(s.doc.variants.values());
        if (!s.readOnly) {
            right -= bh;
            if (gui.iconButton(right, by, bh, Icon.PLUS, false, Component.literal("Новий варіант (копія поточного): окремий монтаж для іншої кількості гравців"))) newVariant(s);
            right -= 2;
        }
        int tabsW = Math.max(0, Math.min(right - cx - 40, vs.size() * 110));
        int tw = vs.isEmpty() ? 0 : Math.max(46, tabsW / vs.size());
        int tx = right - tw * vs.size();
        int tabsStart = tx;
        for (SceneDoc.Variant v : vs) {
            boolean act = v.id.equals(s.variantId);
            boolean hv = gui.hover(tx, by, tw - 2, bh);
            float on = gui.anim("vtab.on." + v.id, act ? 1 : 0, 14), hov = gui.anim("vtab.hv." + v.id, hv ? 1 : 0, 22);
            MenuSkin.buttonT(gui.g, tx, by, tw - 2, bh, hov, 0, on, true);
            String range = v.minPlayers > 0 || v.maxPlayers > 0 ? "  " + v.minPlayers + "–" + (v.maxPlayers > 0 ? v.maxPlayers : "∞") : "";
            gui.textClip(v.name + range, tx + 6, MenuSkin.textY(by, bh), tw - 10, Fx.lerp(Theme.MUTED, 0xFFFFFFFF, Math.max(on, hov * 0.6f)));
            if (hv) gui.tip(Component.literal("Варіант «" + v.name + "»" + (range.isEmpty() ? "" : " — гравців" + range) + "\nПКМ — налаштування, видалити"));
            if (gui.clicked(tx, by, tw - 2, bh, 0) && !act) { s.variantId = v.id; s.select(null); s.rebuild(); }
            if (gui.clicked(tx, by, tw - 2, bh, 1)) variantMenu(s, v, tx, by + bh + 2);
            tx += tw;
        }
        // стан збереження: зелена — збережено, жовта — зберігається, червона пульсує — є незбережені зміни
        int dx = tabsStart - 14, dy = by + (bh - 6) / 2;
        int col = s.readOnly ? Theme.MUTED : !s.history.dirty() ? Theme.OK : s.saving ? Theme.WARN : Theme.DANGER;
        float pulse = s.history.dirty() ? 0.55f + 0.45f * (0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 170.0)) : 1f;
        gui.g.fill(dx - 1, dy - 1, dx + 7, dy + 7, MenuSkin.OUTLINE);
        gui.g.fill(dx, dy, dx + 6, dy + 6, Fx.mulAlpha(col, pulse));
        if (gui.hover(dx - 3, by, 12, bh)) {
            gui.tip(Component.literal(s.readOnly ? "Лише перегляд: сцену редагує " + s.lockedBy
                : s.history.dirty() ? "Є незбережені зміни (Ctrl+S)" : "Збережено · ревізія " + s.doc.revision));
            gui.tipSwatch(col);
        }
        // назва сцени — між меню й вкладками, якщо є місце
        String title = s.def == null ? s.doc.id : s.def.title;
        int space = dx - 10 - (cx + 8);
        if (space > 40) gui.textClip(title, cx + 8, MenuSkin.textY(by, bh), space, Theme.MUTED);
    }

    // ═════════════════════════ випадні меню ═════════════════════════

    static List<Item> items(SceneEditorScreen s, String menu) {
        List<Item> l = new ArrayList<>();
        BooleanSupplier yes = () -> true, edit = () -> !s.readOnly;
        switch (menu) {
            case "Файл" -> {
                l.add(new Item("Зберегти", "Ctrl+S", s::save, edit, null));
                l.add(new Item("Тест у грі (сервер грає збережене)", null, s::testOnServer, yes, null));
                l.add(Item.sep());
                l.add(new Item("Імпорт файлу… (bbmodel, png, wav, ogg, mp3)", "Ctrl+I", () -> LeftPanel.importDialog(s), edit, null));
                l.add(new Item("Точка редагування = вигляд", null, s::setHomeHere, edit, null));
                l.add(new Item("До точки редагування", "H", s::goHome, () -> s.doc.home != null, null));
                l.add(new Item("Відновити чернетку", null, s::restoreDraft, () -> s.draftAvailable, null));
                l.add(Item.sep());
                l.add(new Item("Вийти", "Esc", s::onClose, yes, null));
            }
            case "Правка" -> {
                l.add(new Item("Скасувати" + label(s.history.undoLabel()), "Ctrl+Z", () -> s.replaceDoc(s.history.undo(s.doc)), s.history::canUndo, null));
                l.add(new Item("Повторити" + label(s.history.redoLabel()), "Ctrl+Y", () -> s.replaceDoc(s.history.redo(s.doc)), s.history::canRedo, null));
                l.add(Item.sep());
                l.add(new Item("Дублювати", "Ctrl+D", s::duplicateSelection, edit, null));
                l.add(new Item("Видалити", "Del", s::deleteSelection, edit, null));
                l.add(new Item("Розрізати кліп у playhead", "S", s::splitClip, () -> s.selClip != null, null));
                l.add(Item.sep());
                l.add(new Item("Ключ на вибране", "K", s::keyAll, () -> s.selected() != null, null));
                l.add(new Item("Мітка на playhead", "M", s::addMarker, edit, null));
                l.add(new Item("Записати рух актора", "Ctrl+R", s::startRecording, () -> s.selected() != null && s.selected().kind == SceneObject.Kind.ACTOR, null));
            }
            case "Створити" -> {
                l.add(new Item("Камера з поточного виду", null, s::addCamera, edit, null));
                l.add(new Item("Актор-гравець", null, () -> s.addActor(SceneObject.ModelType.PLAYER, null), edit, null));
                l.add(new Item("Точка (ціль, батько, мітка)", null, s::addEmpty, edit, null));
                l.add(Item.sep());
                l.add(new Item("Трек камер", null, () -> s.addTrack(Track.Type.CAMERA, null), edit, null));
                l.add(new Item("Трек анімації вибраного актора", null, () -> s.addTrack(Track.Type.ANIMATION, s.selObj),
                    () -> s.selected() != null && s.selected().kind == SceneObject.Kind.ACTOR, null));
                l.add(new Item("Трек звуку", null, () -> s.addTrack(Track.Type.AUDIO, null), edit, null));
                l.add(new Item("Трек оверлеїв", null, () -> s.addTrack(Track.Type.OVERLAY, null), edit, null));
                l.add(new Item("Трек ефектів", null, () -> s.addTrack(Track.Type.EFFECT, null), edit, null));
                l.add(new Item("Сповільнення (slow-mo)", null, () -> LeftPanel.addMedia(s, Track.Type.TIME, null, 2), edit, null));
            }
            case "Вигляд" -> {
                l.add(new Item("Вид з камери сцени", "Num 0", () -> s.cameraView(!s.view.cameraView), yes, () -> s.view.cameraView));
                l.add(new Item("Камера = вигляд", "Ctrl+Num 0", s::cameraToView, edit, null));
                l.add(new Item("Камера за видом (навігація рухає камеру)", null, () -> s.lockCameraToView = !s.lockCameraToView, yes, () -> s.lockCameraToView));
                l.add(Item.sep());
                l.add(new Item("Каркаси камер і шляхи", null, () -> s.showGizmos = !s.showGizmos, yes, () -> s.showGizmos));
                l.add(new Item("Назви над об'єктами", null, () -> s.showLabels = !s.showLabels, yes, () -> s.showLabels));
                l.add(new Item("Onion skin", null, () -> s.onion = !s.onion, yes, () -> s.onion));
                l.add(Item.sep());
                l.add(new Item("Спереду", "Num 1", () -> s.view.snap(1), yes, null));
                l.add(new Item("Збоку", "Num 3", () -> s.view.snap(3), yes, null));
                l.add(new Item("Згори", "Num 7", () -> s.view.snap(7), yes, null));
                l.add(new Item("До вибраного", "F", s::focusSelected, () -> s.selected() != null, null));
            }
            case "Сцена" -> {
                l.add(new Item("Автоключ", null, () -> s.autoKey = !s.autoKey, yes, () -> s.autoKey));
                l.add(new Item("Магніт таймлайну", null, () -> s.snapping = !s.snapping, yes, () -> s.snapping));
                l.add(new Item("Зациклити превʼю", null, () -> s.loopPlayback = !s.loopPlayback, yes, () -> s.loopPlayback));
                l.add(Item.sep());
                l.add(new Item("Превʼю: у слотах — я", null, () -> { s.previewSlots = !s.previewSlots; s.rebuild(); }, yes, () -> s.previewSlots));
                l.add(new Item("Новий варіант (копія)", null, () -> newVariant(s), edit, null));
                l.add(new Item("Налаштування варіанта", null, () -> s.select(null), yes, null));
            }
            default -> {
                l.add(new Item("Space — грати / пауза · ←/→ — кадр · Shift — секунда", null, null, () -> false, null));
                l.add(new Item("G / R / S — рух, поворот, масштаб (X/Y/Z — вісь)", null, null, () -> false, null));
                l.add(new Item("СКМ — орбіта · Shift+СКМ — панорама · ПКМ+WASD — політ", null, null, () -> false, null));
                l.add(new Item("K — ключ · M — мітка · Ctrl+R — запис руху", null, null, () -> false, null));
                l.add(new Item("Кинь звук (wav, ogg, mp3) з провідника у вікно — ляже на таймлайн", null, null, () -> false, null));
                l.add(new Item("Тягни звук з «Ассетів» на таймлайн — кліп саме там", null, null, () -> false, null));
                l.add(new Item("Звук: жовта лінія — гучність кліпу, білі квадрати — fade, повзунок у заголовку — гучність треку", null, null, () -> false, null));
            }
        }
        return l;
    }

    private static String label(String l) { return l == null ? "" : ": " + l; }

    /** Малювати після всіх панелей; поки меню відкрите, решта екрана модальна. */
    static void renderMenu(SceneEditorScreen s, Gui gui) {
        if (s.menu == null) return;
        int[] at = RECTS.get(s.menu);
        if (at == null) return;
        List<Item> items = items(s, s.menu);
        int ih = 14, w = 150;
        for (Item it : items) if (!it.label().equals("-")) w = Math.max(w, gui.font.width(it.label()) + (it.key() == null ? 0 : gui.font.width(it.key()) + 18) + 26);
        int rowsH = 4;
        for (Item it : items) rowsH += it.label().equals("-") ? 5 : ih;
        int x = Math.min(at[0], gui.g.guiWidth() - w - 2), y = at[1] + at[3];
        gui.modalBegin();
        gui.g.pose().pushPose();
        gui.g.pose().translate(0, 0, 400);
        MenuSkin.window(gui.g, x, y, w, rowsH + 6);
        int iy = y + 5, idx = 0;
        long now = System.currentTimeMillis();
        Item chosen = null;
        for (Item it : items) {
            if (it.label().equals("-")) { gui.g.fill(x + 6, iy + 2, x + w - 6, iy + 3, MenuSkin.RULE); iy += 5; continue; }
            boolean en = it.enabled() == null || it.enabled().getAsBoolean();
            MenuSkin.row(gui.g, x + 1, iy, w - 2, ih, en && gui.hover(x, iy, w, ih), false);
            float ia = Fx.stagger(now, openedAt, idx++, 14, 170);
            int slide = Math.round((1 - ia) * 8);
            if (it.checked() != null) MenuSkin.checkbox(gui.g, x + 4, iy + (ih - 10) / 2, false, it.checked().getAsBoolean());
            int tx = x + (it.checked() != null ? 18 : 8) + slide;
            gui.text(it.label(), tx, iy + (ih - 8) / 2, Fx.mulAlpha(en ? 0xFF000000 | Theme.TEXT : 0xFF5A6A88, Math.max(0.05f, ia)));
            if (it.key() != null) gui.text(it.key(), x + w - gui.font.width(it.key()) - 6, iy + (ih - 8) / 2, Fx.mulAlpha(0xFF5A607A, Math.max(0.05f, ia)));
            if (en && it.run() != null && gui.clicked(x, iy, w, ih, 0)) chosen = it;
            iy += ih;
        }
        gui.g.pose().popPose();
        if (chosen != null) { gui.modalEnd(); s.menu = null; chosen.run().run(); return; }
        // клік по іншій кнопці меню — перемкнути; поза меню — закрити
        if (gui.pendingClick() == 0) {
            int cx = gui.pendingClickX(), cy = gui.pendingClickY();
            for (Map.Entry<String, int[]> e : RECTS.entrySet()) {
                int[] r = e.getValue();
                if (cx >= r[0] && cx < r[0] + r[2] && cy >= r[1] && cy < r[1] + r[3]) {
                    s.menu = e.getKey().equals(s.menu) ? null : e.getKey();
                    openedAt = System.currentTimeMillis();
                    gui.consumeClick();
                    gui.modalEnd();
                    return;
                }
            }
        }
        if (gui.pendingClick() >= 0) {
            int cx = gui.pendingClickX(), cy = gui.pendingClickY();
            if (!(cx >= x && cx < x + w && cy >= y && cy < y + rowsH + 6)) { s.menu = null; gui.consumeClick(); }
        }
        gui.modalEnd();
    }

    static void newVariant(SceneEditorScreen s) {
        s.edit("Новий варіант", () -> {
            SceneDoc copy = SceneCodec.read(SceneCodec.write(s.doc, false));
            SceneDoc.Variant src = copy.variant(s.variantId);
            String id = "v" + (s.doc.variants.size() + 1);
            while (s.doc.variants.containsKey(id)) id = id + "_";
            src.id = id;
            src.name = "Варіант " + (s.doc.variants.size() + 1);
            s.doc.variants.put(id, src);
            s.variantId = id;
            s.rebuild();
        });
    }

    private static void variantMenu(SceneEditorScreen s, SceneDoc.Variant v, int x, int y) {
        List<Popup.Item> items = new ArrayList<>();
        items.add(Popup.item("Налаштування (довжина, гравці, смуги…)", () -> { s.variantId = v.id; s.rebuild(); s.select(null); }));
        if (s.def != null) for (var hint : s.def.variantHints) {
            if (s.doc.variants.containsKey(hint.id())) continue;
            items.add(Popup.item("+ " + hint.id() + " (" + hint.minPlayers() + "–" + (hint.maxPlayers() > 0 ? hint.maxPlayers() : "∞") + " гравців)", () -> s.edit("Варіант " + hint.id(), () -> {
                SceneDoc.Variant nv = new SceneDoc.Variant(hint.id(), hint.id());
                nv.minPlayers = hint.minPlayers();
                nv.maxPlayers = hint.maxPlayers();
                nv.length = s.variant().length;
                s.doc.variants.put(nv.id, nv);
                s.variantId = nv.id;
                s.rebuild();
            }), !s.readOnly));
        }
        items.add(Popup.item("Видалити варіант", () -> s.edit("Видалити варіант", () -> {
            s.doc.variants.remove(v.id);
            if (v.id.equals(s.variantId)) s.variantId = s.doc.variant(null).id;
            s.rebuild();
        }), !s.readOnly && s.doc.variants.size() > 1));
        Popup.open(v.name, x, y, items);
    }
}
