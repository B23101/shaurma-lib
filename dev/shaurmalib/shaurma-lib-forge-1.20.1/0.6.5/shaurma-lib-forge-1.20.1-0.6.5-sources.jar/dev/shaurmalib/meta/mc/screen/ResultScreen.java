package dev.shaurmalib.meta.mc.screen;

import dev.shaurmalib.meta.economy.Currency;
import dev.shaurmalib.meta.economy.Reward;
import dev.shaurmalib.meta.match.MatchResult;
import dev.shaurmalib.meta.mc.MetaScreens;
import dev.shaurmalib.meta.mc.skin.MetaSkin;
import dev.shaurmalib.meta.mc.ui.MetaUi;
import dev.shaurmalib.meta.progress.RankLadder;
import dev.shaurmalib.meta.stats.StatDef;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Екран «Матч завершено» — кінематографічний підсумок у три розділи.
 *
 * <ol>
 *   <li><b>Вступ.</b> «ПЕРЕМОГА»/«ПОРАЗКА» на весь екран: падає з розгону, удар (струс, спалах, хвиля), конфеті або
 *       попіл; потім заголовок плавно відʼїжджає вгору, і з'являється смуга розділів.</li>
 *   <li><b>ДОСВІД.</b> Рядки «за дії» в'їжджають по черзі, кожен — тік, що підвищується (досвід «стакається»);
 *       великий лічильник XP росте разом із ними.</li>
 *   <li><b>РІВЕНЬ.</b> Смужка заповнюється з тіканням, що прискорюється; кожен новий рівень — спалах, кільце іскор
 *       навколо емблеми, «+1 РІВЕНЬ», окремий звук (вищий з кожним рівнем).</li>
 *   <li><b>НАГОРОДИ.</b> Картки вискакують по одній (монети рахуються дзенькітом, очки покращень, ступінь
 *       пропуску, знахідки).</li>
 * </ol>
 * Enter/Пробіл — домотати до кінця (без лавини звуків), ще раз — закрити. Звуки — через скін режиму
 * ({@link MetaSkin#sound(String, float)}: {@code victory}, {@code defeat}, {@code section}, {@code tick}, {@code levelup},
 * {@code reward}, {@code coin}, {@code stamp}); без скіна — ванільні. Режим може замінити екран цілком —
 * {@link MetaScreens#resultScreen}. Усі цифри — з {@link MatchResult}, нічого не рахується вдруге.
 */
public class ResultScreen extends MetaScreen {

    private final MatchResult r;
    private float skipT = -1;
    private final Random rnd = new Random();

    // ── часова шкала (с) ──
    private static final float SLAM = .32f, INTRO_END = 1.25f, HEAD_MOVE = .45f;
    private static final float LINE_STEP = .26f, BAR_DUR = 1.9f, CARD_STEP = .32f;

    private final List<Card> cards = new ArrayList<>();
    private int lastLevel, linesSounded, cardsSounded, sectionSounded = -1;
    private float levelFlash, levelPop, lastTickT, shake;
    private boolean slammed, doneSound;
    private final List<Float> levelUps = new ArrayList<>();

    private record Card(String icon, int color, String head, String sub, long count, String unit, boolean coins) {}

    private static final class P { float x, y, vx, vy, life, max, size, rot; int rgb; boolean confetti; }
    private final List<P> parts = new ArrayList<>();

    public ResultScreen(MatchResult result, Screen parent) {
        super("Підсумки", parent);
        this.r = result;
        this.nav = false;
        this.lastLevel = result.levelBefore;
        buildCards();
    }

    @Override protected String section() { return "result"; }

    private void buildCards() {
        if (mode == null) return;
        java.util.Map<String, Long> sums = new java.util.LinkedHashMap<>();
        java.util.Map<String, String> notes = new java.util.LinkedHashMap<>();
        for (MatchResult.Coins c : r.coins) { sums.merge(c.currency(), c.amount(), Long::sum); notes.putIfAbsent(c.currency(), c.note()); }
        for (var e : sums.entrySet()) {
            Currency cur = mode.currency(e.getKey());
            cards.add(new Card(cur == null ? "coin" : cur.icon(), cur == null ? theme.gold() : cur.color(),
                    cur == null ? e.getKey() : cur.name(), notes.get(e.getKey()), e.getValue(), "", true));
        }
        if (r.upgradePoints > 0) cards.add(new Card("upgrade", theme.accent(), r.upgradePoints == 1 ? "Очко покращень" : "Очки покращень",
                "Уже у спільному запасі", r.upgradePoints, "", false));
        if (r.passGained > 0) cards.add(new Card("track", theme.gold(), "очок пропуску",
                r.tierAfter > r.tierBefore ? "Ступінь " + r.tierBefore + " → " + r.tierAfter : "Пропуск окремо від рівня", r.passGained, "", true));
        for (int lv : r.unlockedTrack) cards.add(new Card("track", theme.gold(), "Ступінь пропуску " + lv, "Забери нагороду в пропуску", 0, "", false));
        for (Reward d : r.drops) cards.add(new Card(MetaScreens.rewardIcon(mode, d), MetaScreens.rewardColor(mode, d),
                MetaScreens.rewardText(mode, d), "Знахідка за матч", 0, "", false));
        if (cards.isEmpty()) cards.add(new Card("star", theme.dim(), "Без нагород цього разу", "Наступний матч — новий шанс", 0, "", false));
    }

    // ── таймінги розділів ──
    private float t() { return skipT >= 0 ? Math.max(time, 99f) : time; }
    private int lineCount() { return Math.min(9, r.lines.size()); }
    private float xpStart() { return INTRO_END + HEAD_MOVE; }
    private float barStart() { return xpStart() + lineCount() * LINE_STEP + .35f; }
    private float cardsStart() { return barStart() + BAR_DUR + .3f; }
    private float endT() { return cardsStart() + cards.size() * CARD_STEP + .5f; }
    private boolean finished() { return t() >= endT(); }
    private boolean silent() { return skipT >= 0; }

    /** 0 — досвід, 1 — рівень, 2 — нагороди. */
    private int sectionAt(float t) { return t < barStart() ? 0 : t < cardsStart() ? 1 : 2; }

    private void cue(String c, float pitch) {
        if (silent() || minecraft == null) return;
        if (!skin.sound(c, pitch)) vanilla(c, pitch);
    }

    private void vanilla(String c, float pitch) {
        var ev = switch (c) {
            case "levelup" -> net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP;
            case "victory" -> net.minecraft.sounds.SoundEvents.UI_TOAST_CHALLENGE_COMPLETE;
            case "defeat" -> net.minecraft.sounds.SoundEvents.WITHER_HURT;
            case "coin", "reward" -> net.minecraft.sounds.SoundEvents.EXPERIENCE_ORB_PICKUP;
            case "tick" -> net.minecraft.sounds.SoundEvents.NOTE_BLOCK_HAT.value();
            case "stamp" -> net.minecraft.sounds.SoundEvents.ANVIL_LAND;
            default -> net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK.value();
        };
        float vol = switch (c) { case "tick" -> .35f; case "stamp", "defeat" -> .4f; default -> .7f; };
        minecraft.getSoundManager().play(net.minecraft.client.resources.sounds.SimpleSoundInstance.forUI(ev, pitch, vol));
    }

    @Override
    protected void draw(GuiGraphics g) {
        float t = t();
        updateParts();
        sounds(t);
        shake = Math.max(0f, shake - dt * 3f);

        g.pose().pushPose();
        if (shake > 0) g.pose().translate(Math.sin(time * 77) * shake * 6, Math.cos(time * 91) * shake * 5, 0);
        // фон розділу: смуга кольору результату під заголовком
        int resultColor = r.won ? theme.good() : theme.bad();
        float bg = MetaUi.outCubic(t / .5f);
        g.fillGradient(0, 0, DW, 140, MetaUi.a(resultColor, .16f * bg), MetaUi.a(resultColor, 0f));

        drawIntro(g, t, resultColor);
        if (t > INTRO_END) {
            drawStepper(g, t);
            drawXp(g, t);
            drawLevel(g, t);
            drawCards(g, t);
            drawButtons(g, t);
        }
        g.pose().popPose();
        drawParts(g);
        float fl = MetaUi.clamp01(1f - (t - SLAM) / .35f);
        if (t >= SLAM && fl > 0) g.fill(0, 0, DW, DH, MetaUi.a(0xFFFFFF, fl * .22f));
    }

    // ══ звуки, що йдуть за часовою шкалою ═════════════════════════════════
    private void sounds(float t) {
        if (!slammed && t >= SLAM) {
            slammed = true;
            shake = 1f;
            cue(r.won ? "victory" : "defeat", 1f);
            cue("stamp", 1f);
            for (int i = 0; i < (r.won ? 110 : 70); i++) spawn(480, 200, r.won);
        }
        int sec = t < xpStart() ? -1 : sectionAt(t);
        if (sec > sectionSounded) { sectionSounded = sec; cue("section", 1f + sec * .08f); }
        // рядки досвіду: тік на кожен, тон росте — досвід «стакається»
        int due = t < xpStart() ? 0 : Math.min(lineCount(), (int) ((t - xpStart()) / LINE_STEP) + 1);
        while (linesSounded < due) { cue("tick", .9f + .07f * linesSounded); linesSounded++; }
        // смужка: тіки частішають і вищають до кінця заповнення
        float bt = (t - barStart()) / BAR_DUR;
        if (bt > 0 && bt < 1) {
            float gap = .11f - .06f * bt;
            if (time - lastTickT >= gap) { lastTickT = time; cue("tick", .8f + .9f * bt); }
        }
        // картки нагород: «поп» на кожну, монети — дзенькіт
        int cdue = t < cardsStart() ? 0 : Math.min(cards.size(), (int) ((t - cardsStart()) / CARD_STEP) + 1);
        while (cardsSounded < cdue) {
            Card c = cards.get(cardsSounded);
            cue(c.coins ? "coin" : "reward", 1f + .06f * cardsSounded);
            cardsSounded++;
        }
        if (finished() && !doneSound) { doneSound = true; cue("reward", 1.25f); }
    }

    // ══ вступ: великий заголовок ═════════════════════════════════════════
    private void drawIntro(GuiGraphics g, float t, int resultColor) {
        String title = r.won ? "ПЕРЕМОГА" : "ПОРАЗКА";
        // падає з розгону (масштаб 5 → 3), потім їде в шапку (3 → 1.7)
        float slam = MetaUi.clamp01(t / SLAM);
        float scale = 5.2f - 2.2f * slam * slam;
        if (t >= SLAM) scale = 3f + .35f * (float) Math.exp(-(t - SLAM) * 9) * (float) Math.sin((t - SLAM) * 30);
        float move = MetaUi.outCubic((t - INTRO_END) / HEAD_MOVE);
        float y = MetaUi.lerp(222, 22, move);
        scale = MetaUi.lerp(scale, 1.9f, move);
        float a = MetaUi.clamp01(t / .12f);
        // тінь-відбиток і сам заголовок
        MetaUi.textSC(g, font, title, 480 + 3, y + 3, scale, MetaUi.a(0, .55f * a), false);
        MetaUi.textSC(g, font, title, 480, y, scale, MetaUi.a(MetaUi.mix(resultColor, 0xFFFFFF, .15f), a), false);
        // хвиля від удару: лінія, що розходиться в боки
        float st = t - SLAM;
        if (st >= 0 && st < .7f && move <= 0) {
            float k = MetaUi.outCubic(st / .7f);
            int half = (int) (60 + 420 * k);
            int lineY = (int) (y + 9 * scale + 6);
            g.fill(480 - half, lineY, 480 + half, lineY + 2, MetaUi.a(resultColor, (1 - k) * .9f));
            MetaUi.glowEllipse(g, 480, lineY, half, 10, resultColor, (1 - k) * .35f);
        }
        // підзаголовок: роль і тривалість
        float sub = MetaUi.clamp01((t - SLAM - .2f) / .4f) * (1f - move * .2f);
        String line = (r.role.isEmpty() ? "" : r.role.toUpperCase() + "   ·   ") + "ТРИВАЛІСТЬ " + StatDef.formatSeconds(r.durationSeconds);
        float sy = MetaUi.lerp(y + 9 * scale + 18, 44, move);
        MetaUi.textSC(g, font, line, 480, sy, MetaUi.lerp(1.2f, .8f, move), MetaUi.a(theme.dim(), sub), false);
        if (move <= .01f) {
            float hint = MetaUi.clamp01((t - .8f) / .3f);
            MetaUi.textSC(g, font, "МАТЧ ЗАВЕРШЕНО", 480, y - 34, 1f, MetaUi.a(theme.text(), hint * .6f), false);
        }
    }

    // ══ смуга розділів ══════════════════════════════════════════════════
    private void drawStepper(GuiGraphics g, float t) {
        float a = MetaUi.outCubic((t - INTRO_END - .2f) / .4f);
        if (a <= .01f) return;
        String[] names = {"ДОСВІД", "РІВЕНЬ", "НАГОРОДИ"};
        int cur = sectionAt(t), w = 180, gap = 12, x0 = 480 - (3 * w + 2 * gap) / 2, y = 60;
        for (int i = 0; i < 3; i++) {
            int x = x0 + i * (w + gap);
            float p = i < cur ? 1f : i > cur ? 0f : sectionProgress(t, i);
            boolean act = i == cur;
            MetaUi.text(g, font, (i + 1) + "", x, y, MetaUi.a(act ? theme.gold() : theme.dim(), a), false);
            MetaUi.text(g, font, names[i], x + 12, y, MetaUi.a(act ? theme.text() : i < cur ? theme.good() : theme.dim(), a), act);
            g.fill(x, y + 12, x + w, y + 14, MetaUi.a(theme.border(), a * .8f));
            g.fill(x, y + 12, x + Math.round(w * p), y + 14, MetaUi.a(act ? theme.gold() : theme.good(), a));
            if (act) MetaUi.glowDisc(g, x + Math.round(w * p), y + 13, 3, theme.gold(), a * (.5f + .5f * (float) Math.sin(time * 8)));
        }
    }

    private float sectionProgress(float t, int i) {
        return switch (i) {
            case 0 -> MetaUi.clamp01((t - xpStart()) / Math.max(.01f, barStart() - xpStart()));
            case 1 -> MetaUi.clamp01((t - barStart()) / BAR_DUR);
            default -> MetaUi.clamp01((t - cardsStart()) / Math.max(.01f, endT() - cardsStart()));
        };
    }

    // ══ 1. досвід за дії ════════════════════════════════════════════════
    private void drawXp(GuiGraphics g, float t) {
        float sL = MetaUi.outCubic((t - INTRO_END - .1f) / .5f);
        int lx = 20 + Math.round((1f - sL) * -360);
        panel(g, lx, 84, 310, 330, false);
        skin.sectionTitle(g, font, lx + 14, 96, 282, "ДОСВІД ЗА ДІЇ", null, time);
        int ly = 120;
        for (int i = 0; i < lineCount(); i++) {
            MatchResult.Line line = r.lines.get(i);
            float a = MetaUi.clamp01((t - xpStart() - i * LINE_STEP) / .3f);
            if (a <= .01f) { ly += 31; continue; }
            int rx = lx + 10 + Math.round((1f - MetaUi.outBack(a)) * -50);
            float glow = MetaUi.clamp01(1f - (t - xpStart() - i * LINE_STEP) / .5f);
            skin.card(g, rx, ly, 290, 27, theme.border(), false, glow, time);
            icon(g, line.icon(), rx + 7, ly + 6, 2, MetaUi.a(theme.text(), a));
            MetaUi.text(g, font, MetaUi.fit(font, line.name(), 190), rx + 30, ly + (line.count() > 1 ? 5 : 10), MetaUi.a(theme.text(), a), false);
            if (line.count() > 1) MetaUi.textS(g, font, "×" + line.count(), rx + 30, ly + 16, .8f, MetaUi.a(theme.dim(), a), false);
            // «+XP» вискакує збільшеним і сідає на місце
            float pop = 1f + .6f * glow * glow;
            MetaUi.textS(g, font, "+" + line.xp(), rx + 282 - font.width("+" + line.xp()) * pop, ly + 10 - 4 * (pop - 1), pop, MetaUi.a(theme.gold(), a), true);
            skin.cardOverlay(g, rx, ly, 290, 27, theme.border(), false, glow, time);
            ly += 31;
        }
        if (r.lines.size() > 9) MetaUi.textS(g, font, "… ще " + (r.lines.size() - 9), lx + 14, ly + 2, .8f, MetaUi.solid(theme.dim()), false);
    }

    // ══ 2. рівень ═══════════════════════════════════════════════════════
    private void drawLevel(GuiGraphics g, float t) {
        float sC = MetaUi.outCubic((t - INTRO_END - .2f) / .5f);
        int cy0 = 84 + Math.round((1f - sC) * 40);
        panel(g, 346, cy0, 594, 330, true);
        MetaUi.textC(g, font, "ЗАГАЛЬНИЙ РІВЕНЬ", 643, cy0 + 14, MetaUi.solid(theme.dim()), false);

        float barT = MetaUi.clamp01((t - barStart()) / BAR_DUR);
        float eased = barT * barT * (3f - 2f * barT);
        long total = r.xpBefore + Math.round((r.xpAfter - r.xpBefore) * eased);
        int level = mode.curve.levelOf(total);
        if (level > lastLevel) {
            int ups = level - lastLevel;
            lastLevel = level;
            levelFlash = 1f;
            levelPop = 1f;
            levelUps.add(time);
            cue("levelup", 1f + .06f * Math.min(6, levelUps.size() - 1));
            shake = Math.max(shake, .35f);
            for (int i = 0; i < 40 * ups && !silent(); i++) spawnRing(643, cy0 + 96);
        }
        levelFlash = Math.max(0, levelFlash - dt * 1.6f);
        levelPop = Math.max(0, levelPop - dt * 2.4f);

        int hx = 643, hy = cy0 + 96;
        // емблема «пульсує» при новому рівні
        g.pose().pushPose();
        float sc = 1f + .25f * MetaUi.outBack(levelPop);
        g.pose().translate(hx, hy, 0);
        g.pose().scale(sc, sc, 1);
        g.pose().translate(-hx, -hy, 0);
        if (levelFlash > 0) MetaUi.glowDisc(g, hx, hy, 70, theme.gold(), levelFlash * .5f);
        skin.levelBadge(g, font, hx, hy, 38, level, theme.accent(), levelFlash, time);
        g.pose().popPose();
        skin.divider(g, hx - 150, hy, 90);
        skin.divider(g, hx + 60, hy, 90);
        // «+1 РІВЕНЬ» спливає над емблемою
        for (float at : levelUps) {
            float k = (time - at) / 1.2f;
            if (k < 0 || k > 1) continue;
            MetaUi.textSC(g, font, "+1 РІВЕНЬ", hx, hy - 50 - 30 * MetaUi.outCubic(k), 1.4f, MetaUi.a(theme.gold(), 1f - k * k), true);
        }
        RankLadder lad = mode.ladder(r.ladder);
        if (lad != null) {
            RankLadder.Rank rk = lad.ofLevel(level);
            MetaUi.textC(g, font, rk.title().toUpperCase() + "   ·   " + lad.name().toUpperCase(), hx, hy + 52, MetaUi.solid(rk.color()), false);
        }
        // великий лічильник: росте з рядками (розділ 1)
        int shown = 0;
        for (int i = 0; i < r.lines.size(); i++) shown += Math.round(r.lines.get(i).xp() * MetaUi.clamp01((t - xpStart() - Math.min(i, 8) * LINE_STEP) / .3f));
        float bump = 0;
        for (int i = 0; i < lineCount(); i++) {
            float k = t - xpStart() - i * LINE_STEP;
            if (k >= 0 && k < .18f) bump = Math.max(bump, 1f - k / .18f);
        }
        MetaUi.textSC(g, font, "+" + MetaUi.num(shown) + " XP", hx, hy + 70 - bump * 3, 2.4f + .35f * bump, MetaUi.solid(theme.gold()), true);
        MetaUi.textSC(g, font, sectionAt(t) == 0 ? "ЗАРАХУВАННЯ ДОСВІДУ" : "РАЗОМ ЗА МАТЧ", hx, hy + 98, .75f, MetaUi.solid(theme.dim()), false);

        int bx = 366, bw = 554, by = cy0 + 236;
        int needed = mode.curve.needed(level);
        long into = mode.curve.intoLevel(total);
        float fill = level >= mode.curve.maxLevel() ? 1f : MetaUi.clamp01(into / (float) needed);
        skin.bar(g, bx, by, bw, 10, fill, theme.accent(), time);
        if (barT > 0 && barT < 1) MetaUi.glowDisc(g, bx + Math.round(bw * fill), by + 5, 6, theme.gold(), .8f);
        if (levelFlash > 0) g.fill(bx, by, bx + bw, by + 10, MetaUi.a(0xFFFFFF, levelFlash * .55f));
        MetaUi.text(g, font, MetaUi.num(into) + " / " + MetaUi.num(needed) + " XP", bx, by + 16, MetaUi.solid(theme.dim()), false);
        MetaUi.textR(g, font, "ДАЛІ — РІВЕНЬ " + (level + 1), bx + bw, by + 16, MetaUi.solid(theme.dim()), false);
        if (r.levelAfter > r.levelBefore && barT >= 1) {
            MetaUi.textC(g, font, "РІВЕНЬ " + r.levelBefore + "  →  " + r.levelAfter, hx, by + 34, MetaUi.solid(theme.good()), true);
        }
    }

    // ══ 3. нагороди ═════════════════════════════════════════════════════
    private void drawCards(GuiGraphics g, float t) {
        int n = cards.size(), gap = 8, cw = Math.min(228, (920 - gap * (n - 1)) / Math.max(1, n)), x0 = 480 - (n * cw + (n - 1) * gap) / 2, cy = 424;
        for (int i = 0; i < n; i++) {
            float k = (t - cardsStart() - i * CARD_STEP) / .4f;
            if (k <= 0) continue;
            Card c = cards.get(i);
            float s = MetaUi.outBack(MetaUi.clamp01(k));
            int x = x0 + i * (cw + gap), h = 50;
            g.pose().pushPose();
            g.pose().translate(x + cw / 2f, cy + h / 2f, 0);
            g.pose().scale(s, s, 1);
            g.pose().translate(-(x + cw / 2f), -(cy + h / 2f), 0);
            float glow = MetaUi.clamp01(1f - k * .8f);
            skin.card(g, x, cy, cw, h, c.color, glow > .2f, glow, time);
            icon(g, c.icon, x + 10, cy + 17, 2, MetaUi.solid(c.color));
            String head = c.head;
            if (c.count > 0) {
                long shown = Math.round(c.count * MetaUi.outCubic(MetaUi.clamp01(k * 1.4f - .2f)));
                head = "+" + MetaUi.num(shown) + " " + c.head;
            }
            MetaUi.text(g, font, MetaUi.fit(font, head, cw - 44), x + 34, cy + 12, MetaUi.solid(theme.text()), true);
            if (c.sub != null && !c.sub.isEmpty()) MetaUi.textS(g, font, MetaUi.fit(font, c.sub, (int) ((cw - 44) / .75f)), x + 34, cy + 28, .75f, MetaUi.solid(theme.dim()), false);
            skin.cardOverlay(g, x, cy, cw, h, c.color, glow > .2f, glow, time);
            g.pose().popPose();
        }
    }

    private void drawButtons(GuiGraphics g, float t) {
        float a = MetaUi.outCubic((t - INTRO_END - .3f) / .4f);
        if (a <= .01f) return;
        int by = 490;
        if (MetaScreens.onResultStats != null) {
            button(g, "stats", 20, by, 150, 26, "СТАТИСТИКА", false, () -> { click(); MetaScreens.onResultStats.accept(this); });
        }
        String up = !mode.upgrades.isEmpty() ? "ДО ПОКРАЩЕНЬ" : "ДО ПРОПУСКУ";
        button(g, "up", 346, by, 200, 26, up, false, () -> {
            click();
            if (MetaScreens.onResultUpgrades != null) MetaScreens.onResultUpgrades.accept(this);
            else MetaScreens.open(mode.upgrades.isEmpty() ? "track" : "upgrades", null);
        });
        boolean done = finished();
        int pulse = done ? Math.round(2 * (float) Math.sin(time * 5)) : 0;
        button(g, "skip", 740 - pulse, by - pulse / 2, 200 + 2 * pulse, 26 + pulse, done ? "ЗАКРИТИ  [ENTER]" : "ПРОПУСТИТИ  [ENTER]", MetaSkin.Kind.PRIMARY, this::skip);
    }

    // ══ частинки: конфеті/попіл від удару, іскри навколо емблеми ════════
    private void spawn(float cx, float cy, boolean confetti) {
        P p = new P();
        double an = rnd.nextDouble() * Math.PI * 2, sp = 80 + rnd.nextDouble() * 320;
        p.x = cx + (rnd.nextFloat() - .5f) * 300;
        p.y = cy;
        p.vx = (float) (Math.cos(an) * sp);
        p.vy = (float) (Math.sin(an) * sp) - (confetti ? 160 : 40);
        p.max = p.life = confetti ? 1.6f + rnd.nextFloat() * 1.4f : 1.4f + rnd.nextFloat();
        p.size = confetti ? 2 + rnd.nextInt(3) : 1 + rnd.nextInt(2);
        p.confetti = confetti;
        int[] pal = confetti ? new int[]{theme.gold(), theme.good(), theme.accent(), 0xFFFFFF, 0x55E5FF} : new int[]{theme.bad(), 0x555555, 0x2A2A2A, 0x8A3030};
        p.rgb = pal[rnd.nextInt(pal.length)];
        p.rot = rnd.nextFloat() * 6.28f;
        parts.add(p);
    }

    private void spawnRing(float cx, float cy) {
        P p = new P();
        double an = rnd.nextDouble() * Math.PI * 2, sp = 90 + rnd.nextDouble() * 120;
        p.x = cx + (float) Math.cos(an) * 30;
        p.y = cy + (float) Math.sin(an) * 30;
        p.vx = (float) (Math.cos(an) * sp);
        p.vy = (float) (Math.sin(an) * sp);
        p.max = p.life = .6f + rnd.nextFloat() * .5f;
        p.size = 1 + rnd.nextInt(2);
        p.rgb = rnd.nextBoolean() ? theme.gold() : 0xFFFFFF;
        parts.add(p);
    }

    private void updateParts() {
        for (int i = parts.size() - 1; i >= 0; i--) {
            P p = parts.get(i);
            p.life -= dt;
            if (p.life <= 0 || p.y > DH + 20) { parts.remove(i); continue; }
            if (p.confetti) { p.vy += 260 * dt; p.vx *= (float) Math.exp(-dt * 1.4); p.rot += dt * 8; }
            else if (p.max > 1.2f) { p.vy -= 60 * dt; p.vx *= (float) Math.exp(-dt * 2); }   // попіл здіймається
            else { p.vx *= (float) Math.exp(-dt * 3); p.vy *= (float) Math.exp(-dt * 3); }
            p.x += p.vx * dt;
            p.y += p.vy * dt;
        }
    }

    private void drawParts(GuiGraphics g) {
        for (P p : parts) {
            float a = MetaUi.clamp01(p.life / p.max * 1.5f);
            int sz = Math.round(p.size);
            if (p.confetti) {
                int w = Math.max(1, Math.round(sz * Math.abs((float) Math.cos(p.rot)) + 1));   // «перевертається»
                g.fill((int) p.x, (int) p.y, (int) p.x + w, (int) p.y + sz + 1, MetaUi.a(p.rgb, a));
            } else g.fill((int) p.x, (int) p.y, (int) p.x + sz, (int) p.y + sz, MetaUi.a(p.rgb, a));
        }
    }

    private void skip() {
        click();
        if (finished()) onClose();
        else skipT = time;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER || key == GLFW.GLFW_KEY_SPACE) { skip(); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
