package dev.shaurmalib.meta.mc.screen;

import dev.shaurmalib.meta.cosmetics.CosmeticDef;
import dev.shaurmalib.meta.cosmetics.CosmeticSlot;
import dev.shaurmalib.meta.cosmetics.Look;
import dev.shaurmalib.meta.cosmetics.Worn;
import dev.shaurmalib.meta.mc.render.CosmeticRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.world.entity.player.PlayerModelPart;
import org.joml.Quaternionf;

/**
 * 3D-прев'ю косметики на манекені зі скіном гравця (картки магазину, пропуску, гардероба) і фон-«промені»
 * за рідкістю, як у карток вітрини.
 */
final class Preview {

    private static RemotePlayer mannequin;

    private Preview() {}

    static RemotePlayer mannequin() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return null;
        if (mannequin == null || mannequin.level() != mc.level) {
            mannequin = new RemotePlayer(mc.level, mc.player.getGameProfile()) {
                @Override public boolean isModelPartShown(PlayerModelPart part) { return true; }
                @Override public boolean isSpectator() { return false; }   // інакше манекен з UUID спостерігача — лише голова
                @Override public boolean isCreative() { return false; }
            };
        }
        return mannequin;
    }

    /** Манекен з одним предметом у прямокутнику (дизайнові координати екрана {@code s}). */
    static void item(GuiGraphics g, MetaScreen s, CosmeticDef d, int x, int y, int w, int h, float yaw) {
        Worn worn = new Worn(d.id(), d.defaultColor());
        worn.validate(d.slot());
        Look look = new Look().only(d.slot(), worn);
        boolean aura = d.slot() == CosmeticSlot.AURA, pet = d.slot() == CosmeticSlot.PET;
        // для капелюха — крупніше й вище (видно голову), для улюбленця/аури — весь манекен
        float size = d.slot() == CosmeticSlot.HEAD ? h * .62f : aura ? h * .34f : h * .40f;
        int foot = d.slot() == CosmeticSlot.HEAD ? y + h + (int) (h * .55f) : y + h - (aura ? h / 3 : 8);
        figure(g, s, x + w / 2, foot, size, yaw, look, x, y, w, h, aura, pet ? -.1f : 0);
    }

    static void figure(GuiGraphics g, MetaScreen s, int cx, int foot, float size, float yaw, Look look,
                       int clx, int cly, int clw, int clh, boolean tilt, float lift) {
        RemotePlayer m = mannequin();
        if (m == null) return;
        float t = (System.nanoTime() / 1_000_000L % 1_000_000L) / 1000f;
        m.tickCount = (int) (t * 20f);   // від нього залежить гойдання рук у ванільній idle-позі
        idle(m, t, false);
        g.enableScissor((int) (s.ox + clx * s.ui), (int) (s.oy + cly * s.ui), (int) (s.ox + (clx + clw) * s.ui), (int) (s.oy + (cly + clh) * s.ui));
        CosmeticRenderer.preview = look;
        CosmeticRenderer.drawingPreview = true;
        CosmeticRenderer.previewYaw = yaw;
        CosmeticRenderer.previewTilt = tilt ? .42f : 0f;
        CosmeticRenderer.previewLift = lift;
        try {
            render(g, cx, foot, size, yaw, m, look.get(CosmeticSlot.AURA), tilt, clw);
        } finally {
            CosmeticRenderer.drawingPreview = false;
            CosmeticRenderer.preview = null;
            CosmeticRenderer.previewTilt = CosmeticRenderer.previewLift = 0;
            g.disableScissor();
        }
    }

    /**
     * Жива idle-поза манекена замість «статуї»: повільний зсув ваги, голова злегка дрейфує й раз на ~7 с
     * «роззирається» убік з легким кивком (напрям змінюється щоразу). Під час ходьби голова тримається прямо.
     * Ванільне гойдання рук іде від {@code tickCount}, тож його виставляє той, хто викликає (екран чи {@link #figure}).
     */
    static void idle(RemotePlayer m, float t, boolean moving) { idle(m, t, moving, 0f, 0f); }

    /** Те саме + додатковий поворот голови (градуси) — гардероб користується ним, коли персонаж «оглядає себе». */
    static void idle(RemotePlayer m, float t, boolean moving, float extraYaw, float extraPitch) {
        float body = (float) Math.sin(t * .50) * 4f;
        float yawOff = 0f, pitch = 0f;
        if (!moving) {
            float period = 7f, u = (t % period) / period;
            float side = ((long) (t / period) & 1L) == 0 ? 1f : -1f;
            float glance = u < .22f ? (float) Math.sin(u / .22f * Math.PI) : 0f;
            yawOff = (float) Math.sin(t * .70) * 8f + glance * 36f * side;
            pitch = (float) Math.sin(t * .90) * 2.5f + glance * 4f;
        }
        yawOff += extraYaw;
        pitch += extraPitch;
        m.yBodyRot = m.yBodyRotO = body;
        m.yHeadRot = m.yHeadRotO = body + yawOff;
        m.setYRot(0);
        m.setXRot(pitch);
        m.xRotO = pitch;
    }

    /** 0..1 — наскільки «дихати»: гардероб вимикає дихання, поки персонаж у польоті. */
    static float breathMul = 1f;

    /**
     * Дихання — повільний вертикальний рух усієї моделі: вдих піднімає плечі (≈1.2 % висоти), видих опускає, з короткою
     * паузою внизу. Другий, швидший обертон дає несиметричність, щоб рух не виглядав механічним метрономом.
     * @return зсув у пікселях GUI (мінус — вгору)
     */
    static float breathOffset(float t, float size) {
        float phase = t * 1.75f;                                   // ≈ 3.6 с на цикл
        float in = (float) (.5 - .5 * Math.cos(phase));            // 0..1
        float shaped = in * in * (3f - 2f * in);                   // smoothstep: м'які краї вдиху/видиху
        float second = (float) Math.sin(phase * 2.0 + 1.1) * .12f;
        return -size * .012f * (shaped + second) * breathMul;
    }

    private static float clock() { return (System.nanoTime() / 1_000_000L % 1_000_000L) / 1000f; }

    /** Нахил сцени вперед (рад) для превʼю з аурою: кільце на підлозі читається еліпсом, а не лінією. */
    static final float AURA_PITCH = .30f;

    /**
     * Окремий аніматор для манекена (гардероб). Манекен має UUID справжнього гравця, тож без цього він брав би
     * аніматор гравця зі світу — а той у меню «стоїть» і своїм idle-кліпом перекриває ходьбу/біг.
     */
    static Object animatorOverride;

    /**
     * Єдине місце, де манекен малюється у превʼю (магазин, пропуск, гардероб, профіль): аура — ПЕРШОЮ,
     * позаду моделі (без запису глибини вона інакше лягала б поверх ніг), уся сцена — манекен разом з
     * аурою — трохи нахилена вперед, а кільце стиснуте так, щоб влізти у вікно шириною {@code clipW}.
     * Викликати всередині {@code drawingPreview = true} і зі scissor вікна.
     */
    static void render(GuiGraphics g, float cx, float foot, float size, float yawDeg,
                       net.minecraft.world.entity.LivingEntity entity, Worn aura, boolean tilt, float clipW) {
        float pitch = tilt || aura != null ? AURA_PITCH : 0f;
        // Pitch — у просторі екрана (зліва від Z-фліпа), щоб нахилялася вся сцена, а не лише модель.
        Quaternionf rot = new Quaternionf().rotationX(pitch).rotateZ((float) Math.PI)
                .rotateY((float) Math.toRadians(yawDeg));
        // Після нахилу передня дуга кільця аури опускається нижче ніг — renderScene піднімає сцену на цю висоту.
        // Сплющення/розтягування й нахил усієї сцени (гардероб: приземлення, «невагомість» у руці).
        boolean deform = squashX != 1f || squashY != 1f || roll != 0f;
        if (deform) {
            var ps = g.pose();
            ps.pushPose();
            ps.translate(cx, foot - pivotUp, 0f);
            ps.mulPose(com.mojang.math.Axis.ZP.rotationDegrees(roll));
            ps.translate(0f, pivotUp, 0f);
            ps.scale(squashX, squashY, 1f);
            ps.translate(-cx, -foot, 0f);
        }
        try {
            renderScene(g, cx, foot, size, yawDeg, entity, aura, rot, clipW);
        } finally {
            if (deform) g.pose().popPose();
        }
    }

    /** Множники сплющення сцени відносно ніг (1 — без змін) і нахил (градуси) навколо точки на {@code pivotUp} px вище ніг. */
    static float squashX = 1f, squashY = 1f, roll = 0f, pivotUp = 0f;

    static void resetDeform() { squashX = squashY = 1f; roll = pivotUp = 0f; }

    private static void renderScene(GuiGraphics g, float cx, float foot, float size, float yawDeg,
                                    net.minecraft.world.entity.LivingEntity entity, Worn aura, Quaternionf rot, float clipW) {
        float pitch = AURA_PITCH;
        if (aura != null) {
            float fit = clipW > 0 ? clipW * .44f / size : Float.MAX_VALUE;
            float r = Math.min(aura.param(CosmeticSlot.AURA, "scale") * 1.22f, fit);
            foot -= (float) (r * size * Math.sin(pitch));
        }
        final float fx = cx, ffoot = foot, fsize = size;
        final float auraTime = Minecraft.getInstance().level == null ? 0
                : Minecraft.getInstance().level.getGameTime() + Minecraft.getInstance().getFrameTime();
        final float fitBlocks = clipW > 0 ? clipW * .44f / size : Float.MAX_VALUE;
        CosmeticRenderer.previewAuraFit = entity instanceof net.minecraft.client.player.AbstractClientPlayer acp ? CosmeticRenderer.fitOf(acp)[1] : 1f;
        try {
            if (aura != null) {
                // Сендвіч: задня половина аури — ДО манекена (його тіло її перекриє), передня — ПІСЛЯ нього (лягає поверх ніг).
                drawAuraPass(g, fx, ffoot, fsize, rot, aura, yawDeg, auraTime, fitBlocks, -1);
                CosmeticRenderer.previewAuraSeparate = true;
            }
            // Дихання: зсув у float-координатах GUI (renderEntityInInventory бере int, тож зсуваємо матрицю, а не позицію).
            g.pose().pushPose();
            g.pose().translate(0f, breathOffset(clock() + (entity.getId() & 7) * 1.3f, size), 0f);
            try {
                final int ix = (int) cx, iy = (int) foot, isz = (int) size;
                if (animatorOverride != null) {
                    MetaAnimationPreview.withPreview(entity, animatorOverride, Minecraft.getInstance().getFrameTime(),
                            () -> InventoryScreen.renderEntityInInventory(g, ix, iy, isz, rot, null, entity));
                } else {
                    InventoryScreen.renderEntityInInventory(g, ix, iy, isz, rot, null, entity);
                }
            } finally {
                g.pose().popPose();
            }
            if (aura != null) drawAuraPass(g, fx, ffoot, fsize, rot, aura, yawDeg, auraTime, fitBlocks, +1);
        } finally {
            CosmeticRenderer.previewAuraSeparate = false;
            CosmeticRenderer.previewAuraFit = 1f;
        }
    }

    /** Один прохід аури у тій самій матриці сцени, що й манекен. side: -1 позаду моделі, +1 попереду. */
    private static void drawAuraPass(GuiGraphics g, float cx, float foot, float size, Quaternionf rot, Worn aura,
                                     float yawDeg, float time, float fitBlocks, int side) {
        var ps = g.pose();
        ps.pushPose();
        ps.translate(cx, foot, 50.0);
        ps.mulPoseMatrix(new org.joml.Matrix4f().scaling(size, size, -size));
        ps.mulPose(rot);
        CosmeticRenderer.drawPreviewAura(ps, g.bufferSource(), aura, yawDeg, 0f, time, fitBlocks, side);
        ps.popPose();
        g.flush();
    }

    /**
     * Лише сам предмет косметики, без манекена (права панель гардероба): капелюх, рюкзак чи улюбленець — 3D-модель,
     * що повільно обертається й «плаває»; аура — саме кільце з ефектами. Центр (cx, cy), {@code size} — пікселів на блок.
     */
    static void cosmeticOnly(GuiGraphics g, MetaScreen s, Worn w, CosmeticSlot slot, float cx, float cy, float size, float yaw,
                             int clx, int cly, int clw, int clh) {
        if (w == null) return;
        Minecraft mc = Minecraft.getInstance();
        g.enableScissor((int) (s.ox + clx * s.ui), (int) (s.oy + cly * s.ui), (int) (s.ox + (clx + clw) * s.ui), (int) (s.oy + (cly + clh) * s.ui));
        try {
            if (slot == CosmeticSlot.AURA) {
                float pitch = .55f;
                Quaternionf rot = new Quaternionf().rotationX(pitch).rotateZ((float) Math.PI).rotateY((float) Math.toRadians(yaw));
                float fit = clw * .46f / size;
                float t = mc.level == null ? clock() * 20f : mc.level.getGameTime() + mc.getFrameTime();
                drawAuraPass(g, cx, cy, size, rot, w, yaw, t, fit, 0);
                return;
            }
            net.minecraft.world.item.Item it = CosmeticRenderer.item(w.item);
            if (it == null) return;
            var ps = g.pose();
            ps.pushPose();
            ps.translate(cx, cy, 150f);
            ps.mulPoseMatrix(new org.joml.Matrix4f().scaling(1f, -1f, 1f));   // як GuiGraphics.renderItem: Y GUI — вниз
            ps.scale(size, size, size);
            ps.mulPose(com.mojang.math.Axis.XP.rotationDegrees(slot == CosmeticSlot.PET ? 12f : 18f));
            ps.mulPose(com.mojang.math.Axis.YP.rotationDegrees(yaw));
            mc.getItemRenderer().renderStatic(CosmeticRenderer.stack(it, w.color), net.minecraft.world.item.ItemDisplayContext.NONE,
                    net.minecraft.client.renderer.LightTexture.FULL_BRIGHT, net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY,
                    ps, g.bufferSource(), mc.level, 0);
            g.flush();
            ps.popPose();
        } finally {
            g.disableScissor();
        }
    }

    /** Предмет гри як 3D-іконка (скрині, подарунок): {@code itemId} з реєстру, центр (cx, cy), масштаб від 16 px. */
    static void itemIcon(GuiGraphics g, String itemId, float cx, float cy, float scale) {
        var rl = net.minecraft.resources.ResourceLocation.tryParse(itemId);
        var it = rl == null ? net.minecraft.world.item.Items.CHEST : net.minecraft.core.registries.BuiltInRegistries.ITEM.get(rl);
        if (it == net.minecraft.world.item.Items.AIR) it = net.minecraft.world.item.Items.CHEST;
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().scale(scale, scale, 1);
        g.pose().translate(-8, -8, 0);
        g.renderItem(new net.minecraft.world.item.ItemStack(it), 0, 0);
        g.pose().popPose();
    }

    static String timer(long msLeft) {
        if (msLeft <= 0) return "0хв";
        long m = msLeft / 60_000L, h = m / 60, d = h / 24;
        if (d > 0) return d + "д " + (h % 24) + "год";
        if (h > 0) return h + "год " + (m % 60) + "хв";
        return m + "хв";
    }
}
