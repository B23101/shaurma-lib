package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.io.BBModelDoc;
import dev.shaurmalib.scene.mc.ui.Draw2D;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.Icons;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Сторінка «Модель» (режим «Редагувати» Shaurma Modeling у редакторі сцени): дерево груп і кубиків, 3D-вигляд моделі
 * вибраного актора/пропа з інструментами Рух · Розмір · Поворот · Півот, інспектор з числами. Кожне перетягування
 * чи поле — одна дія в історії сцени (Ctrl+Z), модель у сцені оновлюється одразу.
 *
 * <p>Миша у вигляді: ЛКМ по кубику — вибрати й тягнути інструментом; ЛКМ по порожньому чи ПКМ — обертати вигляд;
 * СКМ (або Shift+ПКМ) — зсунути; колесо — наблизити. Клавіші: G рух, S розмір, R поворот, P півот, X/Y/Z — вісь,
 * F — до вибраного, N — новий кубик, Ctrl+D — копія, Delete — видалити, Esc — скасувати перетягування.
 */
final class ModelPage {

    private ModelPage() {}

    enum Tool {
        MOVE("Рух", Icon.MOVE, "G"), RESIZE("Розмір", Icon.RESIZE, "S"), ROTATE("Поворот", Icon.ROTATE, "R"), PIVOT("Півот", Icon.PIVOT, "P");
        final String title; final Icon icon; final String key;
        Tool(String t, Icon i, String k) { title = t; icon = i; key = k; }
    }

    static Tool tool = Tool.MOVE;
    /** Вісь: -1 вільно, 0 X, 1 Y, 2 Z. */
    static int axis = -1;
    static final ModelView.Cam CAM = new ModelView.Cam();

    // перетягування
    private static BBModelDoc dragBase;
    private static ModelView.Hit dragHit;
    private static String dragNode;
    private static double dragX, dragY;
    private static boolean dragging, dragMoved, orbiting;
    private static int orbitButton;
    private static double lastX, lastY;
    private static String lastRebuilt;

    static final int OUT_W = 128, INSP_W = 156;

    // ═════════════ кадр ═════════════

    static void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        gui.g.fill(x, y, x + w, y + h, 0xFF10141F);
        if (!ModelSession.sync(s)) { placeholder(gui, x, y, w, h, ModelSession.problem); return; }
        rebuildIfNeeded();
        int ow = Math.min(OUT_W, w / 4), iw = Math.min(INSP_W, w / 3);
        outliner(s, gui, x, y, ow, h);
        inspector(s, gui, x + w - iw, y, iw, h);
        int vx = x + ow, vw = w - ow - iw;
        toolbar(s, gui, vx, y, vw, 18);
        viewport(s, gui, vx, y + 18, vw, h - 18);
    }

    static void placeholder(Gui gui, int x, int y, int w, int h, String why) {
        Icons.draw(gui.g, Icon.CUBE, x + w / 2 - 12, y + h / 2 - 34, 24, Theme.MUTED);
        String t = why == null ? "Немає моделі" : why;
        List<net.minecraft.util.FormattedCharSequence> lines = gui.font.split(Component.literal(t), Math.max(80, w - 60));
        int ty = y + h / 2 - 2;
        for (var l : lines) { gui.g.drawString(gui.font, l, x + (w - gui.font.width(l)) / 2, ty, Theme.MUTED, false); ty += 11; }
    }

    /** Модель перечитана (undo / інша модель / поле) — перебудувати грані вигляду. */
    static void rebuildIfNeeded() {
        String key = ModelSession.assetId + "@" + System.identityHashCode(ModelSession.parsed);
        if (key.equals(lastRebuilt)) return;
        lastRebuilt = key;
        ModelView.build(ModelSession.parsed);
        if (!CAM.fitted) { ModelView.frame(CAM, ModelView.bounds(null)); CAM.fitted = true; }
        if (!PaintPage.CAM.fitted) { ModelView.frame(PaintPage.CAM, ModelView.bounds(null)); PaintPage.CAM.fitted = true; }
    }

    // ═════════════ дерево ═════════════

    private static void outliner(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        gui.panel(x, y, w, h);
        BBModelDoc bb = ModelSession.bb;
        int bx = x + 3;
        if (gui.iconButton(bx, y + 3, 14, Icon.ADD_CUBE, false, Component.literal("Новий кубик (N)"))) addCube(s);
        if (gui.iconButton(bx + 16, y + 3, 14, Icon.ADD_GROUP, false, Component.literal("Нова група-кістка"))) edit(s, "нова група", () -> ModelSession.sel = bb.addGroup(parentForNew()));
        if (gui.iconButton(bx + 32, y + 3, 14, Icon.DUPLICATE, false, Component.literal("Копія кубика (Ctrl+D)"), ModelSession.sel != null && !bb.isGroup(ModelSession.sel))) duplicate(s);
        if (gui.iconButton(bx + 48, y + 3, 14, Icon.DELETE, false, Component.literal("Видалити (Delete)"), ModelSession.sel != null)) delete(s);
        List<BBModelDoc.Node> nodes = bb.tree();
        int rowH = 12, top = y + 20, listH = h - 22;
        int off = gui.scrollBegin("mdl.outliner", x, top, w, listH, nodes.size() * rowH + 4);
        int ry = top - off;
        for (BBModelDoc.Node n : nodes) {
            if (ry + rowH >= top && ry < top + listH) {
                boolean on = n.uuid().equals(ModelSession.sel), hov = gui.hover(x, ry, w - 6, rowH);
                if (on) gui.g.fill(x + 1, ry, x + w - 6, ry + rowH, 0xFF2B4A86);
                else if (hov) gui.g.fill(x + 1, ry, x + w - 6, ry + rowH, 0x18FFFFFF);
                int ix = x + 4 + n.depth() * 8;
                Icons.draw(gui.g, n.group() ? Icon.FOLDER_OPEN : Icon.CUBE, ix, ry + 1, 10, n.group() ? 0xFFE0B860 : 0xFF8FB4F0);
                gui.textClip(n.name(), ix + 13, ry + 2, x + w - 8 - ix - 13, on ? Theme.TEXT : 0xFFC4CDE0);
                if (gui.clicked(x, ry, w - 6, rowH, 0)) ModelSession.sel = n.uuid();
            }
            ry += rowH;
        }
        gui.scrollEnd();
    }

    // ═════════════ інструменти ═════════════

    private static void toolbar(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        gui.g.fill(x, y, x + w, y + h, 0xFF161D2E);
        int bx = x + 4;
        for (Tool t : Tool.values()) {
            int bw = gui.font.width(t.title) + 20;
            if (gui.button(bx, y + 2, bw, 14, Component.literal(t.title), tool == t, Component.literal(t.title + " (" + t.key + ")"))) tool = t;
            Icons.draw(gui.g, t.icon, bx + 3, y + 4, 10, tool == t ? Theme.TEXT : Theme.MUTED);
            bx += bw + 2;
        }
        bx += 8;
        String[] ax = { "X", "Y", "Z" };
        int[] cols = { 0xFFE5534B, 0xFF6BCB5B, 0xFF4A7BE5 };
        for (int i = 0; i < 3; i++) {
            if (gui.button(bx, y + 2, 16, 14, Component.literal(ax[i]), axis == i, Component.literal("Лише вісь " + ax[i] + " (" + ax[i] + "; ще раз — вільно)"))) axis = axis == i ? -1 : i;
            gui.g.fill(bx + 2, y + 14, bx + 14, y + 15, cols[i]);
            bx += 18;
        }
        bx += 8;
        if (gui.iconButton(bx, y + 2, 14, Icon.ZOOM, false, Component.literal("До вибраного (F)"))) focus();
        String hint = switch (tool) {
            case MOVE -> "Тягни кубик чи групу; Shift — ¼ пікселя, Ctrl — без кроку";
            case RESIZE -> "Тягни грань кубика — вона рухається вздовж своєї осі";
            case ROTATE -> "Тягни вліво-вправо: кроки 22.5°, Shift — по 1°" + (axis < 0 ? " (вісь Y; X/Z — інша)" : "");
            case PIVOT -> "Тягни — переносить точку обертання (оранжева)";
        };
        int hx = bx + 20;
        if (hx + 40 < x + w) gui.textClip(hint, hx, y + 5, x + w - hx - 4, Theme.MUTED);
    }

    // ═════════════ вигляд ═════════════

    private static void viewport(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        ModelView.layout(CAM, x, y, w, h);
        ModelView.render(gui.g, ModelSession.texture());
        String sel = ModelSession.sel;
        BBModelDoc bb = ModelSession.bb;
        Set<String> selCubes = new HashSet<>();
        if (sel != null) { if (bb.isGroup(sel)) selCubes.addAll(bb.cubesIn(sel)); else selCubes.add(sel); }
        boolean over = gui.hover(x, y, w, h);
        ModelView.Hit hover = over && !dragging && !orbiting ? ModelView.pick(gui.mx, gui.my) : null;
        if (hover != null && hover.face().uuid != null && !selCubes.contains(hover.face().uuid)) ModelView.outline(gui.g, Set.of(hover.face().uuid), 0x80FFFFFF, 1f);
        ModelView.outline(gui.g, selCubes, 0xFF5EA0FF, 1.5f);
        if (tool == Tool.RESIZE) {
            ModelView.Face f = dragging && dragHit != null ? dragHit.face() : hover != null && selCubes.contains(hover.face().uuid) ? hover.face() : null;
            ModelView.fillFace(gui.g, f, 0x405EA0FF);
        }
        if (sel != null) pivotMarker(gui, bb, sel);
        if (dragging) gui.text(dragLabel(), x + 6, y + 6, 0xFFF2D27A);

        // ── миша ──
        int c = gui.pendingClick();
        if (c >= 0 && over && gui.clicked(x, y, w, h, c)) {
            lastX = gui.mx; lastY = gui.my;
            ModelView.Hit hit = c == 0 ? ModelView.pick(gui.mx, gui.my) : null;
            if (c == 0 && hit != null && hit.face().uuid != null) {
                String target = sel != null && bb.isGroup(sel) && selCubes.contains(hit.face().uuid) ? sel : hit.face().uuid;
                ModelSession.sel = target;
                startDrag(target, hit);
            } else {
                orbiting = true;
                orbitButton = c;
                dragMoved = false;
            }
        }
        double scroll = gui.pendingScroll();
        if (over && scroll != 0) { ModelView.zoom(CAM, scroll); gui.consumeScroll(); }
        if (orbiting) {
            if (!gui.isDown(orbitButton)) {
                if (!dragMoved && orbitButton == 0) ModelSession.sel = null;   // клік у порожнечу — зняти вибір
                orbiting = false;
            } else {
                double dx = gui.mx - lastX, dy = gui.my - lastY;
                if (Math.abs(dx) + Math.abs(dy) > 0) dragMoved = true;
                if (orbitButton == 2 || Screen.hasShiftDown()) ModelView.pan(CAM, dx, dy); else ModelView.orbit(CAM, dx, dy);
                lastX = gui.mx; lastY = gui.my;
            }
        }
        if (dragging) {
            if (!gui.isDown(0)) finishDrag(s);
            else applyDrag(gui.mx - dragX, gui.my - dragY);
        }
    }

    private static void pivotMarker(Gui gui, BBModelDoc bb, String sel) {
        double[] o = bb.origin(sel);
        double[] p = ModelView.project((float) -o[0] / 16f, (float) o[1] / 16f, (float) o[2] / 16f);
        if (p == null) return;
        int col = tool == Tool.PIVOT ? 0xFFFF9A3C : 0xA0FF9A3C;
        Draw2D.dot(gui.g, p[0], p[1], 3, 0xFF000000);
        Draw2D.dot(gui.g, p[0], p[1], 2, col);
    }

    private static String dragLabel() {
        BBModelDoc bb = ModelSession.bb;
        String n = dragNode;
        if (n == null || bb.props(n) == null) return "";
        return switch (tool) {
            case MOVE -> bb.isGroup(n) ? "Півот " + vec(bb.origin(n)) : "Від " + vec(bb.from(n));
            case RESIZE -> "Розмір " + vec(bb.size(n));
            case ROTATE -> "Поворот " + vec(bb.rotation(n));
            case PIVOT -> "Півот " + vec(bb.origin(n));
        };
    }

    private static String vec(double[] v) { return String.format(Locale.ROOT, "%s, %s, %s", Gui.fmt(v[0]), Gui.fmt(v[1]), Gui.fmt(v[2])); }

    private static void startDrag(String node, ModelView.Hit hit) {
        dragBase = ModelSession.bb.copy();
        dragNode = node;
        dragHit = hit;
        dragX = lastX; dragY = lastY;
        dragging = true;
    }

    /** Застосувати повний зсув миші від початку (від знімка — без накопичення похибок). */
    private static void applyDrag(double dx, double dy) {
        BBModelDoc bb = dragBase.copy();
        String n = dragNode;
        double step = Screen.hasControlDown() ? 0 : Screen.hasShiftDown() ? 0.25 : 1;
        ModelView.Hit h = dragHit;
        switch (tool) {
            case MOVE, PIVOT -> {
                double[] d = planeDelta(h.x(), h.y(), h.z(), dx, dy, step);
                if (tool == Tool.MOVE) bb.move(n, d[0], d[1], d[2]); else bb.movePivot(n, d[0], d[1], d[2]);
            }
            case RESIZE -> {
                if (bb.isGroup(n)) break;
                ModelView.Face f = h.face();
                double[] sv = ModelView.screenDir(h.x(), h.y(), h.z(), f.nx / 16f, f.ny / 16f, f.nz / 16f);
                double len2 = sv[0] * sv[0] + sv[1] * sv[1];
                if (len2 < 1e-6) break;
                double amt = snap((dx * sv[0] + dy * sv[1]) / len2, step);
                bb.resize(n, f.axis, f.side, amt);
            }
            case ROTATE -> {
                double r = snap(dx * 0.75, Screen.hasControlDown() ? 0 : Screen.hasShiftDown() ? 1 : 22.5);
                double[] rot = bb.rotation(n);
                int a = axis < 0 ? 1 : axis;
                rot[a] = wrap(rot[a] + r);
                bb.setRotation(n, rot);
            }
        }
        ModelSession.bb = bb;
        if (ModelSession.geometryChanged()) { /* грані перебудуються в rebuildIfNeeded наступного кадру */ }
    }

    /** Зсув миші → зсув у пікселях Blockbench: по осі (якщо вибрана) або в площині двох найпомітніших осей. */
    private static double[] planeDelta(float px, float py, float pz, double dx, double dy, double step) {
        double[][] sv = new double[3][];
        float u = 1 / 16f;
        sv[0] = ModelView.screenDir(px, py, pz, -u, 0, 0);   // X Blockbench = -X сітки
        sv[1] = ModelView.screenDir(px, py, pz, 0, u, 0);
        sv[2] = ModelView.screenDir(px, py, pz, 0, 0, u);
        double[] out = new double[3];
        if (axis >= 0) {
            double[] a = sv[axis];
            double l2 = a[0] * a[0] + a[1] * a[1];
            if (l2 > 1e-6) out[axis] = snap((dx * a[0] + dy * a[1]) / l2, step);
            return out;
        }
        // відкидаємо вісь, що найбільше «дивиться в камеру» (найкоротша на екрані)
        int drop = 0;
        double minL = Double.MAX_VALUE;
        for (int i = 0; i < 3; i++) { double l = Math.hypot(sv[i][0], sv[i][1]); if (l < minL) { minL = l; drop = i; } }
        int i = drop == 0 ? 1 : 0, j = drop == 2 ? 1 : 2;
        double a = sv[i][0], b = sv[j][0], c = sv[i][1], d = sv[j][1], det = a * d - b * c;
        if (Math.abs(det) < 1e-9) return out;
        out[i] = snap((d * dx - b * dy) / det, step);
        out[j] = snap((-c * dx + a * dy) / det, step);
        return out;
    }

    private static double snap(double v, double step) { return step <= 0 ? Math.round(v * 1000) / 1000.0 : Math.round(v / step) * step; }

    private static double wrap(double a) {
        a = ((a + 180) % 360 + 360) % 360 - 180;
        return Math.round(a * 1000) / 1000.0;
    }

    private static void finishDrag(SceneEditorScreen s) {
        dragging = false;
        String label = tool.title.toLowerCase(Locale.ROOT) + " «" + ModelSession.bb.name(dragNode) + "»";
        boolean changed = !ModelSession.bb.write().equals(dragBase.write());
        if (!changed) ModelSession.bb = dragBase;   // просто клік (вибір) — ні нової версії ассета, ні дії в історії
        dragBase = null;
        if (changed) ModelSession.commitModel(s, label); else { ModelSession.geometryChanged(); ModelSession.clearLive(); }
    }

    static boolean cancelDrag(SceneEditorScreen s) {
        if (!dragging) return false;
        dragging = false;
        ModelSession.bb = dragBase;
        dragBase = null;
        ModelSession.geometryChanged();
        ModelSession.clearLive();
        return true;
    }

    static boolean busy() { return dragging; }

    private static void focus() {
        BBModelDoc bb = ModelSession.bb;
        String sel = ModelSession.sel;
        Set<String> only = null;
        if (sel != null) { only = new HashSet<>(); if (bb.isGroup(sel)) only.addAll(bb.cubesIn(sel)); else only.add(sel); }
        float[] b = ModelView.bounds(only);
        ModelView.frame(CAM, b != null ? b : ModelView.bounds(null));
    }

    // ═════════════ інспектор ═════════════

    private static void inspector(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        gui.panel(x, y, w, h);
        BBModelDoc bb = ModelSession.bb;
        String sel = ModelSession.sel;
        int cy = y + 4;
        var asset = s.doc.assets.get(ModelSession.assetId);
        gui.textClip(asset == null ? "" : asset.name, x + 5, cy, w - 10, Theme.MUTED);
        cy += 12;
        if (sel == null || bb.props(sel) == null) {
            gui.textClip("Виберіть кубик чи групу", x + 5, cy + 4, w - 10, Theme.MUTED);
            gui.textClip("в дереві або кліком у вигляді", x + 5, cy + 15, w - 10, Theme.MUTED);
            cy += 34;
            gui.textClip(ModelView.faces.size() / 6 + " кубиків · текстура " + ModelSession.image.width + "×" + ModelSession.image.height, x + 5, cy, w - 10, Theme.MUTED);
            return;
        }
        boolean group = bb.isGroup(sel);
        gui.text(group ? "Група (кістка)" : "Кубик", x + 5, cy, Theme.TEXT);
        cy += 12;
        String typed = gui.textField("mdl.name." + sel, x + 5, cy, w - 10, 13, bb.name(sel), null);
        if (typed != null && !typed.isBlank() && !typed.strip().equals(bb.name(sel))) edit(s, "назва", () -> bb.rename(sel, typed));
        cy += 18;
        if (!group) {
            cy = vecRow(s, gui, "Від", "from", bb.from(sel), x, cy, w, v -> bb.setFrom(sel, v));
            cy = vecRow(s, gui, "Розмір", "size", bb.size(sel), x, cy, w, v -> bb.setSize(sel, v));
        }
        cy = vecRow(s, gui, "Півот", "origin", bb.origin(sel), x, cy, w, v -> bb.setOrigin(sel, v));
        cy = vecRow(s, gui, "Поворот", "rot", bb.rotation(sel), x, cy, w, v -> bb.setRotation(sel, v));
        if (!group) {
            gui.text("Роздуття", x + 5, cy + 3, MenuSkin.LABEL);
            Gui.Num n = gui.number("mdl.inflate." + sel, x + w / 2, cy, w / 2 - 5, 13, bb.inflate(sel), 0.25, Theme.ACCENT);
            if (n.any()) field(s, n, "роздуття", () -> bb.setInflate(sel, n.value()));
            cy += 18;
        }
        cy += 4;
        gui.textClip("Ctrl+Z — скасувати, як і все в сцені", x + 5, cy, w - 10, Theme.MUTED);
    }

    private static int vecRow(SceneEditorScreen s, Gui gui, String label, String key, double[] v, int x, int y, int w, java.util.function.Consumer<double[]> set) {
        gui.text(label, x + 5, y, MenuSkin.LABEL);
        y += 10;
        int fw = (w - 14) / 3;
        int[] cols = { 0xFFE5534B, 0xFF6BCB5B, 0xFF4A7BE5 };
        for (int i = 0; i < 3; i++) {
            int fx = x + 5 + i * (fw + 2);
            Gui.Num n = gui.number("mdl." + key + "." + i + "." + ModelSession.sel, fx, y, fw, 13, v[i], key.equals("rot") ? 2.5 : 0.25, cols[i]);
            if (n.any()) {
                final int k = i;
                field(s, n, label.toLowerCase(Locale.ROOT), () -> { double[] nv = v.clone(); nv[k] = n.value(); set.accept(nv); });
            }
        }
        return y + 18;
    }

    /** Поле змінилось: наживо, а на COMMIT (відпустили / Enter) — дія в історії. */
    private static void field(SceneEditorScreen s, Gui.Num n, String label, Runnable change) {
        change.run();
        ModelSession.geometryChanged();
        if (!n.live()) ModelSession.commitModel(s, label + " «" + ModelSession.bb.name(ModelSession.sel) + "»");
    }

    private static void edit(SceneEditorScreen s, String label, Runnable change) {
        change.run();
        ModelSession.geometryChanged();
        ModelSession.commitModel(s, label);
    }

    private static String parentForNew() {
        String sel = ModelSession.sel;
        BBModelDoc bb = ModelSession.bb;
        if (sel == null) return null;
        if (bb.isGroup(sel)) return sel;
        for (BBModelDoc.Node n : bb.tree()) if (n.uuid().equals(sel)) return n.parent();
        return null;
    }

    private static void addCube(SceneEditorScreen s) { BBModelDoc bb = ModelSession.bb; edit(s, "новий кубик", () -> ModelSession.sel = bb.addCube(parentForNew())); }

    private static void duplicate(SceneEditorScreen s) {
        BBModelDoc bb = ModelSession.bb;
        String sel = ModelSession.sel;
        if (sel == null || bb.isGroup(sel)) return;
        edit(s, "копія «" + bb.name(sel) + "»", () -> ModelSession.sel = bb.duplicate(sel));
    }

    private static void delete(SceneEditorScreen s) {
        BBModelDoc bb = ModelSession.bb;
        String sel = ModelSession.sel;
        if (sel == null) return;
        edit(s, "видалити «" + bb.name(sel) + "»", () -> { bb.delete(sel); ModelSession.sel = null; });
    }

    // ═════════════ клавіші ═════════════

    static boolean key(SceneEditorScreen s, int key, boolean ctrl) {
        if (ModelSession.bb == null) return false;
        if (ctrl) {
            if (key == GLFW.GLFW_KEY_D) { duplicate(s); return true; }
            return false;
        }
        switch (key) {
            case GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_1 -> tool = Tool.MOVE;
            case GLFW.GLFW_KEY_S, GLFW.GLFW_KEY_2 -> tool = Tool.RESIZE;
            case GLFW.GLFW_KEY_R, GLFW.GLFW_KEY_3 -> tool = Tool.ROTATE;
            case GLFW.GLFW_KEY_P, GLFW.GLFW_KEY_4 -> tool = Tool.PIVOT;
            case GLFW.GLFW_KEY_X -> axis = axis == 0 ? -1 : 0;
            case GLFW.GLFW_KEY_Y -> axis = axis == 1 ? -1 : 1;
            case GLFW.GLFW_KEY_Z -> axis = axis == 2 ? -1 : 2;
            case GLFW.GLFW_KEY_F -> focus();
            case GLFW.GLFW_KEY_N -> addCube(s);
            case GLFW.GLFW_KEY_DELETE, GLFW.GLFW_KEY_BACKSPACE -> delete(s);
            default -> { return false; }
        }
        return true;
    }
}
