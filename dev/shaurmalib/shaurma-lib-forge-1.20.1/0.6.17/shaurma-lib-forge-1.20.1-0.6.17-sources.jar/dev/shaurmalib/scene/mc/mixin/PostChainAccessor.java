package dev.shaurmalib.scene.mc.mixin;

import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;

/** Проходи пост-шейдера — щоб щокадру задавати uniform-и (сила фільтра, кольорова матриця, радіус розмиття). */
@Mixin(PostChain.class)
public interface PostChainAccessor {
    @Accessor("passes")
    List<PostPass> shaurma$passes();
}
