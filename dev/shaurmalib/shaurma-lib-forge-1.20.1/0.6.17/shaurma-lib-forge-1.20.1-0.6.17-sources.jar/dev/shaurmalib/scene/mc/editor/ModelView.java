package dev.shaurmalib.scene.mc.editor;

import com.mojang.blaze3d.platform.Lighting;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexSorting;
import dev.shaurmalib.anim.math.Mat4;
import dev.shaurmalib.anim.mesh.GeoMesh;
import dev.shaurmalib.scene.io.BBModelReader;
import dev.shaurmalib.scene.mc.ui.Draw2D;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.List;

/**
 * 3D-вигляд моделі всередині прямокутника GUI (сторінки «Модель» і «Малювання»): орбіта навколо моделі, сітка-підлога,
 * обведення вибраного, пік грані під курсором — з точкою на поверхні й UV (малювання прямо по моделі,
 * як режим «Малювати» Shaurma Modeling / Blockbench). Поза спокою: анімації сцени тут не діють.
 */
final class ModelView {

    /** Орбітальна камера (кожна сторінка — своя). */
    static final class Cam {
        float yaw = 35, pitch = 22, dist = 3f, tx, ty = 0.5f, tz;
        boolean fitted;
    }

    /** Грань моделі в просторі моделі (блоки) і на екрані. */
    static final class Face {
        String uuid;
        final float[] p = new float[12];
        final float[] uv = new float[8];
        final double[] sx = new double[4], sy = new double[4], w = new double[4];
        float nx, ny, nz;
        int axis, side;
        boolean visible;
    }

    record Hit(Face face, double u, double v, float x, float y, float z, double depth) {}

    static final List<Face> faces = new ArrayList<>();
    private static Matrix4f proj = new Matrix4f(), view = new Matrix4f();
    private static int rx, ry, rw = 1, rh = 1;

    private ModelView() {}

    // ═════════════ геометрія ═════════════

    /** Перебудувати грані з розібраної моделі (у позі спокою). */
    static void build(BBModelReader.Result r) {
        faces.clear();
        if (r == null || r.mesh == null) return;
        float[] tmp = new float[3];
        for (GeoMesh.MeshBone b : r.mesh.roots) bone(b, new Mat4(), r, tmp);
    }

    private static void bone(GeoMesh.MeshBone b, Mat4 parent, BBModelReader.Result r, float[] tmp) {
        Mat4 m = new Mat4().set(parent).translate(b.pivotX, b.pivotY, b.pivotZ).rotateZ(b.rotZ).rotateY(b.rotY).rotateX(b.rotX)
            .translate(-b.pivotX, -b.pivotY, -b.pivotZ);
        List<String> ids = r.boneCubes.get(b.name);
        for (int i = 0; i < b.cubes.size(); i++) {
            GeoMesh.MeshCube c = b.cubes.get(i);
            String uuid = ids != null && i < ids.size() ? ids.get(i) : null;
            Mat4 cm = new Mat4().set(m).translate(c.pivotX, c.pivotY, c.pivotZ).rotateZ(c.rotZ).rotateY(c.rotY).rotateX(c.rotX)
                .translate(-c.pivotX, -c.pivotY, -c.pivotZ);
            for (GeoMesh.Quad q : c.quads) {
                Face f = new Face();
                f.uuid = uuid;
                for (int v = 0; v < 4; v++) {
                    cm.transformPoint(q.pos[v * 3], q.pos[v * 3 + 1], q.pos[v * 3 + 2], tmp);
                    f.p[v * 3] = tmp[0]; f.p[v * 3 + 1] = tmp[1]; f.p[v * 3 + 2] = tmp[2];
                }
                System.arraycopy(q.uv, 0, f.uv, 0, 8);
                cm.transformNormal(q.nx, q.ny, q.nz, tmp);
                f.nx = tmp[0]; f.ny = tmp[1]; f.nz = tmp[2];
                float ax = Math.abs(q.nx), ay = Math.abs(q.ny), az = Math.abs(q.nz);
                f.axis = ax >= ay && ax >= az ? 0 : ay >= az ? 1 : 2;
                f.side = f.axis == 0 ? (q.nx > 0 ? -1 : 1) : f.axis == 1 ? (q.ny > 0 ? 1 : -1) : (q.nz > 0 ? 1 : -1);   // X сітки дзеркальний до Blockbench
                faces.add(f);
            }
        }
        for (GeoMesh.MeshBone ch : b.children) bone(ch, m, r, tmp);
    }

    /** Межі всіх граней (або лише граней uuids) — {minX,minY,minZ,maxX,maxY,maxZ}; null — порожньо. */
    static float[] bounds(java.util.Collection<String> only) {
        float[] b = { Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE, -Float.MAX_VALUE };
        boolean any = false;
        for (Face f : faces) {
            if (only != null && !only.contains(f.uuid)) continue;
            any = true;
            for (int v = 0; v < 4; v++)
                for (int k = 0; k < 3; k++) { b[k] = Math.min(b[k], f.p[v * 3 + k]); b[k + 3] = Math.max(b[k + 3], f.p[v * 3 + k]); }
        }
        return any ? b : null;
    }

    /** Навести камеру на межі. */
    static void frame(Cam c, float[] b) {
        if (b == null) { c.tx = 0; c.ty = 0.5f; c.tz = 0; c.dist = 3; return; }
        c.tx = (b[0] + b[3]) / 2; c.ty = (b[1] + b[4]) / 2; c.tz = (b[2] + b[5]) / 2;
        float size = Math.max(b[3] - b[0], Math.max(b[4] - b[1], b[5] - b[2]));
        c.dist = Math.max(0.3f, size * 2.0f + 0.2f);
    }

    // ═════════════ проєкція ═════════════

    static void layout(Cam c, int x, int y, int w, int h) {
        rx = x; ry = y; rw = Math.max(1, w); rh = Math.max(1, h);
        proj = new Matrix4f().perspective((float) Math.toRadians(50), rw / (float) rh, 0.02f, 200f);
        view = new Matrix4f().translate(0, 0, -c.dist).rotateX((float) Math.toRadians(c.pitch)).rotateY((float) Math.toRadians(c.yaw))
            .translate(-c.tx, -c.ty, -c.tz);
        Matrix4f pv = new Matrix4f(proj).mul(view);
        Vector4f t = new Vector4f();
        for (Face f : faces) {
            f.visible = true;
            for (int v = 0; v < 4; v++) {
                pv.transform(t.set(f.p[v * 3], f.p[v * 3 + 1], f.p[v * 3 + 2], 1));
                if (t.w < 0.01f) { f.visible = false; break; }
                f.sx[v] = rx + (t.x / t.w * 0.5 + 0.5) * rw;
                f.sy[v] = ry + (0.5 - t.y / t.w * 0.5) * rh;
                f.w[v] = t.w;
            }
        }
    }

    /** Точка простору моделі → {x, y, w} на екрані; null — позаду камери. */
    static double[] project(float x, float y, float z) {
        Vector4f t = new Matrix4f(proj).mul(view).transform(new Vector4f(x, y, z, 1));
        if (t.w < 0.01f) return null;
        return new double[] { rx + (t.x / t.w * 0.5 + 0.5) * rw, ry + (0.5 - t.y / t.w * 0.5) * rh, t.w };
    }

    /** Напрямок у просторі моделі з точки p → вектор на екрані (пікселі GUI). */
    static double[] screenDir(float px, float py, float pz, float dx, float dy, float dz) {
        double[] a = project(px, py, pz), b = project(px + dx, py + dy, pz + dz);
        if (a == null || b == null) return new double[] { 0, 0 };
        return new double[] { b[0] - a[0], b[1] - a[1] };
    }

    /** Найближча грань під точкою (перспективно-коректні UV і точка на поверхні). */
    static Hit pick(double mx, double my) {
        Hit best = null;
        for (Face f : faces) {
            if (!f.visible) continue;
            Hit h = tri(f, 0, 1, 2, mx, my);
            if (h == null) h = tri(f, 0, 2, 3, mx, my);
            if (h != null && (best == null || h.depth < best.depth)) best = h;
        }
        return best;
    }

    private static Hit tri(Face f, int a, int b, int c, double px, double py) {
        double x1 = f.sx[a], y1 = f.sy[a], x2 = f.sx[b], y2 = f.sy[b], x3 = f.sx[c], y3 = f.sy[c];
        double den = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3);
        if (Math.abs(den) < 1e-9) return null;
        double l1 = ((y2 - y3) * (px - x3) + (x3 - x2) * (py - y3)) / den;
        double l2 = ((y3 - y1) * (px - x3) + (x1 - x3) * (py - y3)) / den;
        double l3 = 1 - l1 - l2;
        if (l1 < -1e-4 || l2 < -1e-4 || l3 < -1e-4) return null;
        // перспективна корекція: інтерполюємо атрибут/w і 1/w
        double q1 = l1 / f.w[a], q2 = l2 / f.w[b], q3 = l3 / f.w[c], s = q1 + q2 + q3;
        q1 /= s; q2 /= s; q3 /= s;
        double u = q1 * f.uv[a * 2] + q2 * f.uv[b * 2] + q3 * f.uv[c * 2];
        double v = q1 * f.uv[a * 2 + 1] + q2 * f.uv[b * 2 + 1] + q3 * f.uv[c * 2 + 1];
        float x = (float) (q1 * f.p[a * 3] + q2 * f.p[b * 3] + q3 * f.p[c * 3]);
        float y = (float) (q1 * f.p[a * 3 + 1] + q2 * f.p[b * 3 + 1] + q3 * f.p[c * 3 + 1]);
        float z = (float) (q1 * f.p[a * 3 + 2] + q2 * f.p[b * 3 + 2] + q3 * f.p[c * 3 + 2]);
        return new Hit(f, u, v, x, y, z, 1 / s);
    }

    // ═════════════ камера ═════════════

    static void orbit(Cam c, double dx, double dy) {
        c.yaw += (float) dx * 0.6f;
        c.pitch = Math.max(-89, Math.min(89, c.pitch + (float) dy * 0.6f));
    }

    static void pan(Cam c, double dx, double dy) {
        float k = c.dist * 0.0022f;
        double yaw = Math.toRadians(c.yaw), pitch = Math.toRadians(c.pitch);
        // праворуч і вгору камери в просторі моделі
        float rxv = (float) Math.cos(yaw), rzv = (float) Math.sin(yaw);
        float ux = (float) (Math.sin(yaw) * Math.sin(pitch)), uy = (float) Math.cos(pitch), uz = (float) (-Math.cos(yaw) * Math.sin(pitch));
        c.tx += (float) (-dx * rxv + dy * ux) * k;
        c.ty += (float) (dy * uy) * k;
        c.tz += (float) (-dx * rzv + dy * uz) * k;
    }

    static void zoom(Cam c, double delta) { c.dist = Math.max(0.15f, Math.min(60f, c.dist * (float) Math.pow(0.88, delta))); }

    // ═════════════ малювання ═════════════

    /** Тло, сітка, модель (текстура tex), без обведень — їх малює сторінка поверх. */
    static void render(GuiGraphics g, ResourceLocation tex) {
        g.fillGradient(rx, ry, rx + rw, ry + rh, 0xFF2A3247, 0xFF161B27);
        g.enableScissor(rx, ry, rx + rw, ry + rh);
        grid(g);
        g.disableScissor();
        g.flush();
        Minecraft mc = Minecraft.getInstance();
        double scale = mc.getWindow().getGuiScale();
        RenderSystem.viewport((int) (rx * scale), mc.getWindow().getHeight() - (int) ((ry + rh) * scale), (int) (rw * scale), (int) (rh * scale));
        Matrix4f oldProj = RenderSystem.getProjectionMatrix();
        VertexSorting oldSort = RenderSystem.getVertexSorting();
        RenderSystem.setProjectionMatrix(new Matrix4f(proj), VertexSorting.DISTANCE_TO_ORIGIN);
        RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
        var mv = RenderSystem.getModelViewStack();
        mv.pushPose();
        mv.setIdentity();
        RenderSystem.applyModelViewMatrix();
        PoseStack ps = new PoseStack();
        ps.last().pose().set(view);
        ps.last().normal().set(new Matrix3f(view));
        Lighting.setupLevel(new Matrix4f(view).setTranslation(0, 0, 0));
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        ResourceLocation t = tex != null ? tex : new ResourceLocation("minecraft", "textures/misc/white.png");
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(t));
        Matrix4f m4 = ps.last().pose();
        Matrix3f m3 = ps.last().normal();
        for (Face f : faces) {
            for (int v = 0; v < 4; v++) {
                vc.vertex(m4, f.p[v * 3], f.p[v * 3 + 1], f.p[v * 3 + 2]).color(1f, 1f, 1f, 1f).uv(f.uv[v * 2], f.uv[v * 2 + 1])
                    .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(LightTexture.FULL_BRIGHT).normal(m3, f.nx, f.ny, f.nz).endVertex();
            }
        }
        buffers.endBatch();
        mv.popPose();
        RenderSystem.applyModelViewMatrix();
        RenderSystem.setProjectionMatrix(oldProj, oldSort);
        RenderSystem.viewport(0, 0, mc.getWindow().getWidth(), mc.getWindow().getHeight());
        RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
        Lighting.setupFor3DItems();
        axes(g);
    }

    /** Сітка-підлога: клітинка = піксель Blockbench, жирніше — кожні 8 і межі блока. */
    private static void grid(GuiGraphics g) {
        for (int i = -16; i <= 16; i++) {
            float k = i / 16f;
            int col = i == 0 ? 0 : (i % 8 == 0 ? 0x50FFFFFF : 0x1EFFFFFF);
            if (col != 0) {
                seg(g, k, 0, -1, k, 0, 1, col);
                seg(g, -1, 0, k, 1, 0, k, col);
            }
        }
        seg(g, -1, 0, 0, 1, 0, 0, 0xB0E5534B);   // X
        seg(g, 0, 0, -1, 0, 0, 1, 0xB04A7BE5);   // Z
    }

    private static void seg(GuiGraphics g, float x1, float y1, float z1, float x2, float y2, float z2, int col) {
        double[] a = project(x1, y1, z1), b = project(x2, y2, z2);
        if (a != null && b != null) Draw2D.line(g, a[0], a[1], b[0], b[1], 1f, col);
    }

    /** Значок осей у куті: X (червоний, напрям X Blockbench), Y (зелений), Z (синій). */
    private static void axes(GuiGraphics g) {
        Matrix3f r = new Matrix3f(view);
        int cx = rx + 22, cy = ry + rh - 22;
        float[][] dirs = { { -1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } };
        int[] cols = { 0xFFE5534B, 0xFF6BCB5B, 0xFF4A7BE5 };
        String[] names = { "X", "Y", "Z" };
        for (int i = 0; i < 3; i++) {
            org.joml.Vector3f d = r.transform(new org.joml.Vector3f(dirs[i][0], dirs[i][1], dirs[i][2]));
            double ex = cx + d.x * 14, ey = cy - d.y * 14;
            Draw2D.line(g, cx, cy, ex, ey, 1.5f, cols[i]);
            g.drawString(Minecraft.getInstance().font, names[i], (int) ex - 2, (int) ey - 4, cols[i], true);
        }
    }

    /** Обвести грані вузлів (кубиків) кольором. */
    static void outline(GuiGraphics g, java.util.Collection<String> uuids, int col, float width) {
        g.enableScissor(rx, ry, rx + rw, ry + rh);
        for (Face f : faces) {
            if (!f.visible || f.uuid == null || !uuids.contains(f.uuid)) continue;
            for (int v = 0; v < 4; v++) {
                int n = (v + 1) % 4;
                Draw2D.line(g, f.sx[v], f.sy[v], f.sx[n], f.sy[n], width, col);
            }
        }
        g.disableScissor();
    }

    /** Підсвітити одну грань (наведення в режимі «Розмір» / малювання). */
    static void fillFace(GuiGraphics g, Face f, int col) {
        if (f == null || !f.visible) return;
        g.enableScissor(rx, ry, rx + rw, ry + rh);
        Draw2D.quad(g, f.sx[0], f.sy[0], f.sx[1], f.sy[1], f.sx[2], f.sy[2], f.sx[3], f.sy[3], col);
        g.disableScissor();
    }
}
