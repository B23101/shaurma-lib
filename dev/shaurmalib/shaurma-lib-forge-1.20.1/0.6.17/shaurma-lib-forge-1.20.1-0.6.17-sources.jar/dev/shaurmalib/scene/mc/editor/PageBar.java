package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.Icons;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.network.chat.Component;

/**
 * Сторінки редактора внизу — як у DaVinci Resolve (Edit · Fusion · Fairlight…): одна сцена, різні робочі простори.
 * <ul>
 *   <li><b>Монтаж</b> — бібліотека + кліпи на доріжках;</li>
 *   <li><b>Ключі</b> — Dope Sheet на всю висоту;</li>
 *   <li><b>Криві</b> — Graph Editor на всю висоту;</li>
 *   <li><b>Аудіо</b> — лише звукові доріжки (великі, з хвилею й гучністю), решта — сірі смужки; бібліотека на «Аудіо».</li>
 *   <li><b>Модель</b> — кубики й кістки моделі вибраного актора/пропа ({@link ModelPage}, як «Редагувати» Shaurma Modeling);</li>
 *   <li><b>Малювання</b> — текстура цієї моделі: пензель, гумка, заливка, піпетка, фігури ({@link PaintPage}).</li>
 * </ul>
 */
final class PageBar {

    private PageBar() {}

    record Page(String title, Icon icon, String tip) {}

    static final Page[] PAGES = {
        new Page("Монтаж", Icon.LAYOUT_RESET, "Бібліотека й доріжки: тягни звук, текст, ефекти, переходи"),
        new Page("Ключі", Icon.KEYFRAME, "Dope Sheet: ключі вибраного об'єкта по каналах"),
        new Page("Криві", Icon.GRADIENT, "Graph Editor: криві й ручки Безьє"),
        new Page("Аудіо", Icon.VOLUME, "Лише звук: великі доріжки з хвилею, гучністю й fade, решта приглушена"),
        new Page("Модель", Icon.EDIT_MODE, "Кубики й кістки моделі вибраного актора/пропа: рух, розмір, поворот, півот"),
        new Page("Малювання", Icon.PAINT_MODE, "Текстура моделі вибраного актора/пропа: пензель, гумка, заливка, піпетка, фігури"),
    };

    static final int MODEL = 4, PAINT = 5;

    static int current(SceneEditorScreen s) { return s.modelPage >= 0 ? s.modelPage : TimelinePanel.audioFocus ? 3 : s.timelineMode; }

    /** Сторінка моделі/малювання: в'юпорт і таймлайн замінює робочий простір моделі. */
    static boolean modelPage(SceneEditorScreen s) { return s.modelPage >= 0; }

    static void open(SceneEditorScreen s, int page) {
        if (page == current(s)) return;
        if (s.modelPage >= 0) { ModelPage.cancelDrag(s); PaintPage.cancelStroke(); ModelSession.clearLive(); }
        if (page >= MODEL) { s.modelPage = page; return; }
        s.modelPage = -1;
        TimelinePanel.audioFocus = page == 3;
        s.timelineMode = page == 3 ? 0 : page;
        if (page == 3) MediaLibrary.tab = MediaLibrary.Tab.AUDIO;
        s.resetTimelineHeight();
    }

    static void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        gui.g.fill(x, y, x + w, y + h, 0xFF0D121F);
        gui.g.fill(x, y, x + w, y + 1, MenuSkin.OUTLINE);
        int cur = current(s);
        int bw = Math.min(84, (w - 40) / PAGES.length);
        int bx = x + (w - bw * PAGES.length) / 2;
        for (int i = 0; i < PAGES.length; i++) {
            Page p = PAGES[i];
            int px = bx + i * bw;
            boolean on = i == cur, hov = gui.hover(px, y, bw, h);
            if (on) {
                gui.g.fill(px, y + 1, px + bw, y + h, 0xFF1C2742);
                gui.g.fill(px + 6, y + h - 2, px + bw - 6, y + h, 0xFFE5646A);
            } else if (hov) gui.g.fill(px, y + 1, px + bw, y + h, 0x14FFFFFF);
            int c = on ? Theme.TEXT : hov ? 0xFFD0D8EA : Theme.MUTED;
            int tw = gui.font.width(p.title()) + 14;
            int ix = px + (bw - tw) / 2;
            Icons.draw(gui.g, p.icon(), ix, y + (h - 10) / 2 - 1, 10, on ? 0xFFE5646A : c);
            gui.text(p.title(), ix + 14, y + (h - 8) / 2, c);
            if (hov) gui.tip(Component.literal(p.title() + ": " + p.tip()));
            if (gui.clicked(px, y, bw, h, 0)) open(s, i);
        }
    }
}
