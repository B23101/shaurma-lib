package dev.shaurmalib.scene.mc.editor;

import com.mojang.math.Axis;
import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.doc.Track;
import dev.shaurmalib.scene.doc.Transition;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.mc.client.GameSounds;
import dev.shaurmalib.scene.mc.client.SceneAssets;
import dev.shaurmalib.scene.mc.client.SceneHud;
import dev.shaurmalib.scene.mc.client.SceneOverlays;
import dev.shaurmalib.scene.mc.client.ScenePost;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.Icons;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.IntUnaryOperator;

/**
 * Бібліотека як у CapCut: угорі вкладки (Медіа · Аудіо · Текст · Оверлеї · Ефекти · Переходи · Фільтри · Корекція),
 * ліворуч — категорії вкладки, праворуч — плитки з живими мініатюрами (ефект/фільтр/перехід малюється на зразковому
 * кадрі тим самим кодом, що й у грі). Будь-яку плитку <b>тягнуть на таймлайн</b> — кліп з'являється там, де відпустили,
 * на доріжці під курсором (або на новій). «+» на плитці — у playhead. Переходи кидають на стик кліпів камери.
 */
final class MediaLibrary {

    private MediaLibrary() {}

    enum Tab {
        MEDIA("Медіа", Icon.FOLDER), AUDIO("Аудіо", Icon.VOLUME), TEXT("Текст", Icon.TAG), OVERLAY("Оверлеї", Icon.STAMP),
        EFFECTS("Ефекти", Icon.WAND), TRANSITIONS("Переходи", Icon.SWAP), FILTERS("Фільтри", Icon.PALETTE), ADJUST("Корекція", Icon.SETTINGS);

        final String title;
        final Icon icon;

        Tab(String title, Icon icon) { this.title = title; this.icon = icon; }
    }

    /** Те, що можна покласти на таймлайн. */
    static final class Item {
        String key, title, sub;
        /** Тип треку кліпу; null — не кліп (перехід, модель, текстура). */
        Track.Type type;
        String ref;
        double len = 3;
        final Map<String, Object> params = new LinkedHashMap<>();
        Transition.Type trans;
        SceneDoc.Asset asset;
        String actor;
        int color = Theme.ACCENT;
        Thumb thumb;

        Item(String key, String title) { this.key = key; this.title = title; }
    }

    @FunctionalInterface
    interface Thumb { void draw(GuiGraphics g, int w, int h, double t); }

    static Tab tab = Tab.MEDIA;
    private static final Map<Tab, String> CAT = new EnumMap<>(Tab.class);
    private static String search = "";
    private static Item pressed, dragging;
    private static double pressX, pressY;
    private static boolean droppedThisFrame;

    static Item dragging() { return dragging; }

    /** Таймлайн прийняв кидок — бібліотека більше нічого не робить. */
    static void consumed() { dragging = null; pressed = null; droppedThisFrame = true; }

    // ═════════════════════ рендер ═════════════════════

    static void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        int tabsH = tabs(gui, x, y, w);
        int cy = y + tabsH;
        int ch = h - tabsH;
        List<String> cats = categories(s, tab);
        String cat = CAT.get(tab);
        if (cat == null || !cats.contains(cat)) { cat = cats.isEmpty() ? "" : cats.get(0); CAT.put(tab, cat); }

        boolean column = w >= 170;
        int listX = x, listW = w, listY = cy;
        if (column) {
            int cw = Math.max(52, Math.min(86, w * 28 / 100));
            gui.g.fill(x, cy, x + cw, cy + ch, 0xFF10172A);
            int off = gui.scrollBegin("lib.cats." + tab, x, cy, cw, ch, cats.size() * 17 + 6);
            int ry = cy + 3 - off;
            for (String c : cats) {
                boolean on = c.equals(cat), hov = gui.hover(x, ry, cw, 16);
                if (on || hov) gui.g.fill(x + 2, ry, x + cw - 2, ry + 16, on ? 0xFF22304F : MenuSkin.ROW_HOT);
                gui.textClip(catTitle(c), x + 6, ry + 4, cw - 10, on ? 0xFF5FD3E6 : Theme.TEXT);
                if (gui.clicked(x, ry, cw, 16, 0)) CAT.put(tab, c);
                ry += 17;
            }
            gui.scrollEnd();
            gui.g.fill(x + cw, cy, x + cw + 1, cy + ch, MenuSkin.OUTLINE);
            listX = x + cw + 1;
            listW = w - cw - 1;
        } else {
            // вузько — категорії чіпами, що переносяться
            int cx = x + 3, ry = cy + 3;
            for (String c : cats) {
                String t = catTitle(c);
                int bw = gui.font.width(t) + 8;
                if (cx + bw > x + w - 3) { cx = x + 3; ry += 15; }
                boolean on = c.equals(cat);
                if (gui.button(cx, ry, bw, 13, Component.literal(t), on, null)) CAT.put(tab, c);
                cx += bw + 2;
            }
            listY = ry + 16;
        }
        int lh = cy + ch - listY;
        // пошук
        boolean searchable = tab == Tab.AUDIO || tab == Tab.EFFECTS || tab == Tab.MEDIA || tab == Tab.TEXT || tab == Tab.FILTERS;
        if (searchable) {
            String q = gui.textField("lib.search", listX + 4, listY + 3, listW - 8, 13, search, Component.literal("пошук…"));
            if (q != null) search = q;
            listY += 19;
            lh -= 19;
        }
        String filter = GameSounds.search(gui.liveText("lib.search", search));
        if (tab == Tab.MEDIA && "import".equals(cat)) {
            if (gui.button(listX + 4, listY + 2, listW - 8, 16, Component.literal("+ Імпорт файлу…"), false,
                Component.literal(".bbmodel / .geo.json — модель, .png — текстура, .wav / .ogg / .mp3 — звук. Можна просто кинути файл у вікно"), !s.readOnly)) {
                LeftPanel.importDialog(s);
            }
            listY += 21;
            lh -= 21;
        }
        List<Item> items = items(s, tab, cat, filter);
        if (tab == Tab.AUDIO) audioList(s, gui, listX, listY, listW, lh, items);
        else grid(s, gui, listX, listY, listW, lh, items);
        input(s, gui);
    }

    private static String catTitle(String c) {
        if (c.startsWith("snd:")) return c.equals("snd:yours") ? "Ваші" : GameSounds.categoryTitle(c.substring(4));
        return switch (c) {
            case "import" -> "Імпорт";
            case "models" -> "Моделі";
            case "anims" -> "Анімації";
            case "textures" -> "Текстури";
            case "tr:basic" -> "Базові";
            case "tr:wipes" -> "Шторки";
            case "tr:motion" -> "Рух";
            case "tr:light" -> "Світло й глітч";
            case "adjust:presets" -> "Пресети";
            default -> SceneOverlays.categoryTitle(c);
        };
    }

    /** Вкладки: значок + підпис, переносяться в рядки, якщо панель вузька. */
    private static int tabs(Gui gui, int x, int y, int w) {
        Tab[] all = Tab.values();
        int cols = Math.max(1, Math.min(all.length, w / 34));
        int rows = (all.length + cols - 1) / cols;
        int tw = w / cols, th = 26;
        gui.g.fill(x, y, x + w, y + rows * th, Theme.HEADER);
        for (int i = 0; i < all.length; i++) {
            Tab t = all[i];
            int tx = x + (i % cols) * tw, ty = y + (i / cols) * th;
            boolean on = t == tab, hov = gui.hover(tx, ty, tw, th);
            if (hov && !on) gui.g.fill(tx, ty, tx + tw, ty + th, 0x18FFFFFF);
            int c = on ? 0xFF5FD3E6 : hov ? Theme.TEXT : Theme.MUTED;
            if (on) gui.g.fill(tx + 3, ty + th - 2, tx + tw - 3, ty + th, 0xFF5FD3E6);
            Icons.draw(gui.g, t.icon, tx + (tw - 12) / 2, ty + 2, 12, c);
            gui.g.pose().pushPose();
            gui.g.pose().translate(tx + tw / 2f, ty + 16, 0);
            float sc = Math.min(0.75f, (tw - 2) / (float) Math.max(1, gui.font.width(t.title)));
            gui.g.pose().scale(sc, sc, 1);
            gui.g.drawString(gui.font, t.title, -gui.font.width(t.title) / 2, 0, c, false);
            gui.g.pose().popPose();
            if (hov) gui.tip(Component.literal(t.title));
            if (gui.clicked(tx, ty, tw, th, 0)) { tab = t; GameSounds.stopPreview(); }
        }
        gui.g.fill(x, y + rows * th - 1, x + w, y + rows * th, MenuSkin.OUTLINE);
        return rows * th;
    }

    // ═════════════════════ сітка плиток ═════════════════════

    private static final int VW = 320, VH = 180;

    private static void grid(SceneEditorScreen s, Gui gui, int x, int y, int w, int h, List<Item> items) {
        int gap = 4, inner = w - 8 - MenuSkin.SCROLL_W;
        int cols = Math.max(1, inner / 58);
        int tw = (inner - gap * (cols - 1)) / cols, ph = tw * 9 / 16, th = ph + 12;
        int rows = (items.size() + cols - 1) / cols;
        int off = gui.scrollBegin("lib.grid." + tab + CAT.get(tab), x, y, w, h, rows * (th + gap) + 8);
        if (items.isEmpty()) gui.textClip(emptyHint(), x + 6, y + 6, w - 12, Theme.MUTED);
        double t = System.nanoTime() / 1e9;
        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            int tx = x + 4 + (i % cols) * (tw + gap), ty = y + 4 + (i / cols) * (th + gap) - off;
            if (ty + th < y || ty > y + h) continue;
            boolean hov = gui.hover(tx, ty, tw, th) && gui.my >= y && gui.my < y + h;
            gui.g.fill(tx, ty, tx + tw, ty + ph, 0xFF0B0F1A);
            gui.g.enableScissor(Math.max(tx, x), Math.max(ty, y), Math.min(tx + tw, x + w), Math.min(ty + ph, y + h));
            try {
                gui.g.pose().pushPose();
                gui.g.pose().translate(tx, ty, 0);
                gui.g.pose().scale(tw / (float) VW, ph / (float) VH, 1);
                if (it.thumb != null) it.thumb.draw(gui.g, VW, VH, hov ? t : 0.6);
                gui.g.pose().popPose();
            } catch (RuntimeException ignored) {
                gui.g.pose().popPose();
            } finally {
                gui.g.disableScissor();
            }
            gui.g.renderOutline(tx, ty, tw, ph, hov ? 0xFF5FD3E6 : 0xFF263554);
            gui.textClip(it.title, tx + 1, ty + ph + 2, tw - 2, hov ? Theme.TEXT : 0xFFB8C3DA);
            if (hov) {
                gui.tip(Component.literal(it.title + (it.sub != null ? "\n" + it.sub : "") + "\nТягни на таймлайн · «+» — у playhead"));
                if (!s.readOnly && gui.icon(tx + tw - 13, ty + 1, 12, Icon.PLUS, false, Component.literal("Додати в playhead"))) { addAtPlayhead(s, it); continue; }
                if (gui.press("lib.item." + it.key, tx, ty, tw, th, 0)) { pressed = it; pressX = gui.mx; pressY = gui.my; }
                if (gui.doubleClicked(tx, ty, tw, th) && !s.readOnly) { addAtPlayhead(s, it); gui.consumeClick(); }
            }
        }
        gui.scrollEnd();
    }

    private static String emptyHint() {
        return switch (tab) {
            case MEDIA -> "Порожньо. Імпортуйте файл або киньте його у вікно";
            default -> "Нічого не знайдено";
        };
    }

    // ═════════════════════ аудіо — список як у CapCut ═════════════════════

    private static void audioList(SceneEditorScreen s, Gui gui, int x, int y, int w, int h, List<Item> items) {
        int row = 30;
        int off = gui.scrollBegin("lib.audio." + CAT.get(tab), x, y, w, h, items.size() * (row + 3) + 6);
        int first = Math.max(0, off / (row + 3)), last = Math.min(items.size(), (off + h) / (row + 3) + 1);
        if (items.isEmpty()) gui.textClip(CAT.get(tab).equals("snd:yours") ? "Імпортуйте .mp3 / .ogg / .wav або киньте файл у вікно" : "Нічого не знайдено", x + 6, y + 6, w - 12, Theme.MUTED);
        for (int i = first; i < last; i++) {
            Item it = items.get(i);
            int ry = y + 3 + i * (row + 3) - off, rx = x + 4, rw = w - 8 - MenuSkin.SCROLL_W;
            boolean hov = gui.hover(rx, ry, rw, row) && gui.my >= y && gui.my < y + h;
            gui.g.fill(rx, ry, rx + rw, ry + row, hov ? 0xFF243150 : 0xFF1A2236);
            String id = it.asset != null ? null : GameSounds.id(it.ref);
            boolean playing = id != null && GameSounds.previewing(id);
            // обкладинка = кнопка прослуховування
            gui.g.fill(rx + 3, ry + 3, rx + 27, ry + 27, playing ? 0xFF2C66B8 : 0xFF2A3554);
            if (playing) {
                double tt = System.nanoTime() / 1e9;
                for (int b = 0; b < 5; b++) {
                    int bh = 3 + (int) (14 * Math.abs(Math.sin(tt * (4 + b) + b)));
                    gui.g.fill(rx + 6 + b * 4, ry + 24 - bh, rx + 9 + b * 4, ry + 24, 0xFFFFFFFF);
                }
            } else Icons.draw(gui.g, it.asset != null ? Icon.VOLUME : Icon.PLAY, rx + 9, ry + 9, 12, Theme.TEXT);
            if (id != null && gui.clicked(rx + 3, ry + 3, 24, 24, 0)) {
                if (playing) GameSounds.stopPreview(); else GameSounds.play(id, 1f, 1f);
                continue;
            }
            gui.textClip(it.title, rx + 32, ry + 5, rw - 56, Theme.TEXT);
            String sub = it.sub;
            if (id != null) {
                double d = GameSounds.duration(id, 0);
                sub = (sub == null ? "" : sub + " · ") + (d < 0 ? "…" : String.format(Locale.ROOT, "%d:%02d", (int) d / 60, (int) d % 60));
            }
            if (sub != null) gui.textClip(sub, rx + 32, ry + 17, rw - 56, Theme.MUTED);
            if (!s.readOnly && gui.icon(rx + rw - 18, ry + 9, 12, Icon.PLUS, false, Component.literal("На таймлайн у playhead"))) { addAtPlayhead(s, it); continue; }
            if (hov) {
                gui.tip(Component.literal("Тягни на таймлайн — кліп буде там, де відпустиш\nКлік по обкладинці — прослухати"));
                if (gui.press("lib.item." + it.key, rx + 28, ry, rw - 48, row, 0)) { pressed = it; pressX = gui.mx; pressY = gui.my; }
                if (gui.doubleClicked(rx + 28, ry, rw - 48, row) && !s.readOnly) { addAtPlayhead(s, it); gui.consumeClick(); }
            }
        }
        gui.scrollEnd();
    }

    // ═════════════════════ перетягування ═════════════════════

    private static void input(SceneEditorScreen s, Gui gui) {
        if (pressed != null && dragging == null && gui.isDown(0) && Math.hypot(gui.mx - pressX, gui.my - pressY) > 4 && !s.readOnly) dragging = pressed;
        if (!gui.isDown(0) && dragging == null) pressed = null;
    }

    /** Після таймлайну: чіп біля курсора; відпустили не над таймлайном — модель у в'юпорт або скасування. */
    static void afterFrame(SceneEditorScreen s, Gui gui) {
        droppedThisFrame = false;
        if (dragging == null) return;
        Item it = dragging;
        gui.g.pose().pushPose();
        gui.g.pose().translate(0, 0, 400);
        int tw = gui.font.width(it.title) + 22;
        gui.g.fill(gui.mx + 8, gui.my + 6, gui.mx + 8 + tw, gui.my + 22, 0xE0151D30);
        gui.g.renderOutline(gui.mx + 8, gui.my + 6, tw, 16, it.color);
        Icons.draw(gui.g, iconOf(it), gui.mx + 11, gui.my + 8, 12, it.color);
        gui.text(it.title, gui.mx + 26, gui.my + 10, Theme.TEXT);
        gui.g.pose().popPose();
        gui.cursor(Gui.CUR_HAND);
        if (gui.isDown(0)) return;
        // відпустили поза таймлайном
        if (s.inViewport(gui.mx, gui.my)) {
            if (it.asset != null && it.asset.type == SceneDoc.Asset.Type.MODEL) s.addActor(SceneObject.ModelType.ASSET, it.asset.id);
            else if (it.key.startsWith("resmodel:")) s.addActor(SceneObject.ModelType.RESOURCE, it.ref);
            else if (it.asset != null && it.asset.type == SceneDoc.Asset.Type.TEXTURE) applyTexture(s, it.asset);
            else if (it.type != null) s.toast("Кинь на таймлайн знизу — туди, де має з'явитися кліп");
        }
        dragging = null;
        pressed = null;
    }

    static Icon iconOf(Item it) {
        if (it.trans != null) return Icon.SWAP;
        if (it.type == null) return it.asset != null && it.asset.type == SceneDoc.Asset.Type.TEXTURE ? Icon.TEXTURE : Icon.CUBE;
        return SceneEditorScreen.trackIcon(it.type);
    }

    static void addAtPlayhead(SceneEditorScreen s, Item it) {
        if (it.trans != null) {
            if (s.selClip != null && s.selTrack != null && s.selTrack.type == Track.Type.CAMERA) {
                var c = s.selClip;
                s.edit("Перехід", () -> c.transition = Transition.of(it.trans));
            } else s.toast("Виберіть кліп камери (або тягніть перехід на стик кліпів)");
            return;
        }
        if (it.type == null) {
            if (it.asset != null && it.asset.type == SceneDoc.Asset.Type.MODEL) s.addActor(SceneObject.ModelType.ASSET, it.asset.id);
            else if (it.key.startsWith("resmodel:")) s.addActor(SceneObject.ModelType.RESOURCE, it.ref);
            else if (it.asset != null && it.asset.type == SceneDoc.Asset.Type.TEXTURE) applyTexture(s, it.asset);
            return;
        }
        Track target = null;
        for (Track x : s.variant().tracks(it.type)) if (!x.locked && (it.type != Track.Type.ANIMATION || x.target != null && x.target.equals(it.actor))) target = x;
        s.dropItem(it, target, s.time);
    }

    private static void applyTexture(SceneEditorScreen s, SceneDoc.Asset a) {
        SceneObject o = s.selected();
        if (o == null) { s.toast("Виберіть актора"); return; }
        s.edit("Текстура", () -> {
            if (o.modelType == SceneObject.ModelType.PLAYER) { o.skinMode = SceneObject.SkinMode.TEXTURE; o.skinValue = a.id; }
            else o.texture = a.id;
        });
    }

    // ═════════════════════ вміст вкладок ═════════════════════

    static List<String> categories(SceneEditorScreen s, Tab t) {
        List<String> out = new ArrayList<>();
        switch (t) {
            case MEDIA -> { out.add("import"); out.add("models"); out.add("anims"); out.add("textures"); }
            case AUDIO -> {
                out.add("snd:yours");
                List<String> seen = new ArrayList<>();
                for (String c : new String[] { "music", "mobs", "player", "blocks", "items", "ambient", "ui", "other" }) seen.add(c);
                for (String id : GameSounds.all()) { String c = GameSounds.category(id); if (!seen.contains(c)) seen.add(c); }
                for (String c : seen) out.add("snd:" + c);
            }
            case TEXT -> { for (var e : SceneOverlays.overlays()) if (e.category().startsWith("text:") && !out.contains(e.category())) out.add(e.category()); }
            case OVERLAY -> { for (var e : SceneOverlays.overlays()) if (!e.category().startsWith("text:") && !out.contains(e.category())) out.add(e.category()); }
            case EFFECTS -> {
                for (var e : SceneOverlays.effects()) if (e.category().startsWith("fx:") && !out.contains(e.category())) out.add(e.category());
                int i = out.indexOf("fx:mod");
                out.add(i < 0 ? out.size() : i, "fx:time");
            }
            case TRANSITIONS -> { out.add("tr:basic"); out.add("tr:wipes"); out.add("tr:motion"); out.add("tr:light"); }
            case FILTERS -> { for (var e : SceneOverlays.effects()) if (e.category().startsWith("filter:") && !out.contains(e.category())) out.add(e.category()); }
            case ADJUST -> { out.add("adjust"); out.add("adjust:presets"); }
        }
        return out;
    }

    private static boolean match(String filter, String... texts) {
        if (filter.isEmpty()) return true;
        for (String t : texts) if (t != null && t.toLowerCase(Locale.ROOT).contains(filter)) return true;
        return false;
    }

    static List<Item> items(SceneEditorScreen s, Tab t, String cat, String filter) {
        List<Item> out = new ArrayList<>();
        switch (t) {
            case MEDIA -> media(s, cat, filter, out);
            case AUDIO -> {
                if ("snd:yours".equals(cat)) {
                    for (SceneDoc.Asset a : s.doc.assets.values()) {
                        if (a.type != SceneDoc.Asset.Type.AUDIO || !match(filter, a.name)) continue;
                        out.add(audioAsset(a));
                    }
                } else {
                    String c = cat.substring(4);
                    int n = 0;
                    for (String id : GameSounds.all()) {
                        boolean inCat = GameSounds.category(id).equals(c);
                        if (filter.isEmpty() ? !inCat : !id.contains(filter)) continue;   // з пошуком — по всіх звуках гри
                        Item it = new Item("snd:" + id, GameSounds.pretty(id));
                        it.sub = id;
                        it.type = Track.Type.AUDIO;
                        it.ref = GameSounds.PREFIX + id;
                        it.color = SceneEditorScreen.clipColor(Track.Type.AUDIO);
                        out.add(it);
                        if (++n > 1500) break;
                    }
                }
            }
            case TEXT, OVERLAY -> {
                for (var e : SceneOverlays.overlays()) {
                    if (!e.category().equals(cat) || !match(filter, e.title(), e.id())) continue;
                    Item it = new Item("ov:" + e.id(), e.title());
                    it.type = Track.Type.OVERLAY;
                    it.ref = e.id();
                    it.color = SceneEditorScreen.clipColor(Track.Type.OVERLAY);
                    textDefaults(it);
                    var r = e.renderer();
                    it.thumb = (g, w, h, tt) -> {
                        sample(g, w, h, null, tt);
                        SceneFrame.Overlay o = new SceneFrame.Overlay();
                        o.id = e.id(); o.length = 3; o.local = tt % 3; o.x = 0.5; o.y = 0.5; o.scale = 1; o.params = it.params;
                        r.render(g, w, h, o, 1f);
                    };
                    out.add(it);
                }
            }
            case EFFECTS -> {
                if ("fx:time".equals(cat)) {
                    out.add(time("Сповільнення", 0.3, 0.4));
                    out.add(time("Дуже повільно", 0.1, 0.5));
                    out.add(time("Прискорення ×2", 2.0, 0.3));
                    out.add(time("Стоп-кадр", 0.01, 0.15));
                    break;
                }
                effects(cat, filter, out);
            }
            case FILTERS -> effects(cat, filter, out);
            case TRANSITIONS -> {
                Transition.Type[] list = switch (cat) {
                    case "tr:basic" -> new Transition.Type[] { Transition.Type.BLEND, Transition.Type.CROSSFADE, Transition.Type.FADE_BLACK, Transition.Type.DIP_COLOR, Transition.Type.FLASH, Transition.Type.BLUR_DIP };
                    case "tr:wipes" -> new Transition.Type[] { Transition.Type.WIPE, Transition.Type.WIPE_UP, Transition.Type.WIPE_DIAGONAL, Transition.Type.IRIS, Transition.Type.BLINDS, Transition.Type.SPLIT_DOOR, Transition.Type.SHUTTER, Transition.Type.PIXEL_BLOCKS, Transition.Type.INK };
                    case "tr:motion" -> new Transition.Type[] { Transition.Type.ZOOM_PUNCH, Transition.Type.ZOOM_OUT, Transition.Type.WHIP_PAN, Transition.Type.SPIN, Transition.Type.SHAKE, Transition.Type.PUSH_LEFT, Transition.Type.PUSH_UP };
                    default -> new Transition.Type[] { Transition.Type.GLITCH, Transition.Type.RGB_SPLIT, Transition.Type.FILM_BURN, Transition.Type.LIGHT_LEAK };
                };
                for (Transition.Type tt : list) {
                    Item it = new Item("tr:" + tt, transitionTitle(tt));
                    it.trans = tt;
                    it.sub = String.format(Locale.ROOT, "%.2f с · кинь на стик кліпів камери", tt.defaultMs / 1000.0);
                    it.color = 0xFFFFFFFF;
                    it.thumb = (g, w, h, time) -> transitionThumb(g, w, h, tt, time);
                    out.add(it);
                }
            }
            case ADJUST -> {
                if ("adjust".equals(cat)) {
                    Item it = effectItem("shaurma_lib:adjust", "Власна корекція", "fx");
                    it.sub = "яскравість, контраст, насиченість, температура — у властивостях кліпу";
                    out.add(it);
                } else {
                    out.add(adjustPreset("Яскравіше", "brightness", 0.12, "exposure", 0.2));
                    out.add(adjustPreset("Темніше", "brightness", -0.12, "exposure", -0.3));
                    out.add(adjustPreset("Контрастно", "contrast", 1.35, "saturation", 1.1));
                    out.add(adjustPreset("М'яко", "contrast", 0.8, "brightness", 0.04));
                    out.add(adjustPreset("Тепліше", "temperature", 0.8, "saturation", 1.05));
                    out.add(adjustPreset("Холодніше", "temperature", -0.8, "saturation", 0.95));
                    out.add(adjustPreset("Насичено", "saturation", 1.6, "contrast", 1.05));
                    out.add(adjustPreset("Приглушено", "saturation", 0.55, "contrast", 0.95));
                }
            }
        }
        return out;
    }

    private static void media(SceneEditorScreen s, String cat, String filter, List<Item> out) {
        switch (cat) {
            case "import" -> { for (SceneDoc.Asset a : s.doc.assets.values()) if (match(filter, a.name)) out.add(assetItem(a)); }
            case "models" -> {
                for (SceneDoc.Asset a : s.doc.assets.values()) if (a.type == SceneDoc.Asset.Type.MODEL && match(filter, a.name)) out.add(assetItem(a));
                if (s.def != null) for (String id : s.def.resourceModels) {
                    if (!match(filter, id)) continue;
                    Item it = new Item("resmodel:" + id, id.replaceFirst("^[^:]+:", ""));
                    it.ref = id;
                    it.sub = id + " · тягни у в'юпорт — новий актор";
                    it.thumb = iconThumb(Icon.CUBE, 0xFF59D185);
                    out.add(it);
                }
            }
            case "textures" -> { for (SceneDoc.Asset a : s.doc.assets.values()) if (a.type == SceneDoc.Asset.Type.TEXTURE && match(filter, a.name)) out.add(assetItem(a)); }
            case "anims" -> {
                SceneObject sel = s.selected();
                if (sel == null || sel.kind == SceneObject.Kind.CAMERA || sel.kind == SceneObject.Kind.EMPTY) return;
                for (String id : LeftPanel.animationsFor(s, sel)) {
                    if (!match(filter, id)) continue;
                    AnimationClip c = s.clips.clip(id);
                    Item it = new Item("anim:" + id, id.replaceFirst("^[^:]+:", "").replaceFirst("^asset:[^/]+/", ""));
                    it.sub = sel.name + (c != null ? String.format(Locale.ROOT, " · %.1fс", c.length()) : "");
                    it.type = Track.Type.ANIMATION;
                    it.ref = id;
                    it.actor = sel.id;
                    it.len = c != null && c.length() > 0 ? c.length() : 2;
                    it.color = SceneEditorScreen.clipColor(Track.Type.ANIMATION);
                    it.thumb = iconThumb(Icon.ANIMATE, it.color);
                    out.add(it);
                }
            }
            default -> { }
        }
    }

    private static Item assetItem(SceneDoc.Asset a) {
        if (a.type == SceneDoc.Asset.Type.AUDIO) return audioAsset(a);
        Item it = new Item("asset:" + a.id, a.name);
        it.asset = a;
        it.sub = a.type == SceneDoc.Asset.Type.MODEL ? "модель · тягни у в'юпорт — новий актор" : a.type == SceneDoc.Asset.Type.TEXTURE ? a.width + "×" + a.height + " · на вибраного актора" : null;
        it.thumb = iconThumb(a.type == SceneDoc.Asset.Type.MODEL ? Icon.CUBE : a.type == SceneDoc.Asset.Type.TEXTURE ? Icon.TEXTURE : Icon.FOLDER,
            SceneAssets.has(a) ? 0xFF9DB1D6 : Theme.DANGER);
        return it;
    }

    private static Item audioAsset(SceneDoc.Asset a) {
        Item it = new Item("asset:" + a.id, a.name);
        it.asset = a;
        it.type = Track.Type.AUDIO;
        it.ref = a.id;
        it.len = Math.max(0.5, a.duration);
        it.sub = String.format(Locale.ROOT, "%s · %d:%02d", a.ext == null ? "аудіо" : a.ext, (int) a.duration / 60, (int) a.duration % 60);
        it.color = SceneEditorScreen.clipColor(Track.Type.AUDIO);
        it.thumb = (g, w, h, t) -> {
            g.fill(0, 0, w, h, 0xFF1A2E4A);
            for (int x = 0; x < w; x += 6) { int bh = (int) (h * 0.35 * Math.abs(Math.sin(x * 0.13) * Math.cos(x * 0.05))); g.fill(x, h / 2 - bh, x + 4, h / 2 + bh, 0xFF4A9EFF); }
        };
        return it;
    }

    private static void effects(String cat, String filter, List<Item> out) {
        for (var e : SceneOverlays.effects()) {
            if (!e.category().equals(cat) || !match(filter, e.title(), e.id())) continue;
            out.add(effectItem(e.id(), e.title(), cat));
        }
    }

    private static Item effectItem(String id, String title, String cat) {
        Item it = new Item("fx:" + id, title);
        it.type = Track.Type.EFFECT;
        it.ref = id;
        it.len = 3;
        it.color = SceneEditorScreen.clipColor(Track.Type.EFFECT);
        it.sub = ScenePost.isShader(id) ? "шейдер кадру — видно в перегляді з камери" : id.startsWith("shaurma_lib:cam_") ? "рух камери сцени" : null;
        it.thumb = (g, w, h, t) -> effectThumb(g, w, h, id, it.params, t);
        return it;
    }

    private static Item adjustPreset(String title, String k1, double v1, String k2, double v2) {
        Item it = effectItem("shaurma_lib:adjust", title, "adjust");
        it.key = "adj:" + title;
        it.params.put(k1, v1);
        it.params.put(k2, v2);
        return it;
    }

    private static Item time(String title, double speed, double ramp) {
        Item it = new Item("time:" + title, title);
        it.type = Track.Type.TIME;
        it.len = 2;
        it.params.put("speed", speed);
        it.params.put("ramp", ramp);
        it.color = SceneEditorScreen.clipColor(Track.Type.TIME);
        it.sub = "×" + speed + " для всієї сцени";
        it.thumb = (g, w, h, t) -> {
            sample(g, w, h, null, t * speed);
            String l = speed < 0.05 ? "❚❚" : speed < 1 ? "×" + speed : "×" + (int) speed;
            g.pose().pushPose();
            g.pose().translate(w / 2f, h / 2f, 0);
            g.pose().scale(4, 4, 1);
            g.drawString(net.minecraft.client.Minecraft.getInstance().font, l, -net.minecraft.client.Minecraft.getInstance().font.width(l) / 2, -4, 0xFFFFFFFF, true);
            g.pose().popPose();
        };
        return it;
    }

    private static void textDefaults(Item it) {
        String id = it.ref;
        String text = switch (id) {
            case "shaurma_lib:title" -> "ТИТУЛ";
            case "shaurma_lib:subtitle" -> "Субтитр унизу кадру";
            case "shaurma_lib:lower_third" -> "Ім'я Прізвище";
            case "shaurma_lib:chapter" -> "Розділ I";
            case "shaurma_lib:credits" -> "Режисер\\nШаурма\\n\\nКамера\\nКіт";
            case "shaurma_lib:typewriter" -> "Десь у темряві...";
            case "shaurma_lib:pop_text" -> "БАХ!";
            case "shaurma_lib:glitch_text" -> "ERROR";
            case "shaurma_lib:neon_text" -> "NEON";
            case "shaurma_lib:quote" -> "Цитата";
            case "shaurma_lib:countdown" -> "";
            default -> "Текст";
        };
        if (id.startsWith("shaurma_lib:") && !text.isEmpty()) it.params.put("text", text);
        if (id.equals("shaurma_lib:lower_third")) it.params.put("subtitle", "посада / роль");
        if (id.equals("shaurma_lib:credits")) it.len = 8;
        if (id.equals("shaurma_lib:countdown")) it.params.put("from", 3);
        it.params.put("enter", "fade");
        it.params.put("exit", "fade");
    }

    static String transitionTitle(Transition.Type t) {
        return switch (t) {
            case CUT -> "Склейка";
            case BLEND -> "Плавний проїзд";
            case FADE_BLACK -> "Через чорне";
            case DIP_COLOR -> "Dip у колір";
            case FLASH -> "Спалах";
            case GLITCH -> "Глітч";
            case SHUTTER -> "Затвор";
            case WIPE -> "Шторка вбік";
            case ZOOM_PUNCH -> "Наїзд (zoom)";
            case CROSSFADE -> "Розчинення";
            case WHIP_PAN -> "Whip-pan";
            case WIPE_UP -> "Шторка вгору";
            case WIPE_DIAGONAL -> "Діагональ";
            case IRIS -> "Діафрагма";
            case BLINDS -> "Жалюзі";
            case SPLIT_DOOR -> "Двері";
            case PIXEL_BLOCKS -> "Блоки";
            case RGB_SPLIT -> "RGB-розрив";
            case FILM_BURN -> "Опік плівки";
            case LIGHT_LEAK -> "Засвітка";
            case SPIN -> "Обертання";
            case ZOOM_OUT -> "Відліт (zoom out)";
            case SHAKE -> "Тряска";
            case PUSH_LEFT -> "Зсув вліво";
            case PUSH_UP -> "Зсув угору";
            case BLUR_DIP -> "Через туман";
            case INK -> "Чорнило";
        };
    }

    // ═════════════════════ мініатюри ═════════════════════

    /**
     * Зразковий кадр (небо, сонце, пагорби, фігура) — на ньому показують ефекти. {@code grade} — та сама кольорова
     * математика, що в шейдері фільтра, тож мініатюра фільтра чесна.
     */
    static void sample(GuiGraphics g, int w, int h, IntUnaryOperator grade, double t) {
        IntUnaryOperator c = grade == null ? v -> v : grade;
        int bands = 12;
        for (int i = 0; i < bands; i++) {
            float k = i / (float) (bands - 1);
            int r = (int) (60 + 180 * k), gg = (int) (110 + 90 * k), b = (int) (200 - 40 * k);
            g.fill(0, h * 6 / 10 * i / bands, w, h * 6 / 10 * (i + 1) / bands + 1, 0xFF000000 | c.applyAsInt((r << 16) | (gg << 8) | b));
        }
        int sx = (int) (w * 0.72), sy = (int) (h * 0.3);
        for (int y = -18; y <= 18; y += 2) { int hw = (int) Math.sqrt(18 * 18 - y * y); g.fill(sx - hw, sy + y, sx + hw, sy + y + 2, 0xFF000000 | c.applyAsInt(0xFFE08A)); }
        for (int x = 0; x < w; x += 4) {
            int hy = (int) (h * 0.55 + Math.sin(x * 0.03) * 12 + Math.sin(x * 0.011 + 1) * 10);
            g.fill(x, hy, x + 4, h, 0xFF000000 | c.applyAsInt(0x3E8E4A));
        }
        g.fill(0, (int) (h * 0.8), w, h, 0xFF000000 | c.applyAsInt(0x6B4A2E));
        int px = (int) (w * 0.3 + Math.sin(t * 1.4) * 20), py = (int) (h * 0.48);
        g.fill(px - 6, py, px + 6, py + 12, 0xFF000000 | c.applyAsInt(0xC9966B));
        g.fill(px - 7, py + 12, px + 7, py + 30, 0xFF000000 | c.applyAsInt(0x2FA3B5));
        g.fill(px - 7, py + 30, px + 7, py + 46, 0xFF000000 | c.applyAsInt(0x3B3F9E));
        g.fill(px - 12, py + 12, px - 7, py + 30, 0xFF000000 | c.applyAsInt(0xC9966B));
        g.fill(px + 7, py + 12, px + 12, py + 30, 0xFF000000 | c.applyAsInt(0xC9966B));
    }

    private static void effectThumb(GuiGraphics g, int w, int h, String id, Map<String, Object> params, double t) {
        // фільтр/корекція — колір рахуємо тією ж матрицею, що шейдер
        ScenePost.Grade grade = ScenePost.FILTERS.get(id);
        if (grade == null && id.equals("shaurma_lib:adjust")) grade = ScenePost.adjust(params);
        if (grade != null) { ScenePost.Grade gr = grade; sample(g, w, h, gr::apply, t); return; }
        if (id.startsWith("shaurma_lib:cam_")) {
            // рух камери — трусимо/крутимо сам кадр
            g.pose().pushPose();
            g.pose().translate(w / 2f, h / 2f, 0);
            double roll = switch (id) {
                case "shaurma_lib:cam_dutch" -> 14;
                case "shaurma_lib:cam_spin" -> t * 40 % 360;
                case "shaurma_lib:cam_drunk" -> 8 * Math.sin(t * 1.3);
                default -> 0;
            };
            double shake = switch (id) { case "shaurma_lib:cam_shake", "shaurma_lib:cam_earthquake" -> 8; case "shaurma_lib:cam_handheld" -> 3; default -> 0; };
            double zoom = switch (id) {
                case "shaurma_lib:cam_zoom_in" -> 1 + 0.3 * ((t * 0.4) % 1);
                case "shaurma_lib:cam_zoom_pulse", "shaurma_lib:cam_heartbeat" -> 1 + 0.1 * Math.pow(Math.max(0, Math.sin(t * 6)), 8);
                default -> 1.08;
            };
            g.pose().mulPose(Axis.ZP.rotationDegrees((float) roll));
            g.pose().scale((float) zoom * 1.1f, (float) zoom * 1.1f, 1);
            g.pose().translate((float) (-w / 2f + shake * Math.sin(t * 31)), (float) (-h / 2f + shake * Math.cos(t * 27)), 0);
            sample(g, w, h, null, t);
            g.pose().popPose();
            return;
        }
        sample(g, w, h, null, t);
        if (ScenePost.isShader(id)) {
            // шейдер не запустити на мініатюрі — стилізований підпис
            String l = SceneOverlays.effectEntry(id) == null ? id : SceneOverlays.effectEntry(id).title();
            g.fill(0, h - 40, w, h, 0xA0000000);
            g.pose().pushPose();
            g.pose().translate(w / 2f, h - 26, 0);
            g.pose().scale(2.2f, 2.2f, 1);
            var f = net.minecraft.client.Minecraft.getInstance().font;
            g.drawString(f, l, -f.width(l) / 2, -4, 0xFFFFE08A, true);
            g.pose().popPose();
            return;
        }
        SceneOverlays.EffectRenderer r = SceneOverlays.effect(id);
        if (r == null) return;
        SceneFrame.Effect e = new SceneFrame.Effect();
        e.id = id;
        e.intensity = 1;
        e.params = params;
        r.render(g, w, h, e);
    }

    private static void transitionThumb(GuiGraphics g, int w, int h, Transition.Type tt, double t) {
        float u = (float) ((t * 0.45) % 1.0);
        // до склейки — кадр А (день), після — кадр Б (вечір)
        boolean b = u >= 0.5f;
        IntUnaryOperator night = v -> { int r = (v >> 16) & 255, gg = (v >> 8) & 255, bb = v & 255; return ((r * 2 / 3) << 16) | ((gg / 2) << 8) | Math.min(255, bb + 30); };
        g.pose().pushPose();
        float bump = 1 - Math.abs(2 * u - 1);
        if (tt == Transition.Type.SPIN || tt == Transition.Type.ZOOM_PUNCH || tt == Transition.Type.ZOOM_OUT || tt == Transition.Type.WHIP_PAN || tt == Transition.Type.SHAKE || tt == Transition.Type.PUSH_LEFT || tt == Transition.Type.PUSH_UP) {
            g.pose().translate(w / 2f, h / 2f, 0);
            if (tt == Transition.Type.SPIN) g.pose().mulPose(Axis.ZP.rotationDegrees(u < 0.5f ? 180 * (float) Math.pow(u * 2, 3) : -180 * (float) Math.pow(2 - u * 2, 3)));
            float z = tt == Transition.Type.ZOOM_PUNCH ? 1 + bump * 0.6f : tt == Transition.Type.ZOOM_OUT ? 1 - bump * 0.35f : 1;
            g.pose().scale(z * 1.05f, z * 1.05f, 1);
            float dx = tt == Transition.Type.WHIP_PAN ? (u < 0.5f ? -1 : 1) * bump * w : tt == Transition.Type.SHAKE ? (float) Math.sin(t * 40) * 10 * bump
                : tt == Transition.Type.PUSH_LEFT ? (b ? w * (1 - (u - 0.5f) * 2) : -w * u * 2) : 0;
            float dy = tt == Transition.Type.PUSH_UP ? (b ? h * (1 - (u - 0.5f) * 2) : -h * u * 2) : 0;
            g.pose().translate(-w / 2f + dx, -h / 2f + dy, 0);
        }
        sample(g, w, h, b ? night : null, t);
        g.pose().popPose();
        if (tt == Transition.Type.CROSSFADE || tt == Transition.Type.BLEND) {
            // розчинення: поверх А проступає Б
            g.fill(0, 0, w, h, ((int) (bump * 120) << 24) | 0x101830);
        } else SceneHud.transitionPreview(g, w, h, tt, u, tt == Transition.Type.DIP_COLOR ? 0xE5646A : 0);
        g.fill(0, h - 4, (int) (w * u), h, 0xFF5FD3E6);
    }

    private static Thumb iconThumb(Icon icon, int color) {
        return (g, w, h, t) -> {
            g.fill(0, 0, w, h, 0xFF1A2236);
            g.pose().pushPose();
            g.pose().translate(w / 2f - 48, h / 2f - 48, 0);
            g.pose().scale(8, 8, 1);
            Icons.draw(g, icon, 0, 0, 12, color);
            g.pose().popPose();
        };
    }
}
