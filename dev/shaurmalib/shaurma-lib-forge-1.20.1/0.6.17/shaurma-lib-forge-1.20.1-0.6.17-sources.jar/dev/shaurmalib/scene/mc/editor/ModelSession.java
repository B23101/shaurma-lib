package dev.shaurmalib.scene.mc.editor;

import com.mojang.blaze3d.platform.NativeImage;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.io.BBModelDoc;
import dev.shaurmalib.scene.io.BBModelReader;
import dev.shaurmalib.scene.mc.client.SceneAssets;
import dev.shaurmalib.scene.paint.Image;
import dev.shaurmalib.scene.paint.Png;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

import java.io.IOException;

/**
 * Відкрита на сторінках «Модель» / «Малювання» модель вибраного актора чи пропа: робоча копія .bbmodel
 * ({@link BBModelDoc}) і пікселі текстури ({@link Image}).
 *
 * <p>Як живе зміна: під час перетягування / мазка модель і текстура показуються «наживо» (підміни в {@link SceneAssets}),
 * а на відпусканні миші байти лягають у кеш під НОВИМ sha256, і в історію сцени йде одна дія «ассет X: sha A → sha B».
 * Тому Ctrl+Z повертає старий хеш (і стару модель з кешу), збереження сцени вивантажує новий файл на сервер,
 * а сцена в світі малює зміну без жодних окремих механізмів.
 */
final class ModelSession {

    private ModelSession() {}

    static String objectId, assetId, loadedSha, texAssetId, texLoadedSha;
    static BBModelDoc bb;
    static BBModelReader.Result parsed;
    static Image image;
    /** Вибраний вузол (uuid кубика або групи). */
    static String sel;
    /** Чому редагування недоступне (null — усе гаразд). */
    static String problem;
    /** JSON останньої закоміченої версії — щоб «нічого не змінилось» не давало нового ассета й дії в історії. */
    private static String committed;

    private static DynamicTexture dyn;
    private static ResourceLocation dynRl;
    private static boolean texUploaded;
    private static boolean live;

    /** Підхопити вибраний об'єкт сцени; false — редагувати нема що ({@link #problem} пояснює). */
    static boolean sync(SceneEditorScreen s) {
        SceneObject o = s.selected();
        problem = null;
        if (o == null || (o.kind != SceneObject.Kind.ACTOR && o.kind != SceneObject.Kind.PROP)) return fail("Виберіть актора чи проп з моделлю .bbmodel (ліва панель або клік у сцені на сторінці «Монтаж»)");
        if (o.modelType != SceneObject.ModelType.ASSET || o.model == null) return fail("«" + o.name + "»: модель не з ассета світу. Редагувати можна імпортовану .bbmodel (Медіа → Моделі)");
        SceneDoc.Asset a = s.doc.assets.get(o.model);
        if (a == null) return fail("Ассет моделі зник з документа");
        if (!"bbmodel".equals(a.ext)) return fail("«" + a.name + "»: редагувати можна лише .bbmodel (а це ." + a.ext + ")");
        if (s.readOnly) return fail("Лише перегляд: сцену редагує " + s.lockedBy);
        SceneDoc.Asset ta = o.texture != null && !o.texture.contains(":") ? s.doc.assets.get(o.texture) : null;
        if (ta != null && !"png".equals(ta.ext)) ta = null;
        boolean reload = !o.model.equals(assetId) || !a.sha256.equals(loadedSha) || !o.id.equals(objectId)
            || (ta == null ? texAssetId != null : !ta.id.equals(texAssetId) || !ta.sha256.equals(texLoadedSha));
        if (!reload) return bb != null || fail("Модель не читається");
        byte[] data = SceneAssets.bytes(a);
        if (data == null) { SceneAssets.request(a.sha256, a.ext); return fail("Модель ще вантажиться з сервера…"); }
        clearLive();
        try {
            bb = BBModelDoc.parse(data);
            committed = bb.write();
            parsed = BBModelReader.read(committed, o.model);
        } catch (RuntimeException e) {
            bb = null;
            parsed = null;
            objectId = o.id; assetId = o.model; loadedSha = a.sha256;
            return fail("Модель не читається: " + e.getMessage());
        }
        boolean sameModel = o.model.equals(assetId);
        objectId = o.id;
        assetId = o.model;
        loadedSha = a.sha256;
        texAssetId = ta == null ? null : ta.id;
        texLoadedSha = ta == null ? null : ta.sha256;
        if (!sameModel || (sel != null && bb.props(sel) == null)) sel = null;
        image = null;
        byte[] png = ta != null ? SceneAssets.bytes(ta) : bb.texturePng();
        if (ta != null && png == null) SceneAssets.request(ta.sha256, ta.ext);
        if (png != null) {
            try { image = Png.decode(png, 4096, 4096L * 4096); } catch (IOException e) { image = null; }
        }
        if (image == null) image = new Image(Math.max(1, bb.textureWidth()), Math.max(1, bb.textureHeight()));
        texUploaded = false;
        return true;
    }

    private static boolean fail(String why) { problem = why; return false; }

    // ═════════════ текстура для GUI і живого превʼю ═════════════

    /** Текстура з поточними пікселями (завантажується в GPU, якщо щось мінялося). */
    static ResourceLocation texture() {
        if (image == null) return null;
        if (dyn == null || dyn.getPixels() == null || dyn.getPixels().getWidth() != image.width || dyn.getPixels().getHeight() != image.height) {
            if (dyn != null) dyn.close();
            dyn = new DynamicTexture(image.width, image.height, false);
            dynRl = Minecraft.getInstance().getTextureManager().register("shaurma_scene_model_edit", dyn);
            texUploaded = false;
        }
        if (!texUploaded) {
            NativeImage ni = dyn.getPixels();
            for (int y = 0; y < image.height; y++)
                for (int x = 0; x < image.width; x++) {
                    int c = image.argb[y * image.width + x];
                    ni.setPixelRGBA(x, y, (c & 0xFF00FF00) | ((c >> 16) & 0xFF) | ((c & 0xFF) << 16));   // ARGB → ABGR
                }
            dyn.upload();
            texUploaded = true;
        }
        return dynRl;
    }

    /** Пікселі змінились (мазок): показати наживо в GUI і в сцені. */
    static void pixelsChanged() {
        texUploaded = false;
        ResourceLocation rl = texture();
        if (texAssetId != null) SceneAssets.liveTexture(texAssetId, rl);
        else if (parsed != null) SceneAssets.live(assetId, SceneAssets.build(assetId, parsed, rl));
        live = true;
    }

    /** Геометрія змінилась (перетягування / поле): перечитати і показати наживо. */
    static boolean geometryChanged() {
        try {
            parsed = BBModelReader.read(bb.write(), assetId);
        } catch (RuntimeException e) {
            return false;
        }
        ResourceLocation tex = texAssetId != null ? null : texture();
        SceneAssets.live(assetId, SceneAssets.build(assetId, parsed, tex));
        live = true;
        return true;
    }

    static void clearLive() {
        if (assetId != null) SceneAssets.live(assetId, null);
        if (texAssetId != null) SceneAssets.liveTexture(texAssetId, null);
        live = false;
    }

    // ═════════════ коміт в історію сцени ═════════════

    /** Записати робочий .bbmodel як нову версію ассета (одна дія історії). */
    static void commitModel(SceneEditorScreen s, String label) {
        if (bb == null || assetId == null) return;
        SceneDoc.Asset a = s.doc.assets.get(assetId);
        if (a == null) return;
        String json = bb.write();
        if (json.equals(committed)) { clearLive(); return; }
        byte[] data = json.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        String sha;
        try { sha = SceneAssets.store(data, a.ext); } catch (IOException e) { s.toast("Не вдалося записати модель: " + e.getMessage()); return; }
        if (sha.equals(a.sha256)) { clearLive(); return; }
        s.begin("Модель: " + label);
        a.sha256 = sha;
        a.size = data.length;
        s.commit();
        loadedSha = sha;
        committed = json;
        clearLive();
    }

    /** Записати пікселі: у текстуру-ассет (якщо об'єкт має окрему) або у вбудовану текстуру .bbmodel. */
    static void commitPaint(SceneEditorScreen s, String label) {
        if (image == null) return;
        byte[] png = Png.encode(image);
        if (texAssetId == null) {
            if (bb == null) return;
            bb.setTexturePng(png, image.width, image.height);
            commitModel(s, label);
            return;
        }
        SceneDoc.Asset ta = s.doc.assets.get(texAssetId);
        if (ta == null) return;
        String sha;
        try { sha = SceneAssets.store(png, "png"); } catch (IOException e) { s.toast("Не вдалося записати текстуру: " + e.getMessage()); return; }
        if (!sha.equals(ta.sha256)) {
            s.begin("Малювання: " + label);
            ta.sha256 = sha;
            ta.size = png.length;
            ta.width = image.width;
            ta.height = image.height;
            s.commit();
            texLoadedSha = sha;
        }
        clearLive();
    }

    /** Повернути робочу копію до стану ассета (Esc під час перетягування). */
    static void revert(SceneEditorScreen s) {
        loadedSha = null;
        clearLive();
        sync(s);
    }

    static boolean isLive() { return live; }
}
