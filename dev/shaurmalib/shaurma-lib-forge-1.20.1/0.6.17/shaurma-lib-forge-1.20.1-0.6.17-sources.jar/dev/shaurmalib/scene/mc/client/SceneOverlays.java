package dev.shaurmalib.scene.mc.client;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.shaurmalib.scene.eval.SceneFrame;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;

/**
 * Оверлеї (текст, графіка) й ефекти, які можна ставити на таймлайн. Мод реєструє свої ({@code maniac:victory_title}),
 * редактор показує їх у бібліотеці (вкладки й категорії як у CapCut), сцена кличе з прогресом/непрозорістю/силою кадру.
 *
 * <pre>{@code
 * SceneOverlays.overlay("maniac:victory_title", "Титул перемоги", (g, w, h, o, alpha) -> VictoryTitleFx.draw(g, w, h, o.local, alpha));
 * SceneOverlays.effect("maniac:blood_edges", "Кров по краях", (g, w, h, e) -> HudFx.edgeFrame(g, w, h, 0x7A0000, (float) e.intensity * 0.6f, 0.2f));
 * }</pre>
 * Категорії: {@code text:*} — вкладка «Текст», {@code overlay:*} — «Оверлеї», {@code fx:*} — «Ефекти»,
 * {@code filter:*} — «Фільтри», {@code adjust} — «Корекція». Без категорії — «Мод».
 */
public final class SceneOverlays {

    private SceneOverlays() {}

    @FunctionalInterface
    public interface OverlayRenderer {
        /** @param alpha непрозорість з урахуванням появи/зникнення й кривої opacity */
        void render(GuiGraphics g, int w, int h, SceneFrame.Overlay o, float alpha);
    }

    @FunctionalInterface
    public interface EffectRenderer {
        void render(GuiGraphics g, int w, int h, SceneFrame.Effect e);
    }

    public record Entry<T>(String id, String title, String category, T renderer) {}

    private static final Map<String, Entry<OverlayRenderer>> OVERLAYS = new LinkedHashMap<>();
    private static final Map<String, Entry<EffectRenderer>> EFFECTS = new LinkedHashMap<>();

    public static void overlay(String id, String title, OverlayRenderer r) { overlay(id, title, "overlay:mod", r); }

    public static void overlay(String id, String title, String category, OverlayRenderer r) { OVERLAYS.put(id, new Entry<>(id, title, category, r)); }

    public static void effect(String id, String title, EffectRenderer r) { effect(id, title, "fx:mod", r); }

    public static void effect(String id, String title, String category, EffectRenderer r) { EFFECTS.put(id, new Entry<>(id, title, category, r)); }

    public static Collection<Entry<OverlayRenderer>> overlays() { return OVERLAYS.values(); }

    public static Collection<Entry<EffectRenderer>> effects() { return EFFECTS.values(); }

    public static Entry<EffectRenderer> effectEntry(String id) { return EFFECTS.get(id); }

    public static Entry<OverlayRenderer> overlayEntry(String id) { return OVERLAYS.get(id); }

    public static OverlayRenderer overlay(String id) { Entry<OverlayRenderer> e = OVERLAYS.get(id); return e == null ? null : e.renderer; }

    public static EffectRenderer effect(String id) { Entry<EffectRenderer> e = EFFECTS.get(id); return e == null ? null : e.renderer; }

    /** Назва категорії для бібліотеки. */
    public static String categoryTitle(String cat) {
        return switch (cat) {
            case "text:basic" -> "Основні";
            case "text:title" -> "Титри";
            case "text:anim" -> "Анімовані";
            case "overlay:graphics" -> "Графіка";
            case "overlay:mod" -> "Від мода";
            case "fx:basic" -> "Основні";
            case "fx:cinema" -> "Кіно";
            case "fx:light" -> "Світло";
            case "fx:glitch" -> "Глітч";
            case "fx:weather" -> "Атмосфера";
            case "fx:motion" -> "Рух камери";
            case "fx:shader" -> "Шейдери";
            case "fx:time" -> "Час";
            case "fx:mod" -> "Від мода";
            case "filter:life" -> "Життя";
            case "filter:landscape" -> "Пейзаж";
            case "filter:movies" -> "Фільми";
            case "filter:retro" -> "Ретро";
            case "filter:mono" -> "Моно";
            case "filter:night" -> "Ніч";
            case "adjust" -> "Корекція";
            default -> cat;
        };
    }

    // ═════════════════════ утиліти малювання ═════════════════════

    static double num(Object o, double def) {
        if (o instanceof Number n) return n.doubleValue();
        if (o instanceof String s) {
            try { return s.startsWith("#") ? Integer.parseInt(s.substring(1), 16) : Double.parseDouble(s); } catch (NumberFormatException e) { return def; }
        }
        return def;
    }

    static int argb(float a, int rgb) {
        int ai = Math.max(0, Math.min(255, Math.round(a * 255f)));
        return (ai << 24) | (rgb & 0xFFFFFF);
    }

    private static int col(Map<String, Object> p, String k, int def) { return (int) num(p == null ? null : p.get(k), def) & 0xFFFFFF; }

    private static String str(Map<String, Object> p, String k, String def) { Object o = p == null ? null : p.get(k); return o == null ? def : o.toString(); }

    private static Font font() { return Minecraft.getInstance().font; }

    private static double now() { return System.nanoTime() / 1e9; }

    /** Текст по центру точки з масштабом. */
    private static void centered(GuiGraphics g, String text, float cx, float cy, float scale, int argb, boolean shadow) {
        Font f = font();
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().scale(scale, scale, 1);
        g.drawString(f, text, -f.width(text) / 2, -4, argb, shadow);
        g.pose().popPose();
    }

    private static void outlined(GuiGraphics g, String text, float cx, float cy, float scale, int fill, int outline) {
        Font f = font();
        g.pose().pushPose();
        g.pose().translate(cx, cy, 0);
        g.pose().scale(scale, scale, 1);
        int x = -f.width(text) / 2;
        for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) if (dx != 0 || dy != 0) g.drawString(f, text, x + dx, -4 + dy, outline, false);
        g.drawString(f, text, x, -4, fill, false);
        g.pose().popPose();
    }

    private static float ease(double t) { t = Math.max(0, Math.min(1, t)); return (float) (t * t * (3 - 2 * t)); }

    /** Плавний градієнт смугою (вертикальний): від кольору a зверху до b знизу. */
    private static void vgrad(GuiGraphics g, int x0, int y0, int x1, int y1, int a, int b) { g.fillGradient(x0, y0, x1, y1, a, b); }

    /** Заливка з адитивним змішуванням (світло, відблиски). */
    private static void additive(Runnable draw) {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SourceFactor.SRC_ALPHA, com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE);
        try { draw.run(); } finally { RenderSystem.defaultBlendFunc(); }
    }

    /** Множення (затемнює кольором, як шар «Multiply»). */
    private static void multiply(Runnable draw) {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SourceFactor.DST_COLOR, com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        try { draw.run(); } finally { RenderSystem.defaultBlendFunc(); }
    }

    private static void vignette(GuiGraphics g, int w, int h, float k, int c) {
        int d = Math.max(8, (int) (Math.min(w, h) * 0.28));
        for (int i = 0; i < 8; i++) {
            float a = k * (1 - i / 8f) * 0.28f;
            int t = d * (i + 1) / 8;
            g.fill(0, 0, w, t / 3, argb(a, c));
            g.fill(0, h - t / 3, w, h, argb(a, c));
            g.fill(0, 0, t / 2, h, argb(a, c));
            g.fill(w - t / 2, 0, w, h, argb(a, c));
        }
    }

    // ═════════════════════ вбудований вміст ═════════════════════

    static {
        // ─────────────── Текст ───────────────
        overlay("shaurma_lib:text", "Простий текст", "text:basic", (g, w, h, o, a) -> {
            String text = str(o.params, "text", "Текст");
            float s = (float) (o.scale * num(o.params.get("size"), 2));
            boolean box = num(o.params.get("box"), 0) > 0;
            int c = col(o.params, "color", 0xFFFFFF);
            if (box) {
                int tw = (int) (font().width(text) * s);
                g.fill((int) (w * o.x) - tw / 2 - 6, (int) (h * o.y - 6 * s), (int) (w * o.x) + tw / 2 + 6, (int) (h * o.y + 6 * s), argb(a * 0.6f, col(o.params, "accent", 0)));
            }
            centered(g, text, (float) (w * o.x), (float) (h * o.y), s, argb(a, c), true);
        });
        overlay("shaurma_lib:title", "Титул", "text:title", (g, w, h, o, a) -> {
            String text = str(o.params, "text", "ТИТУЛ");
            String sub = o.params.containsKey("subtitle") ? str(o.params, "subtitle", "") : null;
            float s = (float) (o.scale * 3);
            centered(g, text, (float) (w * o.x), (float) (h * o.y), s, argb(a, col(o.params, "color", 0xFFFFFF)), true);
            if (sub != null && !sub.isEmpty()) centered(g, sub, (float) (w * o.x), (float) (h * o.y + 8 * s), 1, argb(a * 0.85f, 0xDDDDDD), true);
        });
        overlay("shaurma_lib:subtitle", "Субтитр", "text:basic", (g, w, h, o, a) -> {
            String text = str(o.params, "text", "...");
            int tw = font().width(text);
            int x = (int) (w * o.x) - tw / 2, y = (int) (h * (o.y == 0.5 ? 0.82 : o.y));
            g.fill(x - 4, y - 3, x + tw + 4, y + 11, argb(a * 0.55f, 0));
            g.drawString(font(), text, x, y, argb(a, col(o.params, "color", 0xFFFFFF)), false);
        });
        overlay("shaurma_lib:outline_text", "Обведений", "text:basic", (g, w, h, o, a) ->
            outlined(g, str(o.params, "text", "ОБВЕДЕНИЙ"), (float) (w * o.x), (float) (h * o.y), (float) (o.scale * 3), argb(a, col(o.params, "color", 0xFFFFFF)), argb(a, col(o.params, "accent", 0))));
        overlay("shaurma_lib:neon_text", "Неон", "text:basic", (g, w, h, o, a) -> {
            String t = str(o.params, "text", "NEON");
            int c = col(o.params, "color", 0xFF3BD6);
            float s = (float) (o.scale * 3), cx = (float) (w * o.x), cy = (float) (h * o.y);
            float flick = 0.85f + 0.15f * (float) Math.sin(now() * 23) * (Math.sin(now() * 1.7) > 0.9 ? 1 : 0.1f);
            additive(() -> { for (int r = 3; r >= 1; r--) for (int i = 0; i < 8; i++) {
                double ang = i * Math.PI / 4;
                centered(g, t, cx + (float) Math.cos(ang) * r, cy + (float) Math.sin(ang) * r, s, argb(a * 0.12f * flick, c), false);
            } });
            centered(g, t, cx, cy, s, argb(a * flick, 0xFFFFFF & (c | 0x808080)), false);
        });
        overlay("shaurma_lib:lower_third", "Нижня третина", "text:title", (g, w, h, o, a) -> {
            String name = str(o.params, "text", "Ім'я Прізвище"), sub = str(o.params, "subtitle", "посада / роль");
            int acc = col(o.params, "accent", 0xE5646A);
            float in = ease(o.enter);
            int x = (int) (w * 0.06), y = (int) (h * 0.74);
            int tw = Math.max(font().width(name) * 2, font().width(sub)) + 16;
            int bw = (int) (tw * in);
            g.fill(x, y, x + 3, y + 30, argb(a, acc));
            g.fill(x + 3, y, x + 3 + bw, y + 20, argb(a * 0.75f, 0x101010));
            g.fill(x + 3, y + 20, x + 3 + (int) (bw * 0.8), y + 30, argb(a * 0.85f, acc));
            g.enableScissor(x, y, x + 3 + bw, y + 31);
            g.pose().pushPose();
            g.pose().translate(x + 9, y + 3, 0);
            g.pose().scale(2, 2, 1);
            g.drawString(font(), name, 0, 0, argb(a, 0xFFFFFF), false);
            g.pose().popPose();
            g.drawString(font(), sub, x + 9, y + 21, argb(a, 0xFFFFFF), false);
            g.disableScissor();
        });
        overlay("shaurma_lib:chapter", "Розділ", "text:title", (g, w, h, o, a) -> {
            String t = str(o.params, "text", "РОЗДІЛ I").toUpperCase(java.util.Locale.ROOT);
            StringBuilder sp = new StringBuilder();
            for (char ch : t.toCharArray()) sp.append(ch).append(' ');
            float s = (float) (o.scale * 2);
            int cx = (int) (w * o.x), cy = (int) (h * o.y);
            int lw = (int) (w * 0.18 * ease(o.enter));
            g.fill(cx - lw - 40, cy, cx - 40, cy + 1, argb(a, 0xFFFFFF));
            g.fill(cx + 40, cy, cx + 40 + lw, cy + 1, argb(a, 0xFFFFFF));
            centered(g, sp.toString().trim(), cx, cy + 1, s, argb(a, col(o.params, "color", 0xFFFFFF)), false);
            String sub = str(o.params, "subtitle", "");
            if (!sub.isEmpty()) centered(g, sub, cx, cy + 14 * s / 2 + 6, 1, argb(a * 0.7f, 0xDDDDDD), false);
        });
        overlay("shaurma_lib:credits", "Титри (прокрутка)", "text:title", (g, w, h, o, a) -> {
            String[] lines = str(o.params, "text", "Режисер\\nШаурма\\n\\nКамера\\nКіт").replace("\\n", "\n").split("\n");
            double prog = o.length <= 0 ? 0 : o.local / o.length;
            int lh = (int) (12 * o.scale * 1.5);
            int total = lines.length * lh;
            int y0 = (int) (h - (h + total) * prog);
            for (int i = 0; i < lines.length; i++) centered(g, lines[i], (float) (w * o.x), y0 + i * lh, (float) (o.scale * 1.5), argb(a, i % 3 == 0 ? 0xFFFFFF : 0xBBBBBB), true);
        });
        overlay("shaurma_lib:quote", "Цитата", "text:basic", (g, w, h, o, a) -> {
            String t = "«" + str(o.params, "text", "Цитата") + "»";
            Component c = Component.literal(t).withStyle(Style.EMPTY.withItalic(true));
            int tw = font().width(c) * 2;
            int cx = (int) (w * o.x), cy = (int) (h * o.y);
            g.fill(cx - tw / 2 - 10, cy - 14, cx + tw / 2 + 10, cy + 14, argb(a * 0.5f, 0));
            g.fill(cx - tw / 2 - 10, cy - 14, cx - tw / 2 - 8, cy + 14, argb(a, col(o.params, "accent", 0xF2B84B)));
            g.pose().pushPose();
            g.pose().translate(cx - tw / 2f, cy - 8, 0);
            g.pose().scale(2, 2, 1);
            g.drawString(font(), c, 0, 0, argb(a, 0xFFFFFF), false);
            g.pose().popPose();
        });
        overlay("shaurma_lib:typewriter", "Друкарська машинка", "text:anim", (g, w, h, o, a) -> {
            String t = str(o.params, "text", "Десь у темряві...");
            double cps = num(o.params.get("cps"), 18);
            int n = (int) Math.min(t.length(), o.local * cps);
            String shown = t.substring(0, n) + ((now() * 2) % 2 < 1 ? "_" : " ");
            float s = (float) (o.scale * 2);
            Font f = font();
            g.pose().pushPose();
            g.pose().translate((float) (w * o.x) - f.width(t) * s / 2, (float) (h * o.y), 0);
            g.pose().scale(s, s, 1);
            g.drawString(f, shown, 0, -4, argb(a, col(o.params, "color", 0xE8E8E8)), true);
            g.pose().popPose();
        });
        overlay("shaurma_lib:wave_text", "Хвиля", "text:anim", (g, w, h, o, a) -> letters(g, w, h, o, a, (i, t) -> new float[] { 0, (float) Math.sin(t * 6 + i * 0.6) * 3, 0 }));
        overlay("shaurma_lib:shake_text", "Тремтіння", "text:anim", (g, w, h, o, a) -> letters(g, w, h, o, a, (i, t) -> {
            Random r = new Random((long) (t * 30) * 31 + i);
            return new float[] { (r.nextFloat() - 0.5f) * 2, (r.nextFloat() - 0.5f) * 2, 0 };
        }));
        overlay("shaurma_lib:pop_text", "Удар (поп)", "text:anim", (g, w, h, o, a) -> {
            double u = Math.min(1, o.local / 0.35);
            float s = (float) (o.scale * 3 * (u < 1 ? 1 + 0.6 * Math.sin(u * Math.PI) * (1 - u) + (1 - u) * 0.8 : 1));
            outlined(g, str(o.params, "text", "БАХ!"), (float) (w * o.x), (float) (h * o.y), s, argb(a, col(o.params, "color", 0xFFE14B)), argb(a, 0));
        });
        overlay("shaurma_lib:glitch_text", "Глітч-текст", "text:anim", (g, w, h, o, a) -> {
            String t = str(o.params, "text", "ERROR");
            float s = (float) (o.scale * 3), cx = (float) (w * o.x), cy = (float) (h * o.y);
            Random r = new Random((long) (now() * 14));
            boolean burst = r.nextFloat() < 0.35f;
            float dx = burst ? (r.nextFloat() - 0.5f) * 6 : 1;
            centered(g, t, cx - dx, cy, s, argb(a * 0.8f, 0x00E5FF), false);
            centered(g, t, cx + dx, cy, s, argb(a * 0.8f, 0xFF2BD6), false);
            centered(g, t, cx, cy, s, argb(a, 0xFFFFFF), false);
        });
        overlay("shaurma_lib:countdown", "Відлік 3-2-1", "text:anim", (g, w, h, o, a) -> {
            int from = (int) num(o.params.get("from"), 3);
            double per = o.length / Math.max(1, from);
            int n = from - (int) (o.local / per);
            if (n <= 0) return;
            double f = (o.local % per) / per;
            float s = (float) (o.scale * (6 - 2 * f));
            centered(g, String.valueOf(n), (float) (w * o.x), (float) (h * o.y), s, argb((float) (a * (1 - f * 0.7)), col(o.params, "color", 0xFFFFFF)), true);
            int r = (int) (Math.min(w, h) * 0.18);
            int seg = 48;
            for (int i = 0; i < seg * (1 - f); i++) {
                double an = -Math.PI / 2 + i * Math.PI * 2 / seg;
                int px = (int) (w * o.x + Math.cos(an) * r), py = (int) (h * o.y + Math.sin(an) * r);
                g.fill(px - 1, py - 1, px + 2, py + 2, argb(a * 0.8f, col(o.params, "accent", 0xE5646A)));
            }
        });

        // ─────────────── Оверлеї-графіка ───────────────
        overlay("shaurma_lib:rec", "REC-камера", "overlay:graphics", (g, w, h, o, a) -> {
            int m = 14, l = 18, c = argb(a, 0xFFFFFF);
            g.fill(m, m, m + l, m + 2, c); g.fill(m, m, m + 2, m + l, c);
            g.fill(w - m - l, m, w - m, m + 2, c); g.fill(w - m - 2, m, w - m, m + l, c);
            g.fill(m, h - m - 2, m + l, h - m, c); g.fill(m, h - m - l, m + 2, h - m, c);
            g.fill(w - m - l, h - m - 2, w - m, h - m, c); g.fill(w - m - 2, h - m - l, w - m, h - m, c);
            if ((now() % 1.2) < 0.7) g.fill(m + 10, m + 10, m + 16, m + 16, argb(a, 0xFF2020));
            g.drawString(font(), "REC", m + 20, m + 9, c, false);
            int secs = (int) o.local;
            g.drawString(font(), String.format("00:%02d:%02d", secs / 60, secs % 60), w - m - 60, m + 9, c, false);
            g.drawString(font(), "▮▮▮▯", w - m - 30, h - m - 16, c, false);
        });
        overlay("shaurma_lib:viewfinder", "Видошукач", "overlay:graphics", (g, w, h, o, a) -> {
            int c = argb(a * 0.6f, 0xFFFFFF);
            g.fill(w / 3, 0, w / 3 + 1, h, c); g.fill(w * 2 / 3, 0, w * 2 / 3 + 1, h, c);
            g.fill(0, h / 3, w, h / 3 + 1, c); g.fill(0, h * 2 / 3, w, h * 2 / 3 + 1, c);
            g.fill(w / 2 - 8, h / 2, w / 2 + 9, h / 2 + 1, argb(a, 0xFFFFFF)); g.fill(w / 2, h / 2 - 8, w / 2 + 1, h / 2 + 9, argb(a, 0xFFFFFF));
        });
        overlay("shaurma_lib:frame", "Рамка", "overlay:graphics", (g, w, h, o, a) -> {
            int t = (int) Math.max(2, num(o.params.get("size"), 10) * o.scale), c = argb(a, col(o.params, "color", 0xFFFFFF));
            g.fill(0, 0, w, t, c); g.fill(0, h - t, w, h, c); g.fill(0, 0, t, h, c); g.fill(w - t, 0, w, h, c);
        });
        overlay("shaurma_lib:letterbox", "Кіно-смуги 2.39", "overlay:graphics", (g, w, h, o, a) -> {
            int target = (int) Math.max(0, (h - w / num(o.params.get("ratio"), 2.39)) / 2);
            int bar = (int) (target * Math.min(ease(o.enter), ease(o.exit)));
            g.fill(0, 0, w, bar, 0xFF000000);
            g.fill(0, h - bar, w, h, 0xFF000000);
        });
        overlay("shaurma_lib:arrow", "Стрілка-вказівник", "overlay:graphics", (g, w, h, o, a) -> {
            int cx = (int) (w * o.x), cy = (int) (h * o.y);
            int bob = (int) (Math.sin(now() * 6) * 4);
            int c = argb(a, col(o.params, "color", 0xFF3B3B));
            for (int i = 0; i < 12; i++) g.fill(cx - i, cy - 30 + bob + i, cx + i + 1, cy - 29 + bob + i, c);
            g.fill(cx - 4, cy - 52 + bob, cx + 5, cy - 30 + bob, c);
        });
        overlay("shaurma_lib:circle", "Коло-виділення", "overlay:graphics", (g, w, h, o, a) -> {
            int cx = (int) (w * o.x), cy = (int) (h * o.y), r = (int) (30 * o.scale);
            double prog = Math.min(1, o.local / 0.5);
            int seg = 72;
            for (int i = 0; i < seg * prog; i++) {
                double an = -Math.PI / 2 + i * Math.PI * 2 / seg;
                int px = (int) (cx + Math.cos(an) * r * 1.3), py = (int) (cy + Math.sin(an) * r);
                g.fill(px - 1, py - 1, px + 2, py + 2, argb(a, col(o.params, "color", 0xFF3B3B)));
            }
        });

        // ─────────────── Ефекти: основні ───────────────
        effect("shaurma_lib:vignette", "Віньєтка", "fx:basic", (g, w, h, e) -> vignette(g, w, h, (float) e.intensity, col(e.params, "color", 0)));
        effect("shaurma_lib:tint", "Тонування", "fx:basic", (g, w, h, e) ->
            g.fill(0, 0, w, h, argb((float) (e.intensity * num(e.params.get("alpha"), 0.35)), col(e.params, "color", 0x7A0000))));
        effect("shaurma_lib:darkness", "Затемнення", "fx:basic", (g, w, h, e) -> g.fill(0, 0, w, h, argb((float) e.intensity, 0)));
        effect("shaurma_lib:flash", "Спалах", "fx:basic", (g, w, h, e) -> g.fill(0, 0, w, h, argb((float) e.intensity, col(e.params, "color", 0xFFF4E0))));
        effect("shaurma_lib:fade_white", "Вибілення", "fx:basic", (g, w, h, e) -> additive(() -> g.fill(0, 0, w, h, argb((float) e.intensity * 0.8f, 0xFFFFFF))));
        effect("shaurma_lib:multiply", "Кольоровий шар (multiply)", "fx:basic", (g, w, h, e) -> multiply(() -> g.fill(0, 0, w, h, argb((float) e.intensity, col(e.params, "color", 0xFF9050)))));
        effect("shaurma_lib:gradient", "Градієнт неба", "fx:basic", (g, w, h, e) -> {
            float k = (float) e.intensity;
            vgrad(g, 0, 0, w, h / 2, argb(0.45f * k, col(e.params, "color", 0xFF7A30)), 0);
            vgrad(g, 0, h / 2, w, h, 0, argb(0.35f * k, col(e.params, "accent", 0x2040A0)));
        });

        // ─────────────── Кіно ───────────────
        effect("shaurma_lib:grain", "Плівкове зерно", "fx:cinema", (g, w, h, e) -> {
            Random r = new Random(System.nanoTime() / 40_000_000L);
            int n = (int) (w * h / 700 * e.intensity);
            for (int i = 0; i < n; i++) {
                int x = r.nextInt(Math.max(1, w)), y = r.nextInt(Math.max(1, h));
                g.fill(x, y, x + 1, y + 1, argb(0.22f, r.nextBoolean() ? 0xFFFFFF : 0));
            }
        });
        effect("shaurma_lib:old_film", "Старе кіно", "fx:cinema", (g, w, h, e) -> {
            float k = (float) e.intensity;
            Random r = new Random(System.nanoTime() / 60_000_000L);
            multiply(() -> g.fill(0, 0, w, h, argb(k * 0.55f, 0xD9B07A)));
            g.fill(0, 0, w, h, argb(k * (0.04f + 0.06f * r.nextFloat()), r.nextBoolean() ? 0 : 0xFFFFFF));
            for (int i = 0; i < 3; i++) if (r.nextFloat() < 0.6f) { int x = r.nextInt(Math.max(1, w)); g.fill(x, 0, x + 1, h, argb(k * 0.35f, 0x221100)); }
            for (int i = 0; i < 12 * k; i++) { int x = r.nextInt(Math.max(1, w)), y = r.nextInt(Math.max(1, h)); g.fill(x, y, x + 2, y + 2, argb(k * 0.5f, 0)); }
            vignette(g, w, h, k, 0x1A0E00);
        });
        effect("shaurma_lib:vhs", "VHS", "fx:cinema", (g, w, h, e) -> {
            float k = (float) e.intensity;
            Random r = new Random(System.nanoTime() / 50_000_000L);
            for (int y = 0; y < h; y += 2) g.fill(0, y, w, y + 1, argb(0.12f * k, 0));
            int band = (int) ((now() * 40) % (h + 40)) - 20;
            g.fill(0, band, w, band + 6, argb(0.12f * k, 0xFFFFFF));
            for (int i = 0; i < 6 * k; i++) {
                int y = r.nextInt(Math.max(1, h)), x = r.nextInt(Math.max(1, w / 2));
                g.fill(x, y, x + r.nextInt(Math.max(1, w / 3)), y + 1, argb(0.35f * k, r.nextBoolean() ? 0x00E5FF : 0xFF2BD6));
            }
            g.fill(0, h - 6, w, h, argb(0.5f * k * r.nextFloat(), 0xFFFFFF));
            g.drawString(font(), "PLAY ▶", 12, 12, argb(k, 0xFFFFFF), true);
            g.drawString(font(), "SP", w - 26, 12, argb(k, 0xFFFFFF), true);
        });
        effect("shaurma_lib:scanlines", "CRT-лінії", "fx:cinema", (g, w, h, e) -> {
            for (int y = 0; y < h; y += 3) g.fill(0, y, w, y + 1, argb((float) (0.25 * e.intensity), 0));
            vignette(g, w, h, (float) e.intensity * 0.7f, 0);
        });
        effect("shaurma_lib:flicker", "Мерехтіння кадру", "fx:cinema", (g, w, h, e) -> {
            Random r = new Random(System.nanoTime() / 70_000_000L);
            g.fill(0, 0, w, h, argb((float) (e.intensity * 0.35 * r.nextFloat()), 0));
        });
        effect("shaurma_lib:dream", "Мрія (сяйво)", "fx:cinema", (g, w, h, e) -> {
            float k = (float) e.intensity;
            additive(() -> { g.fill(0, 0, w, h, argb(k * 0.12f, 0xFFE8F0)); vgrad(g, 0, 0, w, h / 3, argb(k * 0.25f, 0xFFFFFF), 0); });
            vignette(g, w, h, k * 0.6f, 0xFFFFFF);
        });

        // ─────────────── Світло ───────────────
        effect("shaurma_lib:light_leak", "Відблиск плівки", "fx:light", (g, w, h, e) -> {
            float k = (float) e.intensity, t = (float) now();
            int c = col(e.params, "color", 0xFF7A1E);
            additive(() -> {
                for (int i = 0; i < 6; i++) {
                    int x0 = (int) (w * (0.55 + 0.25 * Math.sin(t * 0.4 + i))), r = (int) (w * (0.15 + i * 0.05));
                    g.fill(Math.max(0, x0 - r), 0, Math.min(w, x0 + r), h, argb(k * 0.05f, c));
                }
                vgrad(g, 0, 0, w / 3, h, argb(k * 0.25f, c), 0);
            });
        });
        effect("shaurma_lib:sun_rays", "Сонячні промені", "fx:light", (g, w, h, e) -> {
            float k = (float) e.intensity;
            additive(() -> {
                for (int i = 0; i < 9; i++) {
                    double an = 0.4 + i * 0.13 + Math.sin(now() * 0.3 + i) * 0.02;
                    for (int s = 0; s < 40; s++) {
                        int x = (int) (s * Math.cos(an) * w / 30), y = (int) (s * Math.sin(an) * h / 30);
                        g.fill(x, y, x + 6 + s / 2, y + 6 + s / 2, argb(k * 0.025f, 0xFFF0C0));
                    }
                }
            });
        });
        effect("shaurma_lib:lightning", "Блискавка", "fx:light", (g, w, h, e) -> {
            double t = now();
            double ph = (t * 0.7) % 1;
            if (ph < 0.06 || (ph > 0.1 && ph < 0.13)) g.fill(0, 0, w, h, argb((float) (e.intensity * 0.75), 0xE8F0FF));
        });
        effect("shaurma_lib:strobe", "Стробоскоп", "fx:light", (g, w, h, e) -> {
            if ((now() * num(e.params.get("hz"), 8)) % 1 < 0.5) g.fill(0, 0, w, h, argb((float) e.intensity * 0.8f, col(e.params, "color", 0xFFFFFF)));
        });
        effect("shaurma_lib:neon_edges", "Неонова рамка", "fx:light", (g, w, h, e) -> {
            float k = (float) e.intensity * (0.8f + 0.2f * (float) Math.sin(now() * 4));
            int c = col(e.params, "color", 0x3BD6FF);
            additive(() -> { for (int i = 0; i < 10; i++) { float a = k * 0.09f * (1 - i / 10f); g.fill(0, i * 2, w, i * 2 + 2, argb(a, c)); g.fill(0, h - i * 2 - 2, w, h - i * 2, argb(a, c)); g.fill(i * 2, 0, i * 2 + 2, h, argb(a, c)); g.fill(w - i * 2 - 2, 0, w - i * 2, h, argb(a, c)); } });
        });
        effect("shaurma_lib:police", "Мигалки", "fx:light", (g, w, h, e) -> {
            boolean red = (now() * 3) % 1 < 0.5;
            additive(() -> vgrad(g, red ? 0 : w / 2, 0, red ? w / 2 : w, h, argb((float) e.intensity * 0.35f, red ? 0xFF2020 : 0x2040FF), 0));
        });

        // ─────────────── Глітч ───────────────
        effect("shaurma_lib:glitch", "Глітч", "fx:glitch", (g, w, h, e) -> {
            float k = (float) e.intensity;
            Random r = new Random((System.currentTimeMillis() / 60L) * 7919L);
            if (r.nextFloat() > 0.35f + 0.6f * k) return;
            int[] pal = { 0x00E5FF, 0xFF2BD6, 0x000000, 0xFFFFFF, 0x1AFF6A };
            for (int i = 0; i < 4 + 14 * k; i++) {
                int y = r.nextInt(Math.max(1, h)), sh = 2 + r.nextInt(Math.max(3, (int) (h * 0.05f * k) + 3));
                int x0 = r.nextInt(Math.max(1, w / 3)) - w / 8, x1 = w - r.nextInt(Math.max(1, w / 3)) + w / 8;
                g.fill(Math.max(0, x0), y, Math.min(w, x1), Math.min(h, y + sh), argb(0.2f + 0.45f * k, pal[r.nextInt(pal.length)]));
            }
        });
        effect("shaurma_lib:rgb_split", "RGB-зсув", "fx:glitch", (g, w, h, e) -> {
            float k = (float) e.intensity;
            int d = (int) (3 + 6 * k);
            additive(() -> {
                g.fill(0, 0, d, h, argb(0.3f * k, 0xFF0040)); g.fill(w - d, 0, w, h, argb(0.3f * k, 0x00E5FF));
                g.fill(0, 0, w, d / 2, argb(0.2f * k, 0xFF0040)); g.fill(0, h - d / 2, w, h, argb(0.2f * k, 0x00E5FF));
            });
        });
        effect("shaurma_lib:digital_noise", "Цифровий шум", "fx:glitch", (g, w, h, e) -> {
            Random r = new Random(System.nanoTime() / 45_000_000L);
            int bs = 8;
            for (int i = 0; i < 60 * e.intensity; i++) {
                int x = r.nextInt(Math.max(1, w / bs)) * bs, y = r.nextInt(Math.max(1, h / bs)) * bs;
                g.fill(x, y, x + bs * (1 + r.nextInt(4)), y + bs, argb(0.6f, r.nextInt(0xFFFFFF)));
            }
        });
        effect("shaurma_lib:static", "Перешкоди (снiг ТБ)", "fx:glitch", (g, w, h, e) -> {
            Random r = new Random(System.nanoTime() / 30_000_000L);
            int n = (int) (w * h / 60 * e.intensity);
            for (int i = 0; i < n; i++) { int x = r.nextInt(Math.max(1, w)), y = r.nextInt(Math.max(1, h)); g.fill(x, y, x + 2, y + 1, argb(0.7f, r.nextBoolean() ? 0xFFFFFF : 0x202020)); }
        });
        effect("shaurma_lib:signal_lost", "Втрата сигналу", "fx:glitch", (g, w, h, e) -> {
            float k = (float) e.intensity;
            int[] bars = { 0xC0C0C0, 0xC0C000, 0x00C0C0, 0x00C000, 0xC000C0, 0xC00000, 0x0000C0 };
            for (int i = 0; i < bars.length; i++) g.fill(w * i / bars.length, 0, w * (i + 1) / bars.length, h * 2 / 3, argb(k, bars[i]));
            g.fill(0, h * 2 / 3, w, h, argb(k, 0x101010));
            if (k > 0.5f) centered(g, "NO SIGNAL", w / 2f, h * 0.83f, 2, argb(k, 0xFFFFFF), false);
        });

        // ─────────────── Атмосфера ───────────────
        effect("shaurma_lib:rain", "Дощ", "fx:weather", (g, w, h, e) -> {
            double t = now();
            Random r = new Random(5);
            for (int i = 0; i < 160 * e.intensity; i++) {
                double sp = 600 + r.nextInt(500);
                int x = (int) ((r.nextInt(Math.max(1, w + 60)) - (t * 120) % 60 + w) % (w + 60)) - 30;
                int y = (int) ((r.nextInt(Math.max(1, h)) + t * sp) % (h + 20)) - 20;
                g.fill(x, y, x + 1, y + 10, argb(0.35f, 0xB0C8FF));
            }
        });
        effect("shaurma_lib:snow", "Сніг", "fx:weather", (g, w, h, e) -> {
            double t = now();
            Random r = new Random(9);
            for (int i = 0; i < 140 * e.intensity; i++) {
                double sp = 20 + r.nextInt(40), sw = r.nextDouble() * 6;
                int x = (int) (r.nextInt(Math.max(1, w)) + Math.sin(t + sw) * 12);
                int y = (int) ((r.nextInt(Math.max(1, h)) + t * sp) % (h + 4)) - 2;
                int s = 1 + r.nextInt(2);
                g.fill(x, y, x + s, y + s, argb(0.85f, 0xFFFFFF));
            }
        });
        effect("shaurma_lib:embers", "Іскри / жар", "fx:weather", (g, w, h, e) -> {
            double t = now();
            Random r = new Random(13);
            additive(() -> { for (int i = 0; i < 70 * e.intensity; i++) {
                double sp = 25 + r.nextInt(60);
                int x = (int) (r.nextInt(Math.max(1, w)) + Math.sin(t * 2 + i) * 15);
                int y = (int) (h - (r.nextInt(Math.max(1, h)) + t * sp) % (h + 4));
                g.fill(x, y, x + 2, y + 2, argb(0.5f + 0.5f * (float) Math.sin(t * 9 + i), 0xFF8A2A));
            } });
        });
        effect("shaurma_lib:dust", "Пил у світлі", "fx:weather", (g, w, h, e) -> {
            double t = now();
            Random r = new Random(17);
            for (int i = 0; i < 90 * e.intensity; i++) {
                int x = (int) (r.nextInt(Math.max(1, w)) + Math.sin(t * 0.3 + i) * 25);
                int y = (int) (r.nextInt(Math.max(1, h)) + Math.cos(t * 0.25 + i * 1.3) * 18);
                g.fill(x, y, x + 1, y + 1, argb(0.25f + 0.3f * (float) Math.sin(t + i), 0xFFF2D0));
            }
        });
        effect("shaurma_lib:fog", "Туман", "fx:weather", (g, w, h, e) -> {
            float k = (float) e.intensity;
            vgrad(g, 0, h / 3, w, h, 0, argb(0.7f * k, col(e.params, "color", 0xC8D0D8)));
            g.fill(0, 0, w, h, argb(0.15f * k, col(e.params, "color", 0xC8D0D8)));
        });
        effect("shaurma_lib:blood_edges", "Кров по краях", "fx:weather", (g, w, h, e) -> vignette(g, w, h, (float) e.intensity * 1.6f, 0x7A0000));
        effect("shaurma_lib:heartbeat", "Серцебиття", "fx:weather", (g, w, h, e) -> {
            double b = now() * num(e.params.get("bpm"), 70) / 60, ph = b - Math.floor(b);
            double p = Math.exp(-ph * 14) + 0.6 * Math.exp(-Math.abs(ph - 0.22) * 14);
            vignette(g, w, h, (float) (e.intensity * (0.5 + 1.2 * p)), 0x900000);
        });
        effect("shaurma_lib:underwater", "Під водою", "fx:weather", (g, w, h, e) -> {
            float k = (float) e.intensity;
            multiply(() -> g.fill(0, 0, w, h, argb(k * 0.6f, 0x3080B0)));
            additive(() -> { for (int i = 0; i < 8; i++) { int x = (int) (w * ((i / 8.0 + now() * 0.03) % 1)); g.fill(x, 0, x + 18, h, argb(k * 0.04f, 0xA0E0FF)); } });
        });

        // ─────────────── Рух камери (обробляє SceneEvaluator.motion) ───────────────
        EffectRenderer none = (g, w, h, e) -> { };
        effect("shaurma_lib:cam_shake", "Тряска", "fx:motion", none);
        effect("shaurma_lib:cam_handheld", "З рук (оператор)", "fx:motion", none);
        effect("shaurma_lib:cam_earthquake", "Землетрус", "fx:motion", none);
        effect("shaurma_lib:cam_zoom_in", "Повільний наїзд", "fx:motion", none);
        effect("shaurma_lib:cam_zoom_pulse", "Пульс у ритм", "fx:motion", none);
        effect("shaurma_lib:cam_heartbeat", "Удар серця (зум)", "fx:motion", none);
        effect("shaurma_lib:cam_dutch", "Голландський кут", "fx:motion", none);
        effect("shaurma_lib:cam_spin", "Обертання", "fx:motion", none);
        effect("shaurma_lib:cam_drunk", "П'яна камера", "fx:motion", none);

        // шейдери, фільтри й корекція — реєструє ScenePost (той самий список ефектів)
        ScenePost.shaders();
    }

    /** Текст по літерах зі зсувом кожної (хвиля, тремтіння). */
    private interface LetterFx { float[] offset(int i, double t); }

    private static void letters(GuiGraphics g, int w, int h, SceneFrame.Overlay o, float a, LetterFx fx) {
        String t = str(o.params, "text", "Текст");
        Font f = font();
        float s = (float) (o.scale * 3);
        float x = (float) (w * o.x) - f.width(t) * s / 2;
        double now = now();
        int c = argb(a, col(o.params, "color", 0xFFFFFF));
        for (int i = 0; i < t.length(); i++) {
            String ch = String.valueOf(t.charAt(i));
            float[] off = fx.offset(i, now);
            g.pose().pushPose();
            g.pose().translate(x + off[0] * s, (float) (h * o.y) + off[1] * s, 0);
            g.pose().scale(s, s, 1);
            g.drawString(f, ch, 0, -4, c, true);
            g.pose().popPose();
            x += f.width(ch) * s;
        }
    }
}
