package dev.shaurmalib.scene.mc.client;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.shaurmalib.scene.doc.Transition;
import dev.shaurmalib.scene.eval.SceneFrame;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;

import java.util.Random;

/**
 * Композитор поверх кадру: ефекти, оверлеї, ефекти склейок (технологія мафії: dip, flash, glitch,
 * shutter, wipe, zoom-punch, crossfade зі знімком кадру), кіно-смуги, затемнення входу/виходу.
 * Порядок шарів: ефекти → оверлеї → склейка → смуги → fade.
 */
public final class SceneHud {

    private SceneHud() {}

    private static DynamicTexture snapTex;
    private static ResourceLocation snapId;
    private static int snapW, snapH;
    private static boolean wantSnap;
    private static Transition.Type lastFx;
    private static double lastU;

    /** Перед HUD (чистий кадр світу): зробити знімок для CROSSFADE, якщо склейка от-от. */
    public static void beforeHud() {
        if (!wantSnap) return;
        wantSnap = false;
        try {
            NativeImage img = Screenshot.takeScreenshot(Minecraft.getInstance().getMainRenderTarget());
            releaseSnap();
            snapW = img.getWidth();
            snapH = img.getHeight();
            snapTex = new DynamicTexture(img);
            snapId = Minecraft.getInstance().getTextureManager().register("shaurma_scene_snap", snapTex);
        } catch (RuntimeException e) {
            releaseSnap();
        }
    }

    private static void releaseSnap() {
        if (snapId != null) Minecraft.getInstance().getTextureManager().release(snapId);
        snapId = null;
        snapTex = null;
    }

    /** HUD кадру сесії, що веде камеру (і оверлеї/ефекти всіх сесій). */
    public static void render(GuiGraphics g, float partial) {
        SceneClient.Active cine = SceneClient.cinematic();
        int w = g.guiWidth(), h = g.guiHeight();
        for (SceneClient.Active a : SceneClient.active()) {
            if (a.playback.inPreroll()) continue;
            layers(g, w, h, a.frame);
        }
        if (cine != null) composite(g, w, h, cine.frame, true);
    }

    /** Ефекти та оверлеї кадру (також для превʼю в редакторі). */
    public static void layers(GuiGraphics g, int w, int h, SceneFrame f) {
        for (SceneFrame.Effect e : f.effects) {
            SceneOverlays.EffectRenderer r = SceneOverlays.effect(e.id);
            if (r != null && e.intensity > 0.002) try { r.render(g, w, h, e); } catch (RuntimeException ignored) { }
        }
        for (SceneFrame.Overlay o : f.overlays) {
            SceneOverlays.OverlayRenderer r = SceneOverlays.overlay(o.id);
            if (r == null) continue;
            float alpha = (float) (o.opacity * Math.min(ease(o.enter), ease(o.exit)));
            if (alpha <= 0.003f) continue;
            g.pose().pushPose();
            double appear = Math.min(o.enter, o.exit);
            String kind = o.enter < 1 ? o.enterType : o.exitType;
            if ("slide".equals(kind)) g.pose().translate(0, (1 - ease(appear)) * h * 0.08, 0);
            else if ("scale".equals(kind)) {
                float s = (float) (0.7 + 0.3 * ease(appear));
                g.pose().translate(w * o.x, h * o.y, 0);
                g.pose().scale(s, s, 1);
                g.pose().translate(-w * o.x, -h * o.y, 0);
            }
            try { r.render(g, w, h, o, alpha); } catch (RuntimeException ignored) { }
            g.pose().popPose();
        }
    }

    /** Склейки, смуги, затемнення. @param live false — превʼю редактора (без знімка кадру) */
    public static void composite(GuiGraphics g, int w, int h, SceneFrame f, boolean live) {
        if (f.fx != null) fx(g, w, h, f, live);
        else if (live && (lastFx == Transition.Type.CROSSFADE || lastFx == Transition.Type.PUSH_LEFT || lastFx == Transition.Type.PUSH_UP)) releaseSnap();
        lastFx = f.fx;
        lastU = f.fxU;
        int bar = (int) Math.round(h * f.letterbox);
        if (bar > 0) {
            g.fill(0, 0, w, bar, 0xFF000000);
            g.fill(0, h - bar, w, h, 0xFF000000);
        }
        if (f.fade > 0.002) g.fill(0, 0, w, h, argb((float) f.fade, 0));
    }

    private static void fx(GuiGraphics g, int w, int h, SceneFrame f, boolean live) {
        float u = (float) f.fxU;
        switch (f.fx) {
            case FADE_BLACK -> fill(g, w, h, 0, smooth(bump(u)));
            case DIP_COLOR -> fill(g, w, h, f.fxColor, smooth(bump(u)));
            case FLASH -> {
                float a = u < 0.18f ? u / 0.18f : (float) Math.pow(1f - (u - 0.18f) / 0.82f, 1.6);
                fill(g, w, h, f.fxColor == 0 ? 0xFFF4E0 : f.fxColor, a);
            }
            case SHUTTER -> {
                int half = Math.round(h / 2f * smooth(bump(u)));
                g.fill(0, 0, w, half, 0xFF000000);
                g.fill(0, h - half, w, h, 0xFF000000);
                if (half > 2 && half < h / 2 - 2) {
                    g.fill(0, half, w, half + 1, argb(0.55f, 0xFFFFFF));
                    g.fill(0, h - half - 1, w, h - half, argb(0.55f, 0xFFFFFF));
                }
            }
            case WIPE -> {
                int left, right;
                if (u < 0.5f) { left = 0; right = Math.round(w * smooth(u / 0.5f)); }
                else { left = Math.round(w * smooth((u - 0.5f) / 0.5f)); right = w; }
                g.fill(left, 0, right, h, 0xFF000000);
                int edge = u < 0.5f ? right : left;
                g.fill(Math.max(0, edge - 2), 0, Math.min(w, edge + 2), h, argb(0.85f, 0xFFFFFF));
            }
            case GLITCH -> glitch(g, w, h, bump(u));
            case ZOOM_PUNCH -> fill(g, w, h, 0xFFFFFF, 0.5f * smooth(bump(u)) * smooth(bump(u)));
            case WHIP_PAN -> {
                float k = bump(u);
                Random r = new Random(7);
                for (int i = 0; i < 40 * k; i++) {
                    int y = r.nextInt(Math.max(1, h)), len = (int) (w * (0.3 + 0.7 * r.nextFloat()) * k);
                    int x = r.nextInt(Math.max(1, w));
                    g.fill(x - len / 2, y, x + len / 2, y + 1 + r.nextInt(3), argb(0.25f * k, 0xFFFFFF));
                }
                fill(g, w, h, 0, 0.35f * k * k);
            }
            case WIPE_UP -> {
                int top, bot;
                if (u < 0.5f) { bot = h; top = h - Math.round(h * smooth(u / 0.5f)); }
                else { top = 0; bot = h - Math.round(h * smooth((u - 0.5f) / 0.5f)); }
                g.fill(0, top, w, bot, 0xFF000000);
            }
            case WIPE_DIAGONAL -> {
                // перша половина: чорне наповзає з лівого верхнього кута; друга — йде в правий нижній
                int span = w + h;
                for (int y = 0; y < h; y += 2) {
                    if (u < 0.5f) {
                        int edge = Math.round(span * smooth(u / 0.5f)) - y;
                        if (edge > 0) g.fill(0, y, Math.min(w, edge), y + 2, 0xFF000000);
                    } else {
                        int edge = Math.round(span * smooth((u - 0.5f) / 0.5f)) - y;
                        g.fill(Math.max(0, edge), y, w, y + 2, 0xFF000000);
                    }
                }
            }
            case IRIS -> {
                float k = smooth(bump(u));
                double maxR = Math.hypot(w, h) / 2, r = maxR * (1 - k);
                int cx = w / 2, cy = h / 2;
                for (int y = 0; y < h; y += 2) {
                    double dy = y - cy;
                    if (Math.abs(dy) >= r) { g.fill(0, y, w, y + 2, 0xFF000000); continue; }
                    int half = (int) Math.sqrt(r * r - dy * dy);
                    g.fill(0, y, Math.max(0, cx - half), y + 2, 0xFF000000);
                    g.fill(Math.min(w, cx + half), y, w, y + 2, 0xFF000000);
                }
            }
            case BLINDS -> {
                float k = smooth(bump(u));
                int n = 10, bh = h / n + 1;
                for (int i = 0; i < n; i++) g.fill(0, i * bh, w, i * bh + Math.round(bh * k), 0xFF000000);
            }
            case SPLIT_DOOR -> {
                int half = Math.round(w / 2f * smooth(bump(u)));
                g.fill(0, 0, half, h, 0xFF000000);
                g.fill(w - half, 0, w, h, 0xFF000000);
            }
            case PIXEL_BLOCKS -> {
                float k = bump(u);
                int bs = Math.max(6, w / 24);
                Random r = new Random(11);
                for (int y = 0; y < h; y += bs) for (int x = 0; x < w; x += bs) if (r.nextFloat() < k * 1.05f) g.fill(x, y, x + bs, y + bs, 0xFF000000);
            }
            case RGB_SPLIT -> {
                float k = bump(u);
                Random r = new Random((System.currentTimeMillis() / 50L) * 31L);
                for (int i = 0; i < 12 * k; i++) {
                    int y = r.nextInt(Math.max(1, h)), sh = 2 + r.nextInt(Math.max(2, h / 12));
                    g.fill(0, y, w, Math.min(h, y + sh), argb(0.35f * k, i % 2 == 0 ? 0xFF0040 : 0x00E5FF));
                }
                fill(g, w, h, 0xFFFFFF, 0.25f * k * k);
            }
            case FILM_BURN -> {
                float k = smooth(bump(u));
                RenderSystem.enableBlend();
                RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SourceFactor.SRC_ALPHA, com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE);
                g.fillGradient(0, 0, w, h, argb(k * 0.9f, 0xFF6A10), argb(k * 0.6f, 0xFFD040));
                g.fill(0, 0, w, h, argb(k * k * 0.8f, 0xFFF0D0));
                RenderSystem.defaultBlendFunc();
            }
            case LIGHT_LEAK -> {
                float k = smooth(bump(u));
                RenderSystem.enableBlend();
                RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SourceFactor.SRC_ALPHA, com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE);
                int x0 = Math.round(w * (u - 0.3f));
                g.fill(Math.max(0, x0), 0, Math.min(w, x0 + w / 2), h, argb(k * 0.5f, 0xFF8A3C));
                g.fill(0, 0, w, h, argb(k * 0.35f, 0xFFE0B0));
                RenderSystem.defaultBlendFunc();
            }
            case SPIN, ZOOM_OUT, SHAKE -> fill(g, w, h, 0xFFFFFF, 0.25f * bump(u) * bump(u));
            case BLUR_DIP -> fill(g, w, h, 0x808890, 0.85f * smooth(bump(u)));
            case INK -> {
                float k = smooth(bump(u));
                Random r = new Random(23);
                for (int i = 0; i < 26; i++) {
                    int cx = r.nextInt(Math.max(1, w)), cy = r.nextInt(Math.max(1, h));
                    double rr = (Math.max(w, h) * 0.22) * k * (0.6 + r.nextFloat());
                    for (int y = (int) -rr; y < rr; y += 2) {
                        int half = (int) Math.sqrt(rr * rr - y * y);
                        g.fill(cx - half, cy + y, cx + half, cy + y + 2, 0xFF050505);
                    }
                }
            }
            case PUSH_LEFT, PUSH_UP -> {
                boolean left = f.fx == Transition.Type.PUSH_LEFT;
                if (!live || snapId == null) {
                    if (u < 0.5f && u > 0.38f && live) wantSnap = true;
                    float k = smooth(bump(u));
                    if (left) g.fill(w - Math.round(w * k * 0.5f), 0, w, h, argb(0.6f * k, 0)); else g.fill(0, h - Math.round(h * k * 0.5f), w, h, argb(0.6f * k, 0));
                    break;
                }
                if (u < 0.5f && u > 0.38f) wantSnap = true;
                if (u >= 0.5f) {
                    float k = smooth((u - 0.5f) / 0.5f);
                    int dx = left ? -Math.round(w * k) : 0, dy = left ? 0 : -Math.round(h * k);
                    RenderSystem.enableBlend();
                    g.blit(snapId, dx, dy, w, h, 0f, 0f, snapW, snapH, snapW, snapH);
                }
            }
            case CROSSFADE -> {
                if (!live) { fill(g, w, h, 0, 0.25f * bump(u)); break; }
                if (u < 0.5f && u > 0.38f) wantSnap = true;               // кілька кадрів поспіль «фотографуємо» — лишається останній
                if (u >= 0.5f && snapId != null) {
                    float a = 1f - smooth((u - 0.5f) / 0.5f);
                    RenderSystem.enableBlend();
                    RenderSystem.defaultBlendFunc();
                    RenderSystem.setShaderColor(1f, 1f, 1f, a);
                    g.blit(snapId, 0, 0, w, h, 0f, 0f, snapW, snapH, snapW, snapH);
                    RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
                }
            }
            default -> { }
        }
    }

    /** Мініатюра переходу для бібліотеки: той самий композитор на прогресі u (без знімка кадру). */
    public static void transitionPreview(GuiGraphics g, int w, int h, Transition.Type type, float u, int color) {
        SceneFrame f = new SceneFrame();
        f.fx = type;
        f.fxU = u;
        f.fxColor = color;
        fx(g, w, h, f, false);
    }

    private static void glitch(GuiGraphics g, int w, int h, float k) {
        Random r = new Random((System.currentTimeMillis() / 45L) * 7919L);
        int strips = 5 + Math.round(18 * k);
        int[] pal = { 0x00E5FF, 0xFF2BD6, 0x000000, 0xFFFFFF, 0x1AFF6A };
        for (int i = 0; i < strips; i++) {
            int y = r.nextInt(Math.max(1, h)), sh = 2 + r.nextInt(Math.max(3, Math.round(h * 0.06f * k) + 3));
            int x0 = r.nextInt(Math.max(1, w / 3)) - w / 8, x1 = w - r.nextInt(Math.max(1, w / 3)) + w / 8;
            g.fill(Math.max(0, x0), y, Math.min(w, x1), Math.min(h, y + sh), argb(0.30f + 0.55f * k, pal[r.nextInt(pal.length)]));
        }
        fill(g, w, h, 0, 0.55f * k * k * k);
    }

    private static void fill(GuiGraphics g, int w, int h, int rgb, float a) {
        if (a > 0.003f) g.fill(0, 0, w, h, argb(a, rgb));
    }

    static int argb(float a, int rgb) { return SceneOverlays.argb(a, rgb); }

    private static float bump(float u) { return 1f - Math.abs(2f * u - 1f); }

    private static float smooth(float t) { t = Math.max(0f, Math.min(1f, t)); return t * t * (3f - 2f * t); }

    private static double ease(double t) { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); }
}
