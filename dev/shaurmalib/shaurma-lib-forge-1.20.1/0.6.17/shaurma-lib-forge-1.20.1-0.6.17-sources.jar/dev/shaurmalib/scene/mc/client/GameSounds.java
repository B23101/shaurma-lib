package dev.shaurmalib.scene.mc.client;

import dev.shaurmalib.scene.io.AudioPcm;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.Sound;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.WeighedSoundEvents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.RandomSource;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Звуки гри (ваніль, моди, ресурспаки) як повноцінне джерело для звукових кліпів — як у Shaurma Modeling
 * («підказки /playsound»): список усіх подій, категорії, прослуховування; а для таймлайну — справжній PCM
 * з .ogg ресурспака (хвиля, тривалість, перемотка, trim), а не разовий «пук» на старті кліпу.
 * <p>Посилання в кліпі: {@code sound:minecraft:entity.zombie.ambient}; варіант (якщо подія має кілька файлів) —
 * параметр кліпу {@code variant}.
 */
public final class GameSounds {

    private GameSounds() {}

    public static final String PREFIX = "sound:";

    private static List<String> all;
    private static final Map<String, AudioPcm> PCM = new ConcurrentHashMap<>();
    private static final Map<String, Double> DURATION = new ConcurrentHashMap<>();
    private static final java.util.Set<String> PENDING = ConcurrentHashMap.newKeySet(), FAILED = ConcurrentHashMap.newKeySet();
    private static final ExecutorService DECODER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "shaurma-scene-sounds");
        t.setDaemon(true);
        return t;
    });

    public static boolean isGame(String ref) { return ref != null && ref.startsWith(PREFIX); }

    public static String id(String ref) { return isGame(ref) ? ref.substring(PREFIX.length()) : ref; }

    /** Усі звукові події, які знає гра, за алфавітом. */
    public static List<String> all() {
        if (all == null) {
            List<String> l = new ArrayList<>();
            for (ResourceLocation r : Minecraft.getInstance().getSoundManager().getAvailableSounds()) l.add(r.toString());
            Collections.sort(l);
            all = l;
        }
        return all;
    }

    /** Категорія звуку для бібліотеки (як папки в CapCut «Звукові ефекти»). */
    public static String category(String id) {
        String ns = id.contains(":") ? id.substring(0, id.indexOf(':')) : "minecraft";
        String p = id.substring(id.indexOf(':') + 1);
        if (!"minecraft".equals(ns)) return "mod:" + ns;
        if (p.startsWith("music_disc.") || p.startsWith("music.")) return "music";
        if (p.startsWith("entity.player.") || p.startsWith("entity.generic.")) return "player";
        if (p.startsWith("entity.")) return "mobs";
        if (p.startsWith("block.")) return "blocks";
        if (p.startsWith("item.")) return "items";
        if (p.startsWith("ambient.") || p.startsWith("weather.")) return "ambient";
        if (p.startsWith("ui.") || p.startsWith("event.") || p.startsWith("enchant.")) return "ui";
        if (p.startsWith("particle.")) return "ambient";
        return "other";
    }

    public static String categoryTitle(String cat) {
        if (cat.startsWith("mod:")) return "Мод " + cat.substring(4);
        return switch (cat) {
            case "music" -> "Музика гри";
            case "player" -> "Гравець";
            case "mobs" -> "Моби";
            case "blocks" -> "Блоки";
            case "items" -> "Предмети";
            case "ambient" -> "Атмосфера";
            case "ui" -> "Інтерфейс";
            default -> "Інше";
        };
    }

    /** Гарна назва: {@code entity.zombie.ambient} → «zombie · ambient». */
    public static String pretty(String id) {
        String p = id.substring(id.indexOf(':') + 1);
        String[] parts = p.split("\\.");
        int from = parts.length > 1 && (parts[0].equals("entity") || parts[0].equals("block") || parts[0].equals("item")
            || parts[0].equals("ambient") || parts[0].equals("music") || parts[0].equals("ui")) ? 1 : 0;
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < parts.length; i++) { if (sb.length() > 0) sb.append(" · "); sb.append(parts[i].replace('_', ' ')); }
        return sb.toString();
    }

    private static String key(String id, int variant) { return id + "#" + variant; }

    /** Файл варіанта звукової події (детерміновано за номером варіанта). */
    private static ResourceLocation file(String id, int variant) {
        ResourceLocation rl = ResourceLocation.tryParse(id);
        if (rl == null) return null;
        WeighedSoundEvents ev = Minecraft.getInstance().getSoundManager().getSoundEvent(rl);
        if (ev == null) return null;
        Sound s = ev.getSound(RandomSource.create(31L * variant + 7));
        if (s == null || s.getType() != Sound.Type.FILE) return null;
        return s.getPath();
    }

    /**
     * PCM звуку гри; null — ще декодується у фоні (кличте щокадру) або не вдалося. {@code sync} — декодувати
     * одразу (при додаванні кліпу, щоб знати довжину).
     */
    public static AudioPcm pcm(String id, int variant, boolean sync) {
        String k = key(id, variant);
        AudioPcm p = PCM.get(k);
        if (p != null || FAILED.contains(k)) return p;
        if (sync) return decode(id, variant);
        if (PENDING.add(k)) {
            ResourceLocation f;
            try { f = file(id, variant); } catch (RuntimeException e) { f = null; }
            if (f == null) { FAILED.add(k); PENDING.remove(k); return null; }
            ResourceLocation file = f;
            DECODER.submit(() -> { try { load(k, file); } finally { PENDING.remove(k); } });
        }
        return null;
    }

    private static AudioPcm decode(String id, int variant) {
        String k = key(id, variant);
        ResourceLocation f;
        try { f = file(id, variant); } catch (RuntimeException e) { f = null; }
        if (f == null) { FAILED.add(k); return null; }
        return load(k, f);
    }

    private static AudioPcm load(String k, ResourceLocation file) {
        try {
            Optional<Resource> res = Minecraft.getInstance().getResourceManager().getResource(file);
            if (res.isEmpty()) { FAILED.add(k); return null; }
            byte[] bytes;
            try (InputStream in = res.get().open()) { bytes = in.readAllBytes(); }
            AudioPcm p = SceneAssets.decode(bytes, "ogg");
            PCM.put(k, p);
            DURATION.put(k, p.duration());
            return p;
        } catch (Exception | LinkageError e) {
            FAILED.add(k);
            return null;
        }
    }

    /** Тривалість, якщо вже відома (інакше запускає фонове декодування й повертає -1). */
    public static double duration(String id, int variant) {
        Double d = DURATION.get(key(id, variant));
        if (d != null) return d;
        pcm(id, variant, false);
        return -1;
    }

    // ── прослуховування в бібліотеці ──

    private static SoundInstance preview;
    private static String previewId;
    private static long previewStarted;

    public static void play(String id, float volume, float pitch) {
        stopPreview();
        ResourceLocation rl = ResourceLocation.tryParse(id);
        if (rl == null) return;
        preview = SimpleSoundInstance.forUI(SoundEvent.createVariableRangeEvent(rl), pitch, volume);
        previewId = id;
        previewStarted = System.nanoTime();
        Minecraft.getInstance().getSoundManager().play(preview);
    }

    public static void stopPreview() {
        if (preview != null) Minecraft.getInstance().getSoundManager().stop(preview);
        preview = null;
        previewId = null;
    }

    public static boolean previewing(String id) {
        if (preview == null || !id.equals(previewId)) return false;
        if (!Minecraft.getInstance().getSoundManager().isActive(preview)) {
            // звук ще може «розігріватися» перші кадри
            if (System.nanoTime() - previewStarted > 400_000_000L) { preview = null; previewId = null; return false; }
        }
        return true;
    }

    /** Секунди з початку прослуховування (для смуги прогресу). */
    public static double previewPosition() { return preview == null ? 0 : (System.nanoTime() - previewStarted) / 1e9; }

    public static String search(String s) { return s == null ? "" : s.toLowerCase(Locale.ROOT).strip(); }
}
