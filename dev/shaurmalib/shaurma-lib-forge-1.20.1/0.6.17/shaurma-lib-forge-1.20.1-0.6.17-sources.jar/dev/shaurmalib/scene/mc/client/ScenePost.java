package dev.shaurmalib.scene.mc.client;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.mc.mixin.PostChainAccessor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.EffectInstance;
import net.minecraft.client.renderer.PostChain;
import net.minecraft.client.renderer.PostPass;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Справжні шейдерні ефекти кадру — фільтри (кольорова матриця), корекція (яскравість/контраст/насиченість/температура),
 * розмиття, NTSC, фосфор, олівець тощо. Працюють на ванільних пост-шейдерах ({@code minecraft:shaders/post/*}), тож
 * не потребують ресурсів мода; uniform-и задаються щокадру — сила кліпу плавно змішує з оригіналом.
 * <p>Застосовуються після рендеру світу, до HUD/GUI (хук у {@code MixinSceneGameRenderer}): у грі — кадр сцени,
 * що веде камеру; у редакторі — коли в'юпорт дивиться крізь камеру або йде перегляд.
 */
public final class ScenePost {

    private ScenePost() {}

    /** Як задати uniform-и проходу за силою (0..1) і параметрами кліпу. */
    @FunctionalInterface
    public interface Uniforms { void apply(EffectInstance fx, int passIndex, double k, Map<String, Object> params); }

    public record Shader(String id, String title, String category, ResourceLocation post, Uniforms uniforms, double minK) {}

    private static final Map<String, Shader> SHADERS = new LinkedHashMap<>();
    private static final Map<String, PostChain> CHAINS = new HashMap<>();
    private static final Set<String> BROKEN = new HashSet<>();
    private static int chainW, chainH;

    /** Кадр, який зараз показує редактор (null — редактор не дивиться крізь камеру). */
    public static SceneFrame editorFrame;

    public static Map<String, Shader> shaders() { return SHADERS; }

    public static boolean isShader(String id) { return SHADERS.containsKey(id); }

    /** Зареєструвати шейдерний ефект: у бібліотеці він з'являється разом з 2D-ефектами (категорія — вкладка). */
    public static void register(String id, String title, String category, String vanillaPost, double minK, Uniforms u) {
        SHADERS.put(id, new Shader(id, title, category, new ResourceLocation("minecraft", "shaders/post/" + vanillaPost + ".json"), u, minK));
        SceneOverlays.effect(id, title, category, (g, w, h, e) -> { });
    }

    // ═════════════════════ кольорова матриця (color_convolve) ═════════════════════

    /** Кольорова «оцінка» кадру: матриця 3×3 (рядки R, G, B), зсув, множник, насиченість. */
    public record Grade(float[] r, float[] g, float[] b, float[] offset, float[] scale, float saturation) {
        public static Grade identity() {
            return new Grade(new float[] { 1, 0, 0 }, new float[] { 0, 1, 0 }, new float[] { 0, 0, 1 }, new float[3], new float[] { 1, 1, 1 }, 1);
        }

        /** Застосувати до кольору 0xRRGGBB (для мініатюр у бібліотеці — та сама математика, що в шейдері). */
        public int apply(int rgb) {
            float R = ((rgb >> 16) & 255) / 255f, G = ((rgb >> 8) & 255) / 255f, B = (rgb & 255) / 255f;
            float r2 = R * r[0] + G * r[1] + B * r[2], g2 = R * g[0] + G * g[1] + B * g[2], b2 = R * b[0] + G * b[1] + B * b[2];
            r2 = (r2 + offset[0]) * scale[0]; g2 = (g2 + offset[1]) * scale[1]; b2 = (b2 + offset[2]) * scale[2];
            float luma = r2 * 0.3f + g2 * 0.59f + b2 * 0.11f;
            r2 = (r2 - luma) * saturation + luma; g2 = (g2 - luma) * saturation + luma; b2 = (b2 - luma) * saturation + luma;
            return (c(r2) << 16) | (c(g2) << 8) | c(b2);
        }

        private static int c(float v) { return Math.max(0, Math.min(255, Math.round(v * 255))); }

        public Grade lerp(double k) {
            Grade i = identity();
            float f = (float) k;
            return new Grade(mix(i.r, r, f), mix(i.g, g, f), mix(i.b, b, f), mix(i.offset, offset, f), mix(i.scale, scale, f), 1 + (saturation - 1) * f);
        }

        private static float[] mix(float[] a, float[] b, float f) { return new float[] { a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f }; }
    }

    /** Корекція з параметрів кліпу: brightness, contrast, saturation, temperature, tint, exposure (усе навколо 0, saturation/contrast — 1). */
    public static Grade adjust(Map<String, Object> p) {
        float br = (float) num(p, "brightness", 0), ct = (float) num(p, "contrast", 1), sat = (float) num(p, "saturation", 1);
        float temp = (float) num(p, "temperature", 0), tint = (float) num(p, "tint", 0), exp = (float) num(p, "exposure", 0);
        float e = (float) Math.pow(2, exp);
        // контраст навколо 0.5: (x - 0.5) * c + 0.5 = x*c + 0.5(1-c)  → offset до множення: 0.5(1-c)/c
        float off = ct == 0 ? 0 : 0.5f * (1 - ct) / ct + br / Math.max(0.05f, ct);
        float[] scale = { ct * e * (1 + temp * 0.18f), ct * e * (1 + tint * 0.12f), ct * e * (1 - temp * 0.18f) };
        return new Grade(new float[] { 1, 0, 0 }, new float[] { 0, 1, 0 }, new float[] { 0, 0, 1 }, new float[] { off, off, off }, scale, sat);
    }

    public static double num(Map<String, Object> p, String k, double def) {
        Object o = p == null ? null : p.get(k);
        if (o instanceof Number n) return n.doubleValue();
        if (o instanceof String s) { try { return Double.parseDouble(s); } catch (NumberFormatException ignored) { } }
        return def;
    }

    private static void grade(EffectInstance fx, Grade g) {
        fx.safeGetUniform("RedMatrix").set(g.r[0], g.r[1], g.r[2]);
        fx.safeGetUniform("GreenMatrix").set(g.g[0], g.g[1], g.g[2]);
        fx.safeGetUniform("BlueMatrix").set(g.b[0], g.b[1], g.b[2]);
        fx.safeGetUniform("Offset").set(g.offset[0], g.offset[1], g.offset[2]);
        fx.safeGetUniform("ColorScale").set(g.scale[0], g.scale[1], g.scale[2]);
        fx.safeGetUniform("Saturation").set(g.saturation);
    }

    /** Фільтр-пресет (вкладка «Фільтри»): матриця, що змішується з оригіналом за силою кліпу. */
    public static final Map<String, Grade> FILTERS = new LinkedHashMap<>();

    private static void filter(String id, String title, String cat, Grade g) {
        FILTERS.put(id, g);
        register(id, title, cat, "color_convolve", 0.002, (fx, i, k, p) -> { if (i == 0) grade(fx, g.lerp(k)); });
    }

    private static Grade m(float[] r, float[] g, float[] b, float off, float[] scale, float sat) {
        return new Grade(r, g, b, new float[] { off, off, off }, scale, sat);
    }

    private static float[] v(float a, float b, float c) { return new float[] { a, b, c }; }

    static {
        float[] I = v(1, 1, 1);
        // ── Фільтри (CapCut: Life / Movies / Retro / Mono / Night…) ──
        filter("shaurma_lib:f_warm", "Тепло", "filter:life", m(v(1.08f, 0.04f, 0), v(0.02f, 1.0f, 0), v(0, 0, 0.86f), 0.01f, I, 1.05f));
        filter("shaurma_lib:f_cold", "Холод", "filter:life", m(v(0.88f, 0, 0), v(0, 1.0f, 0.04f), v(0, 0.06f, 1.12f), 0, I, 0.95f));
        filter("shaurma_lib:f_vivid", "Соковито", "filter:life", m(v(1, 0, 0), v(0, 1, 0), v(0, 0, 1), -0.03f, v(1.08f, 1.08f, 1.08f), 1.45f));
        filter("shaurma_lib:f_pastel", "Пастель", "filter:life", m(v(0.9f, 0.05f, 0.05f), v(0.05f, 0.9f, 0.05f), v(0.05f, 0.05f, 0.9f), 0.1f, I, 0.7f));
        filter("shaurma_lib:f_faded", "Вицвіле", "filter:life", m(v(1, 0, 0), v(0, 1, 0), v(0, 0, 1), 0.08f, v(0.86f, 0.86f, 0.9f), 0.72f));
        filter("shaurma_lib:f_sunset", "Захід сонця", "filter:landscape", m(v(1.15f, 0.08f, 0), v(0.05f, 0.92f, 0), v(0, 0, 0.78f), 0.02f, I, 1.2f));
        filter("shaurma_lib:f_forest", "Ліс", "filter:landscape", m(v(0.92f, 0.05f, 0), v(0, 1.08f, 0), v(0, 0.05f, 0.9f), 0, I, 1.15f));
        filter("shaurma_lib:f_ice", "Лід", "filter:landscape", m(v(0.82f, 0.1f, 0.1f), v(0.05f, 0.95f, 0.1f), v(0.05f, 0.1f, 1.15f), 0.04f, I, 0.8f));
        filter("shaurma_lib:f_teal_orange", "Teal & Orange", "filter:movies", m(v(1.1f, 0.05f, -0.05f), v(0, 1.0f, 0.04f), v(-0.05f, 0.1f, 1.08f), -0.02f, v(1.05f, 1.0f, 1.0f), 1.25f));
        filter("shaurma_lib:f_matrix", "Матриця", "filter:movies", m(v(0.75f, 0.1f, 0), v(0.1f, 1.05f, 0.05f), v(0, 0.1f, 0.75f), -0.02f, I, 0.85f));
        filter("shaurma_lib:f_blockbuster", "Блокбастер", "filter:movies", m(v(1.05f, 0, 0), v(0, 1, 0), v(0, 0.05f, 1.1f), -0.06f, v(1.12f, 1.1f, 1.12f), 1.1f));
        filter("shaurma_lib:f_horror", "Жах", "filter:movies", m(v(0.9f, 0.05f, 0.05f), v(0.05f, 0.95f, 0.05f), v(0.05f, 0.1f, 0.95f), -0.08f, v(1.15f, 1.1f, 1.1f), 0.45f));
        filter("shaurma_lib:f_blood", "Кривавий", "filter:movies", m(v(1.2f, 0.1f, 0.1f), v(0, 0.75f, 0), v(0, 0, 0.75f), -0.05f, v(1.1f, 1, 1), 0.9f));
        filter("shaurma_lib:f_sepia", "Сепія", "filter:retro", m(v(0.393f, 0.769f, 0.189f), v(0.349f, 0.686f, 0.168f), v(0.272f, 0.534f, 0.131f), 0, I, 1));
        filter("shaurma_lib:f_vintage", "Вінтаж", "filter:retro", m(v(0.9f, 0.1f, 0.05f), v(0.05f, 0.85f, 0.05f), v(0.05f, 0.1f, 0.7f), 0.06f, v(0.95f, 0.92f, 0.85f), 0.75f));
        filter("shaurma_lib:f_polaroid", "Полароїд", "filter:retro", m(v(1.0f, 0.1f, -0.05f), v(-0.05f, 1.0f, 0.05f), v(0.05f, -0.05f, 0.9f), 0.04f, v(1.02f, 1.0f, 0.95f), 0.9f));
        filter("shaurma_lib:f_kodak", "Плівка 70-х", "filter:retro", m(v(1.05f, 0.08f, 0), v(0.02f, 0.95f, 0.02f), v(0, 0.05f, 0.8f), 0.05f, v(1.0f, 0.97f, 0.9f), 0.85f));
        filter("shaurma_lib:f_bw", "Ч/Б", "filter:mono", m(v(1, 0, 0), v(0, 1, 0), v(0, 0, 1), 0, I, 0));
        filter("shaurma_lib:f_noir", "Нуар", "filter:mono", m(v(1, 0, 0), v(0, 1, 0), v(0, 0, 1), -0.12f, v(1.3f, 1.3f, 1.3f), 0));
        filter("shaurma_lib:f_silver", "Срібло", "filter:mono", m(v(1, 0, 0), v(0, 1, 0), v(0, 0, 1), 0.06f, v(0.95f, 0.97f, 1.02f), 0.08f));
        filter("shaurma_lib:f_night", "Ніч", "filter:night", m(v(0.6f, 0.05f, 0.05f), v(0.05f, 0.7f, 0.1f), v(0.1f, 0.15f, 1.1f), -0.06f, v(0.8f, 0.85f, 1.0f), 0.7f));
        filter("shaurma_lib:f_nightvision", "Нічне бачення", "filter:night", m(v(0.1f, 0.3f, 0.05f), v(0.3f, 0.9f, 0.2f), v(0.05f, 0.2f, 0.05f), 0.04f, v(0.6f, 1.4f, 0.6f), 1));
        filter("shaurma_lib:f_neon", "Неон", "filter:night", m(v(1.1f, 0, 0.15f), v(0, 0.9f, 0.1f), v(0.15f, 0, 1.15f), -0.04f, v(1.1f, 1.0f, 1.1f), 1.6f));
        filter("shaurma_lib:f_invert", "Негатив", "filter:night", m(v(-1, 0, 0), v(0, -1, 0), v(0, 0, -1), -1, v(-1, -1, -1), 1));

        // ── Корекція (CapCut «Adjustment»): параметри кліпу ──
        register("shaurma_lib:adjust", "Корекція кольору", "adjust", "color_convolve", 0.002,
            (fx, i, k, p) -> { if (i == 0) grade(fx, adjust(p).lerp(k)); });

        // ── Шейдерні ефекти (вкладка «Ефекти → Шейдери») ──
        register("shaurma_lib:sh_blur", "Розмиття", "fx:shader", "blur", 0.01, (fx, i, k, p) -> fx.safeGetUniform("Radius").set((float) (Math.max(0.5, k * num(p, "radius", 12)))));
        register("shaurma_lib:sh_ntsc", "Телевізор NTSC", "fx:shader", "ntsc", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_phosphor", "Фосфор (шлейф)", "fx:shader", "phosphor", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_pencil", "Олівець", "fx:shader", "pencil", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_sobel", "Контури", "fx:shader", "sobel", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_art", "Мазки фарби", "fx:shader", "art", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_bits", "Пікселі (8-біт)", "fx:shader", "bits", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_wobble", "Хвилі", "fx:shader", "wobble", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_deconverge", "Розфокус RGB", "fx:shader", "deconverge", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_bumpy", "Рельєф", "fx:shader", "bumpy", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_blobs", "Плями", "fx:shader", "blobs", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_lens", "Лінза CRT", "fx:shader", "scan_pincushion", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_flip", "Перевернути", "fx:shader", "flip", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_green", "Зелений монітор", "fx:shader", "green", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_notch", "Ретро-палітра", "fx:shader", "notch", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_creeper", "Очі кріпера", "fx:shader", "creeper", 0.5, (fx, i, k, p) -> { });
        register("shaurma_lib:sh_spider", "Очі павука", "fx:shader", "spider", 0.5, (fx, i, k, p) -> { });
    }

    // ═════════════════════ застосування ═════════════════════

    /** Після рендеру світу (до GUI): прогнати шейдери кадру сцени. */
    public static void apply(float partial) {
        SceneFrame f = editorFrame;
        if (f == null) {
            SceneClient.Active cine = SceneClient.cinematic();
            if (cine != null && !cine.playback.inPreroll()) f = cine.frame;
        }
        if (f == null || f.effects.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        RenderTarget main = mc.getMainRenderTarget();
        if (main.width != chainW || main.height != chainH) {
            chainW = main.width; chainH = main.height;
            for (PostChain c : CHAINS.values()) c.resize(chainW, chainH);
        }
        boolean any = false;
        for (SceneFrame.Effect e : f.effects) {
            Shader sh = SHADERS.get(e.id);
            if (sh == null || e.intensity < sh.minK()) continue;
            PostChain chain = chain(sh);
            if (chain == null) continue;
            int i = 0;
            for (PostPass p : ((PostChainAccessor) chain).shaurma$passes()) {
                try { sh.uniforms().apply(p.getEffect(), i, Math.min(1, e.intensity), e.params); } catch (RuntimeException ignored) { }
                i++;
            }
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.resetTextureMatrix();
            chain.process(partial);
            any = true;
        }
        if (any) main.bindWrite(true);
    }

    private static PostChain chain(Shader sh) {
        PostChain c = CHAINS.get(sh.post().toString());
        if (c != null || BROKEN.contains(sh.post().toString())) return c;
        Minecraft mc = Minecraft.getInstance();
        try {
            c = new PostChain(mc.getTextureManager(), mc.getResourceManager(), mc.getMainRenderTarget(), sh.post());
            c.resize(mc.getMainRenderTarget().width, mc.getMainRenderTarget().height);
            CHAINS.put(sh.post().toString(), c);
        } catch (Exception e) {
            BROKEN.add(sh.post().toString());
        }
        return c;
    }

    /** Ресурси перезавантажились — шейдери перебудуються при наступному використанні. */
    public static void reset() {
        for (PostChain c : CHAINS.values()) c.close();
        CHAINS.clear();
        BROKEN.clear();
    }
}
