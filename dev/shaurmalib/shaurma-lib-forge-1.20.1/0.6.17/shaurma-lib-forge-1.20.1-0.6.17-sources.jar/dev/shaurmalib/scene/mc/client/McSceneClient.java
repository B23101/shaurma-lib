package dev.shaurmalib.scene.mc.client;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.shaurmalib.scene.mc.editor.EditorOverlay;
import dev.shaurmalib.scene.mc.editor.EditorView;
import dev.shaurmalib.scene.mc.editor.SceneEditorScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Клієнтський клей рушія сцен (без лоадера): лоадер кличе ці методи зі своїх подій. */
public final class McSceneClient {

    private McSceneClient() {}

    /** Початок кадру гри (до Camera.setup). */
    public static void renderTick() {
        dev.shaurmalib.scene.mc.editor.SceneEditorScreen.recordFrame();
        SceneClient.renderTick();
        boolean paused = Minecraft.getInstance().isPaused();
        for (SceneClient.Active a : SceneClient.active()) {
            SceneSound.update(a.playback.id(), a.playback.doc(), a.frame, !paused && !a.playback.inPreroll() && !a.playback.ended());
        }
    }

    /** Кадр світу після сутностей. */
    public static void onWorld(PoseStack ps, MultiBufferSource buffers, Vec3 cam, float partial, Matrix4f projection) {
        EditorView.captureMatrices(ps.last().pose(), projection, cam);
        SceneRender.renderWorld(ps, buffers, cam, partial);
        EditorOverlay.world(ps, buffers, cam);
    }

    /** Перед HUD (чистий кадр світу — знімок для crossfade). */
    public static void beforeHud() { SceneHud.beforeHud(); }

    /** Після HUD. */
    /** Клієнтський тік (кінець): запис руху актора. */
    public static void clientTick() {
        dev.shaurmalib.scene.mc.editor.SceneEditorScreen.recordTick();
        // Esc під час «Тесту в грі» (навіть зацикленої сцени): зупинити тест і повернутись у редактор
        Minecraft mc = Minecraft.getInstance();
        SceneClient.Active a = testSession();
        // будь-яке меню поверх тесту (Esc: ванільна пауза чи меню режиму), крім чату — зупинити тест
        if (a != null && mc.screen != null && !(mc.screen instanceof net.minecraft.client.gui.screens.ChatScreen) && !(mc.screen instanceof SceneEditorScreen)) {
            dev.shaurmalib.scene.net.SceneNetwork.Holder.get().toServer(dev.shaurmalib.scene.net.SceneMessage.of(dev.shaurmalib.scene.net.SceneMessage.Op.STOP_PREVIEW));
            SceneClient.stop(a.playback.id());
            mc.setScreen(null);
            SceneEditorHook.afterTest();
        }
    }

    /** Серверний тест сцени з редактора, що зараз грає (або null). */
    private static SceneClient.Active testSession() {
        for (SceneClient.Active a : SceneClient.active()) if (a.preview && !a.local) return a;
        return null;
    }

    public static void onHud(GuiGraphics g, float partial) {
        dev.shaurmalib.scene.mc.editor.SceneEditorScreen.recordHud(g);
        if (Minecraft.getInstance().screen instanceof SceneEditorScreen) return;
        SceneHud.render(g, partial);
        if (testSession() != null) {
            var font = Minecraft.getInstance().font;
            String t = "ТЕСТ · Esc — назад у редактор";
            g.drawString(font, t, g.guiWidth() - font.width(t) - 6, 6, 0xCCFFFFFF, true);
        }
    }

    /** Ховати ванільний HUD (кінематографічна сцена). */
    public static boolean hideHud() { return SceneCamera.hideHud(); }

    /** Блокувати рух гравця (кінематографічна сцена; тіло — якір камери). */
    public static boolean lockInput() { return SceneClient.cinematicActive(); }

    public static void openEditor() { SceneEditorHook.openPicker(); }

    public static void onDisconnect() { SceneClient.onDisconnect(); }
}
