package dev.shaurmalib.anim.mc.bend;

/**
 * Згин, домішаний у {@code ModelPart} ({@code MixinModelPartBend}). Обертання нижнього сегмента
 * відносно верхнього — градуси, порядок ZYX, ті самі числа, що в кістці {@code *_forearm}/{@code *_shin}.
 *
 * Стан живе, поки його не скине {@code resetPose()}; {@code copyFrom()} копіює його разом із позою
 * (рукави/штани гравця, броня через {@code HumanoidModel.copyPropertiesTo}).
 */
public interface BendablePart {

    void shaurma$setBend(float rx, float ry, float rz);

    /**
     * Згин, де стоїть нижня половина, а верхня повертається на (rx, ry, rz) — тулуб: поясниця на стегнах,
     * груди гнуться ({@code BendMath.setUpper}).
     */
    void shaurma$setBendUpper(float rx, float ry, float rz);

    /** Чи це згин верхньої половини ({@link #shaurma$setBendUpper}). */
    boolean shaurma$bendUpper();

    /**
     * Кореневий згин (кульша): верхній торець частини вирівнюється по батьківській частині — обертання торця
     * відносно частини {@code R_part⁻¹·R_parent}, кватерніон. Кінцівка виходить із нього короткою дугою.
     */
    void shaurma$setRootBend(float qx, float qy, float qz, float qw);

    void shaurma$clearRootBend();

    /** Кватерніон торця {@code (x,y,z,w)} або null — кореневого згину нема. */
    float[] shaurma$rootBend();

    /** Таз: нижній торець частини повернутий на кватерніон (дуга біля торця, {@code BendMath.setTail}). */
    void shaurma$setTailBend(float qx, float qy, float qz, float qw);

    void shaurma$clearTailBend();

    /** Кватерніон нижнього торця або null. */
    float[] shaurma$tailBend();

    void shaurma$clearBend();

    /** Чи є ненульовий згин (інакше частина малюється ванільно). */
    boolean shaurma$hasBend();

    float shaurma$bendX();

    float shaurma$bendY();

    float shaurma$bendZ();
}
