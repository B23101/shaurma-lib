package dev.shaurmalib.meta.mc.screen;

import dev.shaurmalib.meta.client.MetaClient;
import dev.shaurmalib.meta.cosmetics.CosmeticDef;
import dev.shaurmalib.meta.cosmetics.CosmeticSlot;
import dev.shaurmalib.meta.cosmetics.Look;
import dev.shaurmalib.meta.cosmetics.ParamSpec;
import dev.shaurmalib.meta.cosmetics.Wardrobe;
import dev.shaurmalib.meta.cosmetics.Worn;
import dev.shaurmalib.meta.economy.Currency;
import dev.shaurmalib.meta.economy.Recipe;
import dev.shaurmalib.meta.economy.Reward;
import dev.shaurmalib.meta.economy.ShopOffer;
import dev.shaurmalib.meta.mc.MetaScreens;
import dev.shaurmalib.meta.mc.render.CosmeticRenderer;
import dev.shaurmalib.meta.mc.skin.MetaSkin;
import dev.shaurmalib.meta.mc.ui.MetaIcons;
import dev.shaurmalib.meta.mc.ui.MetaUi;
import dev.shaurmalib.meta.profile.MetaProfile;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.RemotePlayer;
import net.minecraft.util.Mth;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.PlayerModelPart;
import org.joml.Quaternionf;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Гардероб (перенесено з мафії й зроблено керованим даними — працює з каталогом будь-якого режиму).
 * Каталог ліворуч, примірка посередині, налаштування праворуч, пресети. Жодних повзунків — усе прямо на моделі:
 * <ul>
 *   <li>ЛКМ на вільному місці — обертання; ПКМ — пересунути модель; колесо поза предметом — масштаб;</li>
 *   <li>ЛКМ на предметі й тягнути — посадка (Shift — уперед/назад для улюбленця);</li>
 *   <li>колесо над предметом — розмір (Ctrl — розмах польоту, Alt — швидкість).</li>
 * </ul>
 * Невласні предмети видно із замком і ціною: купити, скрафтити або «на доріжці, рівень N».
 * Зміни зберігаються самі за 0.8 с (сервер ще раз перевіряє межі й володіння).
 *
 * <p><b>Анімації примірки</b> (усе — лише на головному манекені):
 * <ul>
 *   <li><i>Одягання</i> ({@link #startEquip}): приготування → персонаж злітає, обертаючись, а довкола крутиться аура-орбіта →
 *       зависає → падає, удар об підлогу (хвиля, струс, спалах) → оглядає себе (повороти тулуба, голова вниз).</li>
 *   <li><i>Падіння на місце</i>: обраний предмет висить над своїм місцем і падає з двома відскоками
 *       ({@code CosmeticRenderer.fallCurve}); улюбленець і рюкзак підлітають збоку, аура розростається.</li>
 *   <li><i>«Схопив»</i>: поки предмет тягнеш — він піднятий, трохи більший і гойдається за рухом руки; відпустив — лягає назад з відскоком.</li>
 *   <li>Манекен дихає вертикальним рухом ({@code Preview.breathOffset}); у польоті дихання вимкнене.</li>
 * </ul></p>
 */
public class WardrobeScreen extends MetaScreen {

    private static final int VX = 446, VY = 84, VW = 284, VH = 374;
    private static final int VCX = VX + VW / 2, VFY = 438;
    private static final float BASE = 122f;
    private static final int PRESETS_TAB = -1;
    /** Вкладка «Анімації»: емоції колеса як косметика. */
    private static final int EMOTES_TAB = -2;
    /** Вкладка вибору персонажа (маніяка). */
    private static final int CHARS_TAB = -3;
    /** Вибрана анімація і та, що зараз грає на манекені. */
    private String selEmote, playingEmote;
    /** Колесо анімацій, яке редагують (копія з профілю; сервер — джерело правди). */
    private final String[] wheelEdit = new String[MetaProfile.WHEEL_SLOTS];

    private final Wardrobe wardrobe;
    private String variant;
    private RemotePlayer mannequin;
    /** Індекс у CosmeticSlot.values() або {@link #PRESETS_TAB}. */
    private int cat = CosmeticSlot.HEAD.ordinal();
    private CosmeticDef selected;
    private int selectedPreset = -1;
    private float yaw = 160, panX, panY, zoom = 1, yawGoal = Float.NaN;
    private boolean moving, changed;
    /** Рух: спокій → ходьба → біг (по колу). {@code running} має сенс лише коли {@code moving}. */
    private boolean running;
    /** Власний аніматор манекена (див. {@link Preview#animatorOverride}). */
    private Object mannequinAnim;
    private int drag;
    private float saveAt, jumpStart = -10f, curLift, curLean, catTime, selY;
    private int scroll;
    /** Скільки сторінок у списку зараз (рахує малювання; прокрутка не виходить за межі). */
    private int pagesNow = 1;
    /** Відтінок, який приміряють, але ще не купили (-1 — нема), і колір, що був до примірки. */
    private int pendingColor = -1, prevColor;

    // Діалог назви образу
    private boolean naming, nameFresh;
    private int namingSlot;
    private final StringBuilder nameBuf = new StringBuilder();

    // ── Анімації примірки ────────────────────────────────────────────────
    private static final int N_SLOTS = CosmeticSlot.values().length;
    private static final float EQUIP_LEN = 3.2f, DROP_LEN = .85f;
    private static final float T_DIP = .22f, T_RISE = 1.45f, T_FALL = 1.80f, T_LAND = 2.10f, T_LOOK = 2.25f;
    private static final float FLY_H = .62f;
    /** Коли (у секундах екрана) предмет слота почав/почне падати; велике мінусове — не падає. */
    private final float[] dropStart = new float[N_SLOTS];
    private final float[] dropAmp = new float[N_SLOTS], dropOut = new float[N_SLOTS], dropPrevU = new float[N_SLOTS];
    private float equipStart = -10f, eLift, eYaw, eHeadYaw, eHeadPitch, ePrevLift, landShake, shockT = -10f;
    private int equipColor;
    private boolean landed;
    private float grab, dragVx;
    /** Куди дивиться фігура у вікні (для орбіти й хвилі): центр, ноги, розмір. */
    private float figCx, figFoot, figSize;

    // ── Поява: модель падає згори й приземляється ───────────────────────
    private static final float INTRO_T0 = .3f, INTRO_FALL = .5f, INTRO_H = 340f;
    private boolean introLanded;
    /** 0..1 — частка висоти падіння при появі (1 — ще за верхнім краєм вікна). */
    private float introLift = 1f;
    /** Сила останнього приземлення (сплющення, хвиля): 1 — поява/одягання, менше — м'яке опускання з руки. */
    private float landAmp = 1f;
    private float crouchUntil = -10f;
    /** Зсув старту появи (перезапуск падіння при зміні персонажа). */
    private float introStart;

    // ── «Невагомість»: модель, яку тримаєш ПКМ ──────────────────────────
    /** Показана позиція моделі (пружиною доганяє panX/panY), швидкість, «тримаю» 0..1, нахил-маятник. */
    private float dispX, dispY, velX, velY, hold, swing, swingV;
    private boolean held, falling;

    private String presetTitle(int slot) {
        String n = wardrobe.presetName(scope(), slot);
        return n.isEmpty() ? "ОБРАЗ " + (slot + 1) : n;
    }

    private void startNaming(int slot) {
        naming = true;
        namingSlot = slot;
        nameBuf.setLength(0);
        String cur = wardrobe.presetName(scope(), slot);
        nameBuf.append(cur.isEmpty() ? "Образ " + (slot + 1) : cur);
        nameFresh = true;   // перша ж літера замінює пропозицію, а не дописується до неї
    }

    /** «Зберегти» з шапки: перший вільний слот, інакше вибраний образ, інакше перший. */
    private void quickSave() {
        int slot = -1;
        for (int i = 0; i < Wardrobe.PRESETS && slot < 0; i++) if (wardrobe.preset(scope(), i) == null) slot = i;
        if (slot < 0) slot = selectedPreset >= 0 ? selectedPreset : 0;
        click();
        startNaming(slot);
    }

    private void confirmNaming() {
        String name = Wardrobe.cleanName(nameBuf.toString());
        if (name.isEmpty()) name = "Образ " + (namingSlot + 1);
        wardrobe.setPreset(scope(), namingSlot, look().copy(), name);
        naming = false;
        dirty();
        click();
        say("Образ «" + name + "» збережено", false);
    }

    private void typeInto(String text) {
        if (nameFresh && !text.isEmpty()) { nameBuf.setLength(0); nameFresh = false; }
        for (int i = 0; i < text.length() && nameBuf.length() < Wardrobe.NAME_MAX; i++) {
            char c = text.charAt(i);
            if (c >= 32 && c != 127) nameBuf.append(c);
        }
    }

    private void drawNaming(GuiGraphics g) {
        if (!naming) return;
        zone(0, 0, DW, DH, () -> { });   // перший у списку = останній у пріоритеті: ловить усе, що не кнопки діалогу
        g.fill(0, 0, DW, DH, MetaUi.a(0, .6f));
        int w = 300, h = 132, x = (DW - w) / 2, y = (DH - h) / 2;
        panel(g, x, y, w, h, true);
        MetaUi.text(g, font, "ЗБЕРЕГТИ ОБРАЗ", x + 16, y + 14, MetaUi.solid(theme.text()), true);
        MetaUi.textS(g, font, "Назва", x + 16, y + 36, .85f, MetaUi.solid(theme.dim()), false);
        MetaUi.textR(g, font, nameBuf.length() + " / " + Wardrobe.NAME_MAX, x + w - 16, y + 36, MetaUi.solid(theme.dim()), false);
        panel(g, x + 16, y + 48, w - 32, 24, false);
        Look old = wardrobe.preset(scope(), namingSlot);
        MetaUi.textS(g, font, "Слот " + (namingSlot + 1) + (old == null ? " · вільний" : " · замінить «" + MetaUi.fit(font, presetTitle(namingSlot), 120) + "»"),
                x + 16, y + 76, .75f, MetaUi.solid(old == null ? theme.dim() : theme.gold()), false);
        boolean caret = ((int) (time * 2f) & 1) == 0;
        MetaUi.text(g, font, nameBuf + (caret ? "_" : ""), x + 24, y + 56, MetaUi.solid(theme.text()), false);
        button(g, "nameOk", x + 16, y + 88, 132, 28, "ЗБЕРЕГТИ", MetaSkin.Kind.PRIMARY, this::confirmNaming);
        button(g, "nameNo", x + w - 148, y + 88, 132, 28, "СКАСУВАТИ", MetaSkin.Kind.NORMAL, () -> { naming = false; click(); });
    }

    private static final class Spark { float x, y, vx, vy, life, max, size, grav; int rgb; }
    private final List<Spark> sparks = new ArrayList<>();
    private final Random rnd = new Random();
    private float ambient, flash, auraMix;

    public WardrobeScreen(Screen parent) {
        super("Гардероб", parent);
        MetaProfile p = me();
        wardrobe = p == null ? new Wardrobe() : p.wardrobe.copy();
        variant = mode == null ? "player" : mode.variants.get(0);
        selected = first(slot());
        if (p != null) System.arraycopy(p.emoteWheel, 0, wheelEdit, 0, wheelEdit.length);
        yaw = savedYaw; zoom = savedZoom; panX = dispX = savedPanX; panY = dispY = savedPanY;
        if (savedVariant != null && mode != null && mode.variants.contains(savedVariant)) {
            variant = savedVariant;
            if (mode.isCharacter(variant)) lastCharacter = variant; else lastPlayer = variant;
            ensureSlot();
            selected = first(slot());
        }
        java.util.Arrays.fill(dropStart, -10f);
        java.util.Arrays.fill(dropPrevU, 1f);
    }

    @Override protected String section() { return "wardrobe"; }

    private CosmeticSlot slot() { return cat < 0 ? null : CosmeticSlot.values()[cat]; }

    /** Розділ анімацій: є, якщо режим їх продає; у персонажа (маніяка) емоцій нема. */
    private boolean emoteTab() { return mode != null && !mode.emotes.isEmpty() && !isCharacter(); }

    private Look look() { return wardrobe.look(variant); }

    /** Слоти, дозволені поточному варіанту (маніяк: без тіла й ніг). */
    private List<CosmeticSlot> allowed() { return mode == null ? List.of(CosmeticSlot.values()) : mode.slots(variant); }

    /** Після зміни варіанта: якщо відкрита вкладка недозволена — перейти на першу дозволену. */
    private void ensureSlot() {
        if (cat == EMOTES_TAB && emoteTab()) return;
        if (cat == CHARS_TAB && isCharacter()) return;
        if (cat == CHARS_TAB) { cat = allowed().isEmpty() ? PRESETS_TAB : allowed().get(0).ordinal(); return; }
        if (cat == PRESETS_TAB) return;
        List<CosmeticSlot> a = allowed();
        if (a.contains(slot())) return;
        cat = a.isEmpty() ? PRESETS_TAB : a.get(0).ordinal();
        selected = cat == PRESETS_TAB ? null : first(slot());
        selectedPreset = -1;
        catTime = time;
        scroll = 0;
    }

    private boolean owns(CosmeticDef d) { MetaProfile p = me(); return p != null && (mode == null ? p.owns(d.id()) : p.ownsFor(mode, variant, d.id())); }

    private boolean ownsColor(MetaProfile p, CosmeticDef d, int rgb) { return mode == null ? p.ownsColor(d, rgb) : p.ownsColorFor(mode, variant, d, rgb); }

    /** Область збережених образів: у кожного маніяка свої, у гравця — спільні. */
    private String scope() { return mode == null ? "" : mode.presetScope(variant); }

    private boolean isCharacter() { return mode != null && mode.isCharacter(variant); }

    private String variantName(String v) { return mode == null ? v : mode.variantNames.getOrDefault(v, v); }

    /** Останні вибрані варіанти обох вкладок — щоб перемикач «Гравець / Маніяк» повертав туди, де був. */
    private String lastPlayer, lastCharacter;

    /** Перейти на інший варіант (гравець ↔ маніяк, інший маніяк): свій образ, свої покупки, свої пресети. */
    private void switchVariant(String v) {
        if (v == null || v.equals(variant)) return;
        clearPending();
        variant = v;
        if (mode != null && mode.isCharacter(v)) lastCharacter = v; else lastPlayer = v;
        if (minecraft != null && minecraft.player != null) mannequinAnim = animFor(v);
        ensureSlot();
        selectedPreset = -1;
        catTime = time;
        // новий персонаж «приземляється» у примірку
        introLanded = false;
        introLift = 1f;
        introStart = time - INTRO_T0 + .05f;
        sound("swap");
    }

    private List<CosmeticDef> pieces(CosmeticSlot s) {
        List<CosmeticDef> out = new ArrayList<>();
        if (mode == null || s == null) return out;
        for (CosmeticDef d : mode.cosmetics.bySlot(s)) if (!d.hidden() || owns(d)) out.add(d);
        // власні — першими
        out.sort((a, b) -> Boolean.compare(owns(b), owns(a)));
        return out;
    }

    private CosmeticDef first(CosmeticSlot s) {
        List<CosmeticDef> l = pieces(s);
        return l.isEmpty() ? null : l.get(0);
    }

    private boolean worn(CosmeticDef d) { Worn w = look().get(d.slot()); return w != null && w.item.equals(d.id()); }

    private void wear(CosmeticDef d, boolean on) {
        if (on && !owns(d)) { say("Цей предмет ще не твій", true); return; }
        if (on) {
            Worn prev = look().get(d.slot());
            Worn w = new Worn(d.id(), d.defaultColor());
            if (prev != null) w.params.putAll(prev.params);   // посадка лишається при заміні предмета
            w.validate(d.slot());
            look().put(d.slot(), w);
            startEquip(d);
            sound("equip");
        } else look().remove(d.slot());
        dirty();
        burstItem(on ? accent : theme.dim(), on ? 56 : 24);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Анімації
    // ══════════════════════════════════════════════════════════════════════

    /** Предмет висить над своїм місцем (на висоті {@code amp}, зі зсувом {@code out}) і через {@code delay} с падає на нього. */
    private void startDrop(CosmeticSlot s, float delay, float amp, float out) {
        int i = s.ordinal();
        dropStart[i] = time + delay;
        dropAmp[i] = amp;
        dropOut[i] = out;
        dropPrevU[i] = -1f;
    }

    /** Одягання: повна сцена, якщо попередня закінчилась; інакше лише падіння нового предмета (не перезапускаємо політ). */
    private void startEquip(CosmeticDef d) {
        boolean running = time - equipStart < EQUIP_LEN - .3f;
        equipColor = d.rarity().color;
        CosmeticSlot s = d.slot();
        // падає, коли персонаж біля верхньої точки польоту (або одразу, якщо сцена вже йде)
        dropFor(s, running ? .05f : T_RISE - .55f);
        if (!running) {
            equipStart = time;
            landed = false;
        }
    }

    private void dropFor(CosmeticSlot s, float delay) {
        switch (s) {
            case HEAD -> startDrop(s, delay, 1.05f, 0f);          // капелюх падає зверху
            case BACK -> startDrop(s, delay, .55f, .95f);         // рюкзак підлітає ззаду
            case PET -> startDrop(s, delay, 1.10f, .95f);         // улюбленець — збоку й згори
            case AURA -> startDrop(s, delay, 0f, 0f);             // аура розростається з підлоги
            default -> startDrop(s, delay, .6f, 0f);
        }
    }

    /** Весь образ одягнули одразу (застосували збережений): та сама сцена, предмети падають усі разом. */
    private void startOutfit() {
        equipColor = accent;
        equipStart = time;
        landed = false;
        for (CosmeticSlot s : look().view().keySet()) dropFor(s, T_RISE - .55f);
    }

    private static float easeInOut(float t) { t = MetaUi.clamp01(t); return t * t * (3f - 2f * t); }

    /** Поза й ефекти сцени одягання на момент {@code time}. */
    private void updateEquip() {
        ePrevLift = eLift;
        eLift = eYaw = eHeadYaw = eHeadPitch = 0f;
        float t = time - equipStart;
        boolean on = t >= 0f && t < EQUIP_LEN;
        if (on) {
            if (t < T_DIP) {
                eLift = -.05f * (float) Math.sin(Math.PI * t / T_DIP);                 // присів перед стрибком
            } else if (t < T_FALL) {
                float up = MetaUi.outCubic((t - T_DIP) / (T_RISE - T_DIP));            // злітає, сповільнюючись
                eLift = FLY_H * up + (t > T_RISE ? .018f * (float) Math.sin((t - T_RISE) * 6.5f) : 0f);   // у верхній точці — легке погойдування
                eYaw = 720f * easeInOut((t - T_DIP) / (T_FALL - T_DIP));                // два повних оберти за політ
            } else if (t < T_LAND) {
                float k = (t - T_FALL) / (T_LAND - T_FALL);
                eLift = FLY_H * (1f - k * k);                                           // падає з прискоренням
            } else if (t < T_LAND + .2f) {
                eLift = -.06f * (float) Math.sin(Math.PI * (t - T_LAND) / .2f);         // амортизація
            }
            if (!landed && t >= T_LAND) {
                landed = true;
                landShake = 1f;
                shockT = time;
                landAmp = 1f;
                flash = Math.min(1f, flash + .9f);
                burst(figCx, figFoot, equipColor, 46, true);
                burst(figCx, figFoot, 0xFFFFFF, 16, true);
            }
            if (t >= T_LOOK) {                                                          // оглядає себе
                float u = (t - T_LOOK) / (EQUIP_LEN - T_LOOK);
                float env = (float) Math.sin(Math.PI * Math.min(1f, u * 1.05f));
                eYaw = 38f * (float) Math.sin(Math.PI * 2.0 * u) * (1f - .35f * u);
                eHeadYaw = -eYaw * .8f;
                eHeadPitch = 24f * env;
            }
        }
        landShake = Math.max(0f, landShake - dt * 3.2f);
        // у польоті не дихає: плавно вимикаємо
        Preview.breathMul = 1f - MetaUi.clamp01(Math.abs(eLift) / .12f);
    }

    /** Падіння предметів, «схопив» і нахил від руки — у спільні масиви рендера косметики. */
    private void updateItemAnim() {
        CosmeticRenderer.clearAnim();
        for (int i = 0; i < N_SLOTS; i++) {
            float u = (time - dropStart[i]) / DROP_LEN;
            float lift = 0f, out = 0f;
            if (dropStart[i] > time) { lift = dropAmp[i]; out = dropOut[i]; }          // чекає над місцем
            else if (u < 1f) {
                float f = CosmeticRenderer.fallCurve(u);
                lift = dropAmp[i] * f;
                out = dropOut[i] * MetaUi.clamp01(1f - u * 1.25f) * f;
                if (dropPrevU[i] < .62f && u >= .62f && dropPrevU[i] >= 0f) impact(CosmeticSlot.values()[i]);
            }
            dropPrevU[i] = dropStart[i] > time ? -1f : u;
            CosmeticRenderer.animLift[i] = lift;
            CosmeticRenderer.animOut[i] = out;
        }
        int ai = CosmeticSlot.AURA.ordinal();
        CosmeticRenderer.animAuraGrow = dropStart[ai] > time ? 0f : MetaUi.outBack(MetaUi.clamp01((time - dropStart[ai]) / (DROP_LEN * 1.4f)));

        // Під час редагування посадки предмет НЕ піднімається й не гойдається: видно точне положення.
        grab = 0f;
        dragVx = 0f;
    }

    /** Предмет торкнувся місця: маленький спалах у точці посадки. */
    private void impact(CosmeticSlot s) {
        double[] sp = itemSpot(s);
        if (sp == null) return;
        burst(sp[0], sp[1], s == CosmeticSlot.AURA ? equipColor : theme.gold(), 12, true);
        flash = Math.min(1f, flash + .25f);
    }

    /** Скасувати примірку некупленого відтінку: повернути колір, що був. */
    private void clearPending() {
        if (pendingColor < 0) return;
        if (selected != null) {
            Worn w = look().get(selected.slot());
            if (w != null && (w.color & 0xFFFFFF) == (pendingColor & 0xFFFFFF)) w.color = prevColor;
        }
        pendingColor = -1;
    }

    private void dirty() { changed = true; saveAt = time + .8f; }

    private void save() {
        if (!changed) return;
        changed = false;
        MetaClient.saveWardrobe(wardrobe);
    }

    private void markSeen(CosmeticDef d) {
        MetaProfile p = me();
        if (d != null && p != null && p.unseen.contains(d.id())) MetaClient.seen(List.of(d.id()));
    }

    @Override
    protected void init() {
        super.init();
        if (mannequin == null && minecraft != null && minecraft.player != null && minecraft.level != null) {
            mannequin = new RemotePlayer(minecraft.level, minecraft.player.getGameProfile()) {
                @Override public boolean isModelPartShown(PlayerModelPart part) { return true; }
                @Override public boolean isSpectator() { return false; }   // інакше манекен з UUID спостерігача — лише голова
                @Override public boolean isCreative() { return false; }
            };
            initMannequinAnimator();
        }
    }

    /**
     * Манекен має UUID справжнього гравця, тож рушій віддавав би йому аніматор гравця зі світу (а той у меню стоїть
     * і програє idle). Робимо окремий аніматор із тим самим набором локомоції — як у {@code EmotePreview}.
     */
    private void initMannequinAnimator() {
        playerAnim = MetaAnimationPreview.createPlayerAnimator(minecraft.player.getUUID());
        mannequinAnim = animFor(variant);
    }

    /** Аніматор гравця (виживий) і кеш аніматорів персонажів (маніяк — риг і локомоція його моделі, як у грі). */
    private Object playerAnim;
    private final Map<String, Object> variantAnims = new java.util.HashMap<>();

    private Object animFor(String v) {
        if (mode == null || !mode.isCharacter(v)) return playerAnim;
        Object a = variantAnims.computeIfAbsent(v, k -> {
            try { return CosmeticRenderer.variantAnimator.apply(k); }
            catch (RuntimeException e) { com.mojang.logging.LogUtils.getLogger().warn("[ShaurmaLib] аніматор варіанта {}: {}", k, e.toString()); return null; }
        });
        return a != null ? a : playerAnim;
    }

    @Override
    public void tick() {
        // ходьба рахується в draw() (див. walkTick)
    }

    private float walkAcc;

    /** Частка між тіками манекена (0..1) — синхронна з walkTick, а не з тіками світу. */
    private float walkPartial() { return MetaUi.clamp01(walkAcc / .05f); }

    /** Ходьба/спокій рахується в 20 Гц і з кадру, і з tick(): не залежить від того, чи екран отримує tick. */
    private void walkTick() {
        mannequin.tickCount++;
        mannequin.walkAnimation.update(moving ? (running ? 1f : .8f) : 0f, .5f);
        MetaAnimationPreview.tick(mannequinAnim, mannequin, moving && playingEmote == null, running);
        if (cat == EMOTES_TAB) for (Object a : cardAnims.values()) MetaAnimationPreview.tick(a, mannequin, false, false);
        // Без ванільного присіду: у превʼю з нахилом сцени поза CROUCHING ламала тіло (торс уперед, ноги назад) —
        // удар об підлогу передає сплющення в applyDeform.
        if (mannequin.getPose() != Pose.STANDING) mannequin.setPose(Pose.STANDING);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Поява й «невагомість»
    // ══════════════════════════════════════════════════════════════════════

    /** Модель падає згори з прискоренням і важко приземляється: присід, сплющення, пил, хвиля, струс. */
    private void updateIntro() {
        float t = time - INTRO_T0 - introStart;
        if (t < INTRO_FALL) {
            float k = MetaUi.clamp01(t / INTRO_FALL);
            introLift = 1f - k * k;
        } else introLift = 0f;
        if (!introLanded && t >= INTRO_FALL) {
            introLanded = true;
            land(1f);
            burst(figCx, figFoot, accent, 18, true);
            flash = Math.min(1f, flash + .5f);
        }
    }

    /** Удар об підлогу: {@code power} 0..1 — сила (сплющення, кількість пилу, хвиля, присід). */
    private void land(float power) {
        landAmp = power;
        shockT = time;
        landShake = Math.max(landShake, .85f * power);
        crouchUntil = time + .14f + .16f * power;
        dust(figCx, figFoot, Math.round(8 + 22 * power));
        if (!skin.sound(power > .6f ? "land" : "land_soft") && minecraft != null) {
            minecraft.getSoundManager().play(SimpleSoundInstance.forUI(power > .6f ? SoundEvents.PLAYER_BIG_FALL : SoundEvents.PLAYER_SMALL_FALL,
                    .9f + .2f * rnd.nextFloat(), .35f + .4f * power));
        }
    }

    /**
     * ПКМ «бере» модель: вона відривається від помосту, відстає від руки на пружині, гойдається маятником
     * від швидкості й злегка «плаває» вгору-вниз. Відпустив — падає під дією тяжіння й приземляється.
     */
    private void updateHold() {
        boolean nowHeld = drag == 2;
        if (held && !nowHeld) falling = true;
        if (nowHeld) falling = false;
        held = nowHeld;
        hold += ((held ? 1f : 0f) - hold) * Math.min(1f, dt * 10f);
        float rest = dt;
        while (rest > 0f) {   // підкроки: пружина стабільна й на низькому FPS
            float h = Math.min(rest, 1f / 120f);
            rest -= h;
            float kS = held ? 140f : 220f, dmp = held ? 12f : 18f;
            velX += ((panX - dispX) * kS - velX * dmp) * h;
            dispX += velX * h;
            if (held) {
                float ty = panY - 24f + (float) Math.sin(time * 2.2f) * 1.5f;
                velY += ((ty - dispY) * kS - velY * dmp) * h;
                dispY += velY * h;
            } else if (falling || dispY < panY - .5f) {
                velY += 1500f * h;   // тяжіння
                dispY += velY * h;
                if (dispY >= panY) {
                    dispY = panY;
                    if (velY > 70f) land(MetaUi.clamp01(velY / 520f) * .7f);
                    velY = 0f;
                    falling = false;
                }
            } else {
                velY += ((panY - dispY) * kS - velY * dmp) * h;
                dispY += velY * h;
            }
            // легкий нахил від швидкості руки, без маятника: майже критичне згасання, максимум 7°
            float target = Math.max(-7f, Math.min(7f, -velX * .02f)) * hold;
            swingV += ((target - swing) * 60f - swingV * 15f) * h;
            swing += swingV * h;
        }
    }

    /** Пил з-під ніг: низькі пухкі клуби, що розлітаються в боки. */
    private void dust(double x, double y, int n) {
        for (int i = 0; i < n && sparks.size() < 500; i++) {
            Spark k = new Spark();
            float dir = rnd.nextBoolean() ? 1f : -1f;
            k.x = (float) x + dir * rnd.nextFloat() * 10f;
            k.y = (float) y - rnd.nextFloat() * 3f;
            k.vx = dir * (35f + rnd.nextFloat() * 110f);
            k.vy = -(6f + rnd.nextFloat() * 38f);
            k.max = k.life = .45f + rnd.nextFloat() * .55f;
            k.size = 2 + rnd.nextInt(3);
            k.grav = 55f;
            k.rgb = MetaUi.mix(0xFF8A8580, 0xFF000000 | theme.dim(), rnd.nextFloat()) & 0xFFFFFF;
            sparks.add(k);
        }
    }

    /** Сплющення/розтягування й маятник моделі на цей кадр (застосовує {@link Preview#render}). */
    private void applyDeform(float size) {
        float sx = 1f, sy = 1f;
        if (introLift > 0f && introLift < 1f) { float k = 1f - introLift; sy += .12f * k; sx -= .06f * k; }   // у падінні витягується
        if (falling && velY > 0f) { float k = MetaUi.clamp01(velY / 600f); sy += .07f * k; sx -= .035f * k; }
        float l = time - shockT;
        if (l >= 0f && l < .5f) {
            float sq = l < .13f ? -.22f * (float) Math.sin(Math.PI * l / .13f)
                    : .07f * (float) Math.sin(Math.PI * (l - .13f) / .37f) * (1f - (l - .13f) / .37f);
            sy += sq * landAmp;
            sx -= sq * .6f * landAmp;
        }
        Preview.squashX = sx;
        Preview.squashY = sy;
        Preview.roll = swing;
        Preview.pivotUp = size * .9f;    // нахил навколо центру тіла (гравець 1.8 бл → середина 0.9)
    }

    @Override
    public void onClose() {
        rememberView();
        clearPending();
        save();
        CosmeticRenderer.preview = null;
        CosmeticRenderer.drawingPreview = false;
        CosmeticRenderer.clearAnim();
        Preview.breathMul = 1f;
        Preview.resetDeform();
        super.onClose();
    }

    @Override
    public void removed() {
        rememberView();
        clearPending();
        save();
        CosmeticRenderer.clearAnim();
        Preview.breathMul = 1f;
        Preview.resetDeform();
        super.removed();
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Рендер
    // ══════════════════════════════════════════════════════════════════════

    @Override
    protected void draw(GuiGraphics g) {
        CosmeticSlot s = slot();
        if (changed && time >= saveAt) save();
        if (!Float.isNaN(yawGoal)) {
            if (drag == 1) yawGoal = Float.NaN;
            else {
                float d = Mth.wrapDegrees(yawGoal - yaw);
                yaw += d * Math.min(1f, dt * 6f);
                if (Math.abs(d) < .5f) yawGoal = Float.NaN;
            }
        }
        float u = (time - jumpStart) / .55f;
        float jumpH = 0, lift = 0;
        if (u >= 0 && u <= 1) { jumpH = 4f * .45f * u * (1f - u); lift = -(4f * .45f * (1f - 2f * u) / .55f) * .05f; }
        updateEquip();
        updateItemAnim();
        updateIntro();
        updateHold();
        String wantEmote = cat == EMOTES_TAB ? selEmote : null;
        if (!java.util.Objects.equals(wantEmote, playingEmote)) {
            playingEmote = wantEmote;
            MetaAnimationPreview.previewEmote(mannequinAnim, wantEmote);
        }
        jumpH += eLift;
        lift += Math.max(-.35f, Math.min(.35f, -(eLift - ePrevLift) / Math.max(dt, 1e-3f) * .05f));
        curLift = lift;
        curLean += ((moving ? (running ? 14f : 9f) : 0f) - curLean) * Math.min(1f, dt * 8f);
        auraMix += ((s == CosmeticSlot.AURA ? 1f : 0f) - auraMix) * Math.min(1f, dt * 5f);
        if (mannequin != null) {
            walkAcc += Math.min(dt, .1f);
            while (walkAcc >= .05f) { walkAcc -= .05f; walkTick(); }
            Preview.idle(mannequin, time, moving, eHeadYaw, eHeadPitch);   // жива поза: зсув ваги, голова роззирається, дихання (tickCount веде tick())
        }
        updateFx();
        drawHeader(g);
        drawLeft(g);
        drawViewport(g, jumpH, lift);
        drawRight(g);
        depthBarrier(g);   // далі — лише 2D поверх моделей: підказки, іскри, діалог назви образу
        drawHints(g);
        drawFx(g);
        drawNaming(g);
    }

    private void drawHeader(GuiGraphics g) {
        header(g, "ГАРДЕРОБ", "КОСМЕТИКА");
        int x = 446;
        if (mode != null && !mode.characters.isEmpty()) {
            // Дві вкладки: гравець (виживий) і персонажі (маніяки). Конкретного маніяка обирають у правій панелі.
            List<String> pv = mode.playerVariants();
            String pTitle = pv.size() == 1 ? variantName(pv.get(0)).toUpperCase() : "ГРАВЕЦЬ";
            String cTitle = mode.charactersTitle.toUpperCase();
            boolean ch = isCharacter();
            int w1 = font.width(pTitle) + 26, w2 = font.width(cTitle) + 26;
            // активна вкладка — з порожньою дією: інакше скін малює її як вимкнену (тьмяною)
            button(g, "grpPlayer", x, 54, w1, 20, pTitle, !ch, ch && !pv.isEmpty() ? () -> {
                switchVariant(lastPlayer != null ? lastPlayer : pv.get(0));
                selected = first(slot());
            } : () -> { });
            button(g, "grpChar", x + w1 + 4, 54, w2, 20, cTitle, ch, !ch ? () -> {
                switchVariant(lastCharacter != null ? lastCharacter : mode.characterVariants().get(0));
                selected = null;
                cat = CHARS_TAB;   // одразу розділ вибору маніяка
                catTime = time;
            } : () -> { selected = null; cat = CHARS_TAB; catTime = time; });   // повторний клік — назад до вибору
            x += w1 + w2 + 10;
            if (!ch && pv.size() > 1) {
                for (String v : pv) {
                    String name = variantName(v).toUpperCase();
                    int w = font.width(name) + 18;
                    button(g, "var" + v, x, 54, w, 20, name, v.equals(variant), () -> switchVariant(v));
                    x += w + 4;
                }
            }
        } else if (mode != null && mode.variants.size() > 1) {
            int avail = 590 - x, n = mode.variants.size();
            for (String v : mode.variants) {
                String name = variantName(v).toUpperCase();
                int w = Math.min(font.width(name) + 24, Math.max(44, avail / n - 6));
                button(g, "var" + v, x, 54, w, 20, name, v.equals(variant), () -> switchVariant(v));
                x += w + 6;
            }
        }
        button(g, "move", Math.max(x + 6, 600), 54, 120, 20, !moving ? "РУХ · СПОКІЙ" : running ? "РУХ · БІГ" : "РУХ · ХОДЬБА", moving, () -> {
            // спокій → ходьба → біг → спокій
            if (!moving) { moving = true; running = false; }
            else if (!running) running = true;
            else { moving = false; running = false; }
            click();
        });
        button(g, "saveLook", 726, 54, 94, 20, "ЗБЕРЕГТИ", MetaSkin.Kind.PRIMARY, this::quickSave);
        button(g, "resetView", 826, 54, 120, 20, "R · СКИНУТИ ВИД", false, () -> { resetView(); click(); });
    }

    private void resetView() { yaw = 160; panX = panY = 0; zoom = 1; }

    /** Вигляд примірки, який гравець налаштував, — між відкриттями гардероба (у межах сесії гри). */
    private static float savedYaw = 160, savedZoom = 1, savedPanX, savedPanY;
    private static String savedVariant;

    private void rememberView() { savedYaw = yaw; savedZoom = zoom; savedPanX = panX; savedPanY = panY; savedVariant = variant; }

    // ── ліва панель ─────────────────────────────────────────────────────
    private void drawLeft(GuiGraphics g) {
        panel(g, 14, 84, 424, 374, false);
        CosmeticSlot[] slots = allowed().toArray(new CosmeticSlot[0]);
        boolean emo = mode != null && !mode.emotes.isEmpty();
        boolean emoLocked = emo && !emoteTab();
        boolean chars = isCharacter();
        int off = chars ? 1 : 0;   // у персонажа першою — вкладка вибору персонажа
        int rows = off + slots.length + (emo ? 1 : 0) + 1;
        for (int i = 0; i < rows; i++) {
            int j = i - off;
            final int idx = chars && i == 0 ? CHARS_TAB : j < slots.length ? slots[j].ordinal() : emo && j == slots.length ? EMOTES_TAB : PRESETS_TAB;
            String title = idx == CHARS_TAB ? mode.charactersPlural.toUpperCase() : j >= 0 && j < slots.length ? slots[j].title.toUpperCase()
                    : idx == EMOTES_TAB ? "АНІМАЦІЇ" : "ОБРАЗИ";
            String icon = idx == CHARS_TAB ? "skull" : j >= 0 && j < slots.length ? iconOf(slots[j]) : idx == EMOTES_TAB ? "run" : "preset";
            boolean act = idx == cat;
            int y = 96 + i * 34;
            if (idx == EMOTES_TAB && emoLocked) {
                hv("cat" + i, zone(22, y, 84, 28, () -> { say("Анімації — лише для виживого: маніяк не танцює", true); sound("error"); }));
                skin.tab(g, font, 22, y, 84, 28, title, icon, false, 0f);
                g.fill(23, y + 1, 105, y + 27, MetaUi.a(0, .45f));
                MetaUi.lock(g, 94, y + 10, MetaUi.a(0xFFFFFF, .8f));
                continue;
            }
            float hv = hv("cat" + i, zone(22, y, 84, 28, () -> {
                if (cat != idx) {
                    clearPending();
                    cat = idx;
                    selected = idx < 0 ? null : first(CosmeticSlot.values()[idx]);
                    if (idx == EMOTES_TAB && selEmote == null && !mode.emotes.isEmpty()) selEmote = mode.emotes.keySet().iterator().next();
                    markSeen(selected);
                    selectedPreset = -1;
                    catTime = time;
                    scroll = 0;
                    yawGoal = idx == CosmeticSlot.BACK.ordinal() ? 300f : 160f;
                    sound("tab");
                }
            }));
            skin.tab(g, font, 22, y, 84, 28, title, icon, act, hv);
            if (j >= 0 && j < slots.length && hasUnseen(slots[j])) MetaUi.disc(g, 101, y + 5, 2, MetaUi.solid(theme.gold()));
        }
        g.fill(112, 96, 113, 446, MetaUi.a(theme.border(), .9f));
        if (cat == EMOTES_TAB) { drawEmoteList(g); return; }
        if (cat == CHARS_TAB) { drawCharacterList(g); return; }

        String title = cat == PRESETS_TAB ? "ОБРАЗИ" : slot().title.toUpperCase();
        if (cat == PRESETS_TAB) {
            skin.sectionTitle(g, font, 122, 96, 306, title, null, time);
            for (int i = 0; i < Wardrobe.PRESETS; i++) presetCard(g, i, 122 + i * 104, 120);
            button(g, "clearAll", 122, 258, 306, 26, "ЗНЯТИ ВСЕ", MetaSkin.Kind.DANGER, () -> {
                click();
                look().clear();
                selected = null;
                dirty();
                say("Усе знято", false);
            });
            return;
        }
        List<CosmeticDef> list = pieces(slot());
        int owned = 0;
        for (CosmeticDef d : list) if (owns(d)) owned++;
        skin.sectionTitle(g, font, 122, 96, 306, title, owned + " / " + list.size(), time);
        if (list.isEmpty()) {
            MetaUi.text(g, font, "Предметів поки немає", 122, 124, MetaUi.solid(theme.dim()), false);
            MetaUi.textS(g, font, "Слідкуй за магазином і пропуском сезону.", 122, 138, .8f, MetaUi.a(theme.dim(), .7f), false);
            return;
        }
        int perRow = 3, maxRows = 2;
        int pages = (list.size() + perRow * maxRows - 1) / (perRow * maxRows);
        pagesNow = Math.max(1, pages);
        scroll = Math.max(0, Math.min(scroll, pages - 1));
        int start = scroll * perRow * maxRows;
        for (int i = start; i < Math.min(list.size(), start + perRow * maxRows); i++) {
            int k = i - start;
            pieceCard(g, list.get(i), 122 + (k % perRow) * 104, 120 + (k / perRow) * 134, k);
        }
        if (pages > 1) {
            MetaUi.textC(g, font, (scroll + 1) + " / " + pages, 275, 434, MetaUi.solid(theme.dim()), false);
            button(g, "pgPrev", 122, 428, 40, 20, "<", false, scroll > 0 ? () -> { scroll--; catTime = time; sound("page"); } : null);
            button(g, "pgNext", 388, 428, 40, 20, ">", false, scroll < pages - 1 ? () -> { scroll++; catTime = time; sound("page"); } : null);
        }
    }

    private boolean hasUnseen(CosmeticSlot s) {
        MetaProfile p = me();
        if (p == null || p.unseen.isEmpty() || mode == null) return false;
        for (CosmeticDef d : mode.cosmetics.bySlot(s)) if (p.unseen.contains(d.id())) return true;
        return false;
    }

    static String iconOf(CosmeticSlot s) {
        return switch (s) { case HEAD -> "head"; case BODY -> "body"; case LEGS -> "legs"; case BACK -> "back"; case PET -> "pet"; case AURA -> "aura"; };
    }

    private void pieceCard(GuiGraphics g, CosmeticDef d, int bx, int by, int idx) {
        int w = 98, h = 128, ph = 88;
        boolean sel = d == selected, own = owns(d);
        float hv = hv("card" + d.id(), zone(bx, by, w, h, () -> {
            click();
            if (d != selected) clearPending();
            selected = d;
            markSeen(d);
            if (own && !worn(d)) wear(d, true);
            else burstItem(accent, 18);
        }));
        float appear = MetaUi.outBack(MetaUi.clamp01((time - catTime - .1f - idx * .07f) / .45f));
        if (appear <= .02f) return;
        int x = bx, y = by + Math.round((1f - appear) * 24f);
        int rc = d.rarity().color;
        skin.card(g, x, y, w, h, rc, sel, hv, time);
        skin.stage(g, x + 2, y + 2, w - 4, ph, rc, time, hv);
        boolean au = d.slot() == CosmeticSlot.AURA;
        Worn w1 = worn(d) ? look().get(d.slot()).copy() : new Worn(d.id(), d.defaultColor());
        w1.validate(d.slot());
        figure(g, x + w / 2, y + (au ? 2 + ph - 4 : 84), (au ? 26 : 32) + 2 * hv,
                faceYaw(d.slot()) + (float) Math.sin(time * 1.1 + idx) * 20f + hv * 35f, new Look().only(d.slot(), w1),
                x + 2, y + 2, w - 4, ph, 0, 0, au);
        if (!own) {
            g.fill(x + 2, y + 2, x + w - 2, y + 2 + ph, MetaUi.a(0, .42f));
            MetaUi.lock(g, x + w / 2 - 3, y + 38, MetaUi.a(0xFFFFFF, .85f));
        }
        int ny = y + ph + 6, lines = 0;
        for (String line : MetaUi.wrapS(font, d.name(), w - 12, .85f)) {
            if (lines++ >= 2) break;
            MetaUi.textS(g, font, line, x + 6, ny, .85f, MetaUi.solid(theme.text()), false);
            ny += 9;
        }
        if (!own) {
            String price = priceText(d);
            if (!price.isEmpty()) {
                // ціна — плашкою в правому нижньому куті сцени: так вона ніколи не налазить на ярлик рідкості
                price = MetaUi.fitS(font, price, w - 16, 1f);
                int pw = Math.round(MetaUi.widthS(font, price, 1f)), px = x + w - 7 - pw, py = y + 2 + ph - 14;
                MetaUi.rrect(g, px - 3, py - 2, pw + 6, 13, 3, MetaUi.a(0, .78f));
                MetaUi.textS(g, font, price, px, py, 1f, MetaUi.solid(theme.gold()), false);
            }
        }
        // Рідкість — під назвою, окремим рядком: раніше ярлик стояв у сцені й налазив на ноги моделі.
        skin.tag(g, font, x + 5, y + h - 13, d.rarity().title, rc, true);
        if (worn(d)) MetaUi.check(g, x + w - 13, y + 7, MetaUi.solid(theme.good()));
        MetaProfile p = me();
        if (p != null && p.unseen.contains(d.id())) skin.tag(g, font, x + 5, y + 5, "НОВЕ", theme.gold(), true);
        skin.cardOverlay(g, x, y, w, h, rc, sel, hv, time);
    }

    private String priceText(CosmeticDef d) {
        if (mode == null) return "";
        ShopOffer o = mode.offerFor(d.id());
        if (o != null) return o.price() <= 0 ? "БЕЗКОШТОВНО" : MetaUi.num(o.price()) + " " + currencyShort(o.currency());
        if (mode.recipeFor(d.id()) != null) return "МАЙСТЕРНЯ";
        Integer lvl = trackLevelOf(d);
        return lvl != null ? "ПРОПУСК · " + lvl : "";
    }

    private Integer trackLevelOf(CosmeticDef d) {
        for (Map.Entry<Integer, List<Reward>> e : mode.track.steps().entrySet()) {
            for (Reward r : e.getValue()) if (r.type() == Reward.Type.COSMETIC && r.id().equals(d.id())) return e.getKey();
        }
        return null;
    }

    private String currencyShort(String id) {
        Currency c = mode.currency(id);
        return c == null ? id : c.name();
    }

    private void presetCard(GuiGraphics g, int slot, int x, int y) {
        int w = 98, h = 128, ph = 88;
        boolean sel = slot == selectedPreset;
        float hv = hv("slot" + slot, zone(x, y, w, h, () -> { click(); selectedPreset = slot; }));
        skin.card(g, x, y, w, h, theme.gold(), sel, hv, time);
        skin.stage(g, x + 2, y + 2, w - 4, ph, theme.gold(), time, hv);
        Look s = wardrobe.preset(scope(), slot);
        if (s != null) figure(g, x + w / 2, y + 84, 32, 150, s, x + 2, y + 2, w - 4, ph, 0, 0, false);
        else MetaUi.textC(g, font, "порожньо", x + w / 2, y + 40, MetaUi.a(theme.dim(), .8f), false);
        MetaUi.text(g, font, MetaUi.fit(font, presetTitle(slot), w - 12), x + 6, y + ph + 7, MetaUi.solid(theme.text()), false);
        MetaUi.textS(g, font, s != null ? "збережено" : "—", x + 6, y + ph + 20, .8f, s != null ? MetaUi.solid(theme.good()) : MetaUi.solid(theme.dim()), false);
        skin.cardOverlay(g, x, y, w, h, theme.gold(), sel, hv, time);
    }

    private static float faceYaw(CosmeticSlot s) { return s == CosmeticSlot.BACK ? 300f : 150f; }

    /** true лише під час малювання головного манекена у вікні примірки: тоді діють анімації предметів. */
    private boolean animatedFigure;
    /** Варіант, яким малювати манекен (null — поточний); картки вибору маніяка підставляють свій. */
    private String previewVar;

    /** У скільки разів персонаж вищий за гравця (маніяк): тоді превʼю зменшується, щоб він влазив у вікно. */
    private static float heightFit(String v) {
        float[] f = CosmeticRenderer.variantFit.apply(v);
        return f == null || f.length < 1 || f[0] <= 0f ? 1f : f[0];
    }

    /** Манекен із образом, обрізаний прямокутником (у дизайнових координатах). */
    private void figure(GuiGraphics g, int cx, int fy, float size, float yawDeg, Look lk,
                        int clx, int cly, int clw, int clh, float lift, float lean, boolean tilt) {
        if (mannequin == null) return;
        String pv = previewVar != null ? previewVar : variant;
        size /= 1f + (heightFit(pv) - 1f) * .45f;   // високий персонаж — трохи менший, але не дрібний
        g.enableScissor((int) (ox + clx * ui), (int) (oy + cly * ui), (int) (ox + (clx + clw) * ui), (int) (oy + (cly + clh) * ui));
        CosmeticRenderer.previewVariant = pv;
        CosmeticRenderer.preview = lk;
        CosmeticRenderer.drawingPreview = true;
        CosmeticRenderer.previewLift = lift;
        CosmeticRenderer.previewLean = lean;
        CosmeticRenderer.previewYaw = yawDeg;
        CosmeticRenderer.previewTilt = tilt ? .42f : 0f;
        CosmeticRenderer.previewAnimated = animatedFigure;
        Preview.animatorOverride = figAnim != null ? figAnim : mannequinAnim;
        Preview.partialOverride = walkPartial();
        try {
            // Спільний рендер превʼю: аура позаду моделі, сцена трохи нахилена, кільце вписане у вікно.
            Preview.render(g, cx, fy, size, yawDeg, mannequin, lk == null ? null : lk.get(CosmeticSlot.AURA), tilt, clw);
        } finally {
            CosmeticRenderer.drawingPreview = false;
            CosmeticRenderer.preview = null;
            CosmeticRenderer.previewLift = CosmeticRenderer.previewLean = CosmeticRenderer.previewTilt = 0;
            CosmeticRenderer.previewAnimated = false;
            CosmeticRenderer.previewVariant = null;
            Preview.animatorOverride = null;
            Preview.partialOverride = -1f;
            g.disableScissor();
        }
    }

    // ── центр: модель ───────────────────────────────────────────────────
    private double[] itemSpot(CosmeticSlot k) {
        if (mannequin == null || k == null) return null;
        Worn w = look().get(k);
        if (w == null) return null;
        float size = BASE * zoom;
        double ang = Math.toRadians(yaw), cx = VCX + dispX, fy = VFY + dispY - INTRO_H * introLift;
        return switch (k) {
            case PET -> {
                double phase = (mannequin.tickCount + walkPartial()) * .075 * w.param(k, "speed");
                double h = w.param(k, "y") + Math.sin(phase) * w.param(k, "bob") + curLift;
                yield new double[]{cx - size * (w.param(k, "x") * Math.cos(ang) + w.param(k, "z") * Math.sin(ang)), fy - size * h, size * w.param(k, "scale") * .62};
            }
            case BACK -> {
                double b = -CosmeticRenderer.backCenterZ(w);
                yield new double[]{cx - size * (b * Math.sin(ang)), fy - size * (1.126 + w.param(k, "y")), size * w.param(k, "scale") * .42};
            }
            case HEAD -> new double[]{cx, fy - size * (1.82 + w.param(k, "y")), size * .4 * w.param(k, "scale")};
            default -> null;
        };
    }

    /** Предмети, які можна схопити прямо на моделі. */
    private static final CosmeticSlot[] GRABBABLE = {CosmeticSlot.HEAD, CosmeticSlot.BACK, CosmeticSlot.PET};

    private boolean hit(CosmeticSlot k) {
        // рюкзак — за спиною: поки модель стоїть обличчям до нас, його не видно, і схопити його «крізь» тулуб не можна
        if (k == CosmeticSlot.BACK && !backVisible()) return false;
        double[] p = itemSpot(k);
        if (p == null) return false;
        double dx = mx - p[0], dy = my - p[1];
        return dx * dx + dy * dy <= p[2] * p[2];
    }

    /** Чи видно спину моделі (повернута спиною або боком): лише тоді рюкзак можна схопити. */
    private boolean backVisible() {
        return Math.cos(Math.toRadians(yaw + eYaw)) > -0.3;
    }

    /** Одягнений предмет під курсором (спершу — з відкритої вкладки), або null. */
    private CosmeticSlot hoverSlot() {
        if (naming || drag != 0 || !over(VX, VY, VW, VH) || introLift > 0f) return null;
        CosmeticSlot cur = slot();
        if (cur != null && hit(cur)) return cur;
        List<CosmeticSlot> a = allowed();
        for (CosmeticSlot k : GRABBABLE) if (k != cur && a.contains(k) && hit(k)) return k;
        return null;
    }

    /** Навів/схопив предмет на моделі з іншої вкладки — перемкнути каталог на нього. */
    private void focusSlot(CosmeticSlot k) {
        if (k == slot()) return;
        clearPending();
        cat = k.ordinal();
        Worn w = look().get(k);
        CosmeticDef d = w == null || mode == null ? null : mode.cosmetics.get(w.item);
        selected = d != null ? d : first(k);
        selectedPreset = -1;
        catTime = time;
        scroll = 0;
    }

    @Override
    protected int[] focusTarget() {
        if (!naming) {
            CosmeticSlot fs = drag == 3 ? slot() : hoverSlot();
            double[] p = fs == null ? null : itemSpot(fs);
            if (p != null) {
                int r = (int) (p[2] * .62);
                return new int[]{(int) p[0] - r, (int) p[1] - r, 2 * r, 2 * r, 1000 + fs.ordinal()};
            }
        }
        return null;   // кутики — лише на косметиці на моделі
    }

    private void drawViewport(GuiGraphics g, float jumpH, float lift) {
        float sm = MetaUi.clamp01((time - .2f) / .8f);
        // поміст — під ногами: з аурою модель піднята на 44 px, тож і поміст разом з нею (інакше лінія висіла нижче кільця)
        skin.viewport(g, VX, VY, VW, VH, VCX + (int) panX, VFY + (int) (panY - 44f * auraMix), accent, time, sm * (1f - auraMix * .7f));
        float size = BASE * zoom * (1f - .28f * auraMix);
        float shake = landShake * landShake * 4f;
        int fx = (int) (VCX + dispX + Math.sin(time * 71f) * shake),
            fy = (int) (VFY + dispY - size * jumpH - INTRO_H * introLift - 44f * auraMix + Math.cos(time * 83f) * shake);
        figCx = fx;
        figSize = size;
        figFoot = VFY + panY - 44f * auraMix;   // земля, не залежить від польоту
        drawEquipBack(g, jumpH);
        animatedFigure = true;
        applyDeform(size);
        try {
            // у падінні — пів-оберту, щоб приземлитися обличчям до глядача
            figure(g, fx, fy, size, yaw + eYaw + introLift * introLift * 200f, look(), VX + 2, VY + 22, VW - 4, VH - 24, lift, curLean, auraMix > .5f);
        } finally {
            animatedFigure = false;
            Preview.resetDeform();
        }
        depthBarrier(g);   // передня дуга орбіти й підписи — поверх моделі
        drawEquipFront(g, jumpH);

        // підписи — ПІСЛЯ моделі, на затемненій смузі: пересунута модель не налазить на текст
        g.fillGradient(VX + 2, VY + 2, VX + VW - 2, VY + 22, MetaUi.a(0xFF030304, .85f * sm), MetaUi.a(0xFF030304, 0f));
        MetaUi.text(g, font, "ПРИМІРКА", VX + 10, VY + 8, MetaUi.a(theme.dim(), sm), false);
        if (mode != null && mode.variants.size() > 1) {
            String v = mode.variantNames.getOrDefault(variant, variant).toUpperCase();
            MetaUi.textR(g, font, v, VX + VW - 10, VY + 8, MetaUi.a(theme.gold(), sm), false);
        }

        // підказка бінда — біля курсора (кутики навколо предмета малює MetaScreen за focusTarget())
        if (!naming) {
            // коротко: назва й бінди вже є в правій панелі та в нижньому рядку — біля курсора лише розмір
            if (drag == 3) cursorTip(percentText(slot()));
            else if (drag == 0 && over(VX, VY, VW, VH)) {
                CosmeticSlot hs = hoverSlot();
                if (hs != null) cursorTip(percentText(hs));   // загальні бінди — у нижньому рядку, біля курсора не дублюємо (і не закриваємо обличчя моделі)
            }
        }
    }

    private String percentText(CosmeticSlot s) {
        Worn w = s == null ? null : look().get(s);
        if (w == null) return "";
        if (s == CosmeticSlot.PET && Screen.hasControlDown()) return "розмах " + s.param("bob").percent(w.param(s, "bob")) + "%";
        if (s == CosmeticSlot.PET && Screen.hasAltDown()) return "швидкість " + s.param("speed").percent(w.param(s, "speed")) + "%";
        return s.param("scale").percent(w.param(s, "scale")) + "%";
    }

    // ── права панель ────────────────────────────────────────────────────
    private void drawRight(GuiGraphics g) {
        int x = 738, y = 84, w = 208, h = 374;
        if (cat == PRESETS_TAB) { drawPresetPanel(g, x, y, w, h); return; }
        if (cat == EMOTES_TAB) { drawEmotePanel(g, x, y, w, h); return; }
        if (cat == CHARS_TAB) { panel(g, x, y, w, h, false); drawCharacterPicker(g, x, y, w, h); return; }
        panel(g, x, y, w, h, false);
        if (selected == null) {
            if (isCharacter()) drawCharacterPicker(g, x, y, w, h);
            else MetaUi.textC(g, font, "Обери предмет", x + w / 2, y + h / 2 - 4, MetaUi.a(theme.dim(), .8f), false);
            return;
        }
        CosmeticDef d = selected;
        boolean own = owns(d), on = worn(d);
        if (on) {
            MetaUi.rrect(g, x + 14, y + 15, 6, 6, 2, MetaUi.solid(theme.good()));
            MetaUi.text(g, font, "ОДЯГНЕНО", x + 26, y + 14, MetaUi.solid(theme.good()), false);
        } else skin.tag(g, font, x + 14, y + 13, d.rarity().title.toUpperCase(), d.rarity().color, true);
        float hvX = hv("x", zone(x + w - 28, y + 8, 20, 20, () -> { selected = null; click(); }));
        MetaUi.cross(g, x + w - 21, y + 15, MetaUi.mix(MetaUi.solid(theme.dim()), 0xFFFFFFFF, hvX));
        MetaUi.textS(g, font, MetaUi.fit(font, d.name(), 140), x + 14, y + 34, 1.3f, MetaUi.solid(theme.text()), true);
        skin.divider(g, x + 14, y + 50, w - 28);

        int pvY = y + 58, pvH = 146;
        skin.stage(g, x + 12, pvY, w - 24, pvH, d.rarity().color, time, 0);
        boolean au = d.slot() == CosmeticSlot.AURA;
        Worn cur = on ? look().get(d.slot()).copy() : new Worn(d.id(), d.defaultColor());
        cur.validate(d.slot());
        // лише сам предмет (персонаж з ним і так стоїть у примірці): повільно обертається й «плаває» над тінню
        float bob = au ? 0f : (float) Math.sin(time * 1.7) * 3.5f;
        int pcx = x + w / 2, pcy = pvY + pvH / 2 + (au ? 16 : -4);
        if (!au) MetaUi.ellipse(g, pcx, pvY + pvH - 22, 30 - (int) bob, 5, MetaUi.a(0, .35f));
        Preview.cosmeticOnly(g, this, cur, d.slot(), pcx, pcy + bob, au ? 50f : d.slot() == CosmeticSlot.PET ? 70f : 82f,
                (au ? 0f : 200f) + time * 40f, x + 12, pvY, w - 24, pvH);

        if (own) {
            MetaProfile pr = me();
            MetaUi.text(g, font, "КОЛІР", x + 14, y + 212, MetaUi.solid(theme.dim()), false);
            if (mode.colorPrice > 0) {
                MetaUi.textR(g, font, MetaUi.num(mode.colorPrice) + " " + currencyShort(mode.currency.id()) + " / відтінок",
                        x + w - 14, y + 212, MetaUi.solid(theme.dim()), false);
            }
            int[] pal = d.palette().length == 0 ? new int[]{d.defaultColor(), 0xFFFFFF, 0xFF7A1A, 0xA77BFF, 0x55E5FF, 0x3DDC84} : d.palette();
            for (int i = 0; i < Math.min(6, pal.length); i++) {
                int rgb = pal[i], sx = x + 16 + i * 30, sy = y + 224;
                boolean haveColor = pr != null && ownsColor(pr, d, rgb);
                float hv = hv("col" + i, zone(sx, sy, 24, 22, () -> {
                    if (!worn(d)) wear(d, true);
                    Worn ww = look().get(d.slot());
                    if (ww == null) return;
                    if (pr == null || ownsColor(pr, d, rgb)) {
                        pendingColor = -1;
                        ww.color = rgb;
                        dirty();
                        burstItem(rgb, 40);
                    } else {
                        // не куплений відтінок: лише примірка, купівля — окремою кнопкою нижче
                        if (pendingColor < 0) prevColor = ww.color;
                        pendingColor = rgb;
                        ww.color = rgb;
                        burstItem(rgb, 24);
                    }
                    click();
                }));
                boolean isCur = on && (look().get(d.slot()).color & 0xFFFFFF) == rgb;
                MetaUi.rrect(g, sx, sy, 24, 22, 6, MetaUi.solid(MetaUi.bright(rgb, .6f)));
                MetaUi.rrect(g, sx + 1, sy + 1, 22, 20, 5, MetaUi.solid(rgb));
                if (!haveColor) {
                    MetaUi.rrect(g, sx + 1, sy + 1, 22, 20, 5, MetaUi.a(0, .38f));
                    MetaUi.lock(g, sx + 9, sy + 7, MetaUi.a(0xFFFFFF, .9f));
                }
                if (isCur || hv > .02f) skin.focus(g, sx - 3, sy - 3, 30, 28, isCur ? 0xFFFFFF : MetaUi.mix(0, 0xFFFFFF, hv), time);
            }
            boolean buying = pendingColor >= 0 && pr != null && !ownsColor(pr, d, pendingColor);
            if (buying) {
                boolean can = pr.wallet.canAfford(mode.currency.id(), mode.colorPrice);
                final int want = pendingColor;
                primary(g, "buyColor", x + 12, y + 254, w - 24, 28,
                        "КУПИТИ КОЛІР · " + MetaUi.num(mode.colorPrice) + " " + currencyShort(mode.currency.id()),
                        can ? () -> { sound("buy"); if (isCharacter()) MetaClient.buyColor(d.id(), want, variant); else MetaClient.buyColor(d.id(), want); } : null);
                if (!can) MetaUi.textSC(g, font, "Не вистачає " + currencyShort(mode.currency.id()), x + w / 2, y + 283, .8f, MetaUi.solid(theme.bad()), false);
            } else {
                button(g, "reset", x + 12, y + 258, w - 24, 24, "СКИНУТИ ПОСАДКУ", MetaSkin.Kind.DANGER, on ? () -> {
                    Worn ww = look().get(d.slot());
                    ww.params.clear();
                    ww.color = d.defaultColor();
                    ww.validate(d.slot());
                    pendingColor = -1;
                    dirty();
                    click();
                    say("Налаштування предмета скинуто", false);
                } : null);
            }
            primary(g, "wear", x + 12, y + 290, w - 24, 30, on ? "ЗНЯТИ" : "ОДЯГНУТИ", () -> { wear(d, !on); click(); });
        } else {
            int ly = y + 212;
            for (String line : MetaUi.wrapS(font, d.description(), w - 24, .8f)) {
                MetaUi.textS(g, font, line, x + 12, ly, .8f, MetaUi.solid(theme.dim()), false);
                ly += 9;
                if (ly > y + 246) break;
            }
            ShopOffer offer = mode.offerFor(d.id());
            Recipe recipe = mode.recipeFor(d.id());
            Integer lvl = trackLevelOf(d);
            MetaProfile p = me();
            int by = y + 258;
            if (offer != null) {
                boolean can = p != null && p.wallet.canAfford(offer.currency(), offer.price());
                primary(g, "buy", x + 12, by, w - 24, 28, "КУПИТИ · " + MetaUi.num(offer.price()) + " " + currencyShort(offer.currency()),
                        can ? () -> { sound("buy"); if (isCharacter()) MetaClient.buy(offer.id(), variant); else MetaClient.buy(offer.id()); } : null);
                if (isCharacter() && can) MetaUi.textSC(g, font, "лише для «" + variantName(variant) + "»", x + w / 2, by + 32, .75f, MetaUi.solid(theme.dim()), false);
                if (!can) MetaUi.textSC(g, font, "Не вистачає " + currencyShort(offer.currency()), x + w / 2, by + 32, .8f, MetaUi.solid(theme.bad()), false);
                by += 44;
            }
            if (recipe != null) {
                button(g, "craft", x + 12, by, w - 24, 22, "ДО МАЙСТЕРНІ", false, () -> { click(); MetaScreens.open("craft", parent); });
                by += 28;
            }
            if (lvl != null) MetaUi.textSC(g, font, "Нагорода пропуску · ступінь " + lvl, x + w / 2, by + 4, .8f, MetaUi.solid(theme.gold()), false);
        }
        String how = switch (d.slot()) {
            case PET -> "Тягни улюбленця на моделі. Shift — уперед/назад. Колесо — розмір.";
            case AURA -> "Аура під гравцем. Колесо над моделлю — розмір.";
            case BACK -> "Тягни вгору чи вниз; боком до моделі — відстань від спини.";
            default -> "Тягни предмет вгору або вниз. Колесо — розмір.";
        };
        if (how.isEmpty()) return;   // довідка — у контекстній підказці (під час перетягування) і футері
    }

    /** Ліва панель «Маніяки»: велика картка на кожного — модель у його образі; клік — приміряти цього маніяка. */
    private void drawCharacterList(GuiGraphics g) {
        List<String> chars = mode.characterVariants();
        skin.sectionTitle(g, font, 122, 96, 306, mode.charactersPlural.toUpperCase(), String.valueOf(chars.size()), time);
        int perRow = 3;
        for (int i = 0; i < chars.size(); i++) {
            String v = chars.get(i);
            int x = 122 + (i % perRow) * 104, y = 120 + (i / perRow) * 160, w = 98, h = 152, ph = 118;
            boolean act = v.equals(variant);
            float hv = hv("chl" + v, zone(x, y, w, h, () -> { if (!v.equals(variant)) switchVariant(v); else sound("click"); }));
            float appear = MetaUi.outBack(MetaUi.clamp01((time - catTime - .1f - i * .07f) / .45f));
            if (appear <= .02f) continue;
            int yy = y + Math.round((1f - appear) * 24f);
            skin.card(g, x, yy, w, h, accent, act, hv, time);
            skin.stage(g, x + 2, yy + 2, w - 4, ph, accent, time, hv);
            String keep = previewVar;
            previewVar = v;
            try {
                figure(g, x + w / 2, yy + ph - 6, 48 + 4 * hv, 160 + (float) Math.sin(time * .9 + i) * 16f + hv * 30f,
                        wardrobe.look(v), x + 2, yy + 2, w - 4, ph, 0, 0, false);
            } finally {
                previewVar = keep;
            }
            MetaUi.textS(g, font, MetaUi.fitS(font, variantName(v), w - 12, 1f), x + 6, yy + ph + 8, 1f,
                    MetaUi.solid(act ? theme.text() : theme.dim()), false);
            if (act) skin.tag(g, font, x + 5, yy + h - 14, "ПРИМІРЯНО", theme.good(), true);
            skin.cardOverlay(g, x, yy, w, h, accent, act, hv, time);
        }
    }

    /**
     * Вибір маніяка (права панель, коли предмет не вибрано): картка на кожного — його модель у ЙОГО образі, ім'я,
     * скільки предметів куплено саме для нього. Клік — перемкнути примірку на цього маніяка.
     */
    private void drawCharacterPicker(GuiGraphics g, int x, int y, int w, int h) {
        List<String> chars = mode.characterVariants();
        skin.sectionTitle(g, font, x + 12, y + 12, w - 24, mode.charactersTitle.toUpperCase(), chars.size() > 1 ? chars.size() + "" : null, time);
        int top = y + 34, gap = 8, n = Math.max(1, chars.size());
        int ch = Math.min(176, (h - 34 - 34 - gap * (n - 1)) / n);
        MetaProfile p = me();
        for (int i = 0; i < chars.size(); i++) {
            String v = chars.get(i);
            int cy = top + i * (ch + gap), cx = x + 12, cw = w - 24;
            boolean act = v.equals(variant);
            float hv = hv("char" + v, zone(cx, cy, cw, ch, () -> { if (!v.equals(variant)) switchVariant(v); }));
            float appear = MetaUi.outBack(MetaUi.clamp01((time - catTime - i * .08f) / .4f));
            int ox2 = Math.round((1f - appear) * 30f);
            skin.card(g, cx + ox2, cy, cw, ch, accent, act, hv, time);
            skin.stage(g, cx + ox2 + 2, cy + 2, cw - 4, ch - 24, accent, time, hv);
            String keep = previewVar;
            previewVar = v;
            try {
                figure(g, cx + ox2 + cw / 2, cy + ch - 30, (ch - 40) * .5f, 160 + (float) Math.sin(time * .9 + i) * 16f + hv * 30f,
                        wardrobe.look(v), cx + ox2 + 2, cy + 2, cw - 4, ch - 24, 0, 0, false);
            } finally {
                previewVar = keep;
            }
            MetaUi.text(g, font, variantName(v), cx + ox2 + 8, cy + ch - 16, MetaUi.solid(act ? theme.text() : theme.dim()), false);
            if (p != null) {
                int own = 0;
                for (CosmeticDef d : mode.cosmetics.all()) if (p.ownsFor(mode, v, d.id())) own++;
                MetaUi.textR(g, font, own + " предм.", cx + ox2 + cw - 8, cy + ch - 16, MetaUi.a(theme.dim(), .8f), false);
            }
            if (act) MetaUi.check(g, cx + ox2 + cw - 13, cy + 7, MetaUi.solid(theme.good()));
            skin.cardOverlay(g, cx + ox2, cy, cw, ch, accent, act, hv, time);
        }
        List<String> tip = MetaUi.wrapS(font, "У кожного маніяка свої предмети, кольори й образи. Обери предмет ліворуч, щоб приміряти.", w - 24, 1f);
        int ly = y + h - 8 - tip.size() * 11;
        for (String line : tip) {
            MetaUi.textS(g, font, line, x + 12, ly, 1f, MetaUi.solid(theme.dim()), false);
            ly += 11;
        }
    }

    // ── анімації ─────────────────────────────────────────────────────────
    private int wheelIndex(String id) {
        if (id == null) return -1;
        for (int i = 0; i < wheelEdit.length; i++) if (id.equals(wheelEdit[i])) return i;
        return -1;
    }

    private boolean ownsEmote(String id) { MetaProfile p = me(); return p != null && p.ownsEmote(mode, id); }

    private void drawEmoteList(GuiGraphics g) {
        List<dev.shaurmalib.meta.cosmetics.EmoteDef> list = new ArrayList<>(mode.emotes.values());
        int owned = 0;
        for (var d : list) if (ownsEmote(d.id())) owned++;
        skin.sectionTitle(g, font, 122, 96, 306, "АНІМАЦІЇ", owned + " / " + list.size(), time);
        int perRow = 3, maxRows = 3, per = perRow * maxRows;
        int pages = (list.size() + per - 1) / per;
        pagesNow = Math.max(1, pages);
        scroll = Math.max(0, Math.min(scroll, pages - 1));
        int start = scroll * per;
        for (int i = start; i < Math.min(list.size(), start + per); i++) {
            int k = i - start;
            emoteCard(g, list.get(i), 122 + (k % perRow) * 104, 120 + (k / perRow) * 100, k);
        }
        if (pages > 1) {
            MetaUi.textC(g, font, (scroll + 1) + " / " + pages, 275, 434, MetaUi.solid(theme.dim()), false);
            button(g, "pgPrev", 122, 428, 40, 20, "<", false, scroll > 0 ? () -> { scroll--; catTime = time; sound("page"); } : null);
            button(g, "pgNext", 388, 428, 40, 20, ">", false, scroll < pages - 1 ? () -> { scroll++; catTime = time; sound("page"); } : null);
        }
    }

    /** Окремий аніматор на кожну картку: модель на картці весь час грає СВОЮ анімацію. */
    private final Map<String, Object> cardAnims = new java.util.HashMap<>();
    /** Аніматор, яким малювати наступну фігуру (null — головний манекен). */
    private Object figAnim;

    private Object cardAnim(String emoteId) {
        if (minecraft == null || minecraft.player == null) return null;
        return cardAnims.computeIfAbsent(emoteId, k -> {
            Object a = MetaAnimationPreview.createPlayerAnimator(minecraft.player.getUUID());
            MetaAnimationPreview.previewEmote(a, k);
            return a;
        });
    }

    private void emoteCard(GuiGraphics g, dev.shaurmalib.meta.cosmetics.EmoteDef d, int bx, int by, int idx) {
        int w = 98, h = 94, ph = 58;
        boolean sel = d.id().equals(selEmote), own = ownsEmote(d.id());
        float hv = hv("emo" + d.id(), zone(bx, by, w, h, () -> { click(); selEmote = d.id(); }));
        float appear = MetaUi.outBack(MetaUi.clamp01((time - catTime - .1f - idx * .05f) / .45f));
        if (appear <= .02f) return;
        int x = bx, y = by + Math.round((1f - appear) * 20f);
        int rc = d.rarity().color;
        skin.card(g, x, y, w, h, rc, sel, hv, time);
        skin.stage(g, x + 2, y + 2, w - 4, ph, rc, time, hv);
        // жива модель гравця з цією анімацією (кожна картка — свій аніматор)
        figAnim = cardAnim(d.id());
        Look bare = look().copy();
        bare.remove(CosmeticSlot.AURA);
        bare.remove(CosmeticSlot.PET);
        try {
            // зріст ~1.8 бл × 19 px + капелюх — уміщається в сцену 58 px з повітрям зверху й знизу
            figure(g, x + w / 2, y + ph - 5, 19 + 1.5f * hv, 160 + (float) Math.sin(time * .9 + idx) * 14f + hv * 30f, bare,
                    x + 2, y + 2, w - 4, ph, 0, 0, false);
        } finally {
            figAnim = null;
        }
        if (!own) {
            g.fill(x + 2, y + 2, x + w - 2, y + 2 + ph, MetaUi.a(0, .38f));
            MetaUi.lock(g, x + w - 13, y + 7, MetaUi.a(0xFFFFFF, .85f));
            // компактно — іконка валюти й число в правому нижньому куті сцени, щоб не перекривати ноги моделі
            var cur = mode.currency(d.currency());
            String price = d.price() <= 0 ? "0" : MetaUi.num(d.price());
            int pw = Math.round(MetaUi.widthS(font, price, 1f)) + 12, px = x + w - 7 - pw, py = y + 2 + ph - 15;
            MetaUi.rrect(g, px - 2, py - 2, pw + 4, 13, 3, MetaUi.a(0, .8f));
            icon(g, cur == null ? "coin" : cur.icon(), px, py, 1, MetaUi.solid(cur == null ? theme.gold() : cur.color()));
            MetaUi.textS(g, font, price, px + 11, py + 1, 1f, MetaUi.solid(theme.gold()), false);
        }
        int si = wheelIndex(d.id());
        // «СЛОТ N» — у рядку назви праворуч (у сцені мітка 1× закривала голову моделі)
        String slotTag = own && si >= 0 ? "С" + (si + 1) : "";
        int stw = slotTag.isEmpty() ? 0 : Math.round(MetaUi.widthS(font, slotTag, 1f)) + 10;
        MetaUi.textS(g, font, MetaUi.fitS(font, d.name(), w - 12 - stw - 4, 1f), x + 6, y + ph + 7, 1f,
                MetaUi.solid(own ? theme.text() : theme.dim()), false);
        if (stw > 0) skin.tag(g, font, x + w - 6 - stw, y + ph + 6, slotTag, theme.gold(), true);
        skin.tag(g, font, x + 5, y + h - 13, d.rarity().title, rc, true);
        skin.cardOverlay(g, x, y, w, h, rc, sel, hv, time);
    }

    /** Права панель анімацій: назва, колесо з 8 слотів (клік — поставити/прибрати), купівля. */
    private void drawEmotePanel(GuiGraphics g, int x, int y, int w, int h) {
        panel(g, x, y, w, h, false);
        var d = selEmote == null ? null : mode.emotes.get(selEmote);
        if (d == null) {
            MetaUi.textC(g, font, "Обери анімацію", x + w / 2, y + h / 2 - 4, MetaUi.a(theme.dim(), .8f), false);
            return;
        }
        boolean own = ownsEmote(d.id());
        int inWheel = wheelIndex(d.id());
        skin.tag(g, font, x + 14, y + 13, d.rarity().title.toUpperCase(), d.rarity().color, true);
        MetaUi.textS(g, font, MetaUi.fit(font, d.name(), 140), x + 14, y + 34, 1.3f, MetaUi.solid(theme.text()), true);
        skin.divider(g, x + 14, y + 50, w - 28);

        // колесо: 8 слотів по колу (0 — угорі, за годинниковою), як у грі
        int cx = x + w / 2, cy = y + 136, R = 70;   // 0.707·70 = 49.5 ≥ 44 + 4: діагональні слоти не налазять
        float spin = MetaUi.outBack(MetaUi.clamp01((time - catTime) / .5f));
        MetaUi.ring(g, cx, cy, R, R, MetaUi.a(theme.border(), .95f), 48, time * .15f);
        MetaUi.ring(g, cx, cy, R + 1, R + 1, MetaUi.a(theme.border(), .6f), 48, time * .15f);
        MetaUi.textSC(g, font, "КОЛЕСО", cx, cy - 7, .8f, MetaUi.solid(theme.dim()), false);
        MetaUi.textSC(g, font, inWheel >= 0 ? "слот " + (inWheel + 1) : "—", cx, cy + 3, .8f, MetaUi.solid(inWheel >= 0 ? theme.gold() : theme.dim()), false);
        for (int i = 0; i < wheelEdit.length; i++) {
            double ang = Math.toRadians(-90 + i * 45) - (1f - spin) * 1.2;
            int sw = 44, sh = 18;
            int sx = (int) Math.round(cx + Math.cos(ang) * R * spin) - sw / 2, sy = (int) Math.round(cy + Math.sin(ang) * R * spin) - sh / 2;
            String id = wheelEdit[i];
            var sd = id == null ? null : mode.emotes.get(id);
            String label = id == null ? "+" : sd != null ? sd.name() : id.substring(id.indexOf(':') + 1);
            boolean here = d.id().equals(id);
            final int slot = i;
            boolean usable = own || id != null;   // порожній слот для некупленої анімації — неактивний (раніше клік мовчки нічого не робив)
            boolean on = zone(sx, sy, sw, sh, usable ? () -> onWheelSlot(slot) : () -> { say("Спершу купи цю анімацію", true); sound("error"); });
            float hv = hv(WSLOT[i], on);
            // у слоті — ініціал (5 літер не влазять і обрізались до «ПОМАХ…»), повна назва — у підказці біля курсора
            String mark = id == null ? "+" : label.substring(0, Math.min(2, label.length())).toUpperCase();
            skin.button(g, font, sx, sy, sw, sh, mark, here ? MetaSkin.Kind.SELECTED : MetaSkin.Kind.NORMAL, hv, usable, time);
            if (on && id != null) cursorTip(label);
        }

        int by = y + 226;
        String status = !own ? "Купи, щоб поставити в колесо" : inWheel >= 0 ? "Клік на свій слот — прибрати" : "Клік на слот — поставити сюди";
        MetaUi.textSC(g, font, status, x + w / 2, by, .8f, MetaUi.solid(own ? theme.dim() : theme.gold()), false);
        by += 16;
        MetaProfile p = me();
        if (!own) {
            boolean can = p != null && p.wallet.canAfford(d.currency(), d.price());
            primary(g, "buyEmote", x + 12, by, w - 24, 28, "КУПИТИ · " + MetaUi.num(d.price()) + " " + currencyShort(d.currency()),
                    can ? () -> { sound("buy"); MetaClient.buyEmote(d.id()); } : null);
            if (!can) MetaUi.textSC(g, font, "Не вистачає " + currencyShort(d.currency()), x + w / 2, by + 32, .8f, MetaUi.solid(theme.bad()), false);
        } else if (inWheel >= 0) {
            button(g, "unslot", x + 12, by, w - 24, 24, "ПРИБРАТИ З КОЛЕСА", MetaSkin.Kind.DANGER, () -> onWheelSlot(inWheel));
        } else {
            int free = wheelIndex(null);
            primary(g, "slotIn", x + 12, by, w - 24, 28, free >= 0 ? "У ВІЛЬНИЙ СЛОТ " + (free + 1) : "КОЛЕСО ПОВНЕ",
                    free >= 0 ? () -> onWheelSlot(free) : null);
        }
        int ly = y + h - 26;
        for (String line : MetaUi.wrapS(font, "У грі колесо — клавіша емоцій.", w - 24, 1f)) {
            if (ly > y + h - 11) break;
            MetaUi.textS(g, font, line, x + 12, ly, 1f, MetaUi.solid(theme.dim()), false);
            ly += 11;
        }
    }

    private static final String[] WSLOT = {"wslot0", "wslot1", "wslot2", "wslot3", "wslot4", "wslot5", "wslot6", "wslot7"};

    /** Клік на слот колеса: поставити вибрану анімацію (якщо вже тут — прибрати); одна анімація — один слот. */
    private void onWheelSlot(int slot) {
        if (selEmote == null) return;
        if (!ownsEmote(selEmote)) { say("Спершу купи цю анімацію", true); sound("error"); return; }
        if (selEmote.equals(wheelEdit[slot])) wheelEdit[slot] = null;
        else {
            int old = wheelIndex(selEmote);
            if (old >= 0) wheelEdit[old] = wheelEdit[slot];
            wheelEdit[slot] = selEmote;
        }
        sound("equip");
        burst(VCX + dispX, VFY + dispY - BASE * zoom, accent, 22);
        MetaClient.saveEmotes(java.util.Arrays.asList(wheelEdit.clone()));
    }

    private void drawPresetPanel(GuiGraphics g, int x, int y, int w, int h) {
        panel(g, x, y, w, h, false);
        if (selectedPreset < 0) {
            MetaUi.textC(g, font, "Обери образ", x + w / 2, y + h / 2 - 4, MetaUi.a(theme.dim(), .8f), false);
            return;
        }
        int slot = selectedPreset;
        MetaUi.textS(g, font, MetaUi.fit(font, presetTitle(slot), 150), x + 14, y + 16, 1.3f, MetaUi.solid(theme.text()), true);
        skin.divider(g, x + 14, y + 32, w - 28);
        Look s = wardrobe.preset(scope(), slot);
        skin.stage(g, x + 12, y + 58, w - 24, 146, theme.gold(), time, 0);
        if (s != null) figure(g, x + w / 2, y + 192, 58, 150 + (float) Math.sin(time * .8) * 18f, s, x + 12, y + 58, w - 24, 146, 0, 0, false);
        else MetaUi.textC(g, font, "порожньо", x + w / 2, y + 128, MetaUi.a(theme.dim(), .8f), false);
        button(g, "slotLoad", x + 12, y + 222, w - 24, 24, "ЗАСТОСУВАТИ", false, s == null ? null : () -> {
            click();
            Look copy = s.copy();
            MetaProfile p = me();
            if (p != null) copy.validate(mode.cosmetics, id -> p.ownsFor(mode, variant, id));
            wardrobe.setLook(variant, copy);
            dirty();
            startOutfit();
            say("Образ застосовано", false);
        });
        primary(g, "slotSave", x + 12, y + 256, w - 24, 30, "ЗБЕРЕГТИ ОБРАЗ…", () -> { click(); startNaming(slot); });
    }

    private void drawHints(GuiGraphics g) {
        String hint;
        if (drag == 3) hint = "Не відпускаючи кнопку, тягни предмет, а потім відпусти, щоб закріпити посадку.";
        else if (drag == 1) hint = "Відпусти кнопку — модель залишиться під цим кутом. R — скинути вид.";
        else if (selected != null && !owns(selected)) hint = isCharacter()
                ? "У «" + variantName(variant) + "» цього предмета ще нема: косметика маніяка купується окремо для кожного."
                : "Предмет ще не твій: купи в магазині, скрафти в майстерні або отримай у пропуску сезону.";
        else if (selected != null && worn(selected)) hint = "Зажми ліву кнопку на предметі й тягни, щоб змінити посадку. Колесо над предметом — розмір.";
        else hint = "Натисни на картку, щоб одягнути. ЛКМ біля моделі — повернути її.";
        int y = 468;
        // одна підказка, а не три: контекстна — лише під час перетягування (і на вкладках предметів)
        if (drag != 0 && cat >= 0) {
            for (String line : MetaUi.wrap(font, hint, 560)) { MetaUi.textC(g, font, line, VCX, y, MetaUi.solid(theme.text()), false); y += 11; }
        }
        MetaUi.textC(g, font, "ЛКМ — обертати · ПКМ — взяти модель · колесо — масштаб · Пробіл — стрибок · R — скинути вид", 480, 520,
                MetaUi.solid(theme.dim()), false);
        if (changed) MetaUi.text(g, font, "• Зберігаю…", 18, 468, MetaUi.solid(theme.dim()), false);
    }

    // ── сцена одягання: орбіта аури, тінь, хвиля ──────────────────────────
    private float equipEnv() {
        float t = time - equipStart;
        if (t < 0f || t >= EQUIP_LEN) return 0f;
        // орбіта наростає з приготування, тримається в польоті й гасне до приземлення
        return MetaUi.clamp01((t - .05f) / .35f) * MetaUi.clamp01((T_LAND + .1f - t) / .45f);
    }

    /** Задня половина орбіти (за спиною) і підлога: тінь, що зменшується в польоті, та кільце-світіння. Малюється ДО моделі. */
    private void drawEquipBack(GuiGraphics g, float jumpH) {
        float env = equipEnv();
        float lifted = Math.max(MetaUi.clamp01(eLift / FLY_H), Math.max(introLift < 1f ? introLift : 0f, MetaUi.clamp01((panY - dispY) / 70f)));
        float cx = figCx, fl = figFoot + 4f, sz = figSize;
        g.enableScissor((int) (ox + VX * ui), (int) (oy + VY * ui), (int) (ox + (VX + VW) * ui), (int) (oy + (VY + VH) * ui));
        if (env > .01f || lifted > .01f) {
            // тінь під ногами: у польоті менша й блідіша
            MetaUi.ellipse(g, (int) cx, (int) fl, (int) (sz * (.34f - .14f * lifted)), (int) (sz * (.07f - .03f * lifted)), MetaUi.a(0, .32f * (1f - .5f * lifted)));
            MetaUi.glowEllipse(g, (int) cx, (int) fl, (int) (sz * (.62f + .1f * env)), (int) (sz * .15f), equipColor, .30f * env);
        }
        if (env > .01f) orbit(g, env, false);
        // хвиля від приземлення
        float st = time - shockT;
        if (st >= 0f && st < .75f) {
            float k = st / .75f, a = (1f - k) * (1f - k);
            a *= .35f + .65f * landAmp;
            ringDots(g, cx, fl, sz * (.25f + .95f * MetaUi.outCubic(k)), sz * (.06f + .2f * MetaUi.outCubic(k)), equipColor, a * .9f, 56);
            ringDots(g, cx, fl, sz * (.15f + .70f * MetaUi.outCubic(k)), sz * (.04f + .14f * MetaUi.outCubic(k)), 0xFFFFFF, a * .6f, 40);
        }
        g.disableScissor();
    }

    /** Передня половина орбіти — поверх моделі. */
    private void drawEquipFront(GuiGraphics g, float jumpH) {
        float env = equipEnv();
        if (env <= .01f) return;
        g.enableScissor((int) (ox + VX * ui), (int) (oy + VY * ui), (int) (ox + (VX + VW) * ui), (int) (oy + (VY + VH) * ui));
        orbit(g, env, true);
        g.disableScissor();
    }

    /**
     * Три нахилені орбіти іскор навколо тулуба (знизу вгору, у різні боки), що летять разом із фігурою: аура «несе» персонажа.
     * Іскра ззаду (sin &lt; 0) малюється до моделі, спереду — після, тож створюється відчуття, що вона обертається ДОВКОЛА.
     */
    private void orbit(GuiGraphics g, float env, boolean front) {
        float t = time;
        float cy0 = figFoot - figSize * jumpHeightBlocks();
        for (int ring = 0; ring < 3; ring++) {
            float h = figSize * (.35f + ring * .55f);
            float rx = figSize * (.50f - ring * .05f) * (.6f + .4f * env), ry = rx * .26f;
            float dir = ring % 2 == 0 ? 1f : -1f;
            int n = 12 + ring * 2;
            for (int j = 0; j < n; j++) {
                float a = t * 4.4f * dir + j * 6.2831853f / n + ring * 1.1f;
                float sn = (float) Math.sin(a);
                if ((sn >= 0f) != front) continue;
                float px = figCx + (float) Math.cos(a) * rx;
                float py = cy0 - h + sn * ry + (float) Math.sin(t * 3f + j) * 2f;
                int col = (j & 3) == 0 ? 0xFFFFFF : equipColor;
                float near = .55f + .45f * Math.abs(sn);
                for (int tr = 0; tr < 4; tr++) {   // хвіст
                    float ta = a - dir * tr * .13f;
                    int tx = (int) (figCx + Math.cos(ta) * rx), ty = (int) (cy0 - h + Math.sin(ta) * ry);
                    int sz = tr == 0 ? 3 : 2;
                    g.fill(tx, ty, tx + sz, ty + sz, MetaUi.a(col, env * near * (1f - tr * .26f)));
                }
                MetaUi.glowDisc(g, (int) px + 1, (int) py + 1, 4, equipColor, env * near * .5f);
            }
        }
    }

    private float jumpHeightBlocks() { return eLift; }

    private void ringDots(GuiGraphics g, float cx, float cy, float rx, float ry, int rgb, float alpha, int n) {
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            int x = (int) (cx + Math.cos(a) * rx), y = (int) (cy + Math.sin(a) * ry);
            g.fill(x, y, x + 2, y + 1, MetaUi.a(rgb, alpha));
        }
    }

    // ── ефекти ──────────────────────────────────────────────────────────
    private void burst(double x, double y, int rgb, int n) { burst(x, y, rgb, n, false); }

    /** {@code force} — анімації одягання малюються навіть у скінах, що вимкнули «феєрверки» (вони — частина сцени, а не декор). */
    private void burst(double x, double y, int rgb, int n, boolean force) {
        if (!force && !skin.sparks()) return;
        for (int i = 0; i < n && sparks.size() < 500; i++) {
            Spark k = new Spark();
            double an = rnd.nextDouble() * Math.PI * 2, sp = 40 + rnd.nextDouble() * 140;
            k.x = (float) x; k.y = (float) y; k.vx = (float) (Math.cos(an) * sp); k.vy = (float) (Math.sin(an) * sp - 30);
            k.max = k.life = .6f + rnd.nextFloat() * .7f; k.size = 1 + rnd.nextInt(3); k.grav = 70; k.rgb = rgb;
            sparks.add(k);
        }
        flash = Math.min(1f, flash + .4f);
    }

    private void burstItem(int rgb, int n) {
        double[] sp = itemSpot(slot());
        if (sp == null) sp = new double[]{VCX + panX, VFY + panY - BASE * zoom, 0};
        burst(sp[0], sp[1], rgb, n);
    }

    private void updateFx() {
        if (skin.sparks()) {
            ambient += dt;
            while (ambient > .06f) {
                ambient -= .06f;
                if (sparks.size() > 300) break;
                Spark k = new Spark();
                k.x = VX + rnd.nextFloat() * VW; k.y = VFY + 20;
                k.vx = (rnd.nextFloat() - .5f) * 14; k.vy = -(14 + rnd.nextFloat() * 30);
                k.max = k.life = 2.5f + rnd.nextFloat() * 2f; k.size = 1 + rnd.nextInt(2);
                k.rgb = rnd.nextInt(3) == 0 ? theme.gold() : accent;
                sparks.add(k);
            }
        }
        for (int i = sparks.size() - 1; i >= 0; i--) {
            Spark k = sparks.get(i);
            k.life -= dt;
            if (k.life <= 0) { sparks.remove(i); continue; }
            k.vy += k.grav * dt;
            k.x += k.vx * dt + (k.grav == 0 ? (float) Math.sin(time * 2 + k.y * .05) * .25f : 0);
            k.y += k.vy * dt;
        }
        flash = Math.max(0f, flash - dt * 2.2f);
    }

    private void drawFx(GuiGraphics g) {
        g.enableScissor((int) (ox + VX * ui), (int) (oy + VY * ui), (int) (ox + (VX + VW) * ui), (int) (oy + (VY + VH) * ui));
        for (Spark k : sparks) {
            float a = Math.min(1f, k.life / k.max * (k.grav == 0 ? 1.6f : 1.2f));
            if (k.grav == 0) a *= Math.min(1f, (k.max - k.life) * 2f);
            int sz = Math.max(1, Math.round(k.size * (.5f + .5f * a)));
            g.fill((int) k.x, (int) k.y, (int) k.x + sz, (int) k.y + sz, MetaUi.a(k.rgb, a * .9f));
        }
        g.disableScissor();
        if (flash > .01f) g.fillGradient(VX, VY, VX + VW, VY + VH, MetaUi.a(0xFFFFFF, flash * .10f), 0x00FFFFFF);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Ввід
    // ══════════════════════════════════════════════════════════════════════

    @Override
    public boolean mouseClicked(double rx, double ry, int button) {
        updateMouse(rx, ry);
        if (button == 0) {
            for (int i = zones.size() - 1; i >= 0; i--) {
                Zone z = zones.get(i);
                if (over(z.x(), z.y(), z.w(), z.h())) { z.action().run(); return true; }
            }
        }
        if (over(VX, VY, VW, VH)) {
            if (introLift > 0f) return true;   // ще падає — не чіпаємо
            if (button == 1) { drag = 2; falling = false; click(); }
            else if (button == 0) {
                CosmeticSlot hs = hoverSlot();
                if (hs != null) { focusSlot(hs); drag = 3; }
                else drag = 1;
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double rx, double ry, int button, double rdx, double rdy) {
        updateMouse(rx, ry);
        double dx = rdx / ui, dy = rdy / ui;
        if (drag == 1) { yaw += (float) dx * .9f; return true; }
        if (drag == 2) {
            panX = Math.max(-120, Math.min(120, panX + (float) dx));
            panY = Math.max(-80, Math.min(80, panY + (float) dy));
            return true;
        }
        if (drag == 3) {
            CosmeticSlot s = slot();
            Worn w = s == null ? null : look().get(s);
            if (w == null) return true;
            dragVx = dragVx * .6f + (float) dx / Math.max(dt, .008f) * .02f;   // інерція нахилу «предмета в руці»
            float size = BASE * zoom;
            double ang = Math.toRadians(yaw), cos = Math.cos(ang), sin = Math.sin(ang);
            Map<String, Float> before = Map.copyOf(w.params);
            switch (s) {
                case HEAD -> w.setParam(s, "y", w.param(s, "y") - (float) (dy / size));
                case BACK -> {
                    if (Screen.hasShiftDown() && Math.abs(sin) < .5) w.setParam(s, "z", w.param(s, "z") - (float) (dy / size));
                    else {
                        w.setParam(s, "y", w.param(s, "y") - (float) (dy / size));
                        if (Math.abs(sin) >= .35) w.setParam(s, "z", w.param(s, "z") + (float) (dx / size * Math.signum(sin)));
                    }
                }
                case PET -> {
                    boolean side = Math.abs(cos) >= Math.abs(sin);
                    float sc = (float) Math.signum(side ? cos : sin);
                    float hh = (float) (-dx / size * sc);
                    String a = side ? "x" : "z", b = side ? "z" : "x";
                    if (Screen.hasShiftDown()) {
                        float dd = (float) (side ? -dy / size * sc : dy / size * sc);
                        w.setParam(s, b, w.param(s, b) + dd);
                        w.setParam(s, a, w.param(s, a) + hh);
                    } else {
                        w.setParam(s, a, w.param(s, a) + hh);
                        w.setParam(s, "y", w.param(s, "y") - (float) (dy / size));
                    }
                }
                default -> { }
            }
            w.validate(s);
            if (w.params.equals(before) && (Math.abs(dx) + Math.abs(dy)) > 2) say("Досягнуто межі — далі не можна, щоб не заважати іншим", false);
            dirty();
            return true;
        }
        return super.mouseDragged(rx, ry, button, rdx, rdy);
    }

    @Override
    public boolean mouseReleased(double rx, double ry, int button) {
        if (drag != 0) {
            if (drag == 3) {
                burstItem(theme.gold(), 14);   // відпустив — лише іскри, предмет лишається рівно там, де поставили
            }
            drag = 0;
            return true;
        }
        return super.mouseReleased(rx, ry, button);
    }

    @Override
    public boolean mouseScrolled(double rx, double ry, double amount) {
        updateMouse(rx, ry);
        if (!over(VX, VY, VW, VH)) {
            if (over(116, 118, 318, 330)) {
                // за межами списку — нічого: інакше картки «перепоявлялись» (анімація появи з нуля) і на мить зникали
                int ns = Math.max(0, Math.min(pagesNow - 1, scroll + (amount < 0 ? 1 : -1)));
                if (ns != scroll) { scroll = ns; catTime = time; sound("page"); }
                return true;
            }
            return super.mouseScrolled(rx, ry, amount);
        }
        CosmeticSlot hs = hoverSlot();
        if (hs != null) focusSlot(hs);
        CosmeticSlot s = slot();
        Worn w = s == null ? null : look().get(s);
        float k = 1f + (float) amount * .06f;
        if (s == CosmeticSlot.AURA && w != null) { w.setParam(s, "scale", w.param(s, "scale") * k); dirty(); return true; }
        if (w != null && hs == s) {
            if (s == CosmeticSlot.PET && Screen.hasControlDown()) w.setParam(s, "bob", Math.max(.005f, w.param(s, "bob")) * k);
            else if (s == CosmeticSlot.PET && Screen.hasAltDown()) w.setParam(s, "speed", w.param(s, "speed") * k);
            else {
                ParamSpec sp = s.param("scale");
                if (sp != null) w.setParam(s, "scale", w.param(s, "scale") * k);
            }
            dirty();
        } else zoom = Math.max(.6f, Math.min(1.4f, zoom + (float) amount * .05f));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (naming) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { naming = false; return true; }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { confirmNaming(); return true; }
            if (key == GLFW.GLFW_KEY_BACKSPACE && nameBuf.length() > 0) {
                if (nameFresh) { nameBuf.setLength(0); nameFresh = false; }
                else nameBuf.setLength(nameBuf.length() - 1);
            }
            if (Screen.isPaste(key) && minecraft != null) typeInto(minecraft.keyboardHandler.getClipboard());
            return true;
        }
        if (key == GLFW.GLFW_KEY_R) { resetView(); return true; }
        if (key == GLFW.GLFW_KEY_SPACE) { if (time - jumpStart > .6f) jumpStart = time; return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (naming) { typeInto(String.valueOf(c)); return true; }
        return super.charTyped(c, mods);
    }

    @Override
    public void profileChanged() {
        MetaProfile fresh = me();
        if (fresh != null) System.arraycopy(fresh.emoteWheel, 0, wheelEdit, 0, wheelEdit.length);
        // купили відтінок, який приміряли, — залишаємо його на предметі й зберігаємо
        if (pendingColor >= 0 && selected != null) {
            MetaProfile mp = me();
            Worn w = look().get(selected.slot());
            if (mp != null && w != null && ownsColor(mp, selected, pendingColor)) {
                w.color = pendingColor;
                pendingColor = -1;
                dirty();
                burstItem(w.color, 50);
            }
        }
        // Покупка/крафт додали предмет — лишаємо локальні зміни образу, але оновлюємо вибір.
        if (selected != null && owns(selected) && !worn(selected)) burstItem(theme.gold(), 60);
    }
}
