package dev.shaurmalib.scene.forge;

import com.mojang.blaze3d.platform.InputConstants;
import dev.shaurmalib.scene.mc.client.McSceneClient;
import dev.shaurmalib.scene.mc.client.SceneClient;
import dev.shaurmalib.scene.net.SceneMessage;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.IEventBus;
import org.lwjgl.glfw.GLFW;

/** Клієнтський Forge-клей сцен: кадр, світ, HUD, клавіша редактора, блок руху, вихід зі світу. */
final class ForgeSceneClient {

    private ForgeSceneClient() {}

    /** Клавіша «Редактор сцен» (F7): вибір зареєстрованої сцени (права перевіряє сервер). */
    static final KeyMapping KEY = new KeyMapping("key.shaurma_lib.scene_editor", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_F7, "key.categories.shaurma_lib");

    static void init(IEventBus modBus) {
        modBus.addListener((RegisterKeyMappingsEvent e) -> e.register(KEY));
        MinecraftForge.EVENT_BUS.addListener((TickEvent.RenderTickEvent e) -> { if (e.phase == TickEvent.Phase.START) McSceneClient.renderTick(); });
        MinecraftForge.EVENT_BUS.addListener((RenderLevelStageEvent e) -> {
            if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
            var buffers = Minecraft.getInstance().renderBuffers().bufferSource();
            McSceneClient.onWorld(e.getPoseStack(), buffers, e.getCamera().getPosition(), e.getPartialTick(), e.getProjectionMatrix());
            buffers.endBatch();
        });
        MinecraftForge.EVENT_BUS.addListener((RenderGuiEvent.Pre e) -> McSceneClient.beforeHud());
        MinecraftForge.EVENT_BUS.addListener((RenderGuiEvent.Post e) -> McSceneClient.onHud(e.getGuiGraphics(), e.getPartialTick()));
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGHEST, (RenderGuiOverlayEvent.Pre e) -> { if (McSceneClient.hideHud()) e.setCanceled(true); });
        MinecraftForge.EVENT_BUS.addListener((MovementInputUpdateEvent e) -> {
            if (!McSceneClient.lockInput()) return;
            var in = e.getInput();
            in.forwardImpulse = 0;
            in.leftImpulse = 0;
            in.up = in.down = in.left = in.right = in.jumping = in.shiftKeyDown = false;
        });
        MinecraftForge.EVENT_BUS.addListener((TickEvent.ClientTickEvent e) -> {
            if (e.phase != TickEvent.Phase.END) return;
            McSceneClient.clientTick();
            dev.shaurmalib.scene.mc.client.menu.MenuSelfTest.tick();
            while (KEY.consumeClick()) if (Minecraft.getInstance().screen == null) McSceneClient.openEditor();
        });
        MinecraftForge.EVENT_BUS.addListener((ClientPlayerNetworkEvent.LoggingOut e) -> McSceneClient.onDisconnect());
    }

    static void handle(SceneMessage m) { SceneClient.handle(m); }
}
