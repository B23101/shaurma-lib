package dev.shaurmalib.scene.mc.client.menu;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL30;

/**
 * Кубічна карта глибини точкового світла (6 граней, лінійна глибина, апаратне порівняння для
 * {@code samplerCubeShadow}). Текстура зв'язується напряму як {@code GL_TEXTURE_CUBE_MAP} — кеш гри стежить
 * лише за 2D-прив'язками, тож його не збиваємо.
 */
final class CubeShadow {

    int tex, fbo, res;
    private static int readFbo, drawFbo;

    /** Напрям і «верх» граней за конвенцією OpenGL (+X, −X, +Y, −Y, +Z, −Z). */
    private static final float[][] DIR = { { 1, 0, 0 }, { -1, 0, 0 }, { 0, 1, 0 }, { 0, -1, 0 }, { 0, 0, 1 }, { 0, 0, -1 } };
    private static final float[][] UP = { { 0, -1, 0 }, { 0, -1, 0 }, { 0, 0, 1 }, { 0, 0, -1 }, { 0, -1, 0 }, { 0, -1, 0 } };

    void ensure(int r) {
        if (tex != 0 && r == res) return;
        close();
        res = r;
        tex = GL11.glGenTextures();
        GL11.glBindTexture(GL13.GL_TEXTURE_CUBE_MAP, tex);
        for (int i = 0; i < 6; i++)
            GL11.glTexImage2D(GL13.GL_TEXTURE_CUBE_MAP_POSITIVE_X + i, 0, GL14.GL_DEPTH_COMPONENT24, r, r, 0, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT, (java.nio.ByteBuffer) null);
        GL11.glTexParameteri(GL13.GL_TEXTURE_CUBE_MAP, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL13.GL_TEXTURE_CUBE_MAP, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL13.GL_TEXTURE_CUBE_MAP, GL11.GL_TEXTURE_WRAP_S, GL30.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL13.GL_TEXTURE_CUBE_MAP, GL11.GL_TEXTURE_WRAP_T, GL30.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL13.GL_TEXTURE_CUBE_MAP, GL30.GL_TEXTURE_WRAP_R, GL30.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL13.GL_TEXTURE_CUBE_MAP, GL14.GL_TEXTURE_COMPARE_MODE, GL30.GL_COMPARE_REF_TO_TEXTURE);
        GL11.glTexParameteri(GL13.GL_TEXTURE_CUBE_MAP, GL14.GL_TEXTURE_COMPARE_FUNC, GL11.GL_LEQUAL);
        GL11.glBindTexture(GL13.GL_TEXTURE_CUBE_MAP, 0);
        fbo = GL30.glGenFramebuffers();
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo);
        GL11.glDrawBuffer(GL11.GL_NONE);
        GL11.glReadBuffer(GL11.GL_NONE);
    }

    /** Ціль рендеру — грань i. */
    void bindFace(int face) {
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo);
        GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL13.GL_TEXTURE_CUBE_MAP_POSITIVE_X + face, tex, 0);
        RenderSystem.viewport(0, 0, res, res);
    }

    /** Скопіювати грань (статичний світ → динамічна карта, поверх якої малюються актори). */
    static void blitFace(CubeShadow src, CubeShadow dst, int face) {
        if (readFbo == 0) { readFbo = GL30.glGenFramebuffers(); drawFbo = GL30.glGenFramebuffers(); }
        GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, readFbo);
        GL30.glFramebufferTexture2D(GL30.GL_READ_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL13.GL_TEXTURE_CUBE_MAP_POSITIVE_X + face, src.tex, 0);
        GL11.glReadBuffer(GL11.GL_NONE);
        GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, drawFbo);
        GL30.glFramebufferTexture2D(GL30.GL_DRAW_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL13.GL_TEXTURE_CUBE_MAP_POSITIVE_X + face, dst.tex, 0);
        GL11.glDrawBuffer(GL11.GL_NONE);
        GlStateManager._glBlitFrameBuffer(0, 0, src.res, src.res, 0, 0, dst.res, dst.res, GL11.GL_DEPTH_BUFFER_BIT, GL11.GL_NEAREST);
    }

    /** Перспектива 90° грані (простір сцени). */
    static Matrix4f faceMatrix(int face, Vector3f lp, float far) {
        float[] d = DIR[face], u = UP[face];
        Matrix4f v = new Matrix4f().lookAt(lp, new Vector3f(lp).add(d[0], d[1], d[2]), new Vector3f(u[0], u[1], u[2]));
        return new Matrix4f().perspective((float) Math.toRadians(90), 1, 0.05f, far).mul(v);
    }

    void close() {
        if (tex != 0) { GL11.glDeleteTextures(tex); tex = 0; }
        if (fbo != 0) { GlStateManager._glDeleteFramebuffers(fbo); fbo = 0; }
        res = 0;
    }
}
