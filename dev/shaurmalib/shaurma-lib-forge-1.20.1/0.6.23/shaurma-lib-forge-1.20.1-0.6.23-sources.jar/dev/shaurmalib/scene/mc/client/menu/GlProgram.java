package dev.shaurmalib.scene.mc.client.menu;

import com.mojang.blaze3d.platform.GlStateManager;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL20;
import org.lwjgl.system.MemoryStack;

import java.nio.FloatBuffer;
import java.util.HashMap;
import java.util.Map;

/**
 * Сирий GLSL-шейдер рендеру сцен меню (без ресурс-паків і {@code ShaderInstance}): компіляція, прив'язка атрибутів
 * за індексами елементів ванільного формату вершин (VAO {@code VertexBuffer} ставить атрибут i = i-й елемент),
 * кеш uniform-ів. Після свого проходу рендер скидає кеш програм гри ({@link MenuGl#restore}).
 */
final class GlProgram {

    final int id;
    private final String name;
    private final Map<String, Integer> uniforms = new HashMap<>();

    /** @param attribs ім'я атрибута → індекс (null — без атрибутів, повноекранний трикутник) */
    GlProgram(String name, String vertex, String fragment, Map<String, Integer> attribs) {
        this.name = name;
        int vs = compile(GL20.GL_VERTEX_SHADER, vertex), fs = compile(GL20.GL_FRAGMENT_SHADER, fragment);
        id = GL20.glCreateProgram();
        GL20.glAttachShader(id, vs);
        GL20.glAttachShader(id, fs);
        if (attribs != null) for (Map.Entry<String, Integer> e : attribs.entrySet()) GL20.glBindAttribLocation(id, e.getValue(), e.getKey());
        GL20.glLinkProgram(id);
        if (GL20.glGetProgrami(id, GL20.GL_LINK_STATUS) == 0) {
            String log = GL20.glGetProgramInfoLog(id, 32768);
            GL20.glDeleteProgram(id);
            throw new IllegalStateException("shaurma menu shader '" + name + "' link: " + log);
        }
        GL20.glDetachShader(id, vs);
        GL20.glDetachShader(id, fs);
        GL20.glDeleteShader(vs);
        GL20.glDeleteShader(fs);
    }

    private int compile(int type, String src) {
        int s = GL20.glCreateShader(type);
        GL20.glShaderSource(s, src);
        GL20.glCompileShader(s);
        if (GL20.glGetShaderi(s, GL20.GL_COMPILE_STATUS) == 0) {
            String log = GL20.glGetShaderInfoLog(s, 32768);
            GL20.glDeleteShader(s);
            throw new IllegalStateException("shaurma menu shader '" + name + "' " + (type == GL20.GL_VERTEX_SHADER ? "vertex" : "fragment") + ": " + log);
        }
        return s;
    }

    void use() { GlStateManager._glUseProgram(id); }

    int loc(String u) { return uniforms.computeIfAbsent(u, k -> GL20.glGetUniformLocation(id, k)); }

    void set(String u, float v) { int l = loc(u); if (l >= 0) GL20.glUniform1f(l, v); }

    void set(String u, int v) { int l = loc(u); if (l >= 0) GL20.glUniform1i(l, v); }

    void set(String u, float x, float y) { int l = loc(u); if (l >= 0) GL20.glUniform2f(l, x, y); }

    void set(String u, float x, float y, float z) { int l = loc(u); if (l >= 0) GL20.glUniform3f(l, x, y, z); }

    void set(String u, float x, float y, float z, float w) { int l = loc(u); if (l >= 0) GL20.glUniform4f(l, x, y, z, w); }

    void set(String u, Matrix4f m) {
        int l = loc(u);
        if (l < 0) return;
        try (MemoryStack st = MemoryStack.stackPush()) {
            FloatBuffer b = st.mallocFloat(16);
            m.get(b);
            GL20.glUniformMatrix4fv(l, false, b);
        }
    }

    /** Масив vec3/vec4 одним викликом. */
    void setArray(String u, float[] values, int components) {
        int l = loc(u);
        if (l < 0) return;
        if (components == 3) GL20.glUniform3fv(l, values);
        else if (components == 4) GL20.glUniform4fv(l, values);
        else GL20.glUniform1fv(l, values);
    }

    void close() { GL20.glDeleteProgram(id); }
}
