package dev.shaurmalib.scene.mc.client.menu;

import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.doc.Channels;
import dev.shaurmalib.scene.doc.Clip;
import dev.shaurmalib.scene.doc.MenuFrame;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.doc.Track;
import dev.shaurmalib.scene.mc.client.SceneClient;
import dev.shaurmalib.scene.mc.client.SceneGuiPreview;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Самотест сцен меню для dev-запуску: вмикається файлом {@code shaurma_menutest} у теці гри. Відкриває світ
 * «New World», будує сцену біля гравця, показує екран з картками, імітує наведення, знімає скріншоти
 * ({@code screenshots/menutest_*.png}), пише час рендеру в лог і закриває гру.
 */
public final class MenuSelfTest {

    private MenuSelfTest() {}

    private static int stage = -1;
    private static int ticks;
    private static Boolean enabled;
    static final String ID = "shaurma_lib:menu_selftest";

    private static boolean enabled() {
        if (enabled == null) enabled = Files.exists(Minecraft.getInstance().gameDirectory.toPath().resolve("shaurma_menutest"));
        return enabled;
    }

    /** Кінець клієнтського тіку. */
    public static void tick() {
        if (!enabled()) return;
        Minecraft mc = Minecraft.getInstance();
        ticks++;
        if (stage == -1) {
            if (mc.screen instanceof TitleScreen && ticks > 40) {
                stage = 0;
                ticks = 0;
                mc.createWorldOpenFlows().loadLevel(mc.screen, "New World");
            }
            return;
        }
        if (stage == 0) {
            if (mc.level == null || mc.player == null || ticks < 100) return;
            log("світ відкрито, гравець " + mc.player.blockPosition());
            buildStage(mc);
            stage = 10;
            ticks = 0;
            return;
        }
        if (stage == 10) {
            if (ticks < 80) return;      // чанки платформи дійшли до клієнта
            SceneClient.putDoc(buildDoc(mc));
            mc.setScreen(new TestScreen(0));
            stage = 1;
            ticks = 0;
            return;
        }
        TestScreen ts = mc.screen instanceof TestScreen t ? t : null;
        switch (stage) {
            case 1 -> { if (ticks == 160) { shot("cards"); next(); } }
            case 2 -> { if (ts != null) ts.hoverCard = 1; if (ticks == 50) { shot("hover"); next(); } }
            case 3 -> {
                if (ticks == 1 && ts != null) { ts.hoverCard = -1; ts.bigOnly = true; }
                if (ticks == 120) { shot("big"); next(); }
            }
            case 4 -> {
                if (ticks == 1) {
                    SceneDoc d = SceneClient.doc(ID);
                    SceneDoc.Variant v = d.variant(null);
                    v.look.preset("Нічний неон");
                    v.look.outline = true;
                    v.look.toonBands = 0;
                    d.revision++;
                    SceneClient.putDoc(d);
                }
                if (ticks == 120) { shot("neon"); next(); }
            }
            case 5 -> {
                if (ticks == 1) {
                    var ed = new dev.shaurmalib.scene.mc.editor.SceneEditorScreen(SceneClient.doc(ID), false, null);
                    mc.setScreen(ed);
                    ed.select("cam");
                    ed.openPage(4);
                }
                if (ticks == 100) {
                    shot("editor_look");
                    if (mc.screen instanceof dev.shaurmalib.scene.mc.editor.SceneEditorScreen ed) {
                        log("прокрутка look.env = " + ed.scrollOf("look.env") + ", вікно " + mc.getWindow().getGuiScaledWidth() + "×" + mc.getWindow().getGuiScaledHeight());
                        ed.lookTab(2);
                    }
                }
                if (ticks == 140) shot("editor_menu");
                if (ticks == 141 && mc.screen instanceof dev.shaurmalib.scene.mc.editor.SceneEditorScreen ed) {
                    ed.openPage(0);
                    ed.menuPreview = true;
                    ed.select("spot");
                }
                if (ticks == 220) shot("editor_edit");
                if (ticks == 222) { mc.setScreen(null); next(); }
            }
            case 6 -> {
                if (ticks == 2) log(String.format("рендер: %d кадрів, середнє %.2f мс, макс %.2f мс; помилка: %s",
                    TestScreen.frames, TestScreen.total / Math.max(1, TestScreen.frames) / 1e6, TestScreen.max / 1e6, MenuRenderer.error()));
                if (ticks == 20) { log("кінець самотесту"); mc.stop(); }
            }
            default -> { }
        }
    }

    private static void next() { stage++; ticks = 0; }

    private static int px, py, pz;

    /** Чиста сцена в небі через інтегрований сервер: підлога, стіна, ліхтарі, світлокамінь, вода; гравця — туди. */
    private static void buildStage(Minecraft mc) {
        var server = mc.getSingleplayerServer();
        if (server == null) { log("нема інтегрованого сервера"); return; }
        px = mc.player.getBlockX(); py = 200; pz = mc.player.getBlockZ();
        String[] cmds = {
            "fill %d %d %d %d %d %d minecraft:air".formatted(px - 12, py, pz - 12, px + 12, py + 10, pz + 12),
            "fill %d %d %d %d %d %d minecraft:polished_deepslate".formatted(px - 10, py - 1, pz - 10, px + 10, py - 1, pz + 10),
            "fill %d %d %d %d %d %d minecraft:dark_oak_planks".formatted(px - 6, py, pz + 6, px + 6, py + 5, pz + 6),
            "fill %d %d %d %d %d %d minecraft:glass".formatted(px - 1, py + 1, pz + 6, px + 1, py + 3, pz + 6),
            "fill %d %d %d %d %d %d minecraft:oak_leaves[persistent=true]".formatted(px + 3, py + 4, pz + 2, px + 5, py + 5, pz + 4),
            "fill %d %d %d %d %d %d minecraft:oak_log".formatted(px + 4, py, pz + 3, px + 4, py + 3, pz + 3),
            "setblock %d %d %d minecraft:lantern".formatted(px - 3, py, pz + 3),
            "setblock %d %d %d minecraft:soul_lantern".formatted(px + 2, py, pz - 2),
            "setblock %d %d %d minecraft:glowstone".formatted(px - 5, py, pz - 1),
            "fill %d %d %d %d %d %d minecraft:water".formatted(px - 4, py - 1, pz - 6, px - 2, py - 1, pz - 4),
            "time set 6000",
            "weather clear",
            "tp @p %d %d %d".formatted(px, py, pz - 8),
        };
        for (String c : cmds) server.getCommands().performPrefixedCommand(server.createCommandSourceStack(), c);
        log("сцена-платформа на " + px + " " + py + " " + pz);
    }

    private static void shot(String name) {
        Minecraft mc = Minecraft.getInstance();
        Screenshot.grab(mc.gameDirectory, "menutest_" + name + ".png", mc.getMainRenderTarget(), c -> log("знімок " + name + ": " + c.getString()));
    }

    private static void log(String s) { System.out.println("[shaurma_menutest] " + s); }

    /** Сцена навколо гравця: актор-гравець, камера кружляє, сонце, прожектор з променем, лампа з кубічною тінню. */
    private static SceneDoc buildDoc(Minecraft mc) {
        double x = px + 0.5, y = py, z = pz + 0.5;
        SceneDoc d = new SceneDoc(ID);
        d.revision = 1;
        SceneDoc.Variant v = d.variant(null);
        v.length = 6;
        v.loop = true;
        v.loopBlend = 0.5;
        v.menu = MenuFrame.card(3, 4).safeBottom(0.18f).stageRadius(20);
        v.look.preset("Кіно · теплий");
        v.look.autoLights = true;

        SceneObject hero = new SceneObject("hero", "Герой", SceneObject.Kind.ACTOR);
        hero.modelType = SceneObject.ModelType.PLAYER;
        hero.skinMode = SceneObject.SkinMode.VIEWER;
        hero.x = x; hero.y = y; hero.z = z;
        hero.channels.getOrCreate(Channels.YAW).set(0, 160);
        hero.channels.getOrCreate(Channels.YAW).set(3, 200);
        hero.channels.getOrCreate(Channels.YAW).set(6, 160);
        hero.bone("right_arm").getOrCreate("rx").set(0, -40);
        hero.bone("right_forearm").getOrCreate("rx").set(0, -70);
        hero.bone("left_leg").getOrCreate("rx").set(0, -25);
        hero.bone("left_shin").getOrCreate("rx").set(0, 45);
        v.objects.add(hero);

        SceneObject cam = new SceneObject("cam", "Камера", SceneObject.Kind.CAMERA);
        cam.orbitTarget = "obj:hero";
        cam.channels.getOrCreate(Channels.ORBIT_YAW).set(0, 140);
        cam.channels.getOrCreate(Channels.ORBIT_YAW).set(6, 220);
        cam.channels.getOrCreate(Channels.ORBIT_PITCH).set(0, 12);
        cam.channels.getOrCreate(Channels.ORBIT_DIST).set(0, 5.5);
        cam.fov = 50;
        cam.lookAt = "obj:hero";
        cam.lookOffsetY = 1.1;
        v.objects.add(cam);
        Track tr = new Track("tc", "Камери", Track.Type.CAMERA);
        tr.clips.add(new Clip("cc", 0, 6, "cam"));
        v.tracks.add(tr);

        SceneObject sun = new SceneObject("sun", "Сонце", SceneObject.Kind.LIGHT);
        sun.lightType = SceneObject.LightType.SUN;
        sun.x = x; sun.y = y + 12; sun.z = z;
        sun.yaw = 30; sun.pitch = 50;
        sun.lightColor = 0xFFE0B8; sun.lightIntensity = 1.8f;
        sun.castShadows = true;
        sun.beam = 0.6f;
        v.objects.add(sun);

        SceneObject spot = new SceneObject("spot", "Прожектор", SceneObject.Kind.LIGHT);
        spot.lightType = SceneObject.LightType.SPOT;
        spot.x = x - 3; spot.y = y + 5; spot.z = z - 1;
        spot.yaw = -60; spot.pitch = 50;
        spot.lightColor = 0x6FA8FF; spot.lightIntensity = 4f; spot.lightRange = 12; spot.spotAngle = 40;
        spot.castShadows = true;
        spot.beam = 1.5f;
        v.objects.add(spot);

        SceneObject lamp = new SceneObject("lamp", "Лампа", SceneObject.Kind.LIGHT);
        lamp.lightType = SceneObject.LightType.POINT;
        lamp.x = x + 1.5; lamp.y = y + 1.6; lamp.z = z + 1.5;
        lamp.lightColor = 0xFF6A3C; lamp.lightIntensity = 2.5f; lamp.lightRange = 7;
        lamp.castShadows = true;
        v.objects.add(lamp);
        return d;
    }

    /** Екран самотесту: картки трьох форматів (кнопка, картка, широка) і велика картка. */
    static final class TestScreen extends Screen {
        int hoverCard = -1;
        boolean bigOnly;
        private final MenuScene[] cards = new MenuScene[4];
        static long frames, total, max;

        TestScreen(int unused) {
            super(Component.literal("menu test"));
            SceneBindings b = SceneGuiPreview.viewer("hero");
            for (int i = 0; i < cards.length; i++) cards[i] = MenuScene.of(ID).bindings(b);
            cards[0].frame(MenuFrame.button());
            cards[2].frame(MenuFrame.wide());
        }

        @Override public boolean isPauseScreen() { return false; }

        @Override
        public void render(GuiGraphics g, int mx, int my, float partial) {
            g.fillGradient(0, 0, width, height, 0xFF10131A, 0xFF07080B);
            long t0 = System.nanoTime();
            if (bigOnly) {
                int h = height - 40, w = h * 3 / 4;
                cards[3].render(g, (width - w) / 2, 20, w, h, -1, -1);
            } else {
                int h = Math.min(height - 60, 180);
                int[][] r = { { 0, h / 2, h / 2 }, { 0, h * 3 / 4, h }, { 0, h * 16 / 9 * 2 / 3, h * 2 / 3 } };
                int total = 0;
                for (int[] q : r) total += q[1] + 16;
                int x = (width - total) / 2;
                for (int i = 0; i < 3; i++) {
                    int w = r[i][1], hh = r[i][2], y = (height - hh) / 2;
                    int fx = hoverCard == i ? x + w / 2 : mx, fy = hoverCard == i ? y + hh / 2 : my;
                    cards[i].render(g, x, y, w, hh, fx, fy);
                    final int cx = x, cy = y, cw = w, ch = hh;
                    cards[i].overlay(g, cx, cy, cw, ch, () -> g.drawString(font, "Картка " + (cx > 0 ? "" : "") + cw + "×" + ch, cx + 4, cy + ch - 12, 0xFFFFFF));
                    x += w + 16;
                }
            }
            long dt = System.nanoTime() - t0;
            frames++;
            TestScreen.total += dt;
            max = Math.max(max, dt);
            g.drawString(font, String.format("menu test · %.2f ms", dt / 1e6), 4, 4, 0xA0FFFFFF);
            super.render(g, mx, my, partial);
        }

        @Override
        public void removed() { for (MenuScene c : cards) c.close(); }
    }
}
