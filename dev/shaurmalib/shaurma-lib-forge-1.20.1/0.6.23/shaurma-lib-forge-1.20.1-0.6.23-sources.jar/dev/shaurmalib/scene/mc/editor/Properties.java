package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.anim.math.Easing;
import dev.shaurmalib.scene.api.SceneDefinition;
import dev.shaurmalib.scene.doc.Channels;
import dev.shaurmalib.scene.doc.Clip;
import dev.shaurmalib.scene.doc.KeyChannel;
import dev.shaurmalib.scene.doc.Marker;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.doc.Track;
import dev.shaurmalib.scene.doc.Transition;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.eval.SceneRig;
import dev.shaurmalib.scene.mc.client.SceneOverlays;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.Icons;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

/**
 * Права панель: властивості вибраного — кліп / мітка / об'єкт (трансформ з ◆-ключами, камера, модель, скін,
 * слот і мітки, кістки) або варіант, якщо нічого не вибрано. Поле тягнеться мишею, клік — ввести число.
 */
final class Properties {

    private Properties() {}

    private static final int RH = 15;

    private static final java.util.List<SceneDock.Panel> PANELS = java.util.List.of(
        new SceneDock.Panel("props", "Властивості", Icon.SETTINGS, 1.0, Properties::content));

    /** Права смуга — та сама модульна панель, що в Shaurma Modeling. */
    static void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        SceneDock.render(s, gui, PANELS, false, x, y, w, h);
    }

    private static void content(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        int off = gui.scrollBegin("props", x, y, w, h, 900);
        int[] cy = { y - off + 4 };
        Ctx c = new Ctx(s, gui, x + 4, w - 8, cy);
        if (s.selClip != null && s.selTrack != null && s.selTrack.clips.contains(s.selClip)) clip(c, s.selTrack, s.selClip);
        else if (s.selMarker != null && s.variant().markers.contains(s.selMarker)) marker(c, s.selMarker);
        else if (s.selected() != null) object(c, s.selected());
        else variant(c, s.variant());
        gui.scrollEnd();
    }

    /** Курсор рядків. */
    record Ctx(SceneEditorScreen s, Gui gui, int x, int w, int[] y) {
        int next(int h) { int r = y[0]; y[0] += h; return r; }
    }

    // ═════════════════════════ віджети ═════════════════════════

    static void header(Ctx c, String t) {
        c.y[0] += 2;
        c.gui.header(t, c.x - 2, c.next(14), c.w + 4);
    }

    /** Числове поле з історією (тягнути — одна дія). */
    static void num(Ctx c, String label, String id, double value, double step, int accent, DoubleConsumer set, KeyBtn key) {
        int yy = c.next(RH);
        c.gui.textClip(label, c.x, yy + 3, 44, Theme.MUTED);
        int fw = c.w - 46 - (key != null ? 14 : 0);
        Gui.Num n = c.gui.number(id, c.x + 46, yy, fw, 13, value, step, accent);
        apply(c.s, label, n, set);
        if (key != null) key.draw(c, c.x + c.w - 12, yy);
    }

    static void apply(SceneEditorScreen s, String label, Gui.Num n, DoubleConsumer set) {
        if (s.readOnly || !n.any()) return;
        switch (n.phase()) {
            case START -> { s.begin(label); set.accept(n.value()); }
            case CHANGE -> { s.begin(label); set.accept(n.value()); }
            case COMMIT -> { s.begin(label); set.accept(n.value()); s.commit(); }
            default -> { }
        }
    }

    private static String text(Ctx c, String label, String id, String value, String placeholder) {
        int yy = c.next(RH);
        c.gui.textClip(label, c.x, yy + 3, 44, Theme.MUTED);
        return c.gui.textField(id, c.x + 46, yy, c.w - 46, 13, value == null ? "" : value, Component.literal(placeholder));
    }

    // ───────── колір мишею ─────────

    private static String colorOpen;
    private static boolean colorDrag;
    private static float pickH, pickS, pickV;
    private static final int[] PRESETS = { 0xFFFFFF, 0x000000, 0xE5646A, 0xFF9A3C, 0xF2D14B, 0x59D185, 0x39C5BB, 0x4A9EFF, 0x7C5CFF, 0xD15CC4, 0x8B5A2B, 0x7F8796 };

    static int parseRgb(String s) {
        if (s == null) return -1;
        try { String h = s.replace("#", "").trim(); return h.isEmpty() ? -1 : Integer.parseInt(h, 16) & 0xFFFFFF; } catch (NumberFormatException e) { return -1; }
    }

    /** Колір: квадратик-зразок (клік — палітра: тягни по квадрату й смузі відтінку, або готові кольори) і hex-поле. */
    static void color(Ctx c, String label, String id, int rgb, boolean set, java.util.function.IntConsumer apply) {
        Gui gui = c.gui;
        SceneEditorScreen s = c.s;
        int yy = c.next(RH);
        gui.textClip(label, c.x, yy + 3, 44, Theme.MUTED);
        int sx = c.x + 46;
        boolean open = id.equals(colorOpen);
        gui.g.fill(sx, yy, sx + 22, yy + 13, open ? 0xFFFFFFFF : 0xFF4A5A7A);
        gui.g.fill(sx + 1, yy + 1, sx + 21, yy + 12, set ? 0xFF000000 | rgb : 0xFF1A2236);
        if (!set) gui.g.fill(sx + 1, yy + 6, sx + 21, yy + 7, 0xFFE5646A);
        if (gui.hover(sx, yy, 22, 13)) { gui.cursor(Gui.CUR_HAND); gui.tip(Component.literal(open ? "Сховати палітру" : "Клік — вибрати колір мишею")); }
        if (gui.clicked(sx, yy, 22, 13, 0)) {
            open = !open;
            colorOpen = open ? id : null;
            syncPick(rgb, true);
        }
        String hex = gui.textField(id + ".hex", sx + 25, yy, c.w - 46 - 25, 13, set ? String.format("#%06X", rgb & 0xFFFFFF) : "", Component.literal("#RRGGBB"));
        if (hex != null && !s.readOnly) { int v = parseRgb(hex); if (v >= 0) s.edit("Колір", () -> apply.accept(v)); }
        if (!open) return;
        if (!colorDrag) syncPick(rgb, false);
        int bh = 56, py = c.next(bh + 22);
        int bx = c.x + 2, bw = c.w - 4 - 16;
        // квадрат насиченість × яскравість
        for (int i = 0; i < bw; i++) {
            int top = java.awt.Color.HSBtoRGB(pickH, i / (float) Math.max(1, bw - 1), 1f) | 0xFF000000;
            gui.g.fillGradient(bx + i, py, bx + i + 1, py + bh, top, 0xFF000000);
        }
        int kx = bx + Math.round(pickS * (bw - 1)), ky = py + Math.round((1 - pickV) * (bh - 1));
        gui.g.renderOutline(kx - 3, ky - 3, 7, 7, pickV > 0.6f && pickS < 0.4f ? 0xFF000000 : 0xFFFFFFFF);
        // смуга відтінку
        int hx = bx + bw + 4;
        for (int j = 0; j < bh; j++) gui.g.fill(hx, py + j, hx + 12, py + j + 1, java.awt.Color.HSBtoRGB(j / (float) bh, 1f, 1f) | 0xFF000000);
        int hy = py + Math.round(pickH * (bh - 1));
        gui.g.renderOutline(hx - 1, hy - 2, 14, 5, 0xFFFFFFFF);
        // готові кольори
        int n = PRESETS.length, pw = (bw + 16) / n, prY = py + bh + 5;
        for (int i = 0; i < n; i++) {
            int px = bx + i * pw;
            gui.g.fill(px, prY, px + pw - 2, prY + 12, 0xFF000000 | PRESETS[i]);
            if (gui.hover(px, prY, pw - 2, 12)) { gui.cursor(Gui.CUR_HAND); gui.g.renderOutline(px - 1, prY - 1, pw, 14, 0xFFFFFFFF); }
            int pc = PRESETS[i];
            if (!s.readOnly && gui.clicked(px, prY, pw - 2, 12, 0)) { s.edit("Колір", () -> apply.accept(pc)); syncPick(pc, true); }
        }
        if (s.readOnly) return;
        if (gui.press(id + ".sv", bx, py, bw, bh, 0) | gui.press(id + ".hue", hx - 2, py, 16, bh, 0)) { s.begin("Колір"); colorDrag = true; }
        boolean sv = gui.isActive(id + ".sv"), hue = gui.isActive(id + ".hue");
        if (colorDrag && (sv || hue)) {
            if (sv) {
                pickS = Mth.clamp((gui.mx - bx) / (float) Math.max(1, bw - 1), 0f, 1f);
                pickV = 1f - Mth.clamp((gui.my - py) / (float) Math.max(1, bh - 1), 0f, 1f);
            } else pickH = Mth.clamp((gui.my - py) / (float) bh, 0f, 0.999f);
            apply.accept(java.awt.Color.HSBtoRGB(pickH, pickS, pickV) & 0xFFFFFF);
            gui.cursor(Gui.CUR_HAND);
        }
        if (colorDrag && !gui.isDown(0)) { colorDrag = false; s.commit(); }
    }

    /** Палітра стає на колір; відтінок сірого/чорного не скидаємо (інакше смуга стрибає на червоний). */
    private static void syncPick(int rgb, boolean force) {
        float[] hsv = java.awt.Color.RGBtoHSB(rgb >> 16 & 255, rgb >> 8 & 255, rgb & 255, null);
        if (force || (hsv[1] > 0.02f && hsv[2] > 0.02f)) pickH = hsv[0];
        pickS = hsv[1];
        pickV = hsv[2];
    }

    /** Кнопка-перемикач варіантів по колу (ЛКМ — далі, ПКМ — список). @return вибраний індекс або -1 */
    static int cycle(Ctx c, String label, String[] options, int cur, String tip) {
        int yy = c.next(RH);
        c.gui.textClip(label, c.x, yy + 3, 44, Theme.MUTED);
        String shown = cur >= 0 && cur < options.length ? options[cur] : "—";
        int[] pick = { -1 };
        if (c.gui.button(c.x + 46, yy, c.w - 46, 13, Component.literal(shown), false, tip == null ? null : Component.literal(tip))) {
            List<Popup.Item> items = new ArrayList<>();
            for (int i = 0; i < options.length; i++) {
                int idx = i;
                items.add(Popup.item((i == cur ? "● " : "  ") + options[i], () -> picked = idx));
            }
            Popup.open(label, c.gui.mx, c.gui.my, items);
            pendingCycle = label + "#" + c.s.selObj + "#" + (c.s.selClip == null ? "" : c.s.selClip.id);
        }
        String key = label + "#" + c.s.selObj + "#" + (c.s.selClip == null ? "" : c.s.selClip.id);
        if (picked >= 0 && key.equals(pendingCycle)) { pick[0] = picked; picked = -1; pendingCycle = null; }
        return pick[0];
    }

    private static int picked = -1;
    private static String pendingCycle;

    static boolean check(Ctx c, String label, boolean v, String tip) {
        int yy = c.next(RH - 1);
        return c.gui.checkbox(c.x, yy + 2, c.w, Component.literal(label), v, tip == null ? null : Component.literal(tip));
    }

    /** ◆ біля поля: заповнений — ключ у playhead, контур — ключі є деінде; клік — поставити/зняти. */
    record KeyBtn(KeyChannel channel, double offset, Runnable create) {
        KeyBtn(KeyChannel channel, DoubleSupplier current, Runnable create) { this(channel, 0, create); }

        void draw(Ctx c, int x, int y) {
            SceneEditorScreen s = c.s;
            KeyChannel.Key at = channel == null ? null : channel.keyAt(s.time - offset, 0.5 / s.fps());
            boolean any = channel != null && !channel.isEmpty();
            int col = at != null ? 0xFFF2B84B : any ? 0xFF9DB1D6 : 0xFF3A4A6A;
            Icons.draw(c.gui.g, Icon.KEYFRAME, x, y, 12, col);
            if (c.gui.clicked(x, y, 12, 13, 0) && !s.readOnly) {
                if (at != null) s.edit("Зняти ключ", () -> channel.remove(at));
                else s.edit("Ключ", create);
            }
            if (c.gui.hover(x, y, 12, 13)) c.gui.tip(Component.literal(at != null ? "Зняти ключ у playhead" : "Поставити ключ у playhead (K — усі канали)"));
        }
    }

    private static KeyBtn objKey(SceneEditorScreen s, SceneObject o, String ch) {
        return new KeyBtn(o.channels.get(ch), () -> s.value(o, ch), () -> o.channels.getOrCreate(ch).set(s.time, s.value(o, ch)));
    }

    // ═════════════════════════ об'єкт ═════════════════════════

    private static void object(Ctx c, SceneObject o) {
        SceneEditorScreen s = c.s;
        header(c, switch (o.kind) { case CAMERA -> "Камера"; case ACTOR -> "Актор"; case PROP -> "Проп"; case EMPTY -> "Точка"; case LIGHT -> "Світло"; });
        String n = text(c, "Назва", "o.name." + o.id, o.name, "назва");
        if (n != null && !n.isBlank()) s.edit("Перейменувати", () -> o.name = n.trim());

        if (s.selBone != null) { bone(c, o, s.selBone); return; }

        header(c, "Трансформ · " + s.fmtTime(s.time));
        int[] axis = { Theme.AXIS_X, Theme.AXIS_Y, Theme.AXIS_Z };
        String[] lab = { "X", "Y", "Z" };
        for (int i = 0; i < 3; i++) {
            String ch = Channels.TRANSFORM[i];
            num(c, lab[i], "o." + ch + o.id, s.value(o, ch), 0.05, axis[i], v -> s.setValue(o, ch, v), objKey(s, o, ch));
        }
        String[] rl = { "Yaw", "Pitch", "Roll" };
        for (int i = 0; i < 3; i++) {
            String ch = Channels.TRANSFORM[3 + i];
            num(c, rl[i], "o." + ch + o.id, s.value(o, ch), 1, Theme.ACCENT, v -> s.setAngle(o, ch, v), objKey(s, o, ch));
        }
        if (!o.isCamera() && !o.isLight()) num(c, "Масштаб", "o.scale" + o.id, s.value(o, Channels.SCALE), 0.01, Theme.ACCENT, v -> s.setValue(o, Channels.SCALE, Math.max(0.01, v)), objKey(s, o, Channels.SCALE));
        KeyChannel vis = o.channels.get(Channels.VISIBLE);
        boolean visible = o.channels.sample(Channels.VISIBLE, s.time, 1) >= 0.5;
        int vy = c.y[0];
        if (check(c, "Видимий у цей момент", visible, "Ступінчастий ключ видимості (поява/зникнення актора)")) {
            s.edit("Видимість", () -> {
                KeyChannel k = o.channels.getOrCreate(Channels.VISIBLE);
                if (k.isEmpty() && s.time > 0) k.set(0, 1);
                k.set(s.time, visible ? 0 : 1);
            });
        }
        new KeyBtn(vis, () -> visible ? 1 : 0, () -> o.channels.getOrCreate(Channels.VISIBLE).set(s.time, visible ? 1 : 0)).draw(c, c.x + c.w - 12, vy);

        // батько
        List<SceneObject> others = new ArrayList<>();
        for (SceneObject x : s.variant().objects) if (x != o) others.add(x);
        String[] pn = new String[others.size() + 1];
        pn[0] = "— світ —";
        int cur = 0;
        for (int i = 0; i < others.size(); i++) { pn[i + 1] = others.get(i).name; if (others.get(i).id.equals(o.parent)) cur = i + 1; }
        int p = cycle(c, "Батько", pn, cur, "Рухатись разом з іншим об'єктом (позиція — відносно нього)");
        if (p >= 0) s.edit("Батько", () -> { o.parent = p == 0 ? null : others.get(p - 1).id; if (p == 0) o.parentBone = null; });
        if (o.parent != null) {
            String pb = text(c, "Кістка", "o.pbone" + o.id, o.parentBone, "кістка батька (рука…)");
            if (pb != null) s.edit("Кістка батька", () -> o.parentBone = pb.isBlank() ? null : pb.trim());
        }

        switch (o.kind) {
            case CAMERA -> camera(c, o);
            case LIGHT -> light(c, o);
            case ACTOR, PROP -> actor(c, o);
            default -> labels(c, o);
        }
    }

    private static void camera(Ctx c, SceneObject o) {
        SceneEditorScreen s = c.s;
        header(c, "Об'єктив");
        num(c, "FOV", "o.fov" + o.id, s.value(o, Channels.FOV), 0.5, Theme.ACCENT, v -> s.setValue(o, Channels.FOV, Math.max(5, Math.min(150, v))), objKey(s, o, Channels.FOV));
        num(c, "Тремтіння", "o.shake" + o.id, o.channels.sample(Channels.SHAKE, s.time, 0), 0.05, Theme.ACCENT,
            v -> o.channels.getOrCreate(Channels.SHAKE).set(s.time, Math.max(0, v)), objKey(s, o, Channels.SHAKE));
        num(c, "Дихання", "o.breath" + o.id, o.breath, 0.01, Theme.ACCENT, v -> o.breath = (float) Math.max(0, v), null);
        if (c.gui.button(c.x, c.next(RH + 2), c.w, 14, Component.literal("Камера = вигляд (Ctrl+Num0)"), false, Component.literal("Поставити камеру туди, куди зараз дивиться редактор (ключ у playhead)"))) s.cameraToView();

        header(c, "Погляд на ціль");
        List<String> ids = new ArrayList<>(), names = new ArrayList<>();
        ids.add(null); names.add("— вільно —");
        for (SceneObject x : s.variant().objects) if (x != o && !x.isCamera()) { ids.add("obj:" + x.id); names.add(x.name); }
        if (s.def != null) for (SceneDefinition.Slot sl : s.def.slots) if (sl.kind() != SceneDefinition.SlotKind.VALUE) { ids.add("slot:" + sl.name()); names.add("слот " + sl.title()); }
        int cur = Math.max(0, ids.indexOf(o.lookAt));
        int p = cycle(c, "Ціль", names.toArray(new String[0]), cur, "Камера сама повертається до цілі (track-to)");
        if (p >= 0) s.edit("Ціль погляду", () -> o.lookAt = ids.get(p));
        if (o.lookAt != null) {
            num(c, "Зсув Y", "o.looky" + o.id, o.lookOffsetY, 0.05, Theme.AXIS_Y, v -> o.lookOffsetY = v, null);
            if (check(c, "Тримати напрям, якщо ціль зникла", o.lookHoldOnLoss, null)) s.edit("Ціль", () -> o.lookHoldOnLoss = !o.lookHoldOnLoss);
        }

        header(c, "Модифікатори (як у BBS)");
        List<String> oids = new ArrayList<>(), onames = new ArrayList<>();
        oids.add(null); onames.add("— без орбіти —");
        for (SceneObject x : s.variant().objects) if (x != o && !x.isCamera()) { oids.add("obj:" + x.id); onames.add(x.name); }
        if (s.def != null) for (SceneDefinition.Slot sl : s.def.slots) if (sl.kind() != SceneDefinition.SlotKind.VALUE) { oids.add("slot:" + sl.name()); onames.add("слот " + sl.title()); }
        int oi = cycle(c, "Орбіта", onames.toArray(new String[0]), Math.max(0, oids.indexOf(o.orbitTarget)), "Камера кружляє навколо цілі; кут/нахил/відстань — ключами");
        if (oi >= 0) s.edit("Орбіта", () -> o.orbitTarget = oids.get(oi));
        if (o.orbitTarget != null) {
            num(c, "Кут", "o.oy" + o.id, o.channels.sample(Channels.ORBIT_YAW, s.time, o.yaw), 1, Theme.AXIS_Y, v -> o.channels.getOrCreate(Channels.ORBIT_YAW).set(s.time, v), objKey(s, o, Channels.ORBIT_YAW));
            num(c, "Нахил", "o.op" + o.id, o.channels.sample(Channels.ORBIT_PITCH, s.time, 15), 1, Theme.AXIS_X, v -> o.channels.getOrCreate(Channels.ORBIT_PITCH).set(s.time, Math.max(-89, Math.min(89, v))), objKey(s, o, Channels.ORBIT_PITCH));
            num(c, "Відстань", "o.od" + o.id, o.channels.sample(Channels.ORBIT_DIST, s.time, 4), 0.05, Theme.AXIS_Z, v -> o.channels.getOrCreate(Channels.ORBIT_DIST).set(s.time, Math.max(0.2, v)), objKey(s, o, Channels.ORBIT_DIST));
        }
        num(c, "Інерція", "o.drag" + o.id, o.drag, 0.02, Theme.ACCENT, v -> o.drag = (float) Math.max(0, Math.min(0.95, v)), null);
        if (check(c, "Dolly zoom (вертиго)", o.dollyZoom, "Ключі FOV рухають камеру так, що ціль погляду/орбіти не змінює розміру")) s.edit("Dolly zoom", () -> o.dollyZoom = !o.dollyZoom);

        header(c, "Шлях (сплайн)");
        c.gui.textClip(o.path.isEmpty() ? "без шляху — камера йде за ключами" : o.path.size() + " точок; позиція — канал «path» або кліп", c.x, c.next(12) + 1, c.w, Theme.MUTED);
        int yy = c.next(RH + 2);
        int bw = (c.w - 4) / 3;
        if (c.gui.button(c.x, yy, bw, 14, Component.literal("+ точка"), false, Component.literal("Додати точку шляху з поточного виду редактора"))) {
            SceneFrame.Cam e = s.view.eye(1);
            s.edit("Точка шляху", () -> o.path.add(new SceneObject.PathPoint(e.x, e.y, e.z, e.yaw, e.pitch, 0, o.fov)));
        }
        if (c.gui.button(c.x + bw + 2, yy, bw, 14, Component.literal("− точка"), false, null, !o.path.isEmpty())) s.edit("Точка шляху", () -> o.path.remove(o.path.size() - 1));
        if (c.gui.button(c.x + 2 * (bw + 2), yy, bw, 14, Component.literal("Очистити"), false, null, !o.path.isEmpty())) s.edit("Шлях", () -> { o.path.clear(); o.channels.map().remove(Channels.PATH); });
        if (!o.path.isEmpty()) {
            if (check(c, "Орієнтація по дотичній", o.pathOrient, "Камера дивиться вздовж шляху")) s.edit("Шлях", () -> o.pathOrient = !o.pathOrient);
            num(c, "Позиція", "o.path" + o.id, o.channels.sample(Channels.PATH, s.time, 0), 0.01, Theme.ACCENT,
                v -> o.channels.getOrCreate(Channels.PATH).set(s.time, Math.max(0, Math.min(1, v))), objKey(s, o, Channels.PATH));
        }
    }

    // ═════════════════════════ світло ═════════════════════════

    private static final String[] LIGHT_TYPES = { "Точкове", "Прожектор", "Сонце" };

    private static void light(Ctx c, SceneObject o) {
        SceneEditorScreen s = c.s;
        header(c, "Світло сцени меню");
        int ti = cycle(c, "Тип", LIGHT_TYPES, o.lightType.ordinal(), "Точкове — лампа на всі боки; прожектор — конус (напрям = yaw/pitch); сонце — паралельні промені на всю сцену");
        if (ti >= 0) s.edit("Тип світла", () -> {
            o.lightType = SceneObject.LightType.values()[ti];
            if (o.lightType == SceneObject.LightType.SUN && o.pitch < 5) o.pitch = 50;
        });
        int rgb = lightColorAt(o, s.time);
        boolean keyedColor = o.channels.has(Channels.LIGHT_R);
        int cy = c.y[0];
        color(c, "Колір", "o.lcol" + o.id, rgb, true, v -> {
            if (keyedColor) {
                o.channels.getOrCreate(Channels.LIGHT_R).set(s.time, ((v >> 16) & 255) / 255.0);
                o.channels.getOrCreate(Channels.LIGHT_G).set(s.time, ((v >> 8) & 255) / 255.0);
                o.channels.getOrCreate(Channels.LIGHT_B).set(s.time, (v & 255) / 255.0);
            } else o.lightColor = v;
        });
        new KeyBtn(o.channels.get(Channels.LIGHT_R), 0, () -> {
            int cur = lightColorAt(o, s.time);
            o.channels.getOrCreate(Channels.LIGHT_R).set(s.time, ((cur >> 16) & 255) / 255.0);
            o.channels.getOrCreate(Channels.LIGHT_G).set(s.time, ((cur >> 8) & 255) / 255.0);
            o.channels.getOrCreate(Channels.LIGHT_B).set(s.time, (cur & 255) / 255.0);
        }).draw(c, c.x + c.w - 12, cy);
        num(c, "Сила", "o.lint" + o.id, s.value(o, Channels.INTENSITY), 0.05, 0xFFF2B84B, v -> s.setValue(o, Channels.INTENSITY, Math.max(0, v)), objKey(s, o, Channels.INTENSITY));
        if (o.lightType != SceneObject.LightType.SUN)
            num(c, "Дальність", "o.lrng" + o.id, s.value(o, Channels.RANGE), 0.25, Theme.ACCENT, v -> s.setValue(o, Channels.RANGE, Math.max(0.5, v)), objKey(s, o, Channels.RANGE));
        if (o.lightType == SceneObject.LightType.SPOT) {
            num(c, "Зовн. кут", "o.lang" + o.id, o.spotAngle, 1, Theme.ACCENT, v -> o.spotAngle = (float) Math.max(1, Math.min(179, v)), null);
            float inner = o.spotInner > 0 ? o.spotInner : o.spotAngle * (1 - o.spotBlend);
            num(c, "Внутр. кут", "o.linner" + o.id, inner, 1, Theme.ACCENT, v -> o.spotInner = (float) Math.max(0.5, Math.min(o.spotAngle, v)), null);
        }
        int tg = cycle(c, "Світить на", new String[] { "усе", "лише сутності й акторів", "лише блоки" }, o.lightTarget.ordinal(),
            "Як entitiesOnly / blocksOnly: напр. контрове світло лише на героя, не на стіни");
        if (tg >= 0) s.edit("Ціль світла", () -> o.lightTarget = SceneObject.LightTarget.values()[tg]);
        if (check(c, "Кидає тіні", o.castShadows, o.lightType == SceneObject.LightType.POINT
            ? "Кубічна тінь (на сцену — одне точкове світло з тінню)" : "Тіні від світу й акторів (до двох сонць/прожекторів)"))
            s.edit("Тіні", () -> o.castShadows = !o.castShadows);
        if (o.castShadows) num(c, "Розмиття", "o.lsoft" + o.id, o.shadowSoftness, 0.05, Theme.ACCENT, v -> o.shadowSoftness = (float) Math.max(0, Math.min(8, v)), null);
        header(c, "Промені (об'ємне світло)");
        num(c, "Сила", "o.beam" + o.id, o.channels.sample("beam", s.time, o.beam), 0.05, 0xFFF2B84B, v -> {
            var k = o.channels.get("beam");
            if (k != null && !k.isEmpty()) k.set(s.time, Math.max(0, Math.min(5, v))); else o.beam = (float) Math.max(0, Math.min(5, v));
        }, new KeyBtn(o.channels.get("beam"), 0, () -> o.channels.getOrCreate("beam").set(s.time, o.channels.sample("beam", s.time, o.beam))));
        if (o.beam > 0 || o.channels.has("beam")) {
            num(c, "Щільність", "o.vld" + o.id, o.vlDensity, 0.005, Theme.ACCENT, v -> o.vlDensity = (float) Math.max(0.005, Math.min(0.5, v)), null);
            num(c, "Анізотр.", "o.vlg" + o.id, o.anisotropy, 0.02, Theme.ACCENT, v -> o.anisotropy = (float) Math.max(-0.95, Math.min(0.95, v)), null);
            c.gui.textClip("анізотропія > 0 — промінь яскравіший проти світла", c.x, c.next(12) + 1, c.w, Theme.MUTED);
        }
        if (o.lightType == SceneObject.LightType.SPOT) {
            header(c, "Кукі (маска прожектора)");
            String ck = text(c, "Маска", "o.cookie" + o.id, o.cookie, "ассет-картинка або ns:textures/…png");
            if (ck != null) s.edit("Кукі", () -> o.cookie = ck.isBlank() ? null : ck.trim());
            if (o.cookie != null) {
                num(c, "Поворот", "o.ckr" + o.id, o.cookieRotation, 1, Theme.ACCENT, v -> o.cookieRotation = (float) v, null);
                num(c, "Масштаб", "o.cks" + o.id, o.cookieScale, 0.02, Theme.ACCENT, v -> o.cookieScale = (float) Math.max(0.05, Math.min(20, v)), null);
                if (check(c, "Інвертувати маску", o.cookieInvert, null)) s.edit("Кукі", () -> o.cookieInvert = !o.cookieInvert);
            }
        }
        num(c, "Відблиск", "o.lspec" + o.id, o.lightSpecular, 0.05, Theme.ACCENT, v -> o.lightSpecular = (float) Math.max(0, Math.min(4, v)), null);
        c.gui.textClip(o.lightType == SceneObject.LightType.POINT ? "напрям не важливий" : "напрям — Yaw/Pitch (кільця повороту)", c.x, c.next(12) + 1, c.w, Theme.MUTED);
        if (c.gui.button(c.x, c.next(RH + 2), c.w, 14, Component.literal("Світити туди, куди дивиться камера"), false,
            Component.literal("Повернути світло на точку за 4 блоки перед камерою сцени"), s.frame.hasCamera)) aimAtCamera(s, o);
        labels(c, o);
    }

    static int lightColorAt(SceneObject o, double t) {
        int r = (int) Math.round(Math.max(0, Math.min(1, o.channels.sample(Channels.LIGHT_R, t, ((o.lightColor >> 16) & 255) / 255.0))) * 255);
        int g = (int) Math.round(Math.max(0, Math.min(1, o.channels.sample(Channels.LIGHT_G, t, ((o.lightColor >> 8) & 255) / 255.0))) * 255);
        int b = (int) Math.round(Math.max(0, Math.min(1, o.channels.sample(Channels.LIGHT_B, t, (o.lightColor & 255) / 255.0))) * 255);
        return (r << 16) | (g << 8) | b;
    }

    /** Повернути світло на точку, куди дивиться камера сцени (4 блоки перед нею). */
    private static void aimAtCamera(SceneEditorScreen s, SceneObject o) {
        SceneFrame.Cam cam = s.frame.camera;
        double yr = Math.toRadians(cam.yaw), pr = Math.toRadians(cam.pitch);
        double tx = cam.x - Math.sin(yr) * Math.cos(pr) * 4, ty = cam.y - Math.sin(pr) * 4, tz = cam.z + Math.cos(yr) * Math.cos(pr) * 4;
        double[] xf = s.evaluator.transform(o, s.time, new double[7], 0);
        double dx = tx - xf[0], dy = ty - xf[1], dz = tz - xf[2], hl = Math.sqrt(dx * dx + dz * dz);
        double yaw = Math.toDegrees(Math.atan2(-dx, dz)), pitch = Math.toDegrees(-Math.atan2(dy, hl));
        s.edit("Націлити світло", () -> { s.setAngle(o, Channels.YAW, yaw); s.setValue(o, Channels.PITCH, pitch); });
    }

    private static void actor(Ctx c, SceneObject o) {
        SceneEditorScreen s = c.s;
        header(c, "Модель");
        SceneObject.ModelType[] types = { SceneObject.ModelType.PLAYER, SceneObject.ModelType.ASSET, SceneObject.ModelType.RESOURCE };
        String[] tn = { "Гравець", "Ассет світу", "Ресурс мода" };
        int ti = java.util.Arrays.asList(types).indexOf(o.modelType);
        int p = cycle(c, "Тип", tn, ti, null);
        if (p >= 0) s.edit("Тип моделі", () -> o.modelType = types[p]);
        if (o.modelType == SceneObject.ModelType.ASSET) {
            List<SceneDoc.Asset> models = new ArrayList<>();
            for (SceneDoc.Asset a : s.doc.assets.values()) if (a.type == SceneDoc.Asset.Type.MODEL) models.add(a);
            String[] mn = new String[models.size()];
            int mi = -1;
            for (int i = 0; i < models.size(); i++) { mn[i] = models.get(i).name; if (models.get(i).id.equals(o.model)) mi = i; }
            int q = cycle(c, "Файл", mn, mi, "Імпортуйте .bbmodel у вкладці «Ассети»");
            if (q >= 0) s.edit("Модель", () -> o.model = models.get(q).id);
        } else if (o.modelType == SceneObject.ModelType.RESOURCE) {
            String m = text(c, "Id", "o.model" + o.id, o.model, "ns:файл/модель");
            if (m != null) s.edit("Модель", () -> o.model = m.isBlank() ? null : m.trim());
        }
        if (o.modelType != SceneObject.ModelType.PLAYER) {
            String t = text(c, "Текстура", "o.tex" + o.id, o.texture, "asset id або ns:textures/…png");
            if (t != null) s.edit("Текстура", () -> o.texture = t.isBlank() ? null : t.trim());
        }

        header(c, "Скін");
        SceneObject.SkinMode[] modes = SceneObject.SkinMode.values();
        String[] mn = { "Типовий", "Гравець зі слота", "Профіль (нік)", "Текстура", "Хто дивиться" };
        int m = cycle(c, "Джерело", mn, o.skinMode.ordinal(), "Звідки брати скін. Для кісток з міткою player_skin — скін гравця слота");
        if (m >= 0) s.edit("Скін", () -> o.skinMode = modes[m]);
        if (o.skinMode == SceneObject.SkinMode.PROFILE || o.skinMode == SceneObject.SkinMode.TEXTURE) {
            String v = text(c, "Значення", "o.skinv" + o.id, o.skinValue, o.skinMode == SceneObject.SkinMode.PROFILE ? "нік гравця" : "asset id");
            if (v != null) s.edit("Скін", () -> o.skinValue = v.isBlank() ? null : v.trim());
        }
        String[] sl = { "авто", "тонкі руки", "широкі руки" };
        int si = cycle(c, "Руки", sl, o.slim == null ? 0 : o.slim ? 1 : 2, null);
        if (si >= 0) s.edit("Руки", () -> o.slim = si == 0 ? null : si == 1);

        header(c, "Idle (під усім)");
        String idle = text(c, "Кліп", "o.idle" + o.id, o.idle, "ns:clip або asset:id/назва");
        if (idle != null) s.edit("Idle", () -> o.idle = idle.isBlank() ? null : idle.trim());
        if (o.idle != null) num(c, "Швидкість", "o.idles" + o.id, o.idleSpeed, 0.05, Theme.ACCENT, v -> o.idleSpeed = (float) Math.max(0, v), null);
        if (c.gui.button(c.x, c.next(RH + 2), c.w, 14, Component.literal("+ Трек анімації"), false, Component.literal("Шар анімацій актора: кліпи з loop / hold / stop, маска, blend"))) s.addTrack(Track.Type.ANIMATION, o.id);

        header(c, "Рух (як у BBS)");
        if (c.gui.button(c.x, c.next(RH + 2), c.w, 14, Component.literal("● Записати рух (Ctrl+R)"), false,
            Component.literal("Ви стаєте актором: ходіть, дивіться, присідайте — рух пишеться ключами 20/с, поки сцена грає з playhead. R — стоп"), !s.readOnly)) s.startRecording();
        if (o.modelType == SceneObject.ModelType.PLAYER) {
            if (check(c, "Кроки з руху (ноги/руки самі)", o.autoWalk, "Переміщення ключами чи записом саме дає ходьбу, сила — від швидкості")) s.edit("Кроки", () -> o.autoWalk = !o.autoWalk);
            num(c, "Голова ↔", "o.hy" + o.id, o.channels.sample(Channels.HEAD_YAW, s.time, 0), 1, Theme.AXIS_Y,
                v -> o.channels.getOrCreate(Channels.HEAD_YAW).set(s.time, v), objKey(s, o, Channels.HEAD_YAW));
            num(c, "Голова ↕", "o.hp" + o.id, o.channels.sample(Channels.HEAD_PITCH, s.time, 0), 1, Theme.AXIS_X,
                v -> o.channels.getOrCreate(Channels.HEAD_PITCH).set(s.time, v), objKey(s, o, Channels.HEAD_PITCH));
            boolean sneak = o.channels.sample(Channels.SNEAK, s.time, 0) >= 0.5;
            if (check(c, "Присів у цей момент", sneak, null)) s.edit("Присід", () -> o.channels.getOrCreate(Channels.SNEAK).set(s.time, sneak ? 0 : 1));
        }
        if (check(c, "Onion skin (сусідні ключі)", s.onion, "Напівпрозорі копії пози в попередніх/наступних ключах")) s.onion = !s.onion;

        labels(c, o);
    }

    /** Слот, приховання, семантичні мітки (кому і як режим підставляє гравця). */
    private static void labels(Ctx c, SceneObject o) {
        SceneEditorScreen s = c.s;
        header(c, "Мітки для режиму");
        List<String> slots = new ArrayList<>();
        slots.add(null);
        if (s.def != null) for (SceneDefinition.Slot sl : s.def.slots) slots.add(sl.name());
        String[] sn = new String[slots.size()];
        sn[0] = "— без слота —";
        for (int i = 1; i < slots.size(); i++) sn[i] = s.def.slot(slots.get(i)).title() + " (" + slots.get(i) + ")";
        int cur = Math.max(0, slots.indexOf(o.slot));
        int p = cycle(c, "Слот", sn, cur, "Режим підставить сюди гравця/сутність при запуску (winner, maniac…)");
        if (p >= 0) s.edit("Слот", () -> { o.slot = slots.get(p); if (o.slot != null && o.skinMode == SceneObject.SkinMode.DEFAULT && o.modelType == SceneObject.ModelType.PLAYER) o.skinMode = SceneObject.SkinMode.SLOT; });
        if (o.slot != null) {
            num(c, "Індекс", "o.slotidx" + o.id, o.slotIndex, 1, Theme.ACCENT, v -> o.slotIndex = (int) Math.max(0, Math.round(v)), null);
            if (check(c, "Ховати, якщо гравця нема", o.hideIfUnbound, "Наприклад, 3 гравці — 4-й актор зникає")) s.edit("Приховання", () -> o.hideIfUnbound = !o.hideIfUnbound);
        }
        if (s.def != null && !s.def.labels.isEmpty()) {
            for (String l : s.def.labels) {
                boolean on = o.labels.contains(l);
                if (check(c, l, on, "Семантична мітка: режим знаходить об'єкт за нею")) s.edit("Мітка", () -> { if (on) o.labels.remove(l); else o.labels.add(l); });
            }
        }
    }

    // ═════════════════════════ кістка ═════════════════════════

    private static void bone(Ctx c, SceneObject o, String bone) {
        SceneEditorScreen s = c.s;
        header(c, "Кістка · " + bone);
        if (c.gui.button(c.x, c.next(RH + 2), c.w, 14, Component.literal("← до актора"), false, null)) { s.selBone = null; return; }
        var ch = o.bone(bone);
        String[] names = { "Rot X", "Rot Y", "Rot Z", "Pos X", "Pos Y", "Pos Z", "Scl X", "Scl Y", "Scl Z" };
        int[] cols = { Theme.AXIS_X, Theme.AXIS_Y, Theme.AXIS_Z };
        for (int i = 0; i < 9; i++) {
            String cn = Channels.BONE[i];
            double def = i >= 6 ? 1 : 0;
            double v = ch.sample(cn, s.time, def);
            num(c, names[i], "b." + bone + cn + o.id, v, i < 3 ? 1 : i < 6 ? 0.1 : 0.01, cols[i % 3],
                nv -> ch.getOrCreate(cn).set(s.time, nv), new KeyBtn(ch.get(cn), () -> v, () -> ch.getOrCreate(cn).set(s.time, v)));
        }
        c.gui.textClip("Поза — зсув поверх кліпів та idle", c.x, c.next(12) + 1, c.w, Theme.MUTED);
        header(c, "Мітка кістки");
        List<String> opts = new ArrayList<>();
        opts.add(null);
        opts.add("player_skin");
        if (s.def != null) for (String l : s.def.boneLabels) if (!opts.contains(l)) opts.add(l);
        String[] on = new String[opts.size()];
        on[0] = "— без мітки —";
        for (int i = 1; i < opts.size(); i++) on[i] = opts.get(i);
        int cur = Math.max(0, opts.indexOf(o.boneLabels.get(bone)));
        int p = cycle(c, "Мітка", on, cur, "player_skin — кістка й діти малюються скіном гравця слота (UV 64×64)");
        if (p >= 0) s.edit("Мітка кістки", () -> { if (opts.get(p) == null) o.boneLabels.remove(bone); else o.boneLabels.put(bone, opts.get(p)); });
        boolean hidden = o.hiddenBones.contains(bone);
        if (check(c, "Сховати кістку", hidden, null)) s.edit("Кістка", () -> { if (hidden) o.hiddenBones.remove(bone); else o.hiddenBones.add(bone); });
        SceneRig rig = s.clips.rig(o);
        if (rig == null) c.gui.textClip("риг ще вантажиться", c.x, c.next(12), c.w, Theme.WARN);
    }

    // ═════════════════════════ кліп ═════════════════════════

    private static void clip(Ctx c, Track t, Clip k) {
        SceneEditorScreen s = c.s;
        header(c, switch (t.type) {
            case CAMERA -> "Кліп камери"; case ANIMATION -> "Кліп анімації"; case AUDIO -> "Звук"; case OVERLAY -> "Оверлей";
            case EFFECT -> "Ефект"; case TIME -> "Сповільнення";
        });
        num(c, "Старт", "c.start" + k.id, k.start, 1 / s.fps(), Theme.ACCENT, v -> k.start = Math.max(0, v), null);
        num(c, "Довжина", "c.len" + k.id, k.length, 1 / s.fps(), Theme.ACCENT, v -> k.length = Math.max(0.05, v), null);
        switch (t.type) {
            case CAMERA -> {
                List<SceneObject> cams = new ArrayList<>();
                for (SceneObject o : s.variant().objects) if (o.isCamera()) cams.add(o);
                String[] cn = new String[cams.size()];
                int ci = -1;
                for (int i = 0; i < cams.size(); i++) { cn[i] = cams.get(i).name; if (cams.get(i).id.equals(k.ref)) ci = i; }
                int p = cycle(c, "Камера", cn, ci, null);
                if (p >= 0) s.edit("Камера кліпу", () -> k.ref = cams.get(p).id);
                transition(c, k);
            }
            case ANIMATION -> {
                String r = text(c, "Кліп", "c.ref" + k.id, k.ref, "ns:clip");
                if (r != null) s.edit("Кліп", () -> k.ref = r.trim());
                ends(c, k);
                num(c, "Зсув (in)", "c.in" + k.id, k.in, 0.05, Theme.ACCENT, v -> k.in = Math.max(0, v), null);
                num(c, "Швидкість", "c.speed" + k.id, k.speed, 0.05, Theme.ACCENT, v -> k.speed = Math.max(0.01, v), null);
                num(c, "Blend in", "c.bi" + k.id, k.blendIn, 0.05, Theme.ACCENT, v -> k.blendIn = Math.max(0, v), null);
                num(c, "Blend out", "c.bo" + k.id, k.blendOut, 0.05, Theme.ACCENT, v -> k.blendOut = Math.max(0, v), null);
                num(c, "Вага", "c.w" + k.id, k.weight, 0.05, Theme.ACCENT, v -> k.weight = Math.max(0, Math.min(1, v)), null);
                String m = text(c, "Маска", "c.mask" + k.id, k.mask, "upper_body, full-legs…");
                if (m != null) s.edit("Маска", () -> k.mask = m.isBlank() ? null : m.trim());
                if (check(c, "Адитивний шар", k.additive, "Додається поверх, а не замінює (кивок поверх ходьби)")) s.edit("Адитивний", () -> k.additive = !k.additive);
            }
            case AUDIO -> {
                if (dev.shaurmalib.scene.mc.client.GameSounds.isGame(k.ref)) {
                    String id = dev.shaurmalib.scene.mc.client.GameSounds.id(k.ref);
                    c.gui.textClip("♪ " + id, c.x, c.next(12) + 1, c.w, 0xFF9DE3B0);
                    int by = c.next(RH + 2) + 1, half = (c.w - 4) / 2;
                    boolean pl = dev.shaurmalib.scene.mc.client.GameSounds.previewing(id);
                    if (c.gui.button(c.x, by, half, 14, Component.literal(pl ? "■ Стоп" : "▶ Прослухати"), pl, null)) {
                        if (pl) dev.shaurmalib.scene.mc.client.GameSounds.stopPreview();
                        else dev.shaurmalib.scene.mc.client.GameSounds.play(id, (float) k.param("gain", 1), (float) k.param("pitch", 1));
                    }
                    if (c.gui.button(c.x + half + 4, by, half, 14, Component.literal("Інший звук…"), false, Component.literal("Відкрити «Аудіо» в бібліотеці: тягни звук на цей трек"))) {
                        MediaLibrary.tab = MediaLibrary.Tab.AUDIO;
                    }
                    num(c, "Варіант", "c.var" + k.id, k.param("variant", 0), 1, Theme.ACCENT, v -> {
                        k.params.put("variant", (double) Math.max(0, Math.round(v)));
                        k.sourceLength = 0;
                    }, null);
                }
                ends(c, k);
                num(c, "Зсув (in)", "c.in" + k.id, k.in, 0.05, Theme.ACCENT, v -> k.in = Math.max(0, v), null);
                num(c, "Гучність", "c.gain" + k.id, k.value(Channels.GAIN, s.time, 1), 0.05, Theme.ACCENT,
                    v -> clipValue(s, k, Channels.GAIN, Math.max(0, v)), clipKey(s, k, Channels.GAIN, 1));
                num(c, "Висота", "c.pitch" + k.id, k.param("pitch", 1), 0.05, Theme.ACCENT, v -> k.params.put("pitch", Math.max(0.25, v)), null);
                num(c, "Fade in", "c.bi" + k.id, k.blendIn, 0.05, Theme.ACCENT, v -> k.blendIn = Math.max(0, v), null);
                num(c, "Fade out", "c.bo" + k.id, k.blendOut, 0.05, Theme.ACCENT, v -> k.blendOut = Math.max(0, v), null);
                List<SceneObject> srcs = new ArrayList<>(s.variant().objects);
                String[] sn = new String[srcs.size() + 1];
                sn[0] = "— у голові (не просторовий) —";
                int si = 0;
                for (int i = 0; i < srcs.size(); i++) { sn[i + 1] = srcs.get(i).name; if (srcs.get(i).id.equals(t.target)) si = i + 1; }
                int p = cycle(c, "Джерело", sn, si, "Просторовий звук: чути від об'єкта (трек цілком)");
                if (p >= 0) s.edit("Джерело звуку", () -> t.target = p == 0 ? null : srcs.get(p - 1).id);
            }
            case OVERLAY -> {
                List<String> ids = new ArrayList<>();
                for (var e : SceneOverlays.overlays()) ids.add(e.id());
                int p = cycle(c, "Оверлей", ids.toArray(new String[0]), ids.indexOf(k.ref), null);
                if (p >= 0) s.edit("Оверлей", () -> k.ref = ids.get(p));
                String tx = text(c, "Текст", "c.text" + k.id, k.param("text", ""), "текст титулу");
                if (tx != null) s.edit("Текст", () -> k.params.put("text", tx));
                num(c, "X", "c.x" + k.id, k.value("x", s.time, 0.5), 0.01, Theme.AXIS_X, v -> clipValue(s, k, "x", v), clipKey(s, k, "x", 0.5));
                num(c, "Y", "c.y" + k.id, k.value("y", s.time, 0.5), 0.01, Theme.AXIS_Y, v -> clipValue(s, k, "y", v), clipKey(s, k, "y", 0.5));
                num(c, "Масштаб", "c.sc" + k.id, k.value("scale", s.time, 1), 0.05, Theme.ACCENT, v -> clipValue(s, k, "scale", Math.max(0.05, v)), clipKey(s, k, "scale", 1));
                num(c, "Прозор.", "c.op" + k.id, k.value(Channels.OPACITY, s.time, 1), 0.05, Theme.ACCENT, v -> clipValue(s, k, Channels.OPACITY, Math.max(0, Math.min(1, v))), clipKey(s, k, Channels.OPACITY, 1));
                String[] kinds = { "fade", "slide", "scale" };
                int ei = cycle(c, "Поява", kinds, java.util.Arrays.asList(kinds).indexOf(k.param("enter", "fade")), null);
                if (ei >= 0) s.edit("Поява", () -> k.params.put("enter", kinds[ei]));
                int xi = cycle(c, "Зникнення", kinds, java.util.Arrays.asList(kinds).indexOf(k.param("exit", "fade")), null);
                if (xi >= 0) s.edit("Зникнення", () -> k.params.put("exit", kinds[xi]));
                num(c, "Час появи", "c.et" + k.id, k.param("enter_time", 0.3), 0.05, Theme.ACCENT, v -> k.params.put("enter_time", Math.max(0, v)), null);
                num(c, "Час зник.", "c.xt" + k.id, k.param("exit_time", 0.3), 0.05, Theme.ACCENT, v -> k.params.put("exit_time", Math.max(0, v)), null);
            }
            case EFFECT -> {
                List<String> ids = new ArrayList<>();
                for (var e : SceneOverlays.effects()) ids.add(e.id());
                int p = cycle(c, "Ефект", ids.toArray(new String[0]), ids.indexOf(k.ref), null);
                if (p >= 0) s.edit("Ефект", () -> k.ref = ids.get(p));
                num(c, "Сила", "c.int" + k.id, k.value(Channels.INTENSITY, s.time, 1), 0.05, Theme.ACCENT, v -> clipValue(s, k, Channels.INTENSITY, Math.max(0, v)), clipKey(s, k, Channels.INTENSITY, 1));
                if ("shaurma_lib:adjust".equals(k.ref)) {
                    header(c, "Корекція");
                    num(c, "Яскравість", "c.br" + k.id, k.param("brightness", 0), 0.02, Theme.ACCENT, v -> k.params.put("brightness", Math.max(-1, Math.min(1, v))), null);
                    num(c, "Експозиція", "c.ex" + k.id, k.param("exposure", 0), 0.05, Theme.ACCENT, v -> k.params.put("exposure", Math.max(-3, Math.min(3, v))), null);
                    num(c, "Контраст", "c.ct" + k.id, k.param("contrast", 1), 0.05, Theme.ACCENT, v -> k.params.put("contrast", Math.max(0.1, Math.min(3, v))), null);
                    num(c, "Насиченість", "c.sa" + k.id, k.param("saturation", 1), 0.05, Theme.ACCENT, v -> k.params.put("saturation", Math.max(0, Math.min(3, v))), null);
                    num(c, "Температура", "c.te" + k.id, k.param("temperature", 0), 0.05, Theme.ACCENT, v -> k.params.put("temperature", Math.max(-2, Math.min(2, v))), null);
                    num(c, "Відтінок", "c.ti" + k.id, k.param("tint", 0), 0.05, Theme.ACCENT, v -> k.params.put("tint", Math.max(-2, Math.min(2, v))), null);
                }
                if ("shaurma_lib:sh_blur".equals(k.ref)) num(c, "Радіус", "c.rad" + k.id, k.param("radius", 12), 1, Theme.ACCENT, v -> k.params.put("radius", Math.max(1, Math.min(60, v))), null);
                if (k.ref != null && (k.ref.endsWith("zoom_pulse") || k.ref.endsWith("heartbeat"))) num(c, "BPM", "c.bpm" + k.id, k.param("bpm", 120), 1, Theme.ACCENT, v -> k.params.put("bpm", Math.max(20, Math.min(300, v))), null);
                if (dev.shaurmalib.scene.mc.client.ScenePost.isShader(k.ref)) c.gui.textClip("Шейдер кадру: видно в перегляді з камери (P)", c.x, c.next(12) + 1, c.w, Theme.MUTED);
                String hex = k.param("color", "");
                int rgb = parseRgb(hex);
                color(c, "Колір", "c.col" + k.id, rgb < 0 ? 0xFFFFFF : rgb, rgb >= 0, v -> k.params.put("color", String.format("#%06X", v)));
                num(c, "Fade in", "c.bi" + k.id, k.blendIn, 0.05, Theme.ACCENT, v -> k.blendIn = Math.max(0, v), null);
                num(c, "Fade out", "c.bo" + k.id, k.blendOut, 0.05, Theme.ACCENT, v -> k.blendOut = Math.max(0, v), null);
            }
            case TIME -> {
                num(c, "Швидкість", "c.spd" + k.id, k.value(Channels.SPEED, s.time, k.param(Channels.SPEED, 0.5)), 0.05, Theme.ACCENT,
                    v -> { if (k.channels.has(Channels.SPEED)) clipValue(s, k, Channels.SPEED, Math.max(0.01, v)); else k.params.put(Channels.SPEED, Math.max(0.01, v)); },
                    clipKey(s, k, Channels.SPEED, k.param(Channels.SPEED, 0.5)));
                num(c, "Розгін", "c.bi" + k.id, k.blendIn, 0.05, Theme.ACCENT, v -> k.blendIn = Math.max(0, v), null);
                num(c, "Вихід", "c.bo" + k.id, k.blendOut, 0.05, Theme.ACCENT, v -> k.blendOut = Math.max(0, v), null);
                c.gui.textClip("Сповільнює все: камери, анімації, ефекти", c.x, c.next(12) + 1, c.w, Theme.MUTED);
            }
        }
        if (c.gui.button(c.x, c.next(RH + 3) + 2, c.w, 14, Component.literal("Розрізати в playhead (S)"), false, null)) s.splitClip();
    }

    private static void clipValue(SceneEditorScreen s, Clip k, String ch, double v) {
        if (k.channels.has(ch)) k.channels.getOrCreate(ch).set(s.time - k.start, v);
        else k.params.put(ch, v);
    }

    private static KeyBtn clipKey(SceneEditorScreen s, Clip k, String ch, double def) {
        // ключі кліпу — у ЛОКАЛЬНОМУ часі, тому ◆ шукає ключ зі зсувом на старт кліпу
        return new KeyBtn(k.channels.get(ch), k.start, () -> k.channels.getOrCreate(ch).set(s.time - k.start, k.value(ch, s.time, def)));
    }

    private static void ends(Ctx c, Clip k) {
        String[] en = { "Стоп", "Цикл", "Заморозити" };
        int p = cycle(c, "Кінець", en, k.end.ordinal(), "Що після кінця джерела: зупинитись / зациклити / тримати останній кадр");
        if (p >= 0) c.s.edit("Кінець кліпу", () -> k.end = Clip.End.values()[p]);
    }

    private static void transition(Ctx c, Clip k) {
        SceneEditorScreen s = c.s;
        header(c, "Перехід на вході");
        Transition.Type[] types = Transition.Type.values();
        String[] tn = new String[types.length];
        for (int i = 0; i < types.length; i++) tn[i] = MediaLibrary.transitionTitle(types[i]);
        int cur = k.transition == null ? 0 : k.transition.type.ordinal();
        int p = cycle(c, "Тип", tn, cur, "Blend — камера їде з попереднього кадру; решта — ефект з центром на склейці");
        if (p >= 0) s.edit("Перехід", () -> k.transition = p == 0 ? null : Transition.of(types[p]));
        if (k.transition != null) {
            num(c, "Тривалість", "c.trd" + k.id, k.transition.duration, 0.05, Theme.ACCENT, v -> k.transition.duration = Math.max(0.05, v), null);
            if (k.transition.type == Transition.Type.BLEND) {
                Easing[] es = { null, Easing.EASE_IN_OUT_CUBIC, Easing.EASE_IN_OUT_SINE, Easing.EASE_OUT_CUBIC, Easing.EASE_IN_CUBIC, Easing.EASE_IN_OUT_EXPO, Easing.EASE_OUT_BACK };
                String[] en = { "лінійно", "in-out cubic", "in-out sine", "out cubic", "in cubic", "in-out expo", "out back" };
                int ei = java.util.Arrays.asList(es).indexOf(k.transition.easing);
                int q = cycle(c, "Крива", en, ei, null);
                if (q >= 0) s.edit("Крива переходу", () -> k.transition.easing = es[q]);
            }
            if (k.transition.type == Transition.Type.DIP_COLOR || k.transition.type == Transition.Type.FLASH) {
                color(c, "Колір", "c.trc" + k.id, k.transition.color & 0xFFFFFF, true, v -> k.transition.color = v);
            }
        }
    }

    // ═════════════════════════ мітка / варіант ═════════════════════════

    private static void marker(Ctx c, Marker m) {
        SceneEditorScreen s = c.s;
        header(c, "Мітка таймлайну");
        String n = text(c, "Назва", "m.name" + m.id, m.name, "laugh_start");
        if (n != null && !n.isBlank()) s.edit("Мітка", () -> m.name = n.trim());
        num(c, "Час", "m.t" + m.id, m.time, 1 / s.fps(), Theme.ACCENT, v -> m.time = Math.max(0, v), null);
        if (check(c, "Подія для режиму", m.event, "Режим отримає onMarker(назва) у момент проходу")) s.edit("Мітка", () -> m.event = !m.event);
        if (s.def != null && !s.def.events.isEmpty()) {
            String[] ev = s.def.events.toArray(new String[0]);
            int p = cycle(c, "З режиму", ev, s.def.events.indexOf(m.name), "Події, які режим розуміє");
            if (p >= 0) s.edit("Мітка", () -> m.name = ev[p]);
        }
    }

    private static void variant(Ctx c, SceneDoc.Variant v) {
        SceneEditorScreen s = c.s;
        header(c, "Варіант сцени");
        String n = text(c, "Назва", "v.name" + v.id, v.name, "назва");
        if (n != null && !n.isBlank()) s.edit("Варіант", () -> v.name = n.trim());
        num(c, "Довжина", "v.len" + v.id, v.length, 0.1, Theme.ACCENT, x -> { v.length = Math.max(0.1, x); v.autoLength = false; }, null);
        if (check(c, "Довжина за вмістом (авто)", v.autoLength, "Кінець сцени сам іде за останнім кліпом/ключем, як у монтажці.\nАбо тягни жовту риску на лінійці таймлайна"))
            s.edit("Довжина", () -> v.autoLength = !v.autoLength);
        num(c, "Гравців від", "v.min" + v.id, v.minPlayers, 1, Theme.ACCENT, x -> v.minPlayers = (int) Math.max(0, Math.round(x)), null);
        num(c, "до (0 — ∞)", "v.max" + v.id, v.maxPlayers, 1, Theme.ACCENT, x -> v.maxPlayers = (int) Math.max(0, Math.round(x)), null);
        if (check(c, "Зациклити (статична сценка)", v.loop, "Напр. превʼю кіта: крутиться без кінця")) s.edit("Цикл", () -> v.loop = !v.loop);
        if (check(c, "Кіно-режим (забирає камеру, ховає HUD)", v.cinematic, null)) s.edit("Кіно", () -> v.cinematic = !v.cinematic);
        header(c, "Лише світ (фон)");
        if (check(c, "Лише карта — без сутностей, партіклів, погоди", v.worldOnly(),
            "Для фону меню/лобі: глядач бачить лише блоки. Актори сцени лишаються.\nВидно у виді з камери (Num 0) і коли сцена грає"))
            s.edit("Лише світ", () -> v.worldOnly(!v.worldOnly()));
        if (check(c, "  сховати сутності й гравців", v.hideEntities, "Моби, гравці, предмети, рамки, стійки — з тінями й нікнеймами"))
            s.edit("Сутності", () -> v.hideEntities = !v.hideEntities);
        if (check(c, "  сховати партікли", v.hideParticles, null)) s.edit("Партікли", () -> v.hideParticles = !v.hideParticles);
        if (check(c, "  сховати дощ і сніг", v.hideWeather, null)) s.edit("Погода", () -> v.hideWeather = !v.hideWeather);
        header(c, "Кадр");
        num(c, "Смуги", "v.lb" + v.id, v.letterbox, 0.01, Theme.ACCENT, x -> v.letterbox = Math.max(0, Math.min(0.4, x)), null);
        num(c, "Fade in", "v.fi" + v.id, v.fadeIn, 0.05, Theme.ACCENT, x -> v.fadeIn = Math.max(0, x), null);
        num(c, "Fade out", "v.fo" + v.id, v.fadeOut, 0.05, Theme.ACCENT, x -> v.fadeOut = Math.max(0, x), null);
        String d = text(c, "Вимір", "v.dim" + v.id, v.dimension, "minecraft:overworld (порожньо — глядача)");
        if (d != null) s.edit("Вимір", () -> v.dimension = d.isBlank() ? null : d.trim());
        num(c, "FPS", "doc.fps", s.doc.fps, 1, Theme.ACCENT, x -> s.doc.fps = Math.max(1, Math.min(120, Math.round(x))), null);
        header(c, "Робоча зона");
        num(c, "Від", "v.wi" + v.id, v.workIn, 0.1, Theme.ACCENT, x -> v.workIn = Math.max(0, x), null);
        num(c, "До", "v.wo" + v.id, v.workOut, 0.1, Theme.ACCENT, x -> v.workOut = Math.max(0, x), null);
        c.gui.textClip("Порада: виберіть об'єкт у в'юпорті або Outliner", c.x, c.next(12) + 4, c.w, Theme.MUTED);
    }
}
