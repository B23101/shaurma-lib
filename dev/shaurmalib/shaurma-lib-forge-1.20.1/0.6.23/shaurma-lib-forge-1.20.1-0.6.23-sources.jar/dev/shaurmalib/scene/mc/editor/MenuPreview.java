package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.doc.MenuFrame;
import dev.shaurmalib.scene.edit.MenuChecks;
import dev.shaurmalib.scene.mc.client.menu.MenuRenderer;
import dev.shaurmalib.scene.mc.client.menu.MenuScene;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/**
 * Живе превʼю віконця меню в куті в'юпорта: той самий рендер, що побачить гравець у меню (світло, тіні, корекція),
 * у форматі кадру сцени, з безпечними зонами, імітацією наведення (збільшення + наїзд) і бейджем чек-листа.
 * Перетягується за заголовок, кнопка ⤢ — на пів в'юпорта.
 */
final class MenuPreview {

    private MenuPreview() {}

    private static final MenuRenderer RENDERER = new MenuRenderer();
    private static final MenuRenderer.Input IN = new MenuRenderer.Input();
    static boolean big, safe = true, hoverSim;
    private static float hover, hoverVel;
    private static long lastNs, lastRenderNs;
    private static int tex, texW, texH;
    private static double[] center;
    private static long centerAt;
    /** Зсув від правого нижнього кута в'юпорта (тягнеться за заголовок). */
    private static int offX = 8, offY = 8;
    private static boolean dragging;
    private static int dragMx, dragMy, dragOx, dragOy;

    static void close() { RENDERER.close(); tex = 0; }

    static void render(SceneEditorScreen s, Gui gui) {
        MenuFrame f = MenuChecks.frame(s.variant(), s.def);
        int top = CameraBar.bottom(s);
        int maxW = (int) (s.vw * (big ? 0.62 : 0.36)), maxH = Math.min((int) (s.vh * (big ? 0.82 : 0.5)), s.vy + s.vh - top - 20);
        maxW = Math.max(40, maxW);
        maxH = Math.max(30, maxH);
        double aspect = f.aspect();
        int w = maxW, h = (int) Math.round(w / aspect);
        if (h > maxH) { h = maxH; w = (int) Math.round(h * aspect); }
        w = Math.max(40, w);
        h = Math.max(30, h);
        int head = 14;
        int x = s.vx + s.vw - w - offX, y = s.vy + s.vh - h - head - offY;
        x = Math.max(s.vx + 2, Math.min(s.vx + s.vw - w - 2, x));
        y = Math.max(top + 2, Math.min(s.vy + s.vh - h - head - 2, y));

        long now = System.nanoTime();
        double dt = lastNs == 0 ? 0 : Math.min(0.1, (now - lastNs) / 1e9);
        lastNs = now;
        boolean overImage = gui.hover(x, y + head, w, h);
        float target = hoverSim || overImage ? 1 : 0, omega = 11f;
        for (double left = dt; left > 1e-6; left -= 1 / 240.0) {
            float st = (float) Math.min(left, 1 / 240.0);
            hoverVel += (omega * omega * (target - hover) - 2 * omega * hoverVel) * st;
            hover += hoverVel * st;
        }

        // заголовок
        gui.g.fill(x - 2, y - 2, x + w + 2, y + head + h + 2, 0xFF000000);
        gui.g.fill(x, y, x + w, y + head, 0xFF1A2236);
        int[] n = LookPage.counts(s);
        String title = "Меню · " + f.aspectW + ":" + f.aspectH + (f.hoverZoom > 1.001f ? String.format(" · ×%.2f", f.hoverZoom) : "");
        gui.textClip(title, x + 4, y + 3, w - 64, Theme.TEXT);
        int bx = x + w - 14;
        if (gui.iconButton(bx, y + 1, 12, big ? Icon.MINUS : Icon.MAXIMIZE, false, Component.literal(big ? "Менше" : "Більше превʼю"))) big = !big;
        bx -= 14;
        if (gui.iconButton(bx, y + 1, 12, Icon.INTERACT, hoverSim, Component.literal("Як під курсором: збільшення й наїзд камери\n(або просто наведіть мишу на превʼю)"))) hoverSim = !hoverSim;
        bx -= 14;
        if (gui.iconButton(bx, y + 1, 12, Icon.HITBOX, safe, Component.literal("Безпечні зони (там меню малює назву/ціну)"))) safe = !safe;
        if (n[0] + n[1] > 0) {
            String b = n[0] > 0 ? n[0] + "✖" : n[1] + "⚠";
            int bw = gui.font.width(b) + 6;
            int col = n[0] > 0 ? 0xFFE5646A : 0xFFF2B84B;
            gui.g.fill(bx - bw - 2, y + 2, bx - 2, y + 12, col);
            gui.text(b, bx - bw + 1, y + 3, 0xFF101010);
            if (gui.hover(bx - bw - 2, y + 2, bw, 10)) gui.tip(Component.literal("Вимоги сцени меню: сторінка «Колір» → «Меню й цикл»"));
            if (gui.clicked(bx - bw - 2, y + 2, bw, 10, 0)) PageBar.open(s, PageBar.LOOK);
        }
        // перетягування за заголовок
        if (!dragging && gui.press("menuprev.drag", x, y, w - 60, head, 0)) { dragging = true; dragMx = gui.mx; dragMy = gui.my; dragOx = offX; dragOy = offY; }
        if (dragging) {
            if (!gui.isDown(0)) dragging = false;
            else { offX = dragOx - (gui.mx - dragMx); offY = dragOy - (gui.my - dragMy); }
        }

        // кадр
        double gs = Minecraft.getInstance().getWindow().getGuiScale();
        int pw = (int) Math.ceil(w * gs), ph = (int) Math.ceil(h * gs);
        int fps = s.playing || Math.abs(hoverVel) > 0.01f || dragging ? 60 : 30;
        if (tex == 0 || pw != texW || ph != texH || now - lastRenderNs > 1_000_000_000L / fps) {
            if (center == null || now - centerAt > 1_000_000_000L) {
                center = MenuChecks.stageCenter(s.doc, s.variant(), f, s.clips);
                centerAt = now;
            }
            gui.g.flush();
            IN.frame = s.frame;
            IN.doc = s.doc;
            IN.clips = s.clips;
            IN.menu = f;
            IN.stageCenter = center;
            IN.width = pw;
            IN.height = ph;
            IN.hover = Math.max(0, hover);
            IN.parallaxX = 0;
            IN.parallaxY = 0;
            IN.partial = Minecraft.getInstance().getFrameTime();
            IN.wall = now / 1e9;
            int t = MenuScene.renderFrame(RENDERER, IN);
            if (t != 0) { tex = t; texW = pw; texH = ph; lastRenderNs = now; }
        }
        int iy = y + head;
        gui.g.fill(x, iy, x + w, iy + h, 0xFF06080C);
        if (tex != 0) {
            float z = 1 + (f.hoverZoom - 1) * Math.max(0, hover);
            gui.g.enableScissor(x, iy, x + w, iy + h);
            gui.g.pose().pushPose();
            gui.g.pose().translate(x + w / 2f, iy + h / 2f, 0);
            gui.g.pose().scale(z, z, 1);
            gui.g.pose().translate(-w / 2f, -h / 2f, 0);
            MenuScene.blit(gui.g, tex, 0, 0, w, h);
            gui.g.pose().popPose();
            gui.g.disableScissor();
        } else {
            String err = MenuRenderer.error();
            gui.textClip(err != null ? "рендер вимкнено: " + err : "готуємо сцену…", x + 4, iy + h / 2 - 4, w - 8, err != null ? Theme.DANGER : Theme.MUTED);
        }
        if (!s.frame.hasCamera) gui.textClip("нема кліпу камери в цей момент", x + 4, iy + 4, w - 8, Theme.WARN);
        if (safe) {
            int sb = (int) (h * f.safeBottom), st = (int) (h * f.safeTop), sl = (int) (w * f.safeLeft), sr = (int) (w * f.safeRight);
            int col = 0x55E5646A;
            if (sb > 0) { gui.g.fill(x, iy + h - sb, x + w, iy + h, col); gui.textClip("підпис меню", x + 4, iy + h - sb + 2, w - 8, 0xCCFFFFFF); }
            if (st > 0) gui.g.fill(x, iy, x + w, iy + st, col);
            if (sl > 0) gui.g.fill(x, iy + st, x + sl, iy + h - sb, col);
            if (sr > 0) gui.g.fill(x + w - sr, iy + st, x + w, iy + h - sb, col);
            // третини — допомога в композиції
            int g = 0x26FFFFFF;
            gui.g.fill(x + w / 3, iy, x + w / 3 + 1, iy + h, g);
            gui.g.fill(x + 2 * w / 3, iy, x + 2 * w / 3 + 1, iy + h, g);
            gui.g.fill(x, iy + h / 3, x + w, iy + h / 3 + 1, g);
            gui.g.fill(x, iy + 2 * h / 3, x + w, iy + 2 * h / 3 + 1, g);
        }
        if (RENDERER.stageProgress < 0.999f) {
            gui.g.fill(x, iy + h - 2, x + (int) (w * RENDERER.stageProgress), iy + h, 0xC0FFFFFF);
        }
    }

    /** Прямокутник превʼю (щоб клік у ньому не вибирав об'єкти світу). */
    static boolean contains(SceneEditorScreen s, double mx, double my) {
        MenuFrame f = MenuChecks.frame(s.variant(), s.def);
        int top = CameraBar.bottom(s);
        int maxW = Math.max(40, (int) (s.vw * (big ? 0.62 : 0.36))), maxH = Math.max(30, Math.min((int) (s.vh * (big ? 0.82 : 0.5)), s.vy + s.vh - top - 20));
        int w = maxW, h = (int) Math.round(w / f.aspect());
        if (h > maxH) { h = maxH; w = (int) Math.round(h * f.aspect()); }
        w = Math.max(40, w);
        h = Math.max(30, h);
        int x = s.vx + s.vw - w - offX, y = s.vy + s.vh - h - 14 - offY;
        x = Math.max(s.vx + 2, Math.min(s.vx + s.vw - w - 2, x));
        y = Math.max(top + 2, Math.min(s.vy + s.vh - h - 16, y));
        return mx >= x - 2 && my >= y - 2 && mx < x + w + 2 && my < y + 14 + h + 2;
    }
}
