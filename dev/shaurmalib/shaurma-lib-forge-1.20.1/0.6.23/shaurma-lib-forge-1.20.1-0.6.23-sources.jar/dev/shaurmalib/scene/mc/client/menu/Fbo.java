package dev.shaurmalib.scene.mc.client.menu;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL30;

/**
 * Офскрін-ціль рендеру сцени меню: колір (RGBA8 або RGBA16F для HDR) і/або глибина-текстура (для тіней —
 * з апаратним порівнянням, щоб {@code sampler2DShadow} давав білінійний PCF). Текстури зв'язуються лише через
 * {@link GlStateManager}, щоб кеш прив'язок гри лишався правдивим.
 */
final class Fbo {

    enum Color { NONE, RGBA8, RGBA16F }

    final Color color;
    final boolean depth, shadow;
    int fbo, colorTex, depthTex, width, height;

    Fbo(Color color, boolean depth, boolean shadow) {
        this.color = color;
        this.depth = depth;
        this.shadow = shadow;
    }

    /** Створити або перестворити під розмір. */
    void ensure(int w, int h) {
        w = Math.max(1, w);
        h = Math.max(1, h);
        if (fbo != 0 && w == width && h == height) return;
        close();
        width = w;
        height = h;
        fbo = GL30.glGenFramebuffers();
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo);
        if (color != Color.NONE) {
            colorTex = GlStateManager._genTexture();
            GlStateManager._bindTexture(colorTex);
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL30.GL_CLAMP_TO_EDGE);
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL30.GL_CLAMP_TO_EDGE);
            if (color == Color.RGBA16F) GlStateManager._texImage2D(GL11.GL_TEXTURE_2D, 0, GL30.GL_RGBA16F, w, h, 0, GL11.GL_RGBA, GL11.GL_FLOAT, null);
            else GlStateManager._texImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, w, h, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, null);
            GlStateManager._glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, colorTex, 0);
        } else {
            GL11.glDrawBuffer(GL11.GL_NONE);
            GL11.glReadBuffer(GL11.GL_NONE);
        }
        if (depth) {
            depthTex = GlStateManager._genTexture();
            GlStateManager._bindTexture(depthTex);
            int filter = shadow ? GL11.GL_LINEAR : GL11.GL_NEAREST;
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, filter);
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, filter);
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL30.GL_CLAMP_TO_EDGE);
            GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL30.GL_CLAMP_TO_EDGE);
            if (shadow) {
                GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_COMPARE_MODE, GL30.GL_COMPARE_REF_TO_TEXTURE);
                GlStateManager._texParameter(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_COMPARE_FUNC, GL11.GL_LEQUAL);
            }
            GlStateManager._texImage2D(GL11.GL_TEXTURE_2D, 0, GL14.GL_DEPTH_COMPONENT24, w, h, 0, GL11.GL_DEPTH_COMPONENT, GL11.GL_FLOAT, null);
            GlStateManager._glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_DEPTH_ATTACHMENT, GL11.GL_TEXTURE_2D, depthTex, 0);
        }
        int status = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
        GlStateManager._bindTexture(0);
        if (status != GL30.GL_FRAMEBUFFER_COMPLETE) {
            close();
            throw new IllegalStateException("shaurma menu fbo incomplete: 0x" + Integer.toHexString(status));
        }
    }

    void bind() {
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo);
        RenderSystem.viewport(0, 0, width, height);
    }

    void close() {
        if (colorTex != 0) { GlStateManager._deleteTexture(colorTex); colorTex = 0; }
        if (depthTex != 0) { GlStateManager._deleteTexture(depthTex); depthTex = 0; }
        if (fbo != 0) { GlStateManager._glDeleteFramebuffers(fbo); fbo = 0; }
        width = height = 0;
    }
}
