package dev.shaurmalib.scene.mc.client.menu;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexBuffer;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexSorting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.block.ModelBlockRenderer;
import net.minecraft.client.renderer.chunk.RenderChunkRegion;
import net.minecraft.client.renderer.chunk.RenderRegionCache;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.material.FluidState;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Власна геометрія «сцени» (ділянки світу навколо локації сцени меню): секції 16³ збираються тим самим
 * {@code BlockRenderDispatcher}, що й у ванілі, але у фоновому потоці бібліотеки й у власні VBO. Тож сцена
 * не залежить від того, куди дивиться гравець (ванільні секції за його спиною не скомпільовані) і від модів, що
 * підміняють рендер чанків (Embeddium/Rubidium). Секції пере-збираються по черзі раз на кілька секунд, тож зміни
 * блоків на локації доходять без хуків.
 */
final class StageMesher {

    private StageMesher() {}

    /** Шари: solid, cutout_mipped, cutout, translucent (tripwire — разом з cutout). */
    static final int SOLID = 0, CUTOUT_MIPPED = 1, CUTOUT = 2, TRANSLUCENT = 3, LAYERS = 4;

    static int layer(RenderType t) {
        if (t == RenderType.solid()) return SOLID;
        if (t == RenderType.cutoutMipped()) return CUTOUT_MIPPED;
        if (t == RenderType.translucent()) return TRANSLUCENT;
        return CUTOUT;
    }

    /** Секція сцени. */
    static final class Section {
        final BlockPos origin;
        final VertexBuffer[] buffers = new VertexBuffer[LAYERS];
        final boolean[] has = new boolean[LAYERS];
        final List<BlockEntity> blockEntities = new ArrayList<>();
        /** Блоки, що світяться: {x, y, z (центр), r, g, b, сила, дальність} — для авто-світла. */
        final List<float[]> emitters = new ArrayList<>();
        long builtNs;
        boolean building, built, empty;

        Section(BlockPos origin) { this.origin = origin; }

        void close() {
            for (int i = 0; i < LAYERS; i++) if (buffers[i] != null) { buffers[i].close(); buffers[i] = null; }
        }
    }

    /** Одна сцена: секції в радіусі від центру. */
    static final class Stage {
        final ClientLevel level;
        final long key;
        final double cx, cy, cz, radius;
        final List<Section> sections = new ArrayList<>();
        /** Росте, коли змінилась геометрія (для кешу статичних тіней). */
        int version;
        long lastUsedNs;
        double sortX, sortY, sortZ;
        int refreshCursor;

        Stage(ClientLevel level, long key, double cx, double cy, double cz, double radius) {
            this.level = level;
            this.key = key;
            this.cx = cx; this.cy = cy; this.cz = cz; this.radius = radius;
            int r = (int) Math.ceil((radius + 8) / 16.0);
            int scx = SectionPos.blockToSectionCoord((int) Math.floor(cx)), scy = SectionPos.blockToSectionCoord((int) Math.floor(cy)),
                scz = SectionPos.blockToSectionCoord((int) Math.floor(cz));
            int minY = level.getMinSection(), maxY = level.getMaxSection() - 1;
            double lim = (radius + 14) * (radius + 14);
            for (int x = -r; x <= r; x++) for (int y = -r; y <= r; y++) for (int z = -r; z <= r; z++) {
                int sy = scy + y;
                if (sy < minY || sy > maxY) continue;
                double dx = (scx + x) * 16 + 8 - cx, dy = sy * 16 + 8 - cy, dz = (scz + z) * 16 + 8 - cz;
                if (dx * dx + dy * dy + dz * dz > lim) continue;
                sections.add(new Section(SectionPos.of(scx + x, sy, scz + z).origin()));
            }
            // ближчі до центру — першими (видно, як сцена «з'являється» з середини)
            sections.sort((a, b) -> Double.compare(d2(a.origin), d2(b.origin)));
        }

        private double d2(BlockPos o) {
            double dx = o.getX() + 8 - cx, dy = o.getY() + 8 - cy, dz = o.getZ() + 8 - cz;
            return dx * dx + dy * dy + dz * dz;
        }

        /** Чи всі секції зібрані хоч раз. */
        boolean ready() {
            for (Section s : sections) if (!s.built && !s.empty) return false;
            return true;
        }

        float progress() {
            if (sections.isEmpty()) return 1;
            int n = 0;
            for (Section s : sections) if (s.built || s.empty) n++;
            return n / (float) sections.size();
        }

        void close() { for (Section s : sections) s.close(); }
    }

    // ═════════════════════════ кеш сцен ═════════════════════════

    private static final Map<Long, Stage> STAGES = new HashMap<>();
    private static ClientLevel lastLevel;

    /** Сцена для центру/радіуса (кешується; центр округлюється до блоку). */
    static Stage stage(ClientLevel level, double cx, double cy, double cz, double radius, double sortX, double sortY, double sortZ) {
        if (level != lastLevel) { clear(); lastLevel = level; }
        long key = ((long) Math.floor(cx) * 73856093L) ^ ((long) Math.floor(cy) * 19349663L) ^ ((long) Math.floor(cz) * 83492791L) ^ ((long) Math.round(radius) << 40);
        Stage st = STAGES.get(key);
        if (st == null) {
            st = new Stage(level, key, Math.floor(cx) + 0.5, Math.floor(cy) + 0.5, Math.floor(cz) + 0.5, radius);
            STAGES.put(key, st);
        }
        st.sortX = sortX; st.sortY = sortY; st.sortZ = sortZ;
        st.lastUsedNs = System.nanoTime();
        return st;
    }

    /** Звільнити сцени, які давно не малювались. */
    static void gc() {
        long now = System.nanoTime();
        Iterator<Stage> it = STAGES.values().iterator();
        while (it.hasNext()) {
            Stage s = it.next();
            if (now - s.lastUsedNs > 45_000_000_000L) { s.close(); it.remove(); }
        }
    }

    static void clear() {
        for (Stage s : STAGES.values()) s.close();
        STAGES.clear();
        DONE.clear();
    }

    // ═════════════════════════ збірка ═════════════════════════

    private static final int PACKS = 2;
    private static final BlockingQueue<BufferBuilder[]> POOL = new ArrayBlockingQueue<>(PACKS);
    private static ExecutorService worker;
    private static final ConcurrentLinkedQueue<Result> DONE = new ConcurrentLinkedQueue<>();
    private static final long REFRESH_NS = 12_000_000_000L, REFRESH_GAP_NS = 120_000_000L;
    private static long lastRefreshNs;

    private record Result(Stage stage, Section section, BufferBuilder[] pack, BufferBuilder.RenderedBuffer[] layers, List<BlockEntity> bes, List<float[]> emitters) {}

    private static void init() {
        if (worker != null) return;
        for (int i = 0; i < PACKS; i++) {
            BufferBuilder[] p = new BufferBuilder[LAYERS];
            for (int l = 0; l < LAYERS; l++) p[l] = new BufferBuilder(l == SOLID ? 1 << 20 : 1 << 18);
            POOL.add(p);
        }
        worker = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "shaurma-menu-stage");
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY - 1);
            return t;
        });
    }

    /**
     * Кадр (потік рендеру): прийняти готові секції (завантажити у VBO), запустити наступні.
     *
     * @param budget скільки нових збірок можна запустити зараз
     */
    static void update(Stage st, int budget) {
        init();
        upload();
        if (POOL.isEmpty()) return;
        long now = System.nanoTime();
        int started = 0;
        // спершу — ніколи не зібрані, потім одна найстаріша на оновлення
        for (Section s : st.sections) {
            if (started >= budget || POOL.isEmpty()) break;
            if (s.built || s.empty || s.building) continue;
            if (start(st, s)) started++;
        }
        if (started == 0 && !st.sections.isEmpty() && !POOL.isEmpty() && now - lastRefreshNs > REFRESH_GAP_NS) {
            lastRefreshNs = now;
            for (int i = 0; i < st.sections.size(); i++) {
                Section s = st.sections.get(st.refreshCursor = (st.refreshCursor + 1) % st.sections.size());
                if (!s.building && now - s.builtNs > REFRESH_NS) { start(st, s); break; }
            }
        }
    }

    private static boolean start(Stage st, Section s) {
        ClientLevel level = st.level;
        int cx = SectionPos.blockToSectionCoord(s.origin.getX()), cz = SectionPos.blockToSectionCoord(s.origin.getZ());
        if (level.getChunkSource().getChunk(cx, cz, false) == null) return false;   // чанк ще не прийшов
        RenderChunkRegion region = new RenderRegionCache().createRegion(level, s.origin.offset(-1, -1, -1), s.origin.offset(16, 16, 16), 1);
        if (region == null) {
            s.empty = true;
            s.builtNs = System.nanoTime();
            for (int i = 0; i < LAYERS; i++) s.has[i] = false;
            s.blockEntities.clear();
            return false;
        }
        BufferBuilder[] pack = POOL.poll();
        if (pack == null) return false;
        s.building = true;
        float sx = (float) (st.sortX - s.origin.getX()), sy = (float) (st.sortY - s.origin.getY()), sz = (float) (st.sortZ - s.origin.getZ());
        List<BlockEntity> bes = blockEntities(level, s.origin);
        worker.execute(() -> {
            BufferBuilder.RenderedBuffer[] out = new BufferBuilder.RenderedBuffer[LAYERS];
            List<float[]> emitters = new ArrayList<>();
            try {
                build(region, s.origin, pack, sx, sy, sz, out, emitters);
            } catch (Throwable t) {
                for (int i = 0; i < LAYERS; i++) {
                    if (out[i] != null) { out[i].release(); out[i] = null; }
                    if (pack[i].building()) pack[i].discard();
                }
            }
            DONE.add(new Result(st, s, pack, out, bes, emitters));
        });
        return true;
    }

    /** Блок-сутності секції, що мають рендерер (скрині, таблички, голови…). Потік рендеру. */
    private static List<BlockEntity> blockEntities(ClientLevel level, BlockPos origin) {
        List<BlockEntity> out = new ArrayList<>();
        LevelChunk ch = level.getChunkSource().getChunk(SectionPos.blockToSectionCoord(origin.getX()), SectionPos.blockToSectionCoord(origin.getZ()), false);
        if (ch == null) return out;
        var dispatcher = Minecraft.getInstance().getBlockEntityRenderDispatcher();
        for (BlockEntity be : ch.getBlockEntities().values()) {
            int y = be.getBlockPos().getY();
            if (y < origin.getY() || y > origin.getY() + 15) continue;
            if (dispatcher.getRenderer(be) != null) out.add(be);
        }
        return out;
    }

    /** Фоновий потік: та сама збірка, що у ванільному RebuildTask. */
    private static void build(RenderChunkRegion region, BlockPos origin, BufferBuilder[] pack, float sx, float sy, float sz, BufferBuilder.RenderedBuffer[] out,
                              List<float[]> emitters) {
        java.util.Map<Long, float[]> cells = new java.util.HashMap<>();
        BlockRenderDispatcher brd = Minecraft.getInstance().getBlockRenderer();
        RandomSource rnd = RandomSource.create();
        PoseStack ps = new PoseStack();
        boolean[] begun = new boolean[LAYERS];
        ModelBlockRenderer.enableCaching();
        try {
            BlockPos end = origin.offset(15, 15, 15);
            for (BlockPos p : BlockPos.betweenClosed(origin, end)) {
                BlockState st = region.getBlockState(p);
                if (st.isAir()) continue;
                BlockLightTable.Def def = BlockLightTable.resolve(st);
                if (def != null) emitter(region, p, def, emitters, cells);
                FluidState fs = st.getFluidState();
                if (!fs.isEmpty()) {
                    int l = layer(ItemBlockRenderTypes.getRenderLayer(fs));
                    begin(pack, begun, l);
                    brd.renderLiquid(p, region, pack[l], st, fs);
                }
                if (st.getRenderShape() == RenderShape.MODEL) {
                    int l = layer(ItemBlockRenderTypes.getChunkRenderType(st));
                    begin(pack, begun, l);
                    rnd.setSeed(st.getSeed(p));
                    ps.pushPose();
                    ps.translate(p.getX() & 15, p.getY() & 15, p.getZ() & 15);
                    brd.renderBatched(st, p, region, ps, pack[l], true, rnd);
                    ps.popPose();
                }
            }
        } finally {
            ModelBlockRenderer.clearCache();
        }
        for (float[] c : cells.values()) {
            // комірка масового випромінювача: одне світло в середині, сильніше від кількості блоків
            float n = c[8];
            if (n < 1) continue;
            emitters.add(new float[] { c[0] / n, c[1] / n, c[2] / n, c[3], c[4], c[5], c[6] * (float) Math.min(2.2, 0.8 + 0.15 * n), c[7], c[9] });
        }
        if (begun[TRANSLUCENT] && !pack[TRANSLUCENT].isCurrentBatchEmpty()) pack[TRANSLUCENT].setQuadSorting(VertexSorting.byDistance(sx, sy, sz));
        for (int l = 0; l < LAYERS; l++) if (begun[l]) out[l] = pack[l].endOrDiscardIfEmpty();
    }

    /** Випромінювач: лише «відкритий» (хоч один сусід не суцільний) — закопані не світять; масові — у комірки. */
    private static void emitter(RenderChunkRegion region, BlockPos p, BlockLightTable.Def def, List<float[]> out, java.util.Map<Long, float[]> cells) {
        boolean open = false;
        BlockPos.MutableBlockPos n = new BlockPos.MutableBlockPos();
        for (net.minecraft.core.Direction d : net.minecraft.core.Direction.values()) {
            n.setWithOffset(p, d);
            BlockState ns = region.getBlockState(n);
            if (!ns.isSolidRender(region, n) && BlockLightTable.resolve(ns) == null || ns.isAir()) { open = true; break; }
        }
        float x = p.getX() + 0.5f, y = p.getY() + 0.5f, z = p.getZ() + 0.5f;
        if (def.mergeCells() > 1) {
            int c = def.mergeCells();
            long key = ((long) Math.floorDiv(p.getX(), c) * 73856093L) ^ ((long) Math.floorDiv(p.getY(), c) * 19349663L) ^ ((long) Math.floorDiv(p.getZ(), c) * 83492791L)
                ^ ((long) System.identityHashCode(def) << 20);
            float[] cell = cells.computeIfAbsent(key, k -> new float[] { 0, 0, 0, def.r(), def.g(), def.b(), def.intensity(), def.radius(), 0, 0 });
            cell[0] += x; cell[1] += y; cell[2] += z; cell[8] += 1;
            if (open) cell[9] = 1;
            return;
        }
        out.add(new float[] { x, y, z, def.r(), def.g(), def.b(), def.intensity(), def.radius(), open ? 1 : 0 });
    }

    private static void begin(BufferBuilder[] pack, boolean[] begun, int l) {
        if (begun[l]) return;
        pack[l].begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.BLOCK);
        begun[l] = true;
    }

    /** Потік рендеру: готові секції — у VBO. */
    private static void upload() {
        Result r;
        while ((r = DONE.poll()) != null) {
            Section s = r.section();
            boolean alive = STAGES.get(r.stage().key) == r.stage();
            boolean any = false;
            for (int l = 0; l < LAYERS; l++) {
                BufferBuilder.RenderedBuffer rb = r.layers()[l];
                if (rb == null) { s.has[l] = false; continue; }
                if (!alive) { rb.release(); continue; }
                if (s.buffers[l] == null) s.buffers[l] = new VertexBuffer(VertexBuffer.Usage.STATIC);
                s.buffers[l].bind();
                s.buffers[l].upload(rb);
                s.has[l] = true;
                any = true;
            }
            VertexBuffer.unbind();
            POOL.add(r.pack());
            s.building = false;
            if (!alive) continue;
            s.blockEntities.clear();
            s.blockEntities.addAll(r.bes());
            s.emitters.clear();
            s.emitters.addAll(r.emitters());
            s.built = any;
            s.empty = !any;
            s.builtNs = System.nanoTime();
            r.stage().version++;
        }
    }
}
