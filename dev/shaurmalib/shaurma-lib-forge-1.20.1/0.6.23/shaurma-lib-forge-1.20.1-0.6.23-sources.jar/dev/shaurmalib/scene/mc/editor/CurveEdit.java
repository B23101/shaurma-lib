package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.doc.Channels;
import dev.shaurmalib.scene.doc.KeyChannel;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.mc.ui.Gui;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Крива руху прямо в 3D (як Motion Paths + ручки в Blender): у вибраного об'єкта (камери, актора, світла)
 * на траєкторії видно точки-ключі — тягни точку, і ключі X/Y/Z у той момент переїжджають; клік по точці
 * показує ручки Безьє (вхід/вихід) — тягни ручку, і крива вигинається (ручки X/Y/Z стають «Aligned»,
 * Alt — «Free»). Шлях камери (сплайн) — так само тягнуться його точки. Ctrl+клік по кривій — нова точка,
 * Delete — прибрати вибрану. Тягнеться в площині екрана через точку; Alt — лише по висоті; Ctrl — без сітки.
 */
final class CurveEdit {

    private CurveEdit() {}

    /** kind: 0 — ключ, 1 — ручка виходу, 2 — ручка входу, 3 — точка шляху камери. */
    record Pt(int kind, String obj, double t, int index, double x, double y, double z) {}

    private static Pt selected, hover, drag;
    private static double[] grab;          // зсув курсора від точки в площині
    private static Vec3 planeP, planeN;
    private static double[] start = new double[9];
    private static final double SNAP = 1 / 16.0;

    static boolean busy() { return drag != null; }

    static void reset() { selected = hover = drag = null; }

    // ═════════════════════════ точки ═════════════════════════

    private static boolean editable(SceneObject o) { return o != null && o.parent == null && o.orbitTarget == null && !o.locked; }

    static List<Pt> points(SceneEditorScreen s) {
        List<Pt> out = new ArrayList<>();
        SceneObject o = s.selected();
        if (o == null || o.editorHidden || s.selBone != null) return out;
        if (o.isCamera() && !o.path.isEmpty()) {
            for (int i = 0; i < o.path.size(); i++) {
                SceneObject.PathPoint p = o.path.get(i);
                out.add(new Pt(3, o.id, 0, i, p.x, p.y, p.z));
            }
            return out;
        }
        List<Double> times = keyTimes(o);
        if (times.size() < 1) return out;
        for (double t : times) {
            double[] p = pos(s, o, t);
            out.add(new Pt(0, o.id, t, 0, p[0], p[1], p[2]));
        }
        if (selected != null && selected.kind() == 0 && selected.obj().equals(o.id) && editable(o)) {
            double t = selected.t();
            double[] p = pos(s, o, t);
            double[] r = handle(o, t, true), l = handle(o, t, false);
            if (r != null) out.add(new Pt(1, o.id, t, 0, p[0] + r[0], p[1] + r[1], p[2] + r[2]));
            if (l != null) out.add(new Pt(2, o.id, t, 0, p[0] + l[0], p[1] + l[1], p[2] + l[2]));
        }
        return out;
    }

    /** Часи, де є ключ хоч у одному з X/Y/Z. */
    private static List<Double> keyTimes(SceneObject o) {
        List<Double> t = new ArrayList<>();
        for (String ch : new String[] { Channels.X, Channels.Y, Channels.Z }) {
            KeyChannel k = o.channels.get(ch);
            if (k == null) continue;
            for (KeyChannel.Key key : k.keys()) {
                boolean dup = false;
                for (double x : t) if (Math.abs(x - key.t) < 1e-4) { dup = true; break; }
                if (!dup) t.add(key.t);
            }
        }
        t.sort(Double::compare);
        return t;
    }

    private static double[] pos(SceneEditorScreen s, SceneObject o, double t) {
        double[] xf = s.evaluator.transform(o, t, new double[7], 0);
        return new double[] { xf[0], xf[1], xf[2] };
    }

    /** Ручка Безьє в момент t як 3D-зсув (null — нема ключа/ручки). */
    private static double[] handle(SceneObject o, double t, boolean right) {
        double[] d = new double[3];
        boolean any = false;
        String[] chs = { Channels.X, Channels.Y, Channels.Z };
        for (int i = 0; i < 3; i++) {
            KeyChannel k = o.channels.get(chs[i]);
            KeyChannel.Key key = k == null ? null : k.keyAt(t, 1e-4);
            if (key == null || key.interp != KeyChannel.Interp.BEZIER && right) continue;
            d[i] = right ? key.rv : key.lv;
            any = true;
        }
        if (!any) return null;
        return d;
    }

    // ═════════════════════════ GUI ═════════════════════════

    static void drawGui(SceneEditorScreen s, Gui gui) {
        if (!s.showGizmos || s.previewing) return;
        List<Pt> pts = points(s);
        if (pts.isEmpty()) { hover = null; return; }
        if (drag == null) hover = s.inViewport(gui.mx, gui.my) ? nearest(pts, gui.mx, gui.my, 7) : null;
        SceneObject o = s.selected();
        boolean canEdit = editable(o) || o != null && o.isCamera() && !o.path.isEmpty();
        // лінії ручок
        double[] keyScreen = null;
        for (Pt p : pts) if (p.kind() == 0 && selected != null && selected.kind() == 0 && Math.abs(p.t() - selected.t()) < 1e-4) keyScreen = EditorView.project(p.x(), p.y(), p.z());
        for (Pt p : pts) {
            double[] sc = EditorView.project(p.x(), p.y(), p.z());
            if (sc == null) continue;
            if ((p.kind() == 1 || p.kind() == 2) && keyScreen != null) line(gui, keyScreen[0], keyScreen[1], sc[0], sc[1], p.kind() == 1 ? 0xCCF2B84B : 0xCC9DB1D6);
        }
        for (Pt p : pts) {
            double[] sc = EditorView.project(p.x(), p.y(), p.z());
            if (sc == null || !s.inViewport(sc[0], sc[1])) continue;
            int x = (int) Math.round(sc[0]), y = (int) Math.round(sc[1]);
            boolean sel = same(p, selected), hot = same(p, hover) || same(p, drag);
            int r = p.kind() == 0 || p.kind() == 3 ? 3 : 2;
            int fill = p.kind() == 1 ? 0xFFF2B84B : p.kind() == 2 ? 0xFF9DB1D6 : sel ? 0xFFFFD45A : p.kind() == 3 ? 0xFFFFFFFF : 0xFFE5A23C;
            gui.g.fill(x - r - 1, y - r - 1, x + r + 2, y + r + 2, hot ? 0xFFFFFFFF : 0xFF000000);
            gui.g.fill(x - r, y - r, x + r + 1, y + r + 1, fill);
        }
        if (hover != null && drag == null) {
            gui.cursor(Gui.CUR_HAND);
            String what = switch (hover.kind()) {
                case 0 -> "Ключ руху " + s.fmtTime(hover.t()) + "\nТягни — пересунути точку кривої; клік — ручки Безьє";
                case 1, 2 -> "Ручка Безьє\nТягни — вигнути криву (Alt — зламати ручку)";
                default -> "Точка шляху камери #" + (hover.index() + 1) + "\nТягни — пересунути";
            };
            gui.tip(Component.literal(what + (canEdit ? "\nAlt — лише висота · Ctrl — без сітки · Delete — прибрати" : "\n(об'єкт з батьком/орбітою — редагуйте ключі в таймлайні)")));
        }
    }

    private static void line(Gui gui, double x0, double y0, double x1, double y1, int col) {
        int n = (int) Math.max(1, Math.hypot(x1 - x0, y1 - y0) / 2);
        for (int i = 0; i <= n; i++) {
            int x = (int) Math.round(x0 + (x1 - x0) * i / n), y = (int) Math.round(y0 + (y1 - y0) * i / n);
            gui.g.fill(x, y, x + 1, y + 1, col);
        }
    }

    private static boolean same(Pt a, Pt b) {
        return a != null && b != null && a.kind() == b.kind() && a.obj().equals(b.obj()) && Math.abs(a.t() - b.t()) < 1e-4 && a.index() == b.index();
    }

    private static Pt nearest(List<Pt> pts, double mx, double my, double maxD) {
        Pt best = null;
        double bd = maxD * maxD;
        // ручки над ключами (вони дрібніші й лежать поруч)
        for (int pass = 0; pass < 2; pass++) {
            for (Pt p : pts) {
                if ((pass == 0) != (p.kind() == 1 || p.kind() == 2)) continue;
                double[] sc = EditorView.project(p.x(), p.y(), p.z());
                if (sc == null) continue;
                double d = (sc[0] - mx) * (sc[0] - mx) + (sc[1] - my) * (sc[1] - my);
                if (d < bd) { bd = d; best = p; }
            }
            if (best != null) return best;
        }
        return null;
    }

    // ═════════════════════════ миша ═════════════════════════

    /** @return true — клік забрала крива */
    static boolean press(SceneEditorScreen s, double mx, double my, boolean ctrl) {
        if (!s.showGizmos || s.readOnly) return false;
        SceneObject o = s.selected();
        if (o == null) return false;
        List<Pt> pts = points(s);
        Pt p = nearest(pts, mx, my, 7);
        if (p == null) {
            if (ctrl) return insert(s, o, mx, my);
            return false;
        }
        boolean pathPt = p.kind() == 3;
        if (!pathPt && !editable(o)) { selected = p; return true; }
        if (p.kind() == 0) selected = p;
        drag = p;
        Vec3 pt = new Vec3(p.x(), p.y(), p.z());
        SceneFrame.Cam e = s.editorCamera();
        planeP = pt;
        planeN = Vec3.directionFromRotation(e.pitch, e.yaw);
        double[] hit = planeHit(mx, my);
        grab = hit == null ? new double[3] : new double[] { p.x() - hit[0], p.y() - hit[1], p.z() - hit[2] };
        start = new double[] { p.x(), p.y(), p.z() };
        s.begin(pathPt ? "Точка шляху" : p.kind() == 0 ? "Точка кривої" : "Ручка кривої");
        if (p.kind() == 0) for (String ch : new String[] { Channels.X, Channels.Y, Channels.Z }) {
            KeyChannel k = o.channels.getOrCreate(ch);
            if (k.keyAt(p.t(), 1e-4) == null) k.set(p.t(), k.isEmpty() ? s.value(o, ch) : k.sample(p.t()), 1e-4);
        }
        return true;
    }

    static void drag(SceneEditorScreen s, double mx, double my) {
        if (drag == null) return;
        SceneObject o = s.variant().object(drag.obj());
        if (o == null) { drag = null; return; }
        double[] target;
        if (Screen.hasAltDown() && drag.kind() != 1 && drag.kind() != 2) {
            double[] r = EditorView.ray(mx, my);
            if (r == null) return;
            target = new double[] { start[0], start[1] + verticalParam(r, start), start[2] };
        } else {
            double[] hit = planeHit(mx, my);
            if (hit == null) return;
            target = new double[] { hit[0] + grab[0], hit[1] + grab[1], hit[2] + grab[2] };
        }
        if (!Screen.hasControlDown()) for (int i = 0; i < 3; i++) target[i] = Math.round(target[i] / SNAP) * SNAP;
        double dx = target[0] - start[0], dy = target[1] - start[1], dz = target[2] - start[2];
        String[] chs = { Channels.X, Channels.Y, Channels.Z };
        switch (drag.kind()) {
            case 0 -> {
                double[] d = { dx, dy, dz };
                double[] base = { start[0], start[1], start[2] };
                for (int i = 0; i < 3; i++) {
                    KeyChannel k = o.channels.getOrCreate(chs[i]);
                    KeyChannel.Key key = k.keyAt(drag.t(), 1e-4);
                    if (key == null) key = k.set(drag.t(), base[i], 1e-4);
                    key.v = base[i] + d[i];
                    k.recalcHandles();
                }
                selected = new Pt(0, o.id, drag.t(), 0, target[0], target[1], target[2]);
            }
            case 1, 2 -> {
                boolean right = drag.kind() == 1;
                double[] key = pos(s, o, drag.t());
                double[] off = { target[0] - key[0], target[1] - key[1], target[2] - key[2] };
                for (int i = 0; i < 3; i++) {
                    KeyChannel k = o.channels.getOrCreate(chs[i]);
                    KeyChannel.Key kk = k.keyAt(drag.t(), 1e-4);
                    if (kk == null) kk = k.set(drag.t(), key[i], 1e-4);
                    kk.interp = KeyChannel.Interp.BEZIER;
                    boolean free = Screen.hasAltDown();
                    kk.handle = free ? KeyChannel.HandleMode.FREE : KeyChannel.HandleMode.ALIGNED;
                    if (right) {
                        if (kk.rt <= 1e-6) kk.rt = 0.1;
                        kk.rv = off[i];
                        if (!free) kk.lv = -off[i] * (Math.abs(kk.lt) / kk.rt);
                    } else {
                        if (kk.lt >= -1e-6) kk.lt = -0.1;
                        kk.lv = off[i];
                        if (!free) kk.rv = -off[i] * (kk.rt / Math.abs(kk.lt));
                    }
                }
            }
            case 3 -> {
                if (drag.index() < o.path.size()) {
                    SceneObject.PathPoint pp = o.path.get(drag.index());
                    pp.x = target[0]; pp.y = target[1]; pp.z = target[2];
                }
            }
            default -> { }
        }
    }

    static boolean release(SceneEditorScreen s) {
        if (drag == null) return false;
        drag = null;
        s.commit();
        return true;
    }

    /** Delete з вибраною точкою кривої. @return чи забрали */
    static boolean delete(SceneEditorScreen s) {
        if (selected == null || s.readOnly) return false;
        SceneObject o = s.variant().object(selected.obj());
        if (o == null || !o.id.equals(s.selObj)) { selected = null; return false; }
        Pt p = selected;
        selected = null;
        if (p.kind() == 3) {
            if (p.index() < o.path.size()) s.edit("Прибрати точку шляху", () -> o.path.remove(p.index()));
            return true;
        }
        if (p.kind() != 0) return false;
        s.edit("Прибрати ключ руху", () -> {
            for (String ch : new String[] { Channels.X, Channels.Y, Channels.Z }) {
                KeyChannel k = o.channels.get(ch);
                if (k == null) continue;
                KeyChannel.Key key = k.keyAt(p.t(), 1e-4);
                if (key != null) k.remove(key);
            }
        });
        return true;
    }

    /** Ctrl+клік по кривій — нова точка (ключ X/Y/Z у тому місці або точка шляху). */
    private static boolean insert(SceneEditorScreen s, SceneObject o, double mx, double my) {
        if (o.isCamera() && !o.path.isEmpty()) {
            // найближчий відрізок між точками шляху (по екранній відстані)
            int best = -1;
            double bd = 10;
            for (int i = 0; i + 1 < o.path.size(); i++) {
                SceneObject.PathPoint a = o.path.get(i), b = o.path.get(i + 1);
                double[] pa = EditorView.project(a.x, a.y, a.z), pb = EditorView.project(b.x, b.y, b.z);
                if (pa == null || pb == null) continue;
                double d = segDist(mx, my, pa[0], pa[1], pb[0], pb[1]);
                if (d < bd) { bd = d; best = i; }
            }
            if (best < 0) return false;
            int at = best;
            SceneObject.PathPoint a = o.path.get(at), b = o.path.get(at + 1);
            SceneObject.PathPoint m = new SceneObject.PathPoint((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2,
                (a.yaw + b.yaw) / 2, (a.pitch + b.pitch) / 2, (a.roll + b.roll) / 2, (a.fov + b.fov) / 2);
            s.edit("Точка шляху", () -> o.path.add(at + 1, m));
            selected = new Pt(3, o.id, 0, at + 1, m.x, m.y, m.z);
            return true;
        }
        if (!editable(o) || keyTimes(o).isEmpty()) return false;
        double len = s.length(), step = Math.max(1 / 40.0, len / 400);
        double bestT = -1, bd = 10 * 10;
        for (double t = 0; t <= len + 1e-6; t += step) {
            double[] p = pos(s, o, t);
            double[] sc = EditorView.project(p[0], p[1], p[2]);
            if (sc == null) continue;
            double d = (sc[0] - mx) * (sc[0] - mx) + (sc[1] - my) * (sc[1] - my);
            if (d < bd) { bd = d; bestT = t; }
        }
        if (bestT < 0) return false;
        double t = Math.round(bestT * s.fps()) / s.fps();
        s.edit("Точка кривої", () -> {
            for (String ch : new String[] { Channels.X, Channels.Y, Channels.Z }) {
                KeyChannel k = o.channels.getOrCreate(ch);
                k.set(t, k.isEmpty() ? s.value(o, ch) : k.sample(t), 1e-4);
            }
        });
        double[] p = pos(s, o, t);
        selected = new Pt(0, o.id, t, 0, p[0], p[1], p[2]);
        s.seek(t);
        return true;
    }

    // ═════════════════════════ математика ═════════════════════════

    private static double[] planeHit(double mx, double my) {
        double[] r = EditorView.ray(mx, my);
        if (r == null || planeP == null) return null;
        Vec3 o = new Vec3(r[0], r[1], r[2]), d = new Vec3(r[3], r[4], r[5]);
        double den = d.dot(planeN);
        if (Math.abs(den) < 1e-6) return null;
        double t = planeP.subtract(o).dot(planeN) / den;
        if (t < 0) return null;
        Vec3 h = o.add(d.scale(t));
        return new double[] { h.x, h.y, h.z };
    }

    /** Зсув по вертикалі через точку p, найближчий до променя миші. */
    private static double verticalParam(double[] r, double[] p) {
        Vec3 o = new Vec3(r[0], r[1], r[2]), d = new Vec3(r[3], r[4], r[5]), a = new Vec3(0, 1, 0);
        Vec3 w = new Vec3(p[0], p[1], p[2]).subtract(o);
        double b = a.dot(d), dd = a.dot(w), e = d.dot(w), den = 1 - b * b;
        if (Math.abs(den) < 1e-6) return 0;
        return (b * e - dd) / den;
    }

    private static double segDist(double px, double py, double ax, double ay, double bx, double by) {
        double dx = bx - ax, dy = by - ay, l = dx * dx + dy * dy;
        double t = l < 1e-9 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l));
        double cx = ax + dx * t - px, cy = ay + dy * t - py;
        return Math.sqrt(cx * cx + cy * cy);
    }
}
