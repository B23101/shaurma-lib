package dev.shaurmalib.scene.mc.client.menu;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexBuffer;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

/**
 * {@link MultiBufferSource}, що НЕ малює, а збирає вершини акторів, блок-сутностей і сутностей світу (формат
 * NEW_ENTITY) у власні VBO разом з текстурою кожного RenderType. Один раз за кадр — потім ті самі буфери
 * малюються і в карти тіней, і в кадр (без повторного обходу моделей). Інші формати (лінії, частинки) ігноруються.
 */
final class CaptureBuffers implements MultiBufferSource {

    /** Готовий до малювання шматок. */
    static final class Draw {
        VertexBuffer vb;
        int texture;
        boolean translucent, emissive;
    }

    private final Map<RenderType, BufferBuilder> building = new IdentityHashMap<>();
    private final Map<RenderType, BufferBuilder> builders = new IdentityHashMap<>();
    private final List<VertexBuffer> pool = new ArrayList<>();
    final List<Draw> draws = new ArrayList<>();
    private int used;

    @Override
    public VertexConsumer getBuffer(RenderType type) {
        if (type.format() != DefaultVertexFormat.NEW_ENTITY) return Ignore.INSTANCE;
        BufferBuilder b = building.get(type);
        if (b != null) return b;
        b = builders.computeIfAbsent(type, t -> new BufferBuilder(1 << 16));
        b.begin(type.mode(), type.format());
        building.put(type, b);
        return b;
    }

    /** Почати новий кадр: старі VBO лишаються в пулі. */
    void reset() {
        for (BufferBuilder b : building.values()) if (b.building()) b.discard();
        building.clear();
        draws.clear();
        used = 0;
    }

    /** Закрити батчі: завантажити у VBO і запам'ятати текстуру кожного типу. */
    void finish() {
        for (Map.Entry<RenderType, BufferBuilder> e : building.entrySet()) {
            RenderType type = e.getKey();
            BufferBuilder.RenderedBuffer rb = e.getValue().endOrDiscardIfEmpty();
            if (rb == null) continue;
            String name = type.toString();
            if (name.contains("glint")) { rb.release(); continue; }   // відблиск зачарувань — окремий шейдер, пропускаємо
            VertexBuffer vb;
            if (used < pool.size()) vb = pool.get(used);
            else { vb = new VertexBuffer(VertexBuffer.Usage.DYNAMIC); pool.add(vb); }
            used++;
            vb.bind();
            vb.upload(rb);
            Draw d = new Draw();
            d.vb = vb;
            // текстуру ставить сам тип (TextureStateShard → RenderSystem.setShaderTexture(0, …))
            type.setupRenderState();
            d.texture = RenderSystem.getShaderTexture(0);
            type.clearRenderState();
            d.emissive = name.contains("eyes") || name.contains("energy_swirl");
            d.translucent = d.emissive || name.contains("translucent");
            draws.add(d);
        }
        building.clear();
        VertexBuffer.unbind();
    }

    void close() {
        reset();
        for (VertexBuffer vb : pool) vb.close();
        pool.clear();
    }

    /** Поглинач вершин для непотрібних форматів. */
    private static final class Ignore implements VertexConsumer {
        static final Ignore INSTANCE = new Ignore();
        @Override public VertexConsumer vertex(double x, double y, double z) { return this; }
        @Override public VertexConsumer color(int r, int g, int b, int a) { return this; }
        @Override public VertexConsumer uv(float u, float v) { return this; }
        @Override public VertexConsumer overlayCoords(int u, int v) { return this; }
        @Override public VertexConsumer uv2(int u, int v) { return this; }
        @Override public VertexConsumer normal(float x, float y, float z) { return this; }
        @Override public void endVertex() { }
        @Override public void defaultColor(int r, int g, int b, int a) { }
        @Override public void unsetDefaultColor() { }
    }
}
