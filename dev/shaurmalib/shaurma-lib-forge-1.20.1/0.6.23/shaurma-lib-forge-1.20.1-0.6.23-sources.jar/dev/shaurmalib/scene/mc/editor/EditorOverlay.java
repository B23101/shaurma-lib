package dev.shaurmalib.scene.mc.editor;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.phys.Vec3;

/**
 * Що редактор малює поверх світу: каркаси камер (активна — жовта), шляхи камер (сплайн і точки),
 * траєкторії вибраного об'єкта за ключами, осі вибраного, пунктир схованих акторів, підписи й вибір кліком.
 */
public final class EditorOverlay {

    private EditorOverlay() {}

    /** З кадру світу (після сутностей). */
    public static void world(PoseStack ps, MultiBufferSource buffers, Vec3 cam) {
        if (!(Minecraft.getInstance().screen instanceof SceneEditorScreen s) || !s.showGizmos || s.previewing) return;
        VertexConsumer vc = EditorView.lines(buffers);
        PoseStack.Pose p = ps.last();
        double t = s.time;
        for (SceneObject o : s.variant().objects) {
            if (o.editorHidden) continue;
            boolean sel = o.id.equals(s.selObj);
            int col = 0xFF000000 | o.color;
            if (o.isCamera()) {
                if (s.view.cameraView && o.id.equals(s.frame.cameraId)) continue;
                SceneFrame.Cam c = s.evaluator.cameraOf(o, t, null, new SceneFrame.Cam());
                boolean live = o.id.equals(s.frame.cameraId);
                EditorView.cameraGizmo(vc, p, cam, c, sel ? 0xFFFFFFFF : live ? 0xFFF2B84B : 0xAA8FA6CC, 0.6);
                if (!o.path.isEmpty()) path(vc, p, cam, s, o, sel);
                if (sel || live) trajectory(vc, p, cam, s, o);
            } else if (o.isLight()) {
                light(vc, p, cam, s, o, sel);
                if (sel) trajectory(vc, p, cam, s, o);
            } else if (o.kind == SceneObject.Kind.EMPTY) {
                double[] xf = s.evaluator.transform(o, t, new double[7], 0);
                double r = 0.25;
                EditorView.line(vc, p, cam, xf[0] - r, xf[1], xf[2], xf[0] + r, xf[1], xf[2], col);
                EditorView.line(vc, p, cam, xf[0], xf[1] - r, xf[2], xf[0], xf[1] + r, xf[2], col);
                EditorView.line(vc, p, cam, xf[0], xf[1], xf[2] - r, xf[0], xf[1], xf[2] + r, col);
            } else {
                SceneFrame.Actor a = s.frame.actor(o.id);
                if (a == null) continue;
                if (!a.visible) EditorView.dashedBox(vc, p, cam, a.x, a.y, a.z, 0.35 * a.scale, 1.85 * a.scale, 0xCC9DB1D6);
                if (sel) trajectory(vc, p, cam, s, o);
            }
            if (ViewportTools.multi.contains(o.id) && !sel) axes(vc, p, cam, s.evaluator.transform(o, t, new double[7], 0));
        }
        ViewportTools.drawWorld(s, ps, buffers, cam);
    }

    /**
     * Світло: зірка в кольорі світла; точкове — кільця дальності; прожектор — конус до межі дальності;
     * сонце — пучок паралельних стрілок униз за напрямом.
     */
    private static void light(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, SceneEditorScreen s, SceneObject o, boolean sel) {
        var l = s.evaluator.light(o, s.time);
        int rgb = Properties.lightColorAt(o, s.time);
        int col = (sel ? 0xFF000000 : 0xCC000000) | rgb;
        double r = 0.22;
        for (int i = 0; i < 4; i++) {
            double a = i * Math.PI / 4;
            double cx = Math.cos(a) * r, sz = Math.sin(a) * r;
            EditorView.line(vc, p, cam, l.x - cx, l.y - sz, l.z, l.x + cx, l.y + sz, l.z, col);
            EditorView.line(vc, p, cam, l.x - cx, l.y, l.z - sz, l.x + cx, l.y, l.z + sz, col);
        }
        int faint = (sel ? 0x99000000 : 0x44000000) | rgb;
        switch (l.type) {
            case POINT -> {
                if (!sel) break;
                for (int axis = 0; axis < 3; axis++) circle(vc, p, cam, l.x, l.y, l.z, l.range, axis, faint);
            }
            case SPOT -> {
                double len = Math.min(l.range, 12), half = Math.toRadians(l.spotAngle / 2), rad = Math.tan(half) * len;
                Vec3 d = new Vec3(l.dx, l.dy, l.dz).normalize();
                Vec3 u = Math.abs(d.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
                Vec3 a = d.cross(u).normalize(), b = d.cross(a).normalize();
                Vec3 c0 = new Vec3(l.x, l.y, l.z), end = c0.add(d.scale(len));
                Vec3 prev = null;
                for (int i = 0; i <= 24; i++) {
                    double ang = i * Math.PI * 2 / 24;
                    Vec3 q = end.add(a.scale(Math.cos(ang) * rad)).add(b.scale(Math.sin(ang) * rad));
                    if (prev != null) EditorView.line(vc, p, cam, prev.x, prev.y, prev.z, q.x, q.y, q.z, faint);
                    if (i % 6 == 0) EditorView.line(vc, p, cam, c0.x, c0.y, c0.z, q.x, q.y, q.z, faint);
                    prev = q;
                }
            }
            case SUN -> {
                Vec3 d = new Vec3(l.dx, l.dy, l.dz).normalize();
                Vec3 u = Math.abs(d.y) > 0.95 ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0);
                Vec3 a = d.cross(u).normalize(), b = d.cross(a).normalize();
                for (int i = -1; i <= 1; i++) for (int j = -1; j <= 1; j++) {
                    if (i != 0 && j != 0) continue;
                    Vec3 st = new Vec3(l.x, l.y, l.z).add(a.scale(i * 0.6)).add(b.scale(j * 0.6)), en = st.add(d.scale(2.2));
                    EditorView.line(vc, p, cam, st.x, st.y, st.z, en.x, en.y, en.z, col);
                    Vec3 h1 = en.subtract(d.scale(0.35)).add(a.scale(0.15)), h2 = en.subtract(d.scale(0.35)).subtract(a.scale(0.15));
                    EditorView.line(vc, p, cam, en.x, en.y, en.z, h1.x, h1.y, h1.z, col);
                    EditorView.line(vc, p, cam, en.x, en.y, en.z, h2.x, h2.y, h2.z, col);
                }
            }
        }
    }

    private static void circle(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, double x, double y, double z, double r, int axis, int col) {
        double px = 0, py = 0, pz = 0;
        for (int i = 0; i <= 40; i++) {
            double a = i * Math.PI * 2 / 40, cs = Math.cos(a) * r, sn = Math.sin(a) * r;
            double qx = x + (axis == 0 ? 0 : cs), qy = y + (axis == 0 ? cs : axis == 1 ? 0 : sn), qz = z + (axis == 0 ? sn : axis == 1 ? sn : 0);
            if (i > 0) EditorView.line(vc, p, cam, px, py, pz, qx, qy, qz, col);
            px = qx; py = qy; pz = qz;
        }
    }

    private static void axes(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, double[] xf) {
        double l = 0.8;
        EditorView.line(vc, p, cam, xf[0], xf[1], xf[2], xf[0] + l, xf[1], xf[2], Theme.AXIS_X);
        EditorView.line(vc, p, cam, xf[0], xf[1], xf[2], xf[0], xf[1] + l, xf[2], Theme.AXIS_Y);
        EditorView.line(vc, p, cam, xf[0], xf[1], xf[2], xf[0], xf[1], xf[2] + l, Theme.AXIS_Z);
    }

    /** Траєкторія руху за ключами (як Motion Paths у Blender) з точками на ключах. */
    private static void trajectory(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, SceneEditorScreen s, SceneObject o) {
        if (!o.channels.has("x") && !o.channels.has("y") && !o.channels.has("z") && o.path.isEmpty()) return;
        double len = s.length();
        double step = Math.max(1 / 20.0, len / 240);
        double[] prev = null;
        for (double t = 0; t <= len + 1e-6; t += step) {
            double[] xf = o.isCamera() ? camPos(s, o, t) : s.evaluator.transform(o, t, new double[7], 0);
            if (prev != null) EditorView.line(vc, p, cam, prev[0], prev[1], prev[2], xf[0], xf[1], xf[2], 0x88FFFFFF);
            prev = xf;
        }
        var kx = o.channels.get("x");
        if (kx != null) for (var k : kx.keys()) {
            double[] xf = o.isCamera() ? camPos(s, o, k.t) : s.evaluator.transform(o, k.t, new double[7], 0);
            double r = 0.08;
            EditorView.line(vc, p, cam, xf[0] - r, xf[1], xf[2], xf[0] + r, xf[1], xf[2], 0xFFF2B84B);
            EditorView.line(vc, p, cam, xf[0], xf[1] - r, xf[2], xf[0], xf[1] + r, xf[2], 0xFFF2B84B);
        }
    }

    private static double[] camPos(SceneEditorScreen s, SceneObject o, double t) {
        SceneFrame.Cam c = s.evaluator.cameraOf(o, t, null, new SceneFrame.Cam());
        return new double[] { c.x, c.y, c.z };
    }

    private static void path(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, SceneEditorScreen s, SceneObject o, boolean sel) {
        SceneFrame.Cam a = new SceneFrame.Cam(), b = new SceneFrame.Cam();
        boolean keyed = o.channels.has("path");
        // сплайн малюємо по параметру шляху незалежно від ключів: тимчасовий об'єкт з path = f
        SceneObject probe = new SceneObject(o.id, o.name, o.kind);
        probe.path.addAll(o.path);
        probe.pathOrient = o.pathOrient;
        probe.breath = 0;
        for (int i = 0; i <= 64; i++) {
            probe.channels.getOrCreate("path").keys().clear();
            probe.channels.getOrCreate("path").set(0, i / 64.0);
            s.evaluator.cameraOf(probe, 0, null, b);
            if (i > 0) EditorView.line(vc, p, cam, a.x, a.y, a.z, b.x, b.y, b.z, sel ? 0xFFF2B84B : 0x99F2B84B);
            a.set(b);
        }
        for (SceneObject.PathPoint pt : o.path) {
            double r = 0.12;
            EditorView.line(vc, p, cam, pt.x - r, pt.y, pt.z, pt.x + r, pt.y, pt.z, 0xFFFFFFFF);
            EditorView.line(vc, p, cam, pt.x, pt.y - r, pt.z, pt.x, pt.y + r, pt.z, 0xFFFFFFFF);
            EditorView.line(vc, p, cam, pt.x, pt.y, pt.z - r, pt.x, pt.y, pt.z + r, 0xFFFFFFFF);
        }
        if (!keyed) return;
    }

    // ═════════════════════════ GUI ═════════════════════════

    /** Підписи об'єктів у в'юпорті. */
    static void labels(SceneEditorScreen s, GuiGraphics g) {
        if (!s.showGizmos || (s.view.cameraView && s.frame.hasCamera)) return;
        var font = Minecraft.getInstance().font;
        for (SceneObject o : s.variant().objects) {
            if (o.editorHidden) continue;
            double[] w = anchor(s, o);
            double[] sc = EditorView.project(w[0], w[1], w[2]);
            if (sc == null || !s.inViewport(sc[0], sc[1])) continue;
            boolean sel = o.id.equals(s.selObj);
            String label = o.name + (o.slot != null ? "  ⟨" + o.slot + (o.slotIndex > 0 ? "#" + o.slotIndex : "") + "⟩" : "");
            int tw = font.width(label);
            int x = (int) sc[0] - tw / 2, y = (int) sc[1] - 12;
            g.fill(x - 3, y - 2, x + tw + 3, y + 10, sel ? 0xDD2C66B8 : 0x99000000);
            g.drawString(font, label, x, y, sel ? 0xFFFFFFFF : 0xFF000000 | o.color, false);
        }
    }

    private static double[] anchor(SceneEditorScreen s, SceneObject o) {
        if (o.isCamera()) {
            SceneFrame.Cam c = s.evaluator.cameraOf(o, s.time, null, new SceneFrame.Cam());
            return new double[] { c.x, c.y + 0.35, c.z };
        }
        double[] xf = s.evaluator.transform(o, s.time, new double[7], 0);
        double h = o.kind == SceneObject.Kind.ACTOR ? 2.1 * xf[6] : 0.4;
        return new double[] { xf[0], xf[1] + h, xf[2] };
    }

    /** Найближчий об'єкт до точки кліку (до 18 px від його проєкції на рівні тіла/камери). */
    static String pick(SceneEditorScreen s, double gx, double gy) {
        String best = null;
        double bd = 18 * 18;
        for (SceneObject o : s.variant().objects) {
            if (o.editorHidden || o.locked) continue;
            double[] xf = o.isCamera() ? camPos(s, o, s.time) : s.evaluator.transform(o, s.time, new double[7], 0);
            int samples = o.kind == SceneObject.Kind.ACTOR ? 4 : 1;
            for (int i = 0; i < samples; i++) {
                double[] sc = EditorView.project(xf[0], xf[1] + i * 0.55 * (o.kind == SceneObject.Kind.ACTOR ? xf.length > 6 ? xf[6] : 1 : 0), xf[2]);
                if (sc == null) continue;
                double d = (sc[0] - gx) * (sc[0] - gx) + (sc[1] - gy) * (sc[1] - gy);
                if (d < bd) { bd = d; best = o.id; }
            }
        }
        return best;
    }
}
