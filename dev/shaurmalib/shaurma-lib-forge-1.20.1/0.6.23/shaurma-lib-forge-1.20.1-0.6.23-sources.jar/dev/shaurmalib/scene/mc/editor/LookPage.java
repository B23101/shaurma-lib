package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.doc.MenuFrame;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneLook;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.edit.LoopTools;
import dev.shaurmalib.scene.edit.MenuChecks;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.Icons;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.network.chat.Component;

import java.util.List;

/**
 * Сторінка «Колір» (як Color у DaVinci): замість доріжок — три колонки, кожна зі своєю прокруткою:
 * <b>Середовище</b> (небо, світло неба й ламп світу, заповнення, туман), <b>Корекція</b> (тонмапінг, експозиція,
 * баланс білого, контраст, lift/gamma/gain, спліт-тонування, bloom, віньєтка, зерно, якість) і
 * <b>Меню й цикл</b> (формат кадру, збільшення під курсором, безпечні зони, межі сцени, безшовний цикл і чек-лист
 * вимог режиму з кнопками «Виправити»). В'юпорт над нею лишається світом (ставити світло), а живе превʼю
 * віконця меню висить у ньому ({@link MenuPreview}). Параметри з ◆ анімуються ключами.
 */
final class LookPage {

    private LookPage() {}

    private static final String[] SKY = { "Небо світу", "Градієнт", "Колір", "Прозоре (меню під сценою)" };
    private static final String[] TONEMAP = { "Без (ваніль)", "ACES (кіно)", "Filmic (м'яко)", "AgX (нейтрально)" };
    private static final String[] QUALITY = { "Авто", "Низька", "Середня", "Висока", "Ультра" };

    private static List<MenuChecks.Check> checks = List.of();
    private static long checkedAt;
    private static Object checkedFor;

    /** Вузький екран (GUI ×4 на 1080p): одна колонка з вкладками замість трьох. */
    static int tab;
    private static final String[] TABS = { "Середовище", "Корекція", "Меню й цикл" };
    private static final Icon[] TAB_ICONS = { Icon.LIGHT, Icon.PALETTE, Icon.BUTTON };

    static void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        gui.g.fill(x, y, x + w, y + h, MenuSkin.PANE);
        gui.g.fill(x, y, x + w, y + 1, MenuSkin.OUTLINE);
        int gap = 4, cw = (w - gap * 4) / 3;
        if (cw < 170) {
            int tw = (w - 8) / 3;
            for (int i = 0; i < 3; i++) {
                int tx = x + 4 + i * tw;
                boolean on = tab == i, hov = gui.hover(tx, y + 3, tw - 2, 14);
                gui.g.fill(tx, y + 3, tx + tw - 2, y + 17, on ? 0xFF2A3A62 : hov ? 0xFF1E2842 : 0xFF141B2C);
                Icons.draw(gui.g, TAB_ICONS[i], tx + 3, y + 5, 10, on ? Theme.ACCENT : Theme.MUTED);
                gui.textClip(TABS[i], tx + 16, y + 6, tw - 20, on ? Theme.TEXT : Theme.MUTED);
                if (gui.clicked(tx, y + 3, tw - 2, 14, 0)) tab = i;
            }
            Body[] bodies = { LookPage::environment, LookPage::grading, LookPage::menu };
            String[] ids = { "look.env", "look.grade", "look.menu" };
            int off = gui.scrollBegin(ids[tab], x + 4, y + 19, w - 8, h - 21, 1400);
            int[] cy = { y + 19 - off + 2 };
            bodies[tab].draw(new Properties.Ctx(s, gui, x + 8, w - 16, cy));
            gui.scrollEnd();
            return;
        }
        int cx = x + gap;
        column(s, gui, "Середовище", Icon.LIGHT, "look.env", cx, y + 3, cw, h - 6, LookPage::environment);
        cx += cw + gap;
        column(s, gui, "Корекція", Icon.PALETTE, "look.grade", cx, y + 3, cw, h - 6, LookPage::grading);
        cx += cw + gap;
        column(s, gui, "Меню й цикл", Icon.BUTTON, "look.menu", cx, y + 3, w - (cx - x) - gap, h - 6, LookPage::menu);
    }

    private interface Body { void draw(Properties.Ctx c); }

    private static void column(SceneEditorScreen s, Gui gui, String title, Icon icon, String id, int x, int y, int w, int h, Body body) {
        gui.g.fill(x, y, x + w, y + h, 0xFF121826);
        gui.g.fill(x, y, x + w, y + 14, 0xFF1A2236);
        Icons.draw(gui.g, icon, x + 4, y + 2, 10, Theme.ACCENT);
        gui.text(title, x + 17, y + 3, Theme.TEXT);
        int off = gui.scrollBegin(id, x, y + 15, w, h - 15, 1200);
        int[] cy = { y + 15 - off + 2 };
        body.draw(new Properties.Ctx(s, gui, x + 4, w - 8, cy));
        gui.scrollEnd();
    }

    // ═════════════════════════ середовище ═════════════════════════

    private static void environment(Properties.Ctx c) {
        SceneEditorScreen s = c.s();
        SceneLook l = s.variant().look;
        int p = Properties.cycle(c, "Пресет", SceneLook.PRESETS, -1, "Готовий вигляд: небо, світло, корекція (ключі лишаються)");
        if (p >= 0) s.edit("Пресет вигляду", () -> l.preset(SceneLook.PRESETS[p]));
        Properties.header(c, "Небо");
        int sk = Properties.cycle(c, "Тло", SKY, l.sky.ordinal(), "Що видно за світом сцени");
        if (sk >= 0) s.edit("Небо", () -> l.sky = SceneLook.Sky.values()[sk]);
        if (l.sky == SceneLook.Sky.GRADIENT || l.sky == SceneLook.Sky.COLOR)
            Properties.color(c, l.sky == SceneLook.Sky.COLOR ? "Колір" : "Зеніт", "look.top", l.skyTop, true, v -> l.skyTop = v);
        if (l.sky == SceneLook.Sky.GRADIENT) {
            Properties.color(c, "Горизонт", "look.hor", l.skyHorizon, true, v -> l.skyHorizon = v);
            Properties.color(c, "Земля", "look.gnd", l.ground, true, v -> l.ground = v);
        }
        keyed(c, "Яскравість", SceneLook.SKY_INTENSITY, 0.02, 0, 16);
        Properties.header(c, "Світло світу");
        Properties.color(c, "Небо", "look.skyl", l.skyLightColor, true, v -> l.skyLightColor = v);
        keyed(c, "  сила", SceneLook.SKY_LIGHT, 0.02, 0, 16);
        Properties.color(c, "Лампи", "look.blk", l.blockLightColor, true, v -> l.blockLightColor = v);
        keyed(c, "  сила", SceneLook.BLOCK_LIGHT, 0.02, 0, 16);
        Properties.color(c, "Заповн.", "look.amb", l.ambientColor, true, v -> l.ambientColor = v);
        keyed(c, "  сила", SceneLook.AMBIENT, 0.01, 0, 16);
        c.gui().textClip("факели без мерехтіння; світло сцени — об'єкти «Світло»", c.x(), c.next(12) + 1, c.w(), Theme.MUTED);
        if (c.gui().button(c.x(), c.next(16), c.w() / 3 - 1, 14, Component.literal("+ Сонце"), false, Component.literal("Сонце з тінями над сценою"), !s.readOnly))
            s.addLight(SceneObject.LightType.SUN);
        if (c.gui().button(c.x() + c.w() / 3, c.y()[0] - 16, c.w() / 3 - 1, 14, Component.literal("+ Прожектор"), false, Component.literal("Конус світла з тінями"), !s.readOnly))
            s.addLight(SceneObject.LightType.SPOT);
        if (c.gui().button(c.x() + 2 * c.w() / 3, c.y()[0] - 16, c.w() / 3, 14, Component.literal("+ Лампа"), false, Component.literal("Точкове кольорове світло"), !s.readOnly))
            s.addLight(SceneObject.LightType.POINT);
        Properties.header(c, "Туман і поверхні");
        keyed(c, "Туман до", SceneLook.FOG_END, 0.5, 0, 512);
        Properties.num(c, "Туман від", "look.fogs", l.fogStart, 0.5, Theme.ACCENT, v -> l.fogStart = (float) Math.max(0, v), null);
        Properties.color(c, "Колір", "look.fogc", l.fogColor < 0 ? l.skyHorizon : l.fogColor, l.fogColor >= 0, v -> l.fogColor = v);
        if (l.fogColor >= 0 && c.gui().button(c.x() + 46, c.next(15), c.w() - 46, 13, Component.literal("як горизонт"), false, null)) s.edit("Туман", () -> l.fogColor = -1);
        c.gui().textClip("0 — туман за радіусом сцени", c.x(), c.next(12) + 1, c.w(), Theme.MUTED);
        Properties.num(c, "Відблиски", "look.spec", l.specular, 0.02, Theme.ACCENT, v -> l.specular = (float) Math.max(0, Math.min(4, v)), null);
        if (Properties.check(c, "Об'єм від світла (без ванільних тіней граней)", l.unshade, "Ванільні затемнені боки блоків прибираються — форму дає світло сцени"))
            s.edit("Поверхні", () -> l.unshade = !l.unshade);
        Properties.header(c, "Авто-світло блоків");
        if (Properties.check(c, "Факели, ліхтарі, лава… світять самі", l.autoLights,
            "Кожен блок, що світиться, стає кольоровою лампою сцени (таблиця з IRL-editor). Без тіней — швидко"))
            s.edit("Авто-світло", () -> l.autoLights = !l.autoLights);
        if (l.autoLights) {
            if (Properties.check(c, "  лише відкриті (не закопані)", l.autoLightCulling, null)) s.edit("Авто-світло", () -> l.autoLightCulling = !l.autoLightCulling);
            Properties.num(c, "Сила", "look.ali", l.autoLightIntensity, 0.05, Theme.ACCENT, v -> l.autoLightIntensity = (float) Math.max(0, Math.min(16, v)), null);
            Properties.num(c, "Дальність", "look.alr", l.autoLightReach, 0.05, Theme.ACCENT, v -> l.autoLightReach = (float) Math.max(0.1, Math.min(8, v)), null);
            Properties.num(c, "Найбільше", "look.alm", l.autoLightMax, 1, Theme.ACCENT, v -> l.autoLightMax = (int) Math.max(0, Math.min(32, Math.round(v))), null);
        }
        if (Properties.check(c, "Живі сутності локації (NPC, стійки)", l.worldEntities, "Актори сцени є завжди; це — моби/стійки/рамки, що стоять на локації"))
            s.edit("Сутності", () -> l.worldEntities = !l.worldEntities);
    }

    // ═════════════════════════ корекція ═════════════════════════

    private static void grading(Properties.Ctx c) {
        SceneEditorScreen s = c.s();
        SceneLook l = s.variant().look;
        int tm = Properties.cycle(c, "Тонмап", TONEMAP, l.tonemap.ordinal(), "Як яскраве HDR стискається в екран");
        if (tm >= 0) s.edit("Тонмапінг", () -> l.tonemap = SceneLook.Tonemap.values()[tm]);
        keyed(c, "Експозиція", SceneLook.EXPOSURE, 0.05, -10, 10);
        keyed(c, "Контраст", SceneLook.CONTRAST, 0.02, 0, 4);
        keyed(c, "Насиченість", SceneLook.SATURATION, 0.02, 0, 4);
        Properties.header(c, "Баланс білого");
        keyed(c, "Темпер.", SceneLook.TEMPERATURE, 0.02, -1, 1);
        keyed(c, "Відтінок", SceneLook.TINT, 0.02, -1, 1);
        Properties.header(c, "Lift · Gamma · Gain");
        Properties.num(c, "Lift", "look.lift", l.lift, 0.01, Theme.ACCENT, v -> l.lift = (float) Math.max(-1, Math.min(1, v)), null);
        Properties.num(c, "Gamma", "look.gamma", l.gamma, 0.01, Theme.ACCENT, v -> l.gamma = (float) Math.max(0.1, Math.min(4, v)), null);
        Properties.num(c, "Gain", "look.gain", l.gain, 0.01, Theme.ACCENT, v -> l.gain = (float) Math.max(0, Math.min(4, v)), null);
        Properties.header(c, "Спліт-тонування");
        Properties.color(c, "Тіні", "look.splits", l.splitShadows, true, v -> l.splitShadows = v);
        Properties.color(c, "Світлі", "look.splith", l.splitHighlights, true, v -> l.splitHighlights = v);
        Properties.num(c, "Сила", "look.splita", l.splitAmount, 0.01, Theme.ACCENT, v -> l.splitAmount = (float) Math.max(0, Math.min(1, v)), null);
        Properties.header(c, "Світіння й плівка");
        keyed(c, "Bloom", SceneLook.BLOOM, 0.02, 0, 4);
        Properties.num(c, "Поріг", "look.bth", l.bloomThreshold, 0.02, Theme.ACCENT, v -> l.bloomThreshold = (float) Math.max(0, Math.min(8, v)), null);
        Properties.num(c, "Радіус", "look.brad", l.bloomRadius, 0.05, Theme.ACCENT, v -> l.bloomRadius = (float) Math.max(0.25, Math.min(4, v)), null);
        keyed(c, "Віньєтка", SceneLook.VIGNETTE, 0.02, 0, 1);
        Properties.num(c, "М'якість", "look.vsoft", l.vignetteSoftness, 0.02, Theme.ACCENT, v -> l.vignetteSoftness = (float) Math.max(0.05, Math.min(1, v)), null);
        Properties.num(c, "Зерно", "look.grain", l.grain, 0.01, Theme.ACCENT, v -> l.grain = (float) Math.max(0, Math.min(1, v)), null);
        Properties.num(c, "Різкість", "look.sharp", l.sharpen, 0.01, Theme.ACCENT, v -> l.sharpen = (float) Math.max(0, Math.min(1, v)), null);
        Properties.header(c, "Промені (об'ємне світло)");
        int bs = Properties.cycle(c, "Стиль", SceneLook.BEAM_STYLES, -1, "Чисті / Пил / Дим — як стилі променів IRL-editor");
        if (bs >= 0) s.edit("Стиль променів", () -> l.beamStyle(bs));
        Properties.num(c, "Сила", "look.vli", l.vlIntensity, 0.05, Theme.ACCENT, v -> l.vlIntensity = (float) Math.max(0, Math.min(16, v)), null);
        Properties.num(c, "Кроки", "look.vls", l.vlSteps, 1, Theme.ACCENT, v -> l.vlSteps = (int) Math.max(4, Math.min(96, Math.round(v))), null);
        Properties.num(c, "Дальність", "look.vlm", l.vlMaxDist, 1, Theme.ACCENT, v -> l.vlMaxDist = (float) Math.max(4, Math.min(256, v)), null);
        if (Properties.check(c, "Тіні в променях", l.vlShadows, null)) s.edit("Промені", () -> l.vlShadows = !l.vlShadows);
        Properties.num(c, "Біля джер.", "look.vltb", l.vlTipBoost, 0.05, Theme.ACCENT, v -> l.vlTipBoost = (float) Math.max(0, Math.min(8, v)), null);
        if (Properties.check(c, "Дим (шум щільності)", l.vlNoise, null)) s.edit("Промені", () -> l.vlNoise = !l.vlNoise);
        if (l.vlNoise) {
            Properties.num(c, "  сила", "look.vlna", l.vlNoiseAmount, 0.02, Theme.ACCENT, v -> l.vlNoiseAmount = (float) Math.max(0, Math.min(1, v)), null);
            Properties.num(c, "  розмір", "look.vlns", l.vlNoiseScale, 0.1, Theme.ACCENT, v -> l.vlNoiseScale = (float) Math.max(0.1, Math.min(32, v)), null);
            Properties.num(c, "  дрейф", "look.vlnv", l.vlNoiseSpeed, 0.05, Theme.ACCENT, v -> l.vlNoiseSpeed = (float) Math.max(0, Math.min(8, v)), null);
        }
        c.gui().textClip("промінь вмикається «Силою» в самому світлі", c.x(), c.next(12) + 1, c.w(), Theme.MUTED);
        Properties.header(c, "Контур від світла і тун");
        if (Properties.check(c, "Контур (rim) кольором світла", l.outline, "Обвідка силуету з боку світла, як outline у IRL")) s.edit("Контур", () -> l.outline = !l.outline);
        if (l.outline) {
            int ot = Properties.cycle(c, "На що", new String[] { "усе", "сутності", "блоки" }, l.outlineTarget, null);
            if (ot >= 0) s.edit("Контур", () -> l.outlineTarget = ot);
            Properties.num(c, "Сила", "look.ols", l.outlineStrength, 0.02, Theme.ACCENT, v -> l.outlineStrength = (float) Math.max(0, Math.min(3, v)), null);
            Properties.num(c, "Френель", "look.olp", l.outlinePower, 0.05, Theme.ACCENT, v -> l.outlinePower = (float) Math.max(1, Math.min(4, v)), null);
            Properties.num(c, "Задній", "look.olb", l.outlineBack, 0.05, Theme.ACCENT, v -> l.outlineBack = (float) Math.max(0, Math.min(2, v)), null);
            Properties.num(c, "Передній", "look.olf", l.outlineFront, 0.05, Theme.ACCENT, v -> l.outlineFront = (float) Math.max(0, Math.min(1.5, v)), null);
            Properties.num(c, "Світіння", "look.olg", l.outlineGlow, 0.01, Theme.ACCENT, v -> l.outlineGlow = (float) Math.max(0, Math.min(0.75, v)), null);
        }
        Properties.num(c, "Тун-смуги", "look.toon", l.toonBands, 1, Theme.ACCENT, v -> l.toonBands = (int) Math.max(0, Math.min(16, Math.round(v))), null);
        if (l.toonBands > 0) Properties.num(c, "  м'якість", "look.toons", l.toonSmooth, 0.02, Theme.ACCENT, v -> l.toonSmooth = (float) Math.max(0, Math.min(1, v)), null);
        Properties.num(c, "М'як. тіней", "look.shs", l.shadowSoftness, 0.05, Theme.ACCENT, v -> l.shadowSoftness = (float) Math.max(0, Math.min(8, v)), null);
        Properties.header(c, "Якість і швидкість");
        int q = Properties.cycle(c, "Якість", QUALITY, l.quality.ordinal(), "Суперсемплінг і роздільність тіней. Авто — за розміром картки");
        if (q >= 0) s.edit("Якість", () -> l.quality = SceneLook.Quality.values()[q]);
        Properties.num(c, "FPS спок.", "look.fpsi", l.fpsIdle, 1, Theme.ACCENT, v -> l.fpsIdle = (int) Math.max(1, Math.min(240, Math.round(v))), null);
        Properties.num(c, "FPS навед.", "look.fpsh", l.fpsHover, 1, Theme.ACCENT, v -> l.fpsHover = (int) Math.max(1, Math.min(240, Math.round(v))), null);
        c.gui().textClip("між кадрами меню показує останній кадр", c.x(), c.next(12) + 1, c.w(), Theme.MUTED);
    }

    /** Поле з ◆: є ключі — пише ключ у playhead, інакше базове значення. */
    private static void keyed(Properties.Ctx c, String label, String ch, double step, double min, double max) {
        SceneEditorScreen s = c.s();
        SceneLook l = s.variant().look;
        var kc = l.channels.get(ch);
        Properties.num(c, label, "look." + ch, l.at(ch, s.time), step, kc != null && !kc.isEmpty() ? 0xFFF2B84B : Theme.ACCENT, v -> {
            double x = Math.max(min, Math.min(max, v));
            var k = l.channels.get(ch);
            if (k != null && !k.isEmpty()) k.set(s.time, x);
            else l.setBase(ch, x);
        }, new Properties.KeyBtn(kc, 0, () -> l.channels.getOrCreate(ch).set(s.time, l.at(ch, s.time))));
    }

    // ═════════════════════════ меню й цикл ═════════════════════════

    private static MenuFrame frame(SceneEditorScreen s) { return MenuChecks.frame(s.variant(), s.def); }

    /** Кадр для зміни: перша зміна копіює кадр режиму у документ. */
    private static MenuFrame editable(SceneEditorScreen s) {
        SceneDoc.Variant v = s.variant();
        if (v.menu == null) v.menu = frame(s).copy();
        return v.menu;
    }

    private static void menu(Properties.Ctx c) {
        SceneEditorScreen s = c.s();
        SceneDoc.Variant v = s.variant();
        MenuFrame f = frame(s);
        String[] names = new String[MenuFrame.PRESETS.length + 1];
        int cur = MenuFrame.PRESETS.length;
        for (int i = 0; i < MenuFrame.PRESETS.length; i++) {
            MenuFrame.Preset p = MenuFrame.PRESETS[i];
            names[i] = p.name();
            if ((long) p.w() * f.aspectH == (long) p.h() * f.aspectW) cur = i;
        }
        names[MenuFrame.PRESETS.length] = "Свій: " + f.aspectW + ":" + f.aspectH;
        Properties.header(c, "Кадр віконця");
        int fi = Properties.cycle(c, "Формат", names, cur, "Співвідношення сторін камери в меню: квадрат для кнопки, 3:4 для картки…");
        if (fi >= 0 && fi < MenuFrame.PRESETS.length) s.edit("Формат кадру", () -> editable(s).aspect(MenuFrame.PRESETS[fi].w(), MenuFrame.PRESETS[fi].h()));
        int y0 = c.y()[0];
        int half = (c.w() - 46) / 2;
        c.gui().textClip("Свій", c.x(), y0 + 3, 44, Theme.MUTED);
        Gui.Num nw = c.gui().number("menu.aw", c.x() + 46, y0, half - 2, 13, f.aspectW, 1, Theme.ACCENT);
        Gui.Num nh = c.gui().number("menu.ah", c.x() + 46 + half, y0, half, 13, f.aspectH, 1, Theme.ACCENT);
        Properties.apply(s, "Формат кадру", nw, x -> editable(s).aspect((int) Math.max(1, Math.round(x)), editable(s).aspectH));
        Properties.apply(s, "Формат кадру", nh, x -> editable(s).aspect(editable(s).aspectW, (int) Math.max(1, Math.round(x))));
        c.next(15);
        if (s.def != null && s.def.menu != null) {
            boolean same = v.menu == null;
            c.gui().textClip(same ? "як оголосив режим: " + s.def.menu.label() : "режим чекає " + s.def.menu.aspectW + ":" + s.def.menu.aspectH,
                c.x(), c.next(12) + 1, c.w() - 70, same ? Theme.OK : Theme.WARN);
            if (!same && c.gui().button(c.x() + c.w() - 66, c.y()[0] - 13, 66, 12, Component.literal("як у режимі"), false, null)) s.edit("Кадр", () -> v.menu = null);
        }
        Properties.num(c, "Збільш.", "menu.zoom", f.hoverZoom, 0.01, Theme.ACCENT, x -> editable(s).hoverZoom((float) x), null);
        Properties.num(c, "Наїзд", "menu.dolly", f.hoverDolly, 0.01, Theme.ACCENT, x -> editable(s).hoverDolly((float) x), null);
        c.gui().textClip("під курсором: картка ×збільш., камера наїжджає", c.x(), c.next(12) + 1, c.w(), Theme.MUTED);
        Properties.header(c, "Безпечні зони (під підписи)");
        Properties.num(c, "Низ", "menu.sb", f.safeBottom, 0.01, Theme.ACCENT, x -> { MenuFrame e = editable(s); e.safe(e.safeTop, (float) x, e.safeLeft, e.safeRight); }, null);
        Properties.num(c, "Верх", "menu.st", f.safeTop, 0.01, Theme.ACCENT, x -> { MenuFrame e = editable(s); e.safe((float) x, e.safeBottom, e.safeLeft, e.safeRight); }, null);
        Properties.num(c, "Ліво", "menu.sl", f.safeLeft, 0.01, Theme.ACCENT, x -> { MenuFrame e = editable(s); e.safe(e.safeTop, e.safeBottom, (float) x, e.safeRight); }, null);
        Properties.num(c, "Право", "menu.sr", f.safeRight, 0.01, Theme.ACCENT, x -> { MenuFrame e = editable(s); e.safe(e.safeTop, e.safeBottom, e.safeLeft, (float) x); }, null);
        Properties.header(c, "Сцена (що рендериться)");
        Properties.num(c, "Радіус", "menu.rad", f.stageRadius, 1, Theme.ACCENT, x -> editable(s).stageRadius(x), null);
        int by = c.next(16), bw = (c.w() - 4) / 3;
        if (c.gui().button(c.x(), by, bw, 14, Component.literal("Центр: авто"), f.stageCenter == null, Component.literal("Середина акторів і світел")))
            s.edit("Центр сцени", () -> editable(s).stageCenter = null);
        SceneObject sel = s.selected();
        if (c.gui().button(c.x() + bw + 2, by, bw, 14, Component.literal("= вибране"), false, Component.literal("Центр сцени — вибраний об'єкт"), sel != null)) {
            double[] xf = s.evaluator.transform(sel, s.time, new double[7], 0);
            s.edit("Центр сцени", () -> editable(s).stageCenter = new double[] { xf[0], xf[1], xf[2] });
        }
        if (c.gui().button(c.x() + 2 * (bw + 2), by, bw, 14, Component.literal("= камера"), false, Component.literal("Центр — точка перед камерою сцени"), s.frame.hasCamera)) {
            var cam = s.frame.camera;
            double yr = Math.toRadians(cam.yaw), pr = Math.toRadians(cam.pitch), d = 6;
            double[] p = { cam.x - Math.sin(yr) * Math.cos(pr) * d, cam.y - Math.sin(pr) * d, cam.z + Math.cos(yr) * Math.cos(pr) * d };
            s.edit("Центр сцени", () -> editable(s).stageCenter = p);
        }

        Properties.header(c, "Цикл");
        if (Properties.check(c, "Крутиться без кінця", v.loop, "Сцена в меню — завжди цикл")) s.edit("Цикл", () -> v.loop = !v.loop);
        Properties.num(c, "Від", "loop.in", v.loopIn, 0.05, Theme.ACCENT, x -> v.loopIn = Math.max(0, x), null);
        Properties.num(c, "До", "loop.out", v.loopOut > v.loopIn ? v.loopOut : v.length, 0.05, Theme.ACCENT, x -> v.loopOut = Math.max(0, Math.min(v.length, x)), null);
        Properties.num(c, "Змішув.", "loop.blend", v.loopBlend, 0.05, Theme.ACCENT, x -> v.loopBlend = Math.max(0, Math.min(5, x)), null);
        c.gui().textClip("0..«Від» — вступ один раз; змішування згладжує шов", c.x(), c.next(12) + 1, c.w(), Theme.MUTED);
        int ly = c.next(16), lw = (c.w() - 2) / 2;
        if (c.gui().button(c.x(), ly, lw, 14, Component.literal("Зробити безшовним"), false,
            Component.literal("Ключі на межах циклу, кінець = початок, криві-цикли (як Cycles у Blender)"), !s.readOnly)) s.menuFix("seamless");
        if (c.gui().button(c.x() + lw + 2, ly, lw, 14, Component.literal("Підігнати idle"), false,
            Component.literal("Швидкість idle акторів — ціла кількість повторів у циклі"), !s.readOnly)) s.menuFix("fit_idles");

        checklist(c);
    }

    // ═════════════════════════ чек-лист ═════════════════════════

    static List<MenuChecks.Check> checks(SceneEditorScreen s) {
        long now = System.nanoTime();
        if (now - checkedAt > 500_000_000L || checkedFor != s.variant()) {
            try { checks = MenuChecks.check(s.doc, s.variant(), s.def, s.clips); } catch (RuntimeException e) { checks = List.of(); }
            checkedAt = now;
            checkedFor = s.variant();
        }
        return checks;
    }

    /** Скільки помилок / попереджень (для бейджа превʼю). */
    static int[] counts(SceneEditorScreen s) {
        int f = 0, w = 0;
        for (MenuChecks.Check ch : checks(s)) { if (ch.status() == MenuChecks.Status.FAIL) f++; else if (ch.status() == MenuChecks.Status.WARN) w++; }
        return new int[] { f, w };
    }

    private static void checklist(Properties.Ctx c) {
        SceneEditorScreen s = c.s();
        Gui gui = c.gui();
        List<MenuChecks.Check> list = checks(s);
        int[] n = counts(s);
        Properties.header(c, "Вимоги сцени · " + (n[0] == 0 && n[1] == 0 ? "усе виконано" : n[0] + " ✖  " + n[1] + " ⚠"));
        for (MenuChecks.Check ch : list) {
            int col = switch (ch.status()) { case OK -> Theme.OK; case WARN -> Theme.WARN; case FAIL -> Theme.DANGER; };
            String mark = switch (ch.status()) { case OK -> "✔ "; case WARN -> "⚠ "; case FAIL -> "✖ "; };
            boolean fix = ch.fix() != null && ch.status() != MenuChecks.Status.OK && !s.readOnly;
            int rowH = ch.detail() == null ? 13 : 24;
            int yy = c.next(rowH + 1);
            if (gui.hover(c.x() - 2, yy, c.w() + 4, rowH)) gui.g.fill(c.x() - 2, yy, c.x() + c.w() + 2, yy + rowH, MenuSkin.ROW_HOT);
            gui.textClip(mark + ch.title(), c.x(), yy + 2, c.w() - (fix ? 58 : 0), col);
            if (ch.detail() != null) gui.textClip(ch.detail(), c.x() + 9, yy + 13, c.w() - 9, Theme.MUTED);
            if (ch.detail() != null && gui.hover(c.x(), yy, c.w(), rowH)) gui.tip(Component.literal(ch.title() + "\n" + ch.detail()));
            if (fix && gui.button(c.x() + c.w() - 56, yy, 56, 12, Component.literal("Виправити"), false, null)) s.menuFix(ch.fix());
            else if (ch.objectId() != null && gui.clicked(c.x(), yy, c.w() - (fix ? 58 : 0), rowH, 0)) s.select(ch.objectId());
        }
        if (s.def != null && !s.def.requirements.isEmpty()) {
            c.gui().textClip("вимоги оголосив режим «" + s.def.title + "»", c.x(), c.next(12) + 2, c.w(), Theme.MUTED);
        }
    }

    /** Чи стоїть ідеальний шов (для бейджа таймлайну). */
    static boolean seamClean(SceneEditorScreen s) {
        try { return LoopTools.seam(s.doc, s.variant(), s.clips).clean(); } catch (RuntimeException e) { return false; }
    }
}
