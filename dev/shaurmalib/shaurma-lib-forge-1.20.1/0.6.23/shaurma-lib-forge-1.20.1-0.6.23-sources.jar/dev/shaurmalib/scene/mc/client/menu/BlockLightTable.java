package dev.shaurmalib.scene.mc.client.menu;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RedStoneWireBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Кольори, сила й дальність авто-світла для блоків, що світяться (факели, ліхтарі, світлокамінь, лава…).
 * Таблиця перенесена з IRL-editor ({@code BlockLightDefs}, qualet, MIT — див. {@code docs/THIRD_PARTY.md}):
 * кольори лінійні 0..1, дальність у блоках. Блок не з таблиці, що світиться (модові), отримує теплий білий за
 * рівнем свічення. Масові випромінювачі (лава, світлокамінь) зливаються в одне світло на комірку 4³.
 */
final class BlockLightTable {

    private BlockLightTable() {}

    record Def(float r, float g, float b, float intensity, float radius, int mergeCells) {}

    static final int CLUSTER = 4;
    private static final Map<Block, Def> DEFS = new IdentityHashMap<>();
    private static final Def[] REDSTONE = new Def[16];

    private static void put(Block b, float r, float g, float bl, float i, float rad) { DEFS.put(b, new Def(r, g, bl, i, rad, 0)); }

    private static void merged(Block b, float r, float g, float bl, float i, float rad) { DEFS.put(b, new Def(r, g, bl, i, rad, CLUSTER)); }

    /** Світло для стану блоку або null — не світить. Безпечно з фонового потоку (лише читання). */
    static Def resolve(BlockState st) {
        int lum = st.getLightEmission();
        if (lum > 0) {
            Def d = DEFS.get(st.getBlock());
            if (d != null) return d;
            float k = lum / 15f;
            return new Def(1f, 0.82f, 0.62f, 0.5f + 0.7f * k, 3f + 10f * k, 0);
        }
        if (st.is(Blocks.REDSTONE_WIRE)) {
            int p = st.getValue(RedStoneWireBlock.POWER);
            return p > 0 ? REDSTONE[p] : null;
        }
        return null;
    }

    static {
        put(Blocks.TORCH, 1.00f, 0.72f, 0.36f, 1.2f, 10f);
        put(Blocks.WALL_TORCH, 1.00f, 0.72f, 0.36f, 1.2f, 10f);
        put(Blocks.SOUL_TORCH, 0.35f, 0.78f, 1.00f, 1.0f, 9f);
        put(Blocks.SOUL_WALL_TORCH, 0.35f, 0.78f, 1.00f, 1.0f, 9f);
        put(Blocks.REDSTONE_TORCH, 1.00f, 0.15f, 0.10f, 0.7f, 6f);
        put(Blocks.REDSTONE_WALL_TORCH, 1.00f, 0.15f, 0.10f, 0.7f, 6f);
        put(Blocks.LANTERN, 1.00f, 0.78f, 0.50f, 1.3f, 12f);
        put(Blocks.SOUL_LANTERN, 0.40f, 0.80f, 1.00f, 1.1f, 11f);
        merged(Blocks.GLOWSTONE, 1.00f, 0.86f, 0.60f, 1.5f, 14f);
        merged(Blocks.SEA_LANTERN, 0.80f, 0.95f, 1.00f, 1.4f, 13f);
        merged(Blocks.SHROOMLIGHT, 1.00f, 0.55f, 0.25f, 1.3f, 13f);
        put(Blocks.JACK_O_LANTERN, 1.00f, 0.70f, 0.30f, 1.3f, 13f);
        put(Blocks.REDSTONE_LAMP, 1.00f, 0.76f, 0.42f, 1.3f, 13f);
        merged(Blocks.MAGMA_BLOCK, 1.00f, 0.45f, 0.15f, 0.7f, 6f);
        merged(Blocks.OCHRE_FROGLIGHT, 1.00f, 0.85f, 0.50f, 1.5f, 15f);
        merged(Blocks.VERDANT_FROGLIGHT, 0.80f, 1.00f, 0.70f, 1.5f, 15f);
        merged(Blocks.PEARLESCENT_FROGLIGHT, 1.00f, 0.85f, 0.95f, 1.5f, 15f);
        put(Blocks.END_ROD, 0.95f, 0.95f, 1.00f, 1.2f, 12f);
        put(Blocks.CAMPFIRE, 1.00f, 0.60f, 0.25f, 1.4f, 13f);
        put(Blocks.SOUL_CAMPFIRE, 0.40f, 0.80f, 1.00f, 1.1f, 11f);
        put(Blocks.FIRE, 1.00f, 0.60f, 0.25f, 1.3f, 12f);
        put(Blocks.SOUL_FIRE, 0.40f, 0.80f, 1.00f, 1.1f, 11f);
        merged(Blocks.LAVA, 1.00f, 0.42f, 0.12f, 1.4f, 12f);
        put(Blocks.BEACON, 0.90f, 0.97f, 1.00f, 1.6f, 16f);
        put(Blocks.CONDUIT, 0.60f, 0.90f, 1.00f, 1.4f, 14f);
        put(Blocks.GLOW_LICHEN, 0.45f, 0.85f, 0.55f, 0.7f, 7f);
        put(Blocks.CRYING_OBSIDIAN, 0.60f, 0.30f, 0.95f, 1.0f, 10f);
        put(Blocks.RESPAWN_ANCHOR, 1.00f, 0.30f, 0.90f, 1.3f, 13f);
        put(Blocks.ENDER_CHEST, 0.25f, 0.75f, 0.72f, 0.7f, 7f);
        put(Blocks.SEA_PICKLE, 0.55f, 0.90f, 0.55f, 0.6f, 6f);
        put(Blocks.FURNACE, 1.00f, 0.70f, 0.35f, 1.0f, 11f);
        put(Blocks.SMOKER, 1.00f, 0.70f, 0.35f, 1.0f, 11f);
        put(Blocks.BLAST_FURNACE, 1.00f, 0.70f, 0.35f, 1.0f, 11f);
        put(Blocks.NETHER_PORTAL, 0.65f, 0.30f, 0.95f, 1.1f, 11f);
        put(Blocks.END_PORTAL, 0.40f, 0.55f, 0.95f, 1.4f, 14f);
        put(Blocks.END_GATEWAY, 0.40f, 0.55f, 0.95f, 1.4f, 14f);
        Block[] candles = { Blocks.CANDLE, Blocks.WHITE_CANDLE, Blocks.ORANGE_CANDLE, Blocks.MAGENTA_CANDLE, Blocks.LIGHT_BLUE_CANDLE,
            Blocks.YELLOW_CANDLE, Blocks.LIME_CANDLE, Blocks.PINK_CANDLE, Blocks.GRAY_CANDLE, Blocks.LIGHT_GRAY_CANDLE, Blocks.CYAN_CANDLE,
            Blocks.PURPLE_CANDLE, Blocks.BLUE_CANDLE, Blocks.BROWN_CANDLE, Blocks.GREEN_CANDLE, Blocks.RED_CANDLE, Blocks.BLACK_CANDLE };
        for (Block c : candles) put(c, 1.00f, 0.70f, 0.35f, 0.8f, 8f);
        for (int p = 1; p <= 15; p++) {
            float t = p / 15f;
            REDSTONE[p] = new Def(1.0f, 0.06f, 0.0f, 0.06f + 0.12f * t, 2.0f + 2.5f * t, 0);
        }
    }
}
