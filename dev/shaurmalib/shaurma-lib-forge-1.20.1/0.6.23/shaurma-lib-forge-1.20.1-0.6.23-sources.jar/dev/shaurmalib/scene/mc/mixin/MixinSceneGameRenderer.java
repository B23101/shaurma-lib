package dev.shaurmalib.scene.mc.mixin;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.shaurmalib.scene.mc.client.SceneCamera;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** FOV і крен камери сцени, рука схована в кадрі сцени/редактора. */
@Mixin(GameRenderer.class)
public abstract class MixinSceneGameRenderer {

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void shaurma$scene$fov(Camera camera, float partial, boolean useFovSetting, CallbackInfoReturnable<Double> cir) {
        float f = SceneCamera.fov();
        if (f > 0 && SceneCamera.controlling()) cir.setReturnValue((double) f);
    }

    @Inject(method = "bobHurt", at = @At("HEAD"))
    private void shaurma$scene$roll(PoseStack ps, float partial, CallbackInfo ci) {
        float roll = SceneCamera.roll();
        if (roll != 0 && SceneCamera.controlling()) ps.mulPose(Axis.ZP.rotationDegrees(roll));
    }

    @Inject(method = "bobView", at = @At("HEAD"), cancellable = true)
    private void shaurma$scene$noBob(PoseStack ps, float partial, CallbackInfo ci) {
        if (SceneCamera.controlling()) ci.cancel();
    }

    /** Шейдерні ефекти сцени (фільтри, корекція, розмиття…) — після світу, до HUD і екранів. */
    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;renderLevel(FJLcom/mojang/blaze3d/vertex/PoseStack;)V", shift = At.Shift.AFTER))
    private void shaurma$scene$post(float partial, long nanos, boolean renderLevel, CallbackInfo ci) {
        dev.shaurmalib.scene.mc.client.ScenePost.apply(partial);
        dev.shaurmalib.scene.mc.client.menu.MenuScene.newFrame();
    }

    @Inject(method = "renderItemInHand", at = @At("HEAD"), cancellable = true)
    private void shaurma$scene$hand(PoseStack ps, Camera camera, float partial, CallbackInfo ci) {
        if (SceneCamera.hideHand()) ci.cancel();
    }
}
