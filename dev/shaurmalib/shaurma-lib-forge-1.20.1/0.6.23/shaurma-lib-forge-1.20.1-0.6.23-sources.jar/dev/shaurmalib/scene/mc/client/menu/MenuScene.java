package dev.shaurmalib.scene.mc.client.menu;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.shaurmalib.scene.api.SceneBindings;
import dev.shaurmalib.scene.api.SceneDefinition;
import dev.shaurmalib.scene.api.SceneRegistry;
import dev.shaurmalib.scene.doc.MenuFrame;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.edit.MenuChecks;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.eval.ScenePlayback;
import dev.shaurmalib.scene.mc.client.SceneAssets;
import dev.shaurmalib.scene.mc.client.SceneClient;
import dev.shaurmalib.scene.mc.client.SceneClips;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Анімована сцена у віконці меню — картка/кнопка, у якій живе справжня локація світу з камерою сцени,
 * акторами (зі згинами рук і ніг), світлом, тінями й корекцією кольору. Камера гравця не чіпається: сцена
 * рендериться окремо в текстуру ({@link MenuRenderer}) і малюється як звичайний елемент GUI.
 *
 * <pre>{@code
 * // поле екрана
 * private final MenuScene knife = MenuScene.of("maniacmod:kit_knife").bindings(SceneGuiPreview.viewer("hero"));
 *
 * // render(): картка з плавним збільшенням під курсором
 * knife.render(g, x, y, 120, 160, mouseX, mouseY);
 * knife.overlay(g, () -> g.drawString(font, "Ніж", x + 6, y + 146, 0xFFFFFF));   // підпис збільшується разом з карткою
 * if (knife.isHovered() && clicked) ...
 *
 * // removed(): звільнити GPU-ресурси
 * knife.close();
 * }</pre>
 *
 * Кілька карток на екрані — нормально: кожна має ліміт кадрів ({@code fpsIdle}/{@code fpsHover} у вигляді
 * сцени), а за кадр гри перемальовується не більше {@link #budgetPerFrame} карток (картка під курсором — завжди).
 * Решту часу показується останній кадр, тож меню не просідає.
 */
public final class MenuScene {

    /** Скільки карток може перемалюватись за один кадр гри (крім картки під курсором). */
    public static int budgetPerFrame = 2;

    private final String sceneId;
    private String variantId;
    private SceneBindings bindings = new SceneBindings();
    private boolean hoverable = true;
    private float parallaxDeg = 1.4f;
    private MenuFrame frameOverride;

    private final MenuRenderer renderer = new MenuRenderer();
    private final MenuRenderer.Input input = new MenuRenderer.Input();
    private ScenePlayback playback;
    private SceneClips clips;
    private final SceneFrame frame = new SceneFrame();
    private int revision = -1;
    private double[] stageCenter;
    private MenuFrame spec;
    private float hover, hoverVel, px, py;
    private boolean hovered;
    private long lastNs, lastRenderNs, lastDrawNs, requestedNs;
    private int texture;
    private int texW, texH;
    private boolean closed;

    // кадри гри для бюджету
    private static long frameId, budgetFrame;
    private static int budgetUsed;
    private static long lastFrameNs;
    private static final List<WeakReference<MenuScene>> ALL = new ArrayList<>();

    private MenuScene(String sceneId) {
        this.sceneId = sceneId;
        synchronized (ALL) { ALL.add(new WeakReference<>(this)); }
    }

    public static MenuScene of(String sceneId) { return new MenuScene(sceneId); }

    /** Хто в слотах сцени (найчастіше — {@code SceneGuiPreview.viewer(...)}: «у слотах — я»). */
    public MenuScene bindings(SceneBindings b) { this.bindings = b == null ? new SceneBindings() : b; revision = -1; return this; }

    /** Варіант документа (null — перший). */
    public MenuScene variant(String id) { this.variantId = id; revision = -1; return this; }

    /** Без реакції на курсор (статична картка). */
    public MenuScene hoverable(boolean h) { this.hoverable = h; return this; }

    /** Наскільки камера «дивиться» за курсором, градуси (0 — без паралаксу). */
    public MenuScene parallax(float degrees) { this.parallaxDeg = Math.max(0, degrees); return this; }

    /**
     * Стеля кадрів/с від режиму поверх {@code fpsIdle}/{@code fpsHover} документа (0 — без стелі). Можна міняти
     * щокадру: напр. неактивні картки — 6, обрана — 20, під курсором — як у документі. Береться менше з двох.
     */
    public MenuScene fps(int idleCap, int hoverCap) { this.fpsIdleCap = Math.max(0, idleCap); this.fpsHoverCap = Math.max(0, hoverCap); return this; }

    private int fpsIdleCap, fpsHoverCap;

    /** Свій кадр (збільшення, наїзд…) замість оголошеного режимом/документом. */
    public MenuScene frame(MenuFrame f) { this.frameOverride = f; return this; }

    public String sceneId() { return sceneId; }

    /** Кадр сцени (співвідношення сторін, безпечні зони) — щоб режим міг розкласти картки. */
    public MenuFrame menuFrame() {
        if (frameOverride != null) return frameOverride;
        if (spec != null) return spec;
        SceneDefinition def = SceneRegistry.get(sceneId);
        return def != null && def.menu != null ? def.menu : new MenuFrame();
    }

    public boolean isHovered() { return hovered; }

    /** Анімація наведення 0..1 (м'яка пружина). */
    public float hoverProgress() { return hover; }

    /** Масштаб картки зараз. */
    public float scale() { return 1 + (menuFrame().hoverZoom - 1) * Math.max(0, hover); }

    /** Почати сцену з початку. */
    public void restart() { if (playback != null) playback.seek(0); }

    // ═════════════════════════ кадр гри ═════════════════════════

    /** Новий кадр гри (викликає міксин рендеру; для бюджету перемальовувань). */
    public static void newFrame() { frameId++; lastFrameNs = System.nanoTime(); }

    private static boolean takeBudget(boolean priority) {
        long now = System.nanoTime();
        if (now - lastFrameNs > 40_000_000L) { frameId++; lastFrameNs = now; }   // меню без світу: кадри не рахуються міксином
        if (budgetFrame != frameId) { budgetFrame = frameId; budgetUsed = 0; }
        if (priority) return true;
        if (budgetUsed >= budgetPerFrame) return false;
        budgetUsed++;
        return true;
    }

    // ═════════════════════════ малювання ═════════════════════════

    /**
     * Намалювати картку. Прямокутник — у GUI-координатах (як у будь-якого віджета); під курсором картка плавно
     * збільшується навколо центру і камера трохи наїжджає.
     *
     * @return false — документ сцени ще не прийшов з сервера або рендер недоступний (намальовано заглушку)
     */
    public boolean render(GuiGraphics g, int x, int y, int w, int h, int mouseX, int mouseY) {
        if (closed) closed = false;
        long now = System.nanoTime();
        double dt = lastNs == 0 ? 0 : Math.min(0.1, (now - lastNs) / 1e9);
        lastNs = now;
        lastDrawNs = now;
        gcOthers(now);

        // наведення: критично згасаюча пружина (без перескоку)
        hovered = hoverable && mouseX >= x && mouseY >= y && mouseX < x + w && mouseY < y + h;
        float target = hovered ? 1 : 0, omega = 11f;
        for (double left = dt; left > 1e-6; left -= 1 / 240.0) {
            float st = (float) Math.min(left, 1 / 240.0);
            float acc = omega * omega * (target - hover) - 2 * omega * hoverVel;
            hoverVel += acc * st;
            hover += hoverVel * st;
        }
        hover = Math.max(-0.05f, Math.min(1.05f, hover));
        float tpx = hovered ? Math.max(-1, Math.min(1, (mouseX - (x + w / 2f)) / (w / 2f))) : 0;
        float tpy = hovered ? Math.max(-1, Math.min(1, (mouseY - (y + h / 2f)) / (h / 2f))) : 0;
        float k = (float) (1 - Math.exp(-dt * 6));
        px += (tpx - px) * k;
        py += (tpy - py) * k;

        SceneDoc doc = SceneClient.doc(sceneId);
        if (doc == null) {
            if (System.currentTimeMillis() - requestedNs > 5000) { requestedNs = System.currentTimeMillis(); SceneClient.requestDoc(sceneId); }
            placeholder(g, x, y, w, h);
            return false;
        }
        if (playback == null || revision != doc.revision) {
            SceneDoc.Variant v = doc.variant(variantId);
            playback = new ScenePlayback(-3000 - sceneId.hashCode(), doc, v, bindings, 0, 0, false);
            clips = new SceneClips(doc);
            playback.evaluator().clips(clips);
            revision = doc.revision;
            SceneAssets.ensure(doc);
            spec = frameOverride != null ? frameOverride : MenuChecks.frame(v, SceneRegistry.get(sceneId));
            stageCenter = MenuChecks.stageCenter(doc, v, spec, clips);
            texture = 0;
        }
        playback.advance(dt);
        if (playback.ended()) playback.seek(0);

        float zoom = 1 + (spec.hoverZoom - 1) * Math.max(0, hover);
        double gs = Minecraft.getInstance().getWindow().getGuiScale();
        int pw = (int) Math.ceil(w * gs * spec.hoverZoom), ph = (int) Math.ceil(h * gs * spec.hoverZoom);
        var look = playback.variantDoc().look;
        int fps = hover > 0.05f ? look.fpsHover : look.fpsIdle;
        int cap = hover > 0.05f ? fpsHoverCap : fpsIdleCap;
        if (cap > 0) fps = Math.min(fps, cap);   // стеля режиму (0.6.23)
        boolean due = texture == 0 || pw != texW || ph != texH || now - lastRenderNs >= 1_000_000_000L / Math.max(1, fps);
        if (due && takeBudget(hovered || texture == 0)) {
            g.flush();
            playback.evaluator().eval(playback.time(), frame);
            input.frame = frame;
            input.doc = doc;
            input.clips = clips;
            input.menu = spec;
            input.stageCenter = stageCenter;
            input.width = pw;
            input.height = ph;
            input.hover = Math.max(0, hover);
            input.parallaxX = px;
            input.parallaxY = py;
            input.parallaxDeg = parallaxDeg;
            input.partial = Minecraft.getInstance().getFrameTime();
            input.wall = now / 1e9;
            int tex = renderer.render(input);
            if (tex != 0) { texture = tex; texW = pw; texH = ph; lastRenderNs = now; }
        }
        if (texture == 0) { placeholder(g, x, y, w, h); return false; }

        g.pose().pushPose();
        transform(g, x, y, w, h, zoom);
        blit(g, texture, 0, 0, w, h);
        if (renderer.stageProgress < 0.999f) {
            int bw = (int) (w * renderer.stageProgress);
            g.fill(0, h - 2, w, h, 0x40000000);
            g.fill(0, h - 2, bw, h, 0xA0FFFFFF);
        }
        g.pose().popPose();
        return true;
    }

    /**
     * Намалювати поверх картки те, що має збільшуватись разом з нею (назва, ціна, рамка режиму): та сама
     * поза (масштаб навколо центру і висота над сусідніми картками), що й у сцени.
     */
    public void overlay(GuiGraphics g, int x, int y, int w, int h, Runnable draw) {
        g.pose().pushPose();
        float zoom = 1 + (menuFrame().hoverZoom - 1) * Math.max(0, hover);
        g.pose().translate(x + w / 2f, y + h / 2f, 61 + 60 * Math.max(0, hover));
        g.pose().scale(zoom, zoom, 1);
        g.pose().translate(-(x + w / 2f), -(y + h / 2f), 0);
        draw.run();
        g.pose().popPose();
    }

    private void transform(GuiGraphics g, int x, int y, int w, int h, float zoom) {
        // піднята над сусідами під час збільшення (глибина GUI), масштаб навколо центру
        g.pose().translate(x + w / 2f, y + h / 2f, 60 * Math.max(0, hover));
        g.pose().scale(zoom, zoom, 1);
        g.pose().translate(-w / 2f, -h / 2f, 0);
    }

    /** Текстура результату (premultiplied alpha) у прямокутник поточної пози. */
    public static void blit(GuiGraphics g, int tex, float x, float y, float w, float h) {
        g.flush();
        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderTexture(0, tex);
        RenderSystem.enableBlend();
        RenderSystem.blendFuncSeparate(com.mojang.blaze3d.platform.GlStateManager.SourceFactor.ONE, com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
            com.mojang.blaze3d.platform.GlStateManager.SourceFactor.ONE, com.mojang.blaze3d.platform.GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        Matrix4f m = g.pose().last().pose();
        BufferBuilder b = Tesselator.getInstance().getBuilder();
        b.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
        // текстура GL — початок унизу: v перевернуто
        b.vertex(m, x, y, 0).uv(0, 1).endVertex();
        b.vertex(m, x, y + h, 0).uv(0, 0).endVertex();
        b.vertex(m, x + w, y + h, 0).uv(1, 0).endVertex();
        b.vertex(m, x + w, y, 0).uv(1, 1).endVertex();
        BufferUploader.drawWithShader(b.end());
        RenderSystem.defaultBlendFunc();
    }

    private static void placeholder(GuiGraphics g, int x, int y, int w, int h) {
        g.fillGradient(x, y, x + w, y + h, 0xFF141821, 0xFF0B0D12);
        long t = System.currentTimeMillis();
        int cx = x + w / 2, cy = y + h / 2;
        for (int i = 0; i < 3; i++) {
            float ph = (float) Math.sin(t / 220.0 - i * 0.9);
            int a = (int) (90 + 110 * Math.max(0, ph));
            g.fill(cx - 7 + i * 5, cy - 1, cx - 5 + i * 5, cy + 1, (a << 24) | 0xFFFFFF);
        }
    }

    /** Звільнити GPU-ресурси (екран закрито). Можна знову малювати — створиться заново. */
    public void close() {
        renderer.close();
        texture = 0;
        closed = true;
    }

    /** Звільнити все (вихід зі світу). */
    public static void closeAll() {
        synchronized (ALL) {
            for (WeakReference<MenuScene> r : ALL) { MenuScene m = r.get(); if (m != null) m.close(); }
            ALL.clear();
        }
        StageMesher.clear();
    }

    /** Картки, яких не малювали 10 с, віддають свої цілі рендеру (режим міг забути close()). */
    private static void gcOthers(long now) {
        synchronized (ALL) {
            Iterator<WeakReference<MenuScene>> it = ALL.iterator();
            while (it.hasNext()) {
                MenuScene m = it.next().get();
                if (m == null) { it.remove(); continue; }
                if (!m.closed && m.lastDrawNs != 0 && now - m.lastDrawNs > 10_000_000_000L) m.close();
            }
        }
    }

    // ═════════════════════════ редактор ═════════════════════════

    /**
     * Превʼю з чужим кадром (редактор): той самий рендер, без власного годинника. Повертає текстуру або 0.
     */
    public static int renderFrame(MenuRenderer r, MenuRenderer.Input in) { return r.render(in); }
}
