package dev.shaurmalib.scene.mc.client.menu;

import java.util.Map;

/**
 * GLSL рендеру сцен меню. Освітлення — у лінійному HDR (RGBA16F).
 *
 * <p>Модель світла перенесена з рушія IRLights / irl-core (qualet, MIT — див. {@code docs/THIRD_PARTY.md}), але
 * без шейдерпаків і Iris: точкове / прожектор / сонце; радіальне вікно Frostbite {@code (1−(d/r)⁴)²}; лінійний
 * перехід між зовнішнім і внутрішнім конусом; кукі (гобо) прожектора з поворотом, масштабом та інверсією;
 * «лише блоки / лише сутності»; тіні — 2 карти (сонце/прожектори, білінійний PCF по диску Пуассона, зсув по
 * нормалі) і кубічна карта точкового світла (лінійна глибина); тун-смуги; контур від світла (rim: Френель ×
 * задня/передня сторона × загасання, кольором світла); окремий прохід об'ємних променів (Хеньї-Грінштейн,
 * поглинання по кроку, свічення біля джерела, шум «диму», тіні в променях). Світло неба й ламп світу — з рівнів
 * блоку, без ванільної таблиці (без мерехтіння). Нічого не залежить від часу, крім шуму диму й зерна.
 */
final class MenuShaders {

    private MenuShaders() {}

    /** BLOCK: Position, Color, UV0, UV2, Normal. */
    static final Map<String, Integer> BLOCK_ATTRIBS = Map.of("Position", 0, "Color", 1, "UV0", 2, "UV2", 3, "Normal", 4);
    /** NEW_ENTITY: Position, Color, UV0, UV1, UV2, Normal. */
    static final Map<String, Integer> ENTITY_ATTRIBS = Map.of("Position", 0, "Color", 1, "UV0", 2, "UV1", 3, "UV2", 4, "Normal", 5);
    /** Для тіней: однаково в обох форматах. */
    static final Map<String, Integer> DEPTH_ATTRIBS = Map.of("Position", 0, "UV0", 2);

    /** Світел на піксель (ручні + авто-світло блоків) і об'ємних. */
    static final int MAX_LIGHTS = 32, MAX_VOLUMES = 8;

    static final String WORLD_VS = """
        #version 150
        in vec3 Position;
        in vec4 Color;
        in vec2 UV0;
        in ivec2 UV2;
        in vec3 Normal;
        uniform mat4 uViewProj;
        uniform vec3 uOffset;
        out vec3 vPos;
        out vec4 vColor;
        out vec2 vUV;
        out vec2 vLight;
        out vec3 vNormal;
        void main() {
            vec3 p = Position + uOffset;
            vPos = p;
            gl_Position = uViewProj * vec4(p, 1.0);
            vColor = Color;
            vUV = UV0;
            vLight = clamp(vec2(UV2) / 240.0, 0.0, 1.0);
            vNormal = Normal;
        }
        """;

    /** Спільне для поверхонь і променів: тіні й кукі. Позиції — відносно камери. */
    private static final String SHADOW_COMMON = """
        uniform sampler2DShadow uShadow0;
        uniform sampler2DShadow uShadow1;
        uniform samplerCubeShadow uShadowCube;
        uniform sampler2D uCookie0;
        uniform sampler2D uCookie1;
        uniform mat4 uShadowMat0;
        uniform mat4 uShadowMat1;
        uniform vec4 uShadowInfo0;
        uniform vec4 uShadowInfo1;
        uniform vec3 uCubePos;
        uniform vec4 uCubeInfo;
        uniform vec4 uCookieP0;
        uniform vec4 uCookieP1;

        const vec2 POISSON[12] = vec2[](
            vec2(-0.326, -0.406), vec2(-0.840, -0.074), vec2(-0.696, 0.457), vec2(-0.203, 0.621),
            vec2(0.962, -0.195), vec2(0.473, -0.480), vec2(0.519, 0.767), vec2(0.185, -0.893),
            vec2(0.507, 0.064), vec2(0.896, 0.412), vec2(-0.322, -0.933), vec2(-0.792, -0.598));

        float shadow2D(sampler2DShadow sm, mat4 m, vec4 info, vec3 p, vec3 n, vec3 L, bool fast) {
            float ndl = clamp(dot(n, L), 0.0, 1.0);
            vec3 q = p + n * info.y * (1.0 + 2.0 * (1.0 - ndl));
            vec4 c = m * vec4(q, 1.0);
            c.xyz /= c.w;
            c.xyz = c.xyz * 0.5 + 0.5;
            if (c.x <= 0.0 || c.y <= 0.0 || c.x >= 1.0 || c.y >= 1.0 || c.z >= 1.0) return 1.0;
            float ref = c.z - info.w;
            if (fast) return texture(sm, vec3(c.xy, ref));
            float r = info.x * (0.75 + info.z * 1.5);
            float s = 0.0;
            for (int i = 0; i < 12; i++) s += texture(sm, vec3(c.xy + POISSON[i] * r, ref));
            return s / 12.0;
        }

        /** Кубічна тінь точкового світла: глибина — відстань / far. */
        float shadowCube(vec3 p, vec3 n, vec3 L, bool fast) {
            float ndl = clamp(dot(n, L), 0.0, 1.0);
            vec3 q = p + n * uCubeInfo.y * (1.0 + 2.0 * (1.0 - ndl));
            vec3 d = q - uCubePos;
            float ref = length(d) / uCubeInfo.x - uCubeInfo.w;
            if (ref >= 1.0) return 1.0;
            if (fast) return texture(uShadowCube, vec4(d, ref));
            vec3 a = normalize(abs(d.y) > 0.9 ? cross(d, vec3(1.0, 0.0, 0.0)) : cross(d, vec3(0.0, 1.0, 0.0)));
            vec3 b = normalize(cross(d, a));
            float r = length(d) * 0.012 * (0.75 + uCubeInfo.z * 1.5);
            float s = 0.0;
            for (int i = 0; i < 12; i++) s += texture(uShadowCube, vec4(d + (a * POISSON[i].x + b * POISSON[i].y) * r, ref));
            return s / 12.0;
        }

        float shadowOf(float idx, vec3 p, vec3 n, vec3 L, bool fast) {
            if (idx < -0.5) return 1.0;
            if (idx < 0.5) return shadow2D(uShadow0, uShadowMat0, uShadowInfo0, p, n, L, fast);
            if (idx < 1.5) return shadow2D(uShadow1, uShadowMat1, uShadowInfo1, p, n, L, fast);
            return shadowCube(p, n, L, fast);
        }

        /** Кукі прожектора (формула irlite_cookie): маска в проєкції конуса. cp = (cos rot, sin rot, scale, invert). */
        float cookieOf(float idx, vec3 p, vec3 lp, vec3 ld, float cosOuter) {
            if (idx < -0.5) return 1.0;
            vec4 cp = idx < 0.5 ? uCookieP0 : uCookieP1;
            float c = clamp(cosOuter, -1.0, 1.0);
            float fY = min(c * inversesqrt(max(1.0 - c * c, 1e-12)), 114.58865);
            vec3 up = abs(ld.y) > 0.99 ? vec3(0.0, 0.0, 1.0) : vec3(0.0, 1.0, 0.0);
            vec3 s = normalize(cross(ld, up));
            vec3 u = cross(s, ld);
            vec3 toR = p - lp;
            float z = dot(ld, toR);
            if (z < 0.001) return 0.0;
            vec2 q = vec2(fY * dot(s, toR) / z, fY * dot(u, toR) / z) / max(cp.z, 1e-3);
            q = vec2(cp.x * q.x - cp.y * q.y, cp.y * q.x + cp.x * q.y);
            vec2 uv = q * 0.5 + 0.5;
            if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) return cp.w > 0.5 ? 1.0 : 0.0;
            float m = idx < 0.5 ? texture(uCookie0, uv).r : texture(uCookie1, uv).r;
            return cp.w > 0.5 ? 1.0 - m : m;
        }

        /** Загасання світла за IRL: вікно Frostbite і лінійний конус. params = (тип, дальність, cosOuter, cosInner). */
        float attenuate(vec4 pr, vec3 lpos, vec3 ldir, vec3 p, out vec3 L) {
            if (pr.x > 1.5) { L = -ldir; return 1.0; }
            vec3 d = lpos - p;
            float d2 = dot(d, d);
            if (d2 >= pr.y * pr.y || d2 < 1e-8) { L = vec3(0.0, 1.0, 0.0); return 0.0; }
            float dl = sqrt(d2);
            L = d / dl;
            float dr = dl / pr.y;
            float dr4 = dr * dr * dr * dr;
            float f = max(1.0 - dr4, 0.0);
            float att = f * f;
            if (pr.x > 0.5) att *= clamp((dot(-L, ldir) - pr.z) / max(pr.w - pr.z, 1e-6), 0.0, 1.0);
            return att;
        }
        """;

    static final String WORLD_FS = """
        #version 150
        uniform sampler2D uTex;
        uniform float uAlphaCut;
        uniform float uUnshade;
        uniform float uEmissive;
        uniform float uIsEntity;
        uniform vec3 uSkyCol;
        uniform vec3 uBlockCol;
        uniform vec3 uAmbient;
        uniform float uSpecular;
        uniform int uLightCount;
        uniform vec3 uLPos[32];
        uniform vec3 uLDir[32];
        uniform vec3 uLCol[32];
        uniform vec4 uLParam[32];
        uniform vec4 uLExtra[32];
        uniform vec3 uFogCol;
        uniform vec2 uFog;
        uniform float uOpaque;
        uniform vec2 uToon;
        uniform vec4 uOutline;
        uniform vec2 uOutline2;
        in vec3 vPos;
        in vec4 vColor;
        in vec2 vUV;
        in vec2 vLight;
        in vec3 vNormal;
        out vec4 fragColor;
        """ + SHADOW_COMMON + """

        float faceShade(vec3 n) {
            vec3 a = abs(n);
            if (a.y > 0.5) return n.y > 0.0 ? 1.0 : 0.5;
            return a.x > a.z ? 0.6 : 0.8;
        }

        /** Тун: квантування з м'яким верхнім краєм смуги (irlite_toon). */
        float toon(float x, float bands, float w) {
            x = clamp(x, 0.0, 1.0);
            float scaled = x * bands;
            float band = floor(scaled);
            float fr = scaled - band;
            float t = w <= 1e-4 ? 0.0 : smoothstep(1.0 - w, 1.0, fr);
            return (band + t) / bands;
        }

        void main() {
            vec4 base = texture(uTex, vUV) * vColor;
            if (base.a < uAlphaCut) discard;
            vec3 n = normalize(vNormal);
            if (!gl_FrontFacing) n = -n;
            vec3 col = base.rgb;
            if (uUnshade > 0.0) col /= mix(1.0, faceShade(n), uUnshade);
            vec3 alb = pow(clamp(col, 0.0, 1.0), vec3(2.2));
            float dist = length(vPos);
            vec3 outc;
            if (uEmissive > 0.0) {
                outc = alb * uEmissive;
            } else {
                float blk = vLight.x, sky = vLight.y;
                float bl = blk / (4.0 - 3.0 * blk);
                float sl = sky / (4.0 - 3.0 * sky);
                vec3 V = normalize(-vPos);
                // світло неба/ламп: м'яка крива (не квадрат), інакше під кронами все чорне
                vec3 light = uAmbient + uSkyCol * pow(sl, 1.25) * (0.6 + 0.4 * (n.y * 0.5 + 0.5)) + uBlockCol * pow(bl, 1.5);
                vec3 spec = vec3(0.0);
                vec3 ink = vec3(0.0);
                bool entity = uIsEntity > 0.5;
                float facing = clamp(1.0 - abs(dot(n, V)), 0.0, 1.0);
                bool outlineOn = uOutline.x > 0.0 && (uOutline2.y < 0.5 || (uOutline2.y < 1.5) == entity);
                for (int i = 0; i < 32; i++) {
                    if (i >= uLightCount) break;
                    vec4 ex = uLExtra[i];
                    if ((ex.z > 0.5 && ex.z < 1.5 && !entity) || (ex.z > 1.5 && entity)) continue;
                    vec4 pr = uLParam[i];
                    vec3 L;
                    float att = attenuate(pr, uLPos[i], uLDir[i], vPos, L);
                    if (att <= 0.0) continue;
                    if (pr.x > 0.5 && pr.x < 1.5) { att *= cookieOf(ex.w, vPos, uLPos[i], uLDir[i], pr.z); if (att <= 0.0) continue; }
                    float ndl = max(dot(n, L), 0.0);
                    bool rim = outlineOn && facing > 0.05;
                    if (ndl <= 0.0 && !rim) continue;
                    if (ex.x > -0.5) {
                        att *= shadowOf(ex.x, vPos, n, L, att < 0.04);
                    } else if (pr.x > 1.5) {
                        att *= smoothstep(0.15, 0.85, sky);
                    }
                    if (att <= 0.0) continue;
                    vec3 lc = uLCol[i];
                    float diff = att * ndl;
                    if (uToon.x > 0.5) diff = toon(diff, uToon.x, uToon.y);
                    light += lc * diff;
                    vec3 H = normalize(L + V);
                    spec += lc * pow(max(dot(n, H), 0.0), 48.0) * diff * uSpecular * ex.y;
                    if (rim) {
                        float contour = (smoothstep(0.55, 0.95, facing) + uOutline2.x) * pow(facing, uOutline.y);
                        float r = uOutline.z * (1.0 - ndl) + uOutline.w * ndl;
                        ink += lc * contour * r * att;
                    }
                }
                outc = alb * light + spec * 0.35 + ink * uOutline.x * 1.5;
            }
            if (uFog.y > uFog.x) {
                float f = clamp((dist - uFog.x) / (uFog.y - uFog.x), 0.0, 1.0);
                outc = mix(outc, uFogCol, f * f * (3.0 - 2.0 * f));
            }
            fragColor = uOpaque > 0.5 ? vec4(outc, 1.0) : vec4(outc * base.a, base.a);
        }
        """;

    static final String DEPTH_VS = """
        #version 150
        in vec3 Position;
        in vec2 UV0;
        uniform mat4 uMVP;
        uniform vec3 uOffset;
        out vec2 vUV;
        out vec3 vRel;
        void main() {
            vUV = UV0;
            vRel = Position + uOffset;
            gl_Position = uMVP * vec4(vRel, 1.0);
        }
        """;

    /** uLinear &gt; 0 — пише відстань до світла / far (кубічна тінь). */
    static final String DEPTH_FS = """
        #version 150
        uniform sampler2D uTex;
        uniform float uAlphaCut;
        uniform float uLinear;
        uniform vec3 uLightPos;
        in vec2 vUV;
        in vec3 vRel;
        out vec4 fragColor;
        void main() {
            if (uAlphaCut > 0.0 && texture(uTex, vUV).a < uAlphaCut) discard;
            if (uLinear > 0.0) gl_FragDepth = clamp(length(vRel - uLightPos) / uLinear, 0.0, 1.0);
            else gl_FragDepth = gl_FragCoord.z;
            fragColor = vec4(1.0);
        }
        """;

    static final String FULL_VS = """
        #version 150
        out vec2 vUV;
        void main() {
            vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
            vUV = p;
            gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
        }
        """;

    /**
     * Об'ємні промені (irlite_volumetric): перетин променя зору зі сферою дальності світла, трасування кроками зі
     * статичним дизерингом, на кожному кроці — загасання, конус, кукі, тінь, шум «диму», свічення біля джерела,
     * фаза Хеньї-Грінштейна й поглинання {@code exp(−щільність·крок)}. Половинна роздільність, адитивно в композит.
     */
    static final String VOLUME_FS = """
        #version 150
        in vec2 vUV;
        out vec4 fragColor;
        uniform sampler2D uDepth;
        uniform mat4 uInvViewProj;
        uniform int uVCount;
        uniform vec3 uVPos[8];
        uniform vec3 uVDir[8];
        uniform vec3 uVCol[8];
        uniform vec4 uVParam[8];
        uniform vec4 uVExtra[8];
        uniform vec4 uVlA;
        uniform vec4 uVlB;
        uniform float uTime;
        """ + SHADOW_COMMON + """

        const float PI = 3.14159265;

        float phaseHG(float cosT, float g) {
            float gg = g * g;
            float den = 1.0 + gg - 2.0 * g * cosT;
            return (1.0 / (4.0 * PI)) * (1.0 - gg) / (den * sqrt(max(den, 1e-6)));
        }

        float hash3(vec3 p) { return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453); }

        float noise3(vec3 p) {
            vec3 i = floor(p), f = fract(p);
            f = f * f * (3.0 - 2.0 * f);
            float n000 = hash3(i), n100 = hash3(i + vec3(1, 0, 0)), n010 = hash3(i + vec3(0, 1, 0)), n110 = hash3(i + vec3(1, 1, 0));
            float n001 = hash3(i + vec3(0, 0, 1)), n101 = hash3(i + vec3(1, 0, 1)), n011 = hash3(i + vec3(0, 1, 1)), n111 = hash3(i + vec3(1, 1, 1));
            return mix(mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y), mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y), f.z);
        }

        void main() {
            float depth = texture(uDepth, vUV).r;
            vec4 p = uInvViewProj * vec4(vUV * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
            vec3 end = p.xyz / p.w;
            vec4 far = uInvViewProj * vec4(vUV * 2.0 - 1.0, 1.0, 1.0);
            vec3 dir = normalize(far.xyz / far.w);
            float sceneDist = depth >= 0.99999 ? uVlA.y : length(end);
            float maxDist = min(sceneDist, uVlA.y);
            // статичний дизеринг (interleaved gradient noise) — без мерехтіння між кадрами
            float dither = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
            vec3 result = vec3(0.0);
            for (int i = 0; i < 8; i++) {
                if (i >= uVCount) break;
                vec4 pr = uVParam[i];
                vec4 ex = uVExtra[i];
                vec3 lp = uVPos[i];
                bool sun = pr.x > 1.5;
                float tNear = 0.0, tFar = maxDist;
                if (!sun) {
                    vec3 oc = -lp;
                    float b = dot(oc, dir);
                    float c = dot(oc, oc) - pr.y * pr.y;
                    float disc = b * b - c;
                    if (disc < 0.0) continue;
                    float sq = sqrt(disc);
                    if (-b + sq <= 0.0) continue;
                    tNear = max(-b - sq, 0.0);
                    tFar = min(-b + sq, maxDist);
                }
                float segLen = tFar - tNear;
                if (segLen <= 0.0) continue;
                int maxSteps = int(uVlA.x);
                int steps = clamp(int(ceil(segLen * (float(maxSteps) / 24.0))), min(8, maxSteps), maxSteps);
                float stepLen = segLen / float(steps);
                float ext = max(ex.x, 1e-4);
                float absorption = exp(-ext * stepLen);
                float trans = 1.0;
                float tipR2 = max(uVlA.w * uVlA.w, 1e-4);
                vec3 acc = vec3(0.0);
                for (int s = 0; s < 96; s++) {
                    if (s >= steps) break;
                    vec3 x = dir * (tNear + stepLen * (float(s) + dither));
                    vec3 L;
                    float att = attenuate(pr, lp, uVDir[i], x, L);
                    if (att > 0.0) {
                        if (pr.x > 0.5 && pr.x < 1.5) att *= cookieOf(ex.w, x, lp, uVDir[i], pr.z);
                        if (att > 0.0 && uVlB.w > 0.5 && ex.z > -0.5) att *= shadowOf(ex.z, x, L, L, true);
                        if (att > 0.0 && uVlB.x > 0.0) {
                            vec3 q = (x + vec3(0.0)) / max(uVlB.y, 0.1) + vec3(12.0, 4.0, 8.0) * uTime * uVlB.z * 0.05;
                            float nz = noise3(q) * 0.65 + noise3(q * 2.53 + 0.37) * 0.35;
                            att *= max(0.0, 1.0 - uVlB.x + uVlB.x * 2.0 * nz);
                        }
                        float tip = sun ? 1.0 : 1.0 + uVlA.z * exp(-dot(x - lp, x - lp) / tipR2);
                        float cosT = sun ? dot(dir, uVDir[i]) : dot(dir, normalize(x - lp));
                        acc += att * tip * phaseHG(cosT, ex.y) * (1.0 - absorption) * trans;
                    }
                    trans *= absorption;
                    if (trans < 0.02) break;
                }
                result += uVCol[i] * acc;
            }
            fragColor = vec4(result, 1.0);
        }
        """;

    static final String SKY_FS = """
        #version 150
        in vec2 vUV;
        out vec4 fragColor;
        uniform mat4 uInvViewProj;
        uniform vec3 uTop;
        uniform vec3 uHorizon;
        uniform vec3 uGround;
        uniform float uMode;
        uniform int uSunCount;
        uniform vec3 uSunDir[2];
        uniform vec3 uSunCol[2];
        void main() {
            if (uMode > 1.5) { fragColor = vec4(0.0); return; }
            vec4 p = uInvViewProj * vec4(vUV * 2.0 - 1.0, 1.0, 1.0);
            vec3 d = normalize(p.xyz / p.w);
            vec3 c;
            if (uMode > 0.5) c = uTop;
            else if (d.y >= 0.0) c = mix(uHorizon, uTop, pow(d.y, 0.55));
            else c = mix(uHorizon, uGround, pow(-d.y, 0.35));
            for (int i = 0; i < 2; i++) {
                if (i >= uSunCount) break;
                float m = max(dot(d, -uSunDir[i]), 0.0);
                c += uSunCol[i] * (pow(m, 900.0) * 30.0 + pow(m, 12.0) * 0.18);
            }
            fragColor = vec4(c, 1.0);
        }
        """;

    /** Зменшення 4 білінійними відліками (+ м'який поріг для bloom, якщо uThreshold ≥ 0). */
    static final String DOWN_FS = """
        #version 150
        in vec2 vUV;
        out vec4 fragColor;
        uniform sampler2D uSrc;
        uniform vec2 uTexel;
        uniform float uSpread;
        uniform float uThreshold;
        void main() {
            vec2 o = uTexel * uSpread;
            vec3 c = 0.25 * (texture(uSrc, vUV + vec2(-o.x, -o.y)).rgb + texture(uSrc, vUV + vec2(o.x, -o.y)).rgb
                           + texture(uSrc, vUV + vec2(-o.x, o.y)).rgb + texture(uSrc, vUV + vec2(o.x, o.y)).rgb);
            if (uThreshold >= 0.0) {
                float br = max(c.r, max(c.g, c.b));
                float knee = max(uThreshold * 0.5, 1e-4);
                float soft = clamp(br - uThreshold + knee, 0.0, 2.0 * knee);
                soft = soft * soft / (4.0 * knee);
                c *= max(soft, br - uThreshold) / max(br, 1e-4);
            }
            fragColor = vec4(c, 1.0);
        }
        """;

    static final String BLUR_FS = """
        #version 150
        in vec2 vUV;
        out vec4 fragColor;
        uniform sampler2D uSrc;
        uniform vec2 uDir;
        void main() {
            vec3 c = texture(uSrc, vUV).rgb * 0.2270270270;
            c += texture(uSrc, vUV + uDir * 1.3846153846).rgb * 0.3162162162;
            c += texture(uSrc, vUV - uDir * 1.3846153846).rgb * 0.3162162162;
            c += texture(uSrc, vUV + uDir * 3.2307692308).rgb * 0.0702702703;
            c += texture(uSrc, vUV - uDir * 3.2307692308).rgb * 0.0702702703;
            fragColor = vec4(c, 1.0);
        }
        """;

    static final String COMPOSITE_FS = """
        #version 150
        in vec2 vUV;
        out vec4 fragColor;
        uniform sampler2D uHdr;
        uniform sampler2D uBloom;
        uniform sampler2D uVol;
        uniform vec2 uHdrTexel;
        uniform float uSpread;
        uniform float uExposure;
        uniform int uTonemap;
        uniform vec3 uWB;
        uniform float uContrast;
        uniform float uSaturation;
        uniform float uLift;
        uniform float uGamma;
        uniform float uGain;
        uniform vec3 uSplitShadow;
        uniform vec3 uSplitHigh;
        uniform float uSplit;
        uniform float uBloomAmt;
        uniform float uVolAmt;
        uniform float uVignette;
        uniform float uVigSoft;
        uniform float uAspect;
        uniform float uGrain;
        uniform float uSharpen;
        uniform float uTime;

        const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);

        float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

        vec4 hdr(vec2 uv, float s) {
            vec2 o = uHdrTexel * s;
            return 0.25 * (texture(uHdr, uv + vec2(-o.x, -o.y)) + texture(uHdr, uv + vec2(o.x, -o.y))
                         + texture(uHdr, uv + vec2(-o.x, o.y)) + texture(uHdr, uv + vec2(o.x, o.y)));
        }

        vec3 aces(vec3 x) { return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }

        vec3 hable(vec3 x) {
            const float A = 0.15, B = 0.50, C = 0.10, D = 0.20, E = 0.02, F = 0.30;
            return ((x * (A * x + C * B) + D * E) / (x * (A * x + B) + D * F)) - E / F;
        }

        vec3 agxContrast(vec3 x) {
            vec3 x2 = x * x;
            vec3 x4 = x2 * x2;
            return 15.5 * x4 * x2 - 40.14 * x4 * x + 31.96 * x4 - 6.868 * x2 * x + 0.4298 * x2 + 0.1191 * x - 0.00232;
        }

        vec3 agx(vec3 v) {
            const mat3 m = mat3(0.842479062253094, 0.0423282422610123, 0.0423756549057051,
                                0.0784335999999992, 0.878468636469772, 0.0784336,
                                0.0792237451477643, 0.0791661274605434, 0.879142973793104);
            const mat3 inv = mat3(1.19687900512017, -0.0528968517574562, -0.0529716355144438,
                                  -0.0980208811401368, 1.15190312990417, -0.0980434501171241,
                                  -0.0990297440797205, -0.0989611768448433, 1.15107367264116);
            const float mn = -12.47393, mx = 4.026069;
            v = m * v;
            v = clamp(log2(max(v, vec3(1e-10))), mn, mx);
            v = (v - mn) / (mx - mn);
            v = agxContrast(v);
            v = inv * v;
            return pow(max(v, 0.0), vec3(2.2));
        }

        vec3 tonemap(vec3 c) {
            if (uTonemap == 1) c = aces(c);
            else if (uTonemap == 2) c = hable(c * 2.0) / hable(vec3(11.2));
            else if (uTonemap == 3) c = agx(c);
            return pow(clamp(c, 0.0, 1.0), vec3(1.0 / 2.2));
        }

        void main() {
            vec4 h = hdr(vUV, uSpread);
            if (uSharpen > 0.0) {
                vec4 wide = hdr(vUV, uSpread * 2.0 + 1.0);
                h.rgb = max(h.rgb + uSharpen * (h.rgb - wide.rgb), 0.0);
            }
            vec3 vol = uVolAmt > 0.0 ? texture(uVol, vUV).rgb * uVolAmt : vec3(0.0);
            float a = max(h.a, clamp(dot(vol, LUMA), 0.0, 1.0));
            vec3 c = a > 1e-4 ? (h.rgb + vol) / a : vec3(0.0);
            c += texture(uBloom, vUV).rgb * uBloomAmt;
            c *= exp2(uExposure) * uWB;
            c = tonemap(c);
            c = (c - 0.5) * uContrast + 0.5;
            float l = dot(c, LUMA);
            c = mix(vec3(l), c, uSaturation);
            c = uGain * (c + uLift * (1.0 - c));
            c = pow(max(c, 0.0), vec3(1.0 / uGamma));
            l = clamp(dot(c, LUMA), 0.0, 1.0);
            c += uSplit * ((1.0 - l) * (uSplitShadow - 0.5) + l * (uSplitHigh - 0.5)) * 0.6;
            vec2 q = (vUV - 0.5) * vec2(uAspect, 1.0) / max(1.0, uAspect) * 2.0;
            float v = smoothstep(1.45, 1.45 - 1.4 * uVigSoft, length(q));
            c *= mix(1.0, v, uVignette);
            if (uGrain > 0.0) c += (hash(vUV * 731.0 + fract(uTime) * 17.0) - 0.5) * uGrain * 0.18;
            c += (hash(gl_FragCoord.xy) - 0.5) / 255.0;
            c = clamp(c, 0.0, 1.0);
            fragColor = vec4(c * a, a);
        }
        """;
}
