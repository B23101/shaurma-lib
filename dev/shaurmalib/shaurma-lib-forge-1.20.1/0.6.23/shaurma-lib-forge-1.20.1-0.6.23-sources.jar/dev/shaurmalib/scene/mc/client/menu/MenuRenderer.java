package dev.shaurmalib.scene.mc.client.menu;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexBuffer;
import dev.shaurmalib.scene.doc.MenuFrame;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneLook;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.mc.client.SceneAssets;
import dev.shaurmalib.scene.mc.client.SceneClips;
import dev.shaurmalib.scene.mc.client.SceneRender;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.joml.FrustumIntersection;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL30;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Рендер сцени меню в офскрін-текстуру — окремо від камери гравця і від ванільного рендеру світу:
 * <ol>
 *   <li>геометрія локації — {@link StageMesher} (свої VBO), актори/блок-сутності/сутності — {@link CaptureBuffers};</li>
 *   <li>світло: до 32 на піксель — світла сцени й авто-світло блоків, що світяться ({@link BlockLightTable});</li>
 *   <li>тіні: до 2 карт (сонце — ортографічна на всю сцену, прожектор — перспективна) і кубічна карта одного
 *       точкового світла; світ рендериться в карту лише коли змінився світ або світло, щокадру поверх — актори;</li>
 *   <li>кадр у HDR з суперсемплінгом: небо, світ, актори, вода; кукі, контур від світла, тун;</li>
 *   <li>об'ємні промені (½ роздільності), bloom і композит: тонмапінг і корекція, згладжування зменшенням.</li>
 * </ol>
 * Модель світла — з IRLights / irl-core (qualet, MIT), реалізована тут без Iris і шейдерпаків.
 * Один екземпляр — одне віконце (свої цілі рендеру); шейдери й геометрія сцен спільні.
 */
public final class MenuRenderer {

    /** Що малювати. */
    public static final class Input {
        public SceneFrame frame;
        public SceneDoc doc;
        public SceneClips clips;
        public MenuFrame menu;
        /** Центр сцени (світові координати). */
        public double[] stageCenter;
        /** Розмір результату, фізичні пікселі. */
        public int width, height;
        /** Під курсором 0..1 (наїзд камери) і зсув паралаксу −1..1. */
        public float hover, parallaxX, parallaxY;
        /** Градусів паралаксу при повному наведенні. */
        public float parallaxDeg = 1.4f;
        public float partial;
        /** Секунди реального часу (зерно, дрейф диму). */
        public double wall;
    }

    // ── спільне ──
    private static GlProgram terrain, entity, depth, sky, down, blur, composite, volume;
    private static int emptyVao;
    private static boolean broken;
    private static String error;
    private static final SceneLook DEFAULT_LOOK = new SceneLook();
    private static final int UNIT_SHADOW0 = 1, UNIT_SHADOW1 = 2, UNIT_CUBE = 3, UNIT_COOKIE0 = 4, UNIT_COOKIE1 = 5;

    // ── своє ──
    private final Fbo hdr = new Fbo(Fbo.Color.RGBA16F, true, false);
    private final Fbo ldr = new Fbo(Fbo.Color.RGBA8, false, false);
    private final Fbo half = new Fbo(Fbo.Color.RGBA16F, false, false);
    private final Fbo vol = new Fbo(Fbo.Color.RGBA16F, false, false);
    private final Fbo bloomA = new Fbo(Fbo.Color.RGBA16F, false, false), bloomB = new Fbo(Fbo.Color.RGBA16F, false, false);
    private final Fbo[] shadowStatic = { new Fbo(Fbo.Color.NONE, true, true), new Fbo(Fbo.Color.NONE, true, true) };
    private final Fbo[] shadowDyn = { new Fbo(Fbo.Color.NONE, true, true), new Fbo(Fbo.Color.NONE, true, true) };
    /** Ключ кешу статичних тіней: 0, 1 — карти, 2 — куб. */
    private final float[][] staticKey = new float[3][];
    private final int[] staticVersion = { -1, -1, -1 };
    private final long[] staticAt = new long[3];
    private final CubeShadow cubeStatic = new CubeShadow(), cubeDyn = new CubeShadow();
    private final CaptureBuffers capture = new CaptureBuffers();
    /** Готовність геометрії сцени 0..1 (для індикатора завантаження). */
    public float stageProgress = 1;
    /** Поточна камера (для координат світел відносно камери). */
    private SceneFrame.Cam camRef;

    public static String error() { return error; }

    // ═════════════════════════ ресурси ═════════════════════════

    private static boolean init() {
        if (broken) return false;
        if (terrain != null) return true;
        try {
            terrain = new GlProgram("terrain", MenuShaders.WORLD_VS, MenuShaders.WORLD_FS, MenuShaders.BLOCK_ATTRIBS);
            entity = new GlProgram("entity", MenuShaders.WORLD_VS, MenuShaders.WORLD_FS, MenuShaders.ENTITY_ATTRIBS);
            depth = new GlProgram("depth", MenuShaders.DEPTH_VS, MenuShaders.DEPTH_FS, MenuShaders.DEPTH_ATTRIBS);
            sky = new GlProgram("sky", MenuShaders.FULL_VS, MenuShaders.SKY_FS, null);
            down = new GlProgram("down", MenuShaders.FULL_VS, MenuShaders.DOWN_FS, null);
            blur = new GlProgram("blur", MenuShaders.FULL_VS, MenuShaders.BLUR_FS, null);
            composite = new GlProgram("composite", MenuShaders.FULL_VS, MenuShaders.COMPOSITE_FS, null);
            volume = new GlProgram("volume", MenuShaders.FULL_VS, MenuShaders.VOLUME_FS, null);
            emptyVao = GlStateManager._glGenVertexArrays();
            for (GlProgram p : new GlProgram[] { terrain, entity, volume }) {
                p.use();
                p.set(p == volume ? "uDepth" : "uTex", 0);
                p.set("uShadow0", UNIT_SHADOW0);
                p.set("uShadow1", UNIT_SHADOW1);
                p.set("uShadowCube", UNIT_CUBE);
                p.set("uCookie0", UNIT_COOKIE0);
                p.set("uCookie1", UNIT_COOKIE1);
            }
            terrain.use();
            terrain.set("uIsEntity", 0f);
            entity.use();
            entity.set("uIsEntity", 1f);
            depth.use();
            depth.set("uTex", 0);
            composite.use();
            composite.set("uHdr", 0);
            composite.set("uBloom", 1);
            composite.set("uVol", 2);
            for (GlProgram p : new GlProgram[] { down, blur }) { p.use(); p.set("uSrc", 0); }
            GlStateManager._glUseProgram(0);
            return true;
        } catch (RuntimeException e) {
            broken = true;
            error = e.getMessage();
            System.err.println("[shaurma_scene] рендер сцен меню вимкнено: " + e.getMessage());
            return false;
        }
    }

    public void close() {
        hdr.close(); ldr.close(); half.close(); vol.close(); bloomA.close(); bloomB.close();
        for (Fbo f : shadowStatic) f.close();
        for (Fbo f : shadowDyn) f.close();
        cubeStatic.close();
        cubeDyn.close();
        capture.close();
    }

    // ═════════════════════════ якість ═════════════════════════

    private record Q(float ss, int shadow, boolean bloom, boolean volume) {}

    private static Q quality(SceneLook look, int w, int h) {
        SceneLook.Quality q = look.quality;
        if (q == SceneLook.Quality.AUTO) q = (long) w * h > 700_000 ? SceneLook.Quality.MEDIUM : SceneLook.Quality.HIGH;
        return switch (q) {
            case LOW -> new Q(1f, 512, false, false);
            case MEDIUM -> new Q(1.25f, 1024, true, true);
            case ULTRA -> new Q(2f, 2048, true, true);
            default -> new Q(1.5f, 2048, true, true);
        };
    }

    // ═════════════════════════ ролі світел ═════════════════════════

    /** Світла кадру і їхні ролі: тінь (0/1 — карта, 2 — куб, −1 — без) і кукі (0/1, −1 — без). */
    private static final class Roles {
        final List<SceneFrame.Light> lights;
        final int[] shadow, cookie;
        final List<SceneFrame.Light> maps = new ArrayList<>();
        SceneFrame.Light cube;
        final SceneFrame.Light[] cookies = new SceneFrame.Light[2];

        Roles(List<SceneFrame.Light> lights) {
            this.lights = lights;
            shadow = new int[lights.size()];
            cookie = new int[lights.size()];
            int nc = 0;
            for (int i = 0; i < lights.size(); i++) {
                SceneFrame.Light l = lights.get(i);
                shadow[i] = -1;
                cookie[i] = -1;
                if (l.shadows && !l.auto) {
                    if (l.type == SceneObject.LightType.POINT) { if (cube == null) { cube = l; shadow[i] = 2; } }
                    else if (maps.size() < 2) { shadow[i] = maps.size(); maps.add(l); }
                }
                if (l.type == SceneObject.LightType.SPOT && l.cookie != null && !l.cookie.isBlank() && nc < 2) { cookie[i] = nc; cookies[nc++] = l; }
            }
        }
    }

    /** Матриці/параметри тіней кадру (у просторі «відносно камери»). */
    private static final class Shadows {
        final Matrix4f[] mats = new Matrix4f[2];
        final float[][] info = new float[2][];
        float[] cube, cubeInfo;
    }

    // ═════════════════════════ кадр ═════════════════════════

    /** @return GL-id текстури результату (RGBA8, premultiplied alpha) або 0 — рендер недоступний */
    public int render(Input in) {
        RenderSystem.assertOnRenderThread();
        if (!init()) return 0;
        Minecraft mc = Minecraft.getInstance();
        SceneFrame f = in.frame;
        SceneLook look = f.look != null ? f.look : DEFAULT_LOOK;
        double t = f.time;
        int w = Math.max(8, in.width), h = Math.max(8, in.height);
        Q q = quality(look, w, h);
        float scale = Math.min(q.ss, 2560f / Math.max(w, h));
        int sw = Math.max(8, Math.round(w * scale)), sh = Math.max(8, Math.round(h * scale));
        MenuFrame menu = in.menu != null ? in.menu : new MenuFrame();
        double[] center = in.stageCenter != null ? in.stageCenter : new double[] { f.camera.x, f.camera.y, f.camera.z };
        double radius = menu.stageRadius;

        // ── камера ──
        SceneFrame.Cam cam = new SceneFrame.Cam();
        if (f.hasCamera) cam.set(f.camera);
        else { cam.x = center[0]; cam.y = center[1] + 1.6; cam.z = center[2] - 6; cam.fov = 50; }
        camRef = cam;
        float hov = Math.max(0, Math.min(1, in.hover));
        float fov = (float) Math.max(5, cam.fov * (1 - menu.hoverDolly * hov));
        float yaw = cam.yaw + in.parallaxX * in.parallaxDeg * hov, pitch = cam.pitch + in.parallaxY * in.parallaxDeg * hov;
        double camDist = Math.sqrt(sq(cam.x - center[0]) + sq(cam.y - center[1]) + sq(cam.z - center[2]));
        float far = (float) Math.max(64, camDist + radius * 1.6 + 16);
        Matrix4f view = new Matrix4f().rotateZ((float) Math.toRadians(cam.roll)).rotateX((float) Math.toRadians(pitch)).rotateY((float) Math.toRadians(yaw + 180));
        Matrix4f proj = new Matrix4f().perspective((float) Math.toRadians(fov), w / (float) h, 0.05f, far);
        Matrix4f viewProj = new Matrix4f(proj).mul(view);
        FrustumIntersection frustum = new FrustumIntersection(viewProj);

        // ── сцена світу ──
        ClientLevel level = mc.level;
        StageMesher.Stage stage = null;
        if (level != null) {
            stage = StageMesher.stage(level, center[0], center[1], center[2], radius, cam.x, cam.y, cam.z);
            StageMesher.update(stage, 4);
            stageProgress = stage.progress();
            if ((System.nanoTime() & 0x3F) == 0) StageMesher.gc();
        } else stageProgress = 1;

        // ── світла: сцени + авто-світло блоків ──
        Roles roles = new Roles(pickLights(f.lights, autoLights(look, stage, cam), cam));

        // ── захоплення акторів / блок-сутностей / сутностей (до будь-якої зміни фреймбуфера) ──
        capture.reset();
        PoseStack ps = new PoseStack();
        for (SceneFrame.Actor a : f.actors) {
            if (!a.visible) continue;
            ps.pushPose();
            ps.translate(a.x - cam.x, a.y - cam.y, a.z - cam.z);
            try { SceneRender.actor(ps, capture, a, in.clips, in.doc, actorLight(level, a), 1f); } catch (RuntimeException ignored) { }
            ps.popPose();
        }
        if (stage != null) {
            captureBlockEntities(stage, level, cam, in.partial, ps);
            if (look.worldEntities) captureEntities(level, center, radius, cam, in.partial, ps);
        }
        capture.finish();
        int[] cookieTex = { cookieTexture(roles.cookies[0], in.doc), cookieTexture(roles.cookies[1], in.doc) };

        // ── стан гри, який змінимо ──
        boolean scissor = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
        int[] box = new int[4];
        if (scissor) GL11.glGetIntegerv(GL11.GL_SCISSOR_BOX, box);
        boolean blendOn = GL11.glIsEnabled(GL11.GL_BLEND), depthOn = GL11.glIsEnabled(GL11.GL_DEPTH_TEST), cullOn = GL11.glIsEnabled(GL11.GL_CULL_FACE);
        boolean depthMask = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
        int activeTex = GlStateManager._getActiveTexture();
        GlStateManager._disableScissorTest();
        try {
            int texAtlas = mc.getTextureManager().getTexture(TextureAtlas.LOCATION_BLOCKS).getId();

            // ── тіні ──
            Shadows shd = new Shadows();
            for (int k = 0; k < roles.maps.size(); k++) {
                SceneFrame.Light l = roles.maps.get(k);
                Matrix4f lightVP = lightMatrix(l, center, radius);
                int res = l.type == SceneObject.LightType.SUN ? q.shadow : Math.max(512, q.shadow / 2);
                renderShadow(k, l, lightVP, res, stage, center, cam, texAtlas);
                shd.mats[k] = new Matrix4f(lightVP).translate((float) (cam.x - center[0]), (float) (cam.y - center[1]), (float) (cam.z - center[2]));
                float world = l.type == SceneObject.LightType.SUN ? (float) ((radius + 4) * 2 / res)
                    : (float) (Math.tan(Math.toRadians(Math.min(170, l.spotAngle + 10)) / 2) * l.range / res);
                shd.info[k] = new float[] { 1f / res, world * 1.2f, l.softness * look.shadowSoftness, l.type == SceneObject.LightType.SUN ? 0.0004f : 0.00006f };
            }
            if (roles.cube != null) {
                SceneFrame.Light l = roles.cube;
                int res = Math.max(256, q.shadow / 4);
                renderCube(l, res, stage, center, cam, texAtlas);
                shd.cube = new float[] { (float) (l.x - cam.x), (float) (l.y - cam.y), (float) (l.z - cam.z) };
                shd.cubeInfo = new float[] { Math.max(1, l.range), (float) (l.range * 2 / res), l.softness * look.shadowSoftness, 0.004f };
            }

            // ── кадр HDR ──
            hdr.ensure(sw, sh);
            hdr.bind();
            RenderSystem.clearColor(0, 0, 0, 0);
            RenderSystem.clearDepth(1);
            RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
            RenderSystem.colorMask(true, true, true, true);
            drawSky(look, t, view, proj, roles.lights);

            RenderSystem.enableDepthTest();
            RenderSystem.depthFunc(GL11.GL_LEQUAL);
            RenderSystem.depthMask(true);
            RenderSystem.disableBlend();
            bindShadowAndCookies(roles, cookieTex);
            float fogEnd = (float) look.at(SceneLook.FOG_END, t);
            if (fogEnd <= 0) fogEnd = (float) (camDist + radius);
            float fogStart = look.fogStart > 0 ? look.fogStart : fogEnd * 0.55f;
            int fogRgb = look.fogColor >= 0 ? look.fogColor : look.skyHorizon;
            boolean fogOn = look.sky != SceneLook.Sky.NONE;
            float[] fogCol = fogOn ? lin(fogRgb, (float) look.at(SceneLook.SKY_INTENSITY, t)) : new float[3];
            float fogEndU = fogOn ? fogEnd : 0;

            // світ: solid, cutout_mipped, cutout
            AbstractTexture atlas = mc.getTextureManager().getTexture(TextureAtlas.LOCATION_BLOCKS);
            List<StageMesher.Section> visible = new ArrayList<>();
            if (stage != null) for (StageMesher.Section s : stage.sections) {
                if (!s.built) continue;
                float x0 = (float) (s.origin.getX() - cam.x), y0 = (float) (s.origin.getY() - cam.y), z0 = (float) (s.origin.getZ() - cam.z);
                if (frustum.testAab(x0, y0, z0, x0 + 16, y0 + 16, z0 + 16)) visible.add(s);
            }
            setupLit(terrain, look, t, viewProj, roles, shd, fogStart, fogEndU, fogCol);
            terrain.set("uUnshade", look.unshade ? 1f : 0f);
            terrain.set("uEmissive", 0f);
            terrain.set("uOpaque", 1f);
            RenderSystem.enableCull();
            for (int layer = StageMesher.SOLID; layer <= StageMesher.CUTOUT; layer++) {
                RenderSystem.activeTexture(GL13.GL_TEXTURE0);
                atlas.setFilter(false, layer != StageMesher.CUTOUT);
                RenderSystem.bindTexture(texAtlas);
                terrain.set("uAlphaCut", layer == StageMesher.SOLID ? -1f : layer == StageMesher.CUTOUT_MIPPED ? 0.5f : 0.1f);
                drawSections(visible, layer, cam);
            }
            atlas.setFilter(false, true);

            // актори й блок-сутності: непрозорі
            RenderSystem.disableCull();
            setupLit(entity, look, t, viewProj, roles, shd, fogStart, fogEndU, fogCol);
            entity.set("uOffset", 0f, 0f, 0f);
            entity.set("uUnshade", 0f);
            entity.set("uAlphaCut", 0.1f);
            entity.set("uOpaque", 1f);
            entity.set("uEmissive", 0f);
            for (CaptureBuffers.Draw d : capture.draws) if (!d.translucent) drawEntity(d);

            // прозоре: вода/скло (від дальніх секцій), потім прозорі частини акторів
            RenderSystem.enableBlend();
            premultipliedBlend();
            terrain.use();
            terrain.set("uAlphaCut", 0.004f);
            terrain.set("uOpaque", 0f);
            RenderSystem.enableCull();
            visible.sort(Comparator.comparingDouble((StageMesher.Section s) -> -(sq(s.origin.getX() + 8 - cam.x) + sq(s.origin.getY() + 8 - cam.y) + sq(s.origin.getZ() + 8 - cam.z))));
            RenderSystem.activeTexture(GL13.GL_TEXTURE0);
            RenderSystem.bindTexture(texAtlas);
            drawSections(visible, StageMesher.TRANSLUCENT, cam);
            RenderSystem.disableCull();
            entity.use();
            entity.set("uOpaque", 0f);
            entity.set("uAlphaCut", 0.004f);
            for (CaptureBuffers.Draw d : capture.draws) {
                if (!d.translucent) continue;
                entity.set("uEmissive", d.emissive ? 3f : 0f);
                if (d.emissive) RenderSystem.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE);
                RenderSystem.depthMask(!d.emissive);
                drawEntity(d);
                if (d.emissive) premultipliedBlend();
                RenderSystem.depthMask(true);
            }
            VertexBuffer.unbind();

            // ── пост ──
            RenderSystem.disableBlend();
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask(false);
            GlStateManager._glBindVertexArray(emptyVao);

            // об'ємні промені
            float volAmt = 0;
            vol.ensure(Math.max(4, w / 2), Math.max(4, h / 2));
            vol.bind();
            RenderSystem.clearColor(0, 0, 0, 0);
            RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT, Minecraft.ON_OSX);
            if (q.volume && look.vlIntensity > 0) volAmt = drawVolumes(look, roles, shd, view, proj, in.wall, cookieTex);

            float bloomAmt = q.bloom ? (float) look.at(SceneLook.BLOOM, t) : 0;
            int bw = Math.max(4, w / 4), bh = Math.max(4, h / 4);
            bloomA.ensure(bw, bh);
            if (bloomAmt > 0.001f) {
                half.ensure(Math.max(4, w / 2), Math.max(4, h / 2));
                bloomB.ensure(bw, bh);
                downsample(hdr, half, look.bloomThreshold);
                downsample(half, bloomA, -1);
                for (int pass = 0; pass < 2; pass++) {
                    float r = look.bloomRadius * (pass + 1);
                    blurPass(bloomA, bloomB, r / bw, 0);
                    blurPass(bloomB, bloomA, 0, r / bh);
                }
            } else {
                bloomA.bind();
                RenderSystem.clearColor(0, 0, 0, 0);
                RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT, Minecraft.ON_OSX);
            }
            ldr.ensure(w, h);
            ldr.bind();
            composite.use();
            composite.set("uHdrTexel", 1f / sw, 1f / sh);
            composite.set("uSpread", Math.max(0f, scale * 0.5f - 0.5f));
            composite.set("uExposure", (float) look.at(SceneLook.EXPOSURE, t));
            composite.set("uTonemap", look.tonemap.ordinal());
            float temp = (float) look.at(SceneLook.TEMPERATURE, t), tint = (float) look.at(SceneLook.TINT, t);
            float wr = 1 + 0.28f * temp, wg = 1 - 0.18f * tint, wb = 1 - 0.28f * temp;
            float wl = 0.2126f * wr + 0.7152f * wg + 0.0722f * wb;
            composite.set("uWB", wr / wl, wg / wl, wb / wl);
            composite.set("uContrast", (float) look.at(SceneLook.CONTRAST, t));
            composite.set("uSaturation", (float) look.at(SceneLook.SATURATION, t));
            composite.set("uLift", look.lift);
            composite.set("uGamma", Math.max(0.1f, look.gamma));
            composite.set("uGain", look.gain);
            float[] ssh = srgb(look.splitShadows), shi = srgb(look.splitHighlights);
            composite.set("uSplitShadow", ssh[0], ssh[1], ssh[2]);
            composite.set("uSplitHigh", shi[0], shi[1], shi[2]);
            composite.set("uSplit", look.splitAmount);
            composite.set("uBloomAmt", bloomAmt);
            composite.set("uVolAmt", volAmt);
            composite.set("uVignette", (float) look.at(SceneLook.VIGNETTE, t));
            composite.set("uVigSoft", look.vignetteSoftness);
            composite.set("uAspect", w / (float) h);
            composite.set("uGrain", look.grain);
            composite.set("uSharpen", look.sharpen);
            composite.set("uTime", (float) (in.wall % 1000));
            RenderSystem.activeTexture(GL13.GL_TEXTURE2);
            RenderSystem.bindTexture(vol.colorTex);
            RenderSystem.activeTexture(GL13.GL_TEXTURE1);
            RenderSystem.bindTexture(bloomA.colorTex);
            RenderSystem.activeTexture(GL13.GL_TEXTURE0);
            RenderSystem.bindTexture(hdr.colorTex);
            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
            return ldr.colorTex;
        } finally {
            restore(mc, scissor, box, blendOn, depthOn, cullOn, depthMask, activeTex);
        }
    }

    private static void premultipliedBlend() {
        RenderSystem.blendFuncSeparate(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
            GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
    }

    private void bindShadowAndCookies(Roles roles, int[] cookieTex) {
        for (int k = 0; k < 2; k++) {
            RenderSystem.activeTexture(GL13.GL_TEXTURE0 + UNIT_SHADOW0 + k);
            RenderSystem.bindTexture(k < roles.maps.size() ? shadowDyn[k].depthTex : 0);
            RenderSystem.activeTexture(GL13.GL_TEXTURE0 + UNIT_COOKIE0 + k);
            RenderSystem.bindTexture(cookieTex[k]);
        }
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + UNIT_CUBE);
        GL11.glBindTexture(GL13.GL_TEXTURE_CUBE_MAP, roles.cube != null ? cubeDyn.tex : 0);
        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
    }

    // ═════════════════════════ проходи ═════════════════════════

    private void drawSections(List<StageMesher.Section> visible, int layer, SceneFrame.Cam cam) {
        GlProgram p = terrain;
        p.use();
        for (StageMesher.Section s : visible) {
            if (!s.has[layer] || s.buffers[layer] == null) continue;
            p.set("uOffset", (float) (s.origin.getX() - cam.x), (float) (s.origin.getY() - cam.y), (float) (s.origin.getZ() - cam.z));
            s.buffers[layer].bind();
            s.buffers[layer].draw();
        }
    }

    private void drawEntity(CaptureBuffers.Draw d) {
        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        RenderSystem.bindTexture(d.texture);
        d.vb.bind();
        d.vb.draw();
    }

    private void drawSky(SceneLook look, double t, Matrix4f view, Matrix4f proj, List<SceneFrame.Light> lights) {
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableBlend();
        sky.use();
        Matrix4f inv = new Matrix4f(proj).mul(view).invert();
        sky.set("uInvViewProj", inv);
        float k = (float) look.at(SceneLook.SKY_INTENSITY, t);
        int top = look.skyTop, hor = look.skyHorizon;
        if (look.sky == SceneLook.Sky.WORLD) {
            ClientLevel level = Minecraft.getInstance().level;
            if (level != null) {
                var c = level.getSkyColor(Minecraft.getInstance().gameRenderer.getMainCamera().getPosition(), 1f);
                top = rgb(c.x, c.y, c.z);
                hor = rgb(c.x * 0.55 + 0.45, c.y * 0.55 + 0.45, c.z * 0.55 + 0.45);
            }
        }
        float[] a = lin(top, k), b = lin(hor, k), g = lin(look.ground, k);
        sky.set("uTop", a[0], a[1], a[2]);
        sky.set("uHorizon", b[0], b[1], b[2]);
        sky.set("uGround", g[0], g[1], g[2]);
        sky.set("uMode", switch (look.sky) { case COLOR -> 1f; case NONE -> 2f; default -> 0f; });
        float[] dirs = new float[6], cols = new float[6];
        int n = 0;
        for (SceneFrame.Light l : lights) {
            if (l.type != SceneObject.LightType.SUN || n >= 2) continue;
            dirs[n * 3] = (float) l.dx; dirs[n * 3 + 1] = (float) l.dy; dirs[n * 3 + 2] = (float) l.dz;
            float[] c = lin(l.r, l.g, l.b, l.intensity);
            System.arraycopy(c, 0, cols, n * 3, 3);
            n++;
        }
        sky.set("uSunCount", n);
        sky.setArray("uSunDir", dirs, 3);
        sky.setArray("uSunCol", cols, 3);
        GlStateManager._glBindVertexArray(emptyVao);
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
    }

    /** Тіні й кукі — спільні uniform-и поверхонь і променів. */
    private void setupShadowUniforms(GlProgram p, Roles roles, Shadows shd) {
        for (int k = 0; k < 2; k++) {
            if (shd.mats[k] == null) continue;
            p.set("uShadowMat" + k, shd.mats[k]);
            float[] si = shd.info[k];
            p.set("uShadowInfo" + k, si[0], si[1], si[2], si[3]);
        }
        if (shd.cube != null) {
            p.set("uCubePos", shd.cube[0], shd.cube[1], shd.cube[2]);
            p.set("uCubeInfo", shd.cubeInfo[0], shd.cubeInfo[1], shd.cubeInfo[2], shd.cubeInfo[3]);
        }
        for (int k = 0; k < 2; k++) {
            SceneFrame.Light l = roles.cookies[k];
            if (l == null) continue;
            double r = Math.toRadians(l.cookieRotation);
            p.set("uCookieP" + k, (float) Math.cos(r), (float) Math.sin(r), Math.max(0.05f, l.cookieScale), l.cookieInvert ? 1f : 0f);
        }
    }

    private void setupLit(GlProgram p, SceneLook look, double t, Matrix4f viewProj, Roles roles, Shadows shd, float fogStart, float fogEnd, float[] fogCol) {
        p.use();
        p.set("uViewProj", viewProj);
        float[] sky = lin(look.skyLightColor, (float) look.at(SceneLook.SKY_LIGHT, t));
        float[] blk = lin(look.blockLightColor, (float) look.at(SceneLook.BLOCK_LIGHT, t));
        float[] amb = lin(look.ambientColor, (float) look.at(SceneLook.AMBIENT, t));
        p.set("uSkyCol", sky[0], sky[1], sky[2]);
        p.set("uBlockCol", blk[0], blk[1], blk[2]);
        p.set("uAmbient", amb[0], amb[1], amb[2]);
        p.set("uSpecular", look.specular);
        List<SceneFrame.Light> lights = roles.lights;
        int max = MenuShaders.MAX_LIGHTS;
        int n = Math.min(max, lights.size());
        float[] pos = new float[max * 3], dir = new float[max * 3], col = new float[max * 3], par = new float[max * 4], ex = new float[max * 4];
        SceneFrame.Cam cam = camRef;
        for (int i = 0; i < n; i++) {
            SceneFrame.Light l = lights.get(i);
            pos[i * 3] = (float) (l.x - cam.x); pos[i * 3 + 1] = (float) (l.y - cam.y); pos[i * 3 + 2] = (float) (l.z - cam.z);
            dir[i * 3] = (float) l.dx; dir[i * 3 + 1] = (float) l.dy; dir[i * 3 + 2] = (float) l.dz;
            System.arraycopy(lin(l.r, l.g, l.b, l.intensity), 0, col, i * 3, 3);
            float[] cone = cone(l);
            par[i * 4] = l.type == SceneObject.LightType.SUN ? 2 : l.type == SceneObject.LightType.SPOT ? 1 : 0;
            par[i * 4 + 1] = Math.max(0.5f, l.range);
            par[i * 4 + 2] = cone[0];
            par[i * 4 + 3] = cone[1];
            ex[i * 4] = roles.shadow[i];
            ex[i * 4 + 1] = l.specular;
            ex[i * 4 + 2] = l.target;
            ex[i * 4 + 3] = roles.cookie[i];
        }
        p.set("uLightCount", n);
        p.setArray("uLPos", pos, 3);
        p.setArray("uLDir", dir, 3);
        p.setArray("uLCol", col, 3);
        p.setArray("uLParam", par, 4);
        p.setArray("uLExtra", ex, 4);
        setupShadowUniforms(p, roles, shd);
        p.set("uToon", look.toonBands, look.toonSmooth);
        p.set("uOutline", look.outline ? look.outlineStrength : 0f, look.outlinePower, look.outlineBack, look.outlineFront);
        p.set("uOutline2", look.outlineGlow, look.outlineTarget);
        p.set("uFog", fogStart, fogEnd);
        p.set("uFogCol", fogCol[0], fogCol[1], fogCol[2]);
    }

    /** cos зовнішнього і внутрішнього півкута конуса (як LightMath.cone у irl-core: внутрішній ≤ зовнішнього). */
    private static float[] cone(SceneFrame.Light l) {
        float outerDeg = Math.max(1, Math.min(179, l.spotAngle));
        float innerDeg = l.spotInner > 0 ? Math.min(l.spotInner, outerDeg) : outerDeg * (1 - Math.max(0.02f, Math.min(1, l.spotBlend)));
        return new float[] { (float) Math.cos(Math.toRadians(outerDeg / 2)), (float) Math.cos(Math.toRadians(innerDeg / 2)) };
    }

    /** Об'ємні промені в {@link #vol}. @return множник для композиту (0 — нема променів) */
    private float drawVolumes(SceneLook look, Roles roles, Shadows shd, Matrix4f view, Matrix4f proj, double wall, int[] cookieTex) {
        List<SceneFrame.Light> beams = new ArrayList<>();
        List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < roles.lights.size() && beams.size() < MenuShaders.MAX_VOLUMES; i++) {
            SceneFrame.Light l = roles.lights.get(i);
            if (l.beam > 0.001f && !l.auto) { beams.add(l); idx.add(i); }
        }
        if (beams.isEmpty()) return 0;
        SceneFrame.Cam cam = camRef;
        int m = MenuShaders.MAX_VOLUMES;
        float[] pos = new float[m * 3], dir = new float[m * 3], col = new float[m * 3], par = new float[m * 4], ex = new float[m * 4];
        for (int i = 0; i < beams.size(); i++) {
            SceneFrame.Light l = beams.get(i);
            int li = idx.get(i);
            pos[i * 3] = (float) (l.x - cam.x); pos[i * 3 + 1] = (float) (l.y - cam.y); pos[i * 3 + 2] = (float) (l.z - cam.z);
            dir[i * 3] = (float) l.dx; dir[i * 3 + 1] = (float) l.dy; dir[i * 3 + 2] = (float) l.dz;
            System.arraycopy(lin(l.r, l.g, l.b, l.intensity * l.beam * look.vlIntensity), 0, col, i * 3, 3);
            float[] cone = cone(l);
            par[i * 4] = l.type == SceneObject.LightType.SUN ? 2 : l.type == SceneObject.LightType.SPOT ? 1 : 0;
            par[i * 4 + 1] = Math.max(0.5f, l.range);
            par[i * 4 + 2] = cone[0];
            par[i * 4 + 3] = cone[1];
            ex[i * 4] = Math.max(0.005f, l.vlDensity);
            ex[i * 4 + 1] = Math.max(-0.95f, Math.min(0.95f, l.anisotropy));
            ex[i * 4 + 2] = roles.shadow[li];
            ex[i * 4 + 3] = roles.cookie[li];
        }
        volume.use();
        volume.set("uInvViewProj", new Matrix4f(proj).mul(view).invert());
        volume.set("uVCount", beams.size());
        volume.setArray("uVPos", pos, 3);
        volume.setArray("uVDir", dir, 3);
        volume.setArray("uVCol", col, 3);
        volume.setArray("uVParam", par, 4);
        volume.setArray("uVExtra", ex, 4);
        volume.set("uVlA", Math.max(4, Math.min(96, look.vlSteps)), look.vlMaxDist, look.vlTipBoost, look.vlTipRadius);
        volume.set("uVlB", look.vlNoise ? look.vlNoiseAmount : 0f, look.vlNoiseScale, look.vlNoiseSpeed, look.vlShadows ? 1f : 0f);
        volume.set("uTime", (float) (wall % 3600));
        setupShadowUniforms(volume, roles, shd);
        bindShadowAndCookies(roles, cookieTex);
        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        RenderSystem.bindTexture(hdr.depthTex);
        GlStateManager._glBindVertexArray(emptyVao);
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
        return 1f;
    }

    // ═════════════════════════ тіні ═════════════════════════

    private void renderShadow(int k, SceneFrame.Light l, Matrix4f lightVP, int res, StageMesher.Stage stage, double[] center,
                              SceneFrame.Cam cam, int texAtlas) {
        Fbo st = shadowStatic[k], dyn = shadowDyn[k];
        float[] key = { (float) l.dx, (float) l.dy, (float) l.dz, (float) l.x, (float) l.y, (float) l.z, l.spotAngle, l.range, res,
            (float) center[0], (float) center[1], (float) center[2] };
        boolean rebuild = needStatic(k, key, stage) || st.width != res;
        beginShadowState();
        depth.use();
        depth.set("uMVP", lightVP);
        depth.set("uLinear", 0f);
        if (rebuild) {
            st.ensure(res, res);
            st.bind();
            RenderSystem.clearDepth(1);
            RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
            drawStageDepth(stage, center, texAtlas, null, 0);
            markStatic(k, key, stage);
        }
        dyn.ensure(res, res);
        GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, st.fbo);
        GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, dyn.fbo);
        GlStateManager._glBlitFrameBuffer(0, 0, res, res, 0, 0, res, res, GL11.GL_DEPTH_BUFFER_BIT, GL11.GL_NEAREST);
        dyn.bind();
        drawActorsDepth(cam, center);
        endShadowState();
    }

    /** Кубічна тінь точкового світла: 6 граней 90°, лінійна глибина (відстань / дальність). */
    private void renderCube(SceneFrame.Light l, int res, StageMesher.Stage stage, double[] center, SceneFrame.Cam cam, int texAtlas) {
        float[] key = { (float) l.x, (float) l.y, (float) l.z, l.range, res, (float) center[0], (float) center[1], (float) center[2] };
        boolean rebuild = needStatic(2, key, stage) || cubeStatic.res != res;
        cubeStatic.ensure(res);
        cubeDyn.ensure(res);
        Vector3f lp = new Vector3f((float) (l.x - center[0]), (float) (l.y - center[1]), (float) (l.z - center[2]));
        float far = Math.max(1, l.range);
        beginShadowState();
        depth.use();
        depth.set("uLinear", far);
        depth.set("uLightPos", lp.x, lp.y, lp.z);
        for (int face = 0; face < 6; face++) {
            Matrix4f vp = CubeShadow.faceMatrix(face, lp, far);
            depth.set("uMVP", vp);
            if (rebuild) {
                cubeStatic.bindFace(face);
                RenderSystem.clearDepth(1);
                RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
                drawStageDepth(stage, center, texAtlas, lp, far);
            }
            CubeShadow.blitFace(cubeStatic, cubeDyn, face);
            cubeDyn.bindFace(face);
            drawActorsDepth(cam, center);
        }
        if (rebuild) markStatic(2, key, stage);
        depth.set("uLinear", 0f);
        endShadowState();
    }

    private boolean needStatic(int k, float[] key, StageMesher.Stage stage) {
        int version = stage == null ? 0 : stage.version;
        boolean keyChanged = staticKey[k] == null || !same(staticKey[k], key);
        boolean worldChanged = version != staticVersion[k] && System.nanoTime() - staticAt[k] > 1_000_000_000L;
        return keyChanged || worldChanged;
    }

    private void markStatic(int k, float[] key, StageMesher.Stage stage) {
        staticKey[k] = key;
        staticVersion[k] = stage == null ? 0 : stage.version;
        staticAt[k] = System.nanoTime();
    }

    private static void beginShadowState() {
        RenderSystem.enableDepthTest();
        RenderSystem.depthFunc(GL11.GL_LEQUAL);
        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        RenderSystem.disableCull();
        RenderSystem.enablePolygonOffset();
        RenderSystem.polygonOffset(1.1f, 4f);
    }

    private static void endShadowState() {
        VertexBuffer.unbind();
        RenderSystem.polygonOffset(0f, 0f);
        RenderSystem.disablePolygonOffset();
    }

    /** Глибина світу сцени (простір сцени); lp/far — лише секції в радіусі точкового світла. */
    private void drawStageDepth(StageMesher.Stage stage, double[] center, int texAtlas, Vector3f lp, float far) {
        if (stage == null) return;
        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        RenderSystem.bindTexture(texAtlas);
        for (StageMesher.Section s : stage.sections) {
            if (!s.built) continue;
            float ox = (float) (s.origin.getX() - center[0]), oy = (float) (s.origin.getY() - center[1]), oz = (float) (s.origin.getZ() - center[2]);
            if (lp != null) {
                float dx = ox + 8 - lp.x, dy = oy + 8 - lp.y, dz = oz + 8 - lp.z;
                if (dx * dx + dy * dy + dz * dz > (far + 14) * (far + 14)) continue;
            }
            depth.set("uOffset", ox, oy, oz);
            for (int layer = StageMesher.SOLID; layer <= StageMesher.CUTOUT; layer++) {
                if (!s.has[layer] || s.buffers[layer] == null) continue;
                depth.set("uAlphaCut", layer == StageMesher.SOLID ? 0f : 0.5f);
                s.buffers[layer].bind();
                s.buffers[layer].draw();
            }
        }
    }

    private void drawActorsDepth(SceneFrame.Cam cam, double[] center) {
        depth.set("uOffset", (float) (cam.x - center[0]), (float) (cam.y - center[1]), (float) (cam.z - center[2]));
        depth.set("uAlphaCut", 0.1f);
        for (CaptureBuffers.Draw d : capture.draws) {
            if (d.emissive) continue;
            RenderSystem.activeTexture(GL13.GL_TEXTURE0);
            RenderSystem.bindTexture(d.texture);
            d.vb.bind();
            d.vb.draw();
        }
    }

    /** Матриця світла в просторі сцени (початок — центр сцени). */
    private static Matrix4f lightMatrix(SceneFrame.Light l, double[] center, double radius) {
        Vector3f d = new Vector3f((float) l.dx, (float) l.dy, (float) l.dz).normalize();
        Vector3f up = Math.abs(d.y) > 0.98f ? new Vector3f(0, 0, 1) : new Vector3f(0, 1, 0);
        if (l.type == SceneObject.LightType.SUN) {
            float r = (float) radius + 4;
            Vector3f eye = new Vector3f(d).mul(-r * 2);
            Matrix4f v = new Matrix4f().lookAt(eye, new Vector3f(0, 0, 0), up);
            return new Matrix4f().ortho(-r, r, -r, r, 0.5f, r * 4).mul(v);
        }
        Vector3f p = new Vector3f((float) (l.x - center[0]), (float) (l.y - center[1]), (float) (l.z - center[2]));
        Matrix4f v = new Matrix4f().lookAt(p, new Vector3f(p).add(d), up);
        float ang = (float) Math.toRadians(Math.min(170, l.spotAngle + 10));
        return new Matrix4f().perspective(ang, 1, 0.1f, Math.max(1, l.range)).mul(v);
    }

    private void downsample(Fbo src, Fbo dst, float threshold) {
        dst.bind();
        down.use();
        down.set("uTexel", 1f / src.width, 1f / src.height);
        float ratio = src.width / (float) dst.width;
        down.set("uSpread", Math.max(0.5f, ratio * 0.5f - 0.5f));
        down.set("uThreshold", threshold);
        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        RenderSystem.bindTexture(src.colorTex);
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
    }

    private void blurPass(Fbo src, Fbo dst, float dx, float dy) {
        dst.bind();
        blur.use();
        blur.set("uDir", dx, dy);
        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        RenderSystem.bindTexture(src.colorTex);
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
    }

    // ═════════════════════════ світла ═════════════════════════

    /** Авто-світло: відкриті випромінювачі сцени, найближчі до камери, з множниками вигляду. */
    private static List<SceneFrame.Light> autoLights(SceneLook look, StageMesher.Stage stage, SceneFrame.Cam cam) {
        List<SceneFrame.Light> out = new ArrayList<>();
        if (!look.autoLights || stage == null || look.autoLightMax <= 0) return out;
        double r2 = sq(stage.radius + 4);
        List<float[]> found = new ArrayList<>();
        for (StageMesher.Section s : stage.sections) {
            for (float[] e : s.emitters) {
                if (look.autoLightCulling && e.length > 8 && e[8] < 0.5f) continue;
                if (sq(e[0] - stage.cx) + sq(e[1] - stage.cy) + sq(e[2] - stage.cz) > r2) continue;
                found.add(e);
            }
        }
        found.sort(Comparator.comparingDouble(e -> sq(e[0] - cam.x) + sq(e[1] - cam.y) + sq(e[2] - cam.z)));
        for (int i = 0; i < found.size() && i < look.autoLightMax; i++) {
            float[] e = found.get(i);
            SceneFrame.Light l = new SceneFrame.Light();
            l.type = SceneObject.LightType.POINT;
            l.auto = true;
            l.x = e[0]; l.y = e[1]; l.z = e[2];
            // таблиця — лінійні кольори; світло сцени задається в sRGB
            l.r = (float) Math.pow(e[3], 1 / 2.2); l.g = (float) Math.pow(e[4], 1 / 2.2); l.b = (float) Math.pow(e[5], 1 / 2.2);
            l.intensity = e[6] * look.autoLightIntensity;
            l.range = e[7] * look.autoLightReach;
            l.specular = 0.5f;
            out.add(l);
        }
        return out;
    }

    /** Світла сцени першими (сонця, далі за силою й близькістю), авто-світло — у вільні з 32 місць. */
    private static List<SceneFrame.Light> pickLights(List<SceneFrame.Light> all, List<SceneFrame.Light> auto, SceneFrame.Cam cam) {
        List<SceneFrame.Light> l = new ArrayList<>();
        for (SceneFrame.Light x : all) if (x.intensity > 1e-4f) l.add(x);
        l.sort(Comparator.comparingDouble((SceneFrame.Light x) -> {
            if (x.type == SceneObject.LightType.SUN) return -1e9 - x.intensity;
            double d2 = sq(x.x - cam.x) + sq(x.y - cam.y) + sq(x.z - cam.z);
            return -(x.intensity * (x.shadows ? 4 : 1) * (x.beam > 0 ? 4 : 1)) / (1 + d2 / (x.range * x.range));
        }));
        for (SceneFrame.Light a : auto) { if (l.size() >= MenuShaders.MAX_LIGHTS) break; l.add(a); }
        while (l.size() > MenuShaders.MAX_LIGHTS) l.remove(l.size() - 1);
        return l;
    }

    /** Текстура кукі (ассет-картинка світу або {@code ns:шлях.png}); 0 — нема. */
    private static int cookieTexture(SceneFrame.Light l, SceneDoc doc) {
        if (l == null || l.cookie == null || l.cookie.isBlank()) return 0;
        try {
            ResourceLocation rl = l.cookie.contains(":") ? ResourceLocation.tryParse(l.cookie) : doc == null ? null : SceneAssets.texture(doc, l.cookie);
            if (rl == null) return 0;
            return Minecraft.getInstance().getTextureManager().getTexture(rl).getId();
        } catch (RuntimeException e) {
            return 0;
        }
    }

    // ═════════════════════════ захоплення ═════════════════════════

    private static int actorLight(ClientLevel level, SceneFrame.Actor a) {
        if (level == null) return LightTexture.pack(0, 15);
        return LevelRenderer.getLightColor(level, BlockPos.containing(a.x, a.y + 0.6, a.z));
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    private void captureBlockEntities(StageMesher.Stage stage, ClientLevel level, SceneFrame.Cam cam, float partial, PoseStack ps) {
        var dispatcher = Minecraft.getInstance().getBlockEntityRenderDispatcher();
        double r2 = sq(stage.radius + 2);
        for (StageMesher.Section s : stage.sections) {
            for (BlockEntity be : s.blockEntities) {
                if (be.isRemoved()) continue;
                BlockPos p = be.getBlockPos();
                if (sq(p.getX() + 0.5 - stage.cx) + sq(p.getY() + 0.5 - stage.cy) + sq(p.getZ() + 0.5 - stage.cz) > r2) continue;
                BlockEntityRenderer r = dispatcher.getRenderer(be);
                if (r == null) continue;
                ps.pushPose();
                ps.translate(p.getX() - cam.x, p.getY() - cam.y, p.getZ() - cam.z);
                try { r.render(be, partial, ps, capture, LevelRenderer.getLightColor(level, p), OverlayTexture.NO_OVERLAY); } catch (RuntimeException ignored) { }
                ps.popPose();
            }
        }
    }

    private void captureEntities(ClientLevel level, double[] center, double radius, SceneFrame.Cam cam, float partial, PoseStack ps) {
        Minecraft mc = Minecraft.getInstance();
        var dispatcher = mc.getEntityRenderDispatcher();
        double r2 = radius * radius;
        for (Entity e : level.entitiesForRendering()) {
            if (e == mc.player || e.isInvisible()) continue;
            if (sq(e.getX() - center[0]) + sq(e.getY() - center[1]) + sq(e.getZ() - center[2]) > r2) continue;
            double x = e.xOld + (e.getX() - e.xOld) * partial, y = e.yOld + (e.getY() - e.yOld) * partial, z = e.zOld + (e.getZ() - e.zOld) * partial;
            float yRot = e.getViewYRot(partial);
            try {
                dispatcher.render(e, x - cam.x, y - cam.y, z - cam.z, yRot, partial, ps, capture, dispatcher.getPackedLightCoords(e, partial));
            } catch (RuntimeException ignored) { }
        }
    }

    // ═════════════════════════ стан ═════════════════════════

    private static void restore(Minecraft mc, boolean scissor, int[] box, boolean blend, boolean depthTest, boolean cull, boolean depthMask, int activeTex) {
        VertexBuffer.unbind();
        GlStateManager._glBindVertexArray(0);
        GlStateManager._glUseProgram(0);
        // кеш «вже прив'язаного шейдера» гри: інакше наступний ShaderInstance.apply() пропустить glUseProgram
        var any = GameRenderer.getPositionTexShader();
        if (any != null) any.clear();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + UNIT_CUBE);
        GL11.glBindTexture(GL13.GL_TEXTURE_CUBE_MAP, 0);
        for (int i = UNIT_COOKIE1; i >= 0; i--) {
            RenderSystem.activeTexture(GL13.GL_TEXTURE0 + i);
            RenderSystem.bindTexture(0);
        }
        RenderSystem.activeTexture(activeTex);
        mc.getMainRenderTarget().bindWrite(true);
        RenderSystem.polygonOffset(0f, 0f);
        RenderSystem.disablePolygonOffset();
        RenderSystem.depthFunc(GL11.GL_LEQUAL);
        RenderSystem.depthMask(depthMask);
        RenderSystem.colorMask(true, true, true, true);
        if (blend) RenderSystem.enableBlend(); else RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
        if (depthTest) RenderSystem.enableDepthTest(); else RenderSystem.disableDepthTest();
        if (cull) RenderSystem.enableCull(); else RenderSystem.disableCull();
        if (scissor) {
            GlStateManager._enableScissorTest();
            GlStateManager._scissorBox(box[0], box[1], box[2], box[3]);
        }
    }

    // ═════════════════════════ кольори ═════════════════════════

    private static float[] lin(int rgb, float k) {
        return new float[] { (float) Math.pow(((rgb >> 16) & 255) / 255.0, 2.2) * k, (float) Math.pow(((rgb >> 8) & 255) / 255.0, 2.2) * k,
            (float) Math.pow((rgb & 255) / 255.0, 2.2) * k };
    }

    private static float[] lin(float r, float g, float b, float k) {
        return new float[] { (float) Math.pow(r, 2.2) * k, (float) Math.pow(g, 2.2) * k, (float) Math.pow(b, 2.2) * k };
    }

    private static float[] srgb(int rgb) { return new float[] { ((rgb >> 16) & 255) / 255f, ((rgb >> 8) & 255) / 255f, (rgb & 255) / 255f }; }

    private static int rgb(double r, double g, double b) {
        return ((int) (Math.max(0, Math.min(1, r)) * 255) << 16) | ((int) (Math.max(0, Math.min(1, g)) * 255) << 8) | (int) (Math.max(0, Math.min(1, b)) * 255);
    }

    private static boolean same(float[] a, float[] b) {
        if (a.length != b.length) return false;
        for (int i = 0; i < a.length; i++) if (Math.abs(a[i] - b[i]) > 1e-4f) return false;
        return true;
    }

    private static double sq(double d) { return d * d; }
}
