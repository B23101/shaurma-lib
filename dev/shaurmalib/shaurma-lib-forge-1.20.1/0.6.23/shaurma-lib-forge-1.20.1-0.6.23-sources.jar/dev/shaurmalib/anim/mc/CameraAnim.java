package dev.shaurmalib.anim.mc;

import dev.shaurmalib.anim.pose.Pose;
import dev.shaurmalib.anim.runtime.CameraSolver;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Камера першої особи за анімованою головою: впав — камера падає разом з головою, лягає на спину —
 * дивиться вгору, нахилився — нахиляється. Вмикається вагою {@code camera}/{@code camera_rotation}
 * у кліпі, запиті або правилі; переходить плавно разом з fade кліпа. Мишка працює поверх (кути додаються).
 *
 * Ваніль-рівень: міксин {@code Camera.setup} TAIL ставить позицію й yaw/pitch, міксин
 * {@code GameRenderer.bobHurt} додає крен — однаково на Forge/Fabric/NeoForge.
 */
public final class CameraAnim {

    private CameraAnim() {}

    private static final CameraSolver.Frame FRAME = new CameraSolver.Frame();
    private static float roll;
    /** Око перед обличчям (пікселі моделі): півголови (4) + запас, щоб не бачити зсередини голову/шию. */
    private static final float FACE_FORWARD = 3.5f;
    /**
     * Найменша відстань камери до блоків (блоки). Ванільне око — мінімум 0.3 від стіни (півширина хітбокса);
     * зсунута камера (обличчя, нахил, лежання) не підходить до блока ближче, ніж на це, інакше ближня площина
     * відсікання показує крізь стіну/підлогу.
     */
    private static final double WALL_MARGIN = 0.22;
    /** Чи цей кадр камеру поставив рушій (для власного гравця) — First-person Model тоді не зсуває тіло. */
    private static volatile boolean placedLocal;

    public static boolean placedLocal() { return placedLocal; }

    /** Результат для {@code Camera.setup}: null — камеру не чіпати. */
    public record Result(Vec3 position, float yRot, float xRot) {}

    public static Result apply(Entity entity, boolean detached, float partial, Vec3 camPos, float camYRot, float camXRot) {
        roll = 0;
        placedLocal = false;
        if (detached || !dev.shaurmalib.anim.ShaurmaAnim.headCamera() || !(entity instanceof LivingEntity e)) return null;
        if (McAnim.rigOf(e) == null || dev.shaurmalib.anim.ShaurmaAnim.find(e.getUUID()) == null) return null;
        Pose pose = McAnim.evaluate(e, partial, null, true);
        boolean body = dev.shaurmalib.anim.ShaurmaAnim.bodyCamera() && e instanceof net.minecraft.world.entity.player.Player;
        if (pose == null || !CameraSolver.solve(pose, FRAME, body ? 1f : 0f, body ? FACE_FORWARD : 0f)) return null;
        placedLocal = body;

        float bodyYaw = Mth.rotLerp(partial, e.yBodyRotO, e.yBodyRot) * Mth.DEG_TO_RAD;
        // сцена Blockbench: +X праворуч, +Y вгору, −Z вперед → світ за поворотом тіла
        double fx = -Mth.sin(bodyYaw), fz = Mth.cos(bodyYaw);   // вперед
        double rx = -Mth.cos(bodyYaw), rz = -Mth.sin(bodyYaw);  // праворуч
        // модель малюється в масштабі рендерера (гравець — 0.9375, PlayerRenderer.scale), а на шифті гра
        // опускає її на 0.125 блока (getRenderOffset) — око камери має бути там, де намальована голова
        boolean player = e instanceof net.minecraft.world.entity.player.Player;
        double s = (player ? 0.9375 : 1.0) / 16.0;
        double lx = FRAME.eyeX * s, ly = FRAME.eyeY * s, lz = FRAME.eyeZ * s;
        Vec3 base = e.getPosition(partial);
        if (player && e.isCrouching()) base = base.add(0, -0.125, 0);
        Vec3 target = new Vec3(base.x + rx * lx + fx * -lz, base.y + ly, base.z + rz * lx + fz * -lz);
        Vec3 pos = keepOutOfBlocks(e, camPos, camPos.lerp(target, FRAME.positionWeight));

        float w = FRAME.rotationWeight;
        roll = FRAME.roll * w;
        return new Result(pos, camYRot + FRAME.yaw * w, camXRot + FRAME.pitch * w);
    }

    /**
     * Камера йде від ванільного ока (воно завжди поза блоками) до цілі лише доки до блока лишається
     * {@link #WALL_MARGIN}: промінь по видимих формах блоків продовжено на запас за ціль.
     */
    private static Vec3 keepOutOfBlocks(LivingEntity e, Vec3 from, Vec3 to) {
        Vec3 d = to.subtract(from);
        double len = d.length();
        if (len < 1e-4) return to;
        Vec3 n = d.scale(1.0 / len);
        net.minecraft.world.phys.BlockHitResult hit = e.level().clip(new net.minecraft.world.level.ClipContext(
            from, to.add(n.scale(WALL_MARGIN)), net.minecraft.world.level.ClipContext.Block.VISUAL,
            net.minecraft.world.level.ClipContext.Fluid.NONE, e));
        if (hit.getType() == net.minecraft.world.phys.HitResult.Type.MISS) return to;
        double free = Math.max(0, hit.getLocation().distanceTo(from) - WALL_MARGIN);
        return from.add(n.scale(Math.min(free, len)));
    }

    /** Крен поточного кадру (градуси) для {@code GameRenderer.bobHurt}. */
    public static float roll() { return roll; }
}
