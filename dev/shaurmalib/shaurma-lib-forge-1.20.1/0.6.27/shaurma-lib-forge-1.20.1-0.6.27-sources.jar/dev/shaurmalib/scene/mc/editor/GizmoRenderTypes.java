package dev.shaurmalib.scene.mc.editor;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.RenderType;

import java.util.OptionalDouble;

/**
 * Лінії гізмо редактора БЕЗ тесту глибини: стрілки переміщення / кільця повороту завжди поверх моделей
 * і блоків (як у Blender), а не «провалюються» в актора. Наслідуємо RenderType лише заради захищених станів.
 */
public final class GizmoRenderTypes extends RenderType {

    public static final RenderType LINES_ON_TOP = RenderType.create("shaurma_scene_gizmo_lines",
            DefaultVertexFormat.POSITION_COLOR_NORMAL, VertexFormat.Mode.LINES, 1024, false, false,
            CompositeState.builder()
                    .setShaderState(RENDERTYPE_LINES_SHADER)
                    .setLineState(new LineStateShard(OptionalDouble.of(3.0)))
                    .setLayeringState(VIEW_OFFSET_Z_LAYERING)
                    .setTransparencyState(TRANSLUCENT_TRANSPARENCY)
                    .setWriteMaskState(COLOR_WRITE)
                    .setCullState(NO_CULL)
                    .setDepthTestState(NO_DEPTH_TEST)
                    .createCompositeState(false));

    private GizmoRenderTypes() {
        super("shaurma_scene_gizmo_dummy", DefaultVertexFormat.POSITION_COLOR, VertexFormat.Mode.QUADS, 256, false, false, () -> { }, () -> { });
    }
}
