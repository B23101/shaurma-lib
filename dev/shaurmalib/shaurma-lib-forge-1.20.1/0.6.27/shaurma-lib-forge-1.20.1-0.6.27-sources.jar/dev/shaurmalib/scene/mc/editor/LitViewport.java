package dev.shaurmalib.scene.mc.editor;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexSorting;
import dev.shaurmalib.scene.doc.MenuFrame;
import dev.shaurmalib.scene.edit.MenuChecks;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.mc.client.SceneCamera;
import dev.shaurmalib.scene.mc.client.menu.MenuRenderer;
import dev.shaurmalib.scene.mc.client.menu.MenuScene;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.MultiBufferSource;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

/**
 * В'юпорт «зі світлом» (як Rendered у Blender): той самий рендер, що віконце меню (світла, прожектори, тіні,
 * об'ємні промені, корекція «Колір»), але на весь кадр і з камери редактора — тієї самої пози, з якою щойно
 * намальовано світ, тож картинка й гізмо збігаються піксель у піксель. Каркаси/стрілки потім домальовуються
 * поверх уже в GUI-проході з матрицями світу. Якщо рендер недоступний — лишається звичайний світ.
 */
final class LitViewport {

    private LitViewport() {}

    private static final MenuRenderer RENDERER = new MenuRenderer();
    private static final MenuRenderer.Input IN = new MenuRenderer.Input();
    private static final SceneFrame.Cam CAM = new SceneFrame.Cam();
    private static double[] center;
    private static long centerAt;
    /** Мінімальний радіус сцени в редакторі: менше — і світ навколо зникає в небо, щойно відлетиш. */
    private static final double EDITOR_RADIUS = 64;

    static void close() { RENDERER.close(); }

    /** Чи є що «запалювати»: світла в сцені або свій вигляд (небо, корекція). */
    static boolean worthIt(SceneEditorScreen s) {
        if (s.variant().look != null) return true;
        for (var o : s.variant().objects) if (o.isLight()) return true;
        return false;
    }

    /**
     * Намалювати освітлений кадр у прямокутник (GUI) поверх світу. Кадр рендериться на весь екран (та сама
     * проєкція, що й у світу), видно лише вирізку через scissor.
     * @return true — намальовано
     */
    static boolean render(SceneEditorScreen s, GuiGraphics g, int x, int y, int w, int h, boolean fromCamera) {
        var mc = Minecraft.getInstance();
        var win = mc.getWindow();
        long now = System.nanoTime();
        MenuFrame f = MenuChecks.frame(s.variant(), s.def).copy();
        if (center == null || now - centerAt > 1_000_000_000L) {
            double[] c = MenuChecks.stageCenter(s.doc, s.variant(), f, s.clips);
            // сітка 8 бл: центр не «повзе» за кожним рухом актора, і чанки не перебудовуються щокадру
            center = new double[] { Math.floor(c[0] / 8) * 8, Math.floor(c[1] / 8) * 8, Math.floor(c[2] / 8) * 8 };
            centerAt = now;
        }
        f.stageRadius(Math.max(EDITOR_RADIUS, f.stageRadius));
        f.hoverDolly = 0;
        CAM.set(fromCamera && s.frame.hasCamera ? s.frame.camera : SceneCamera.last);
        IN.frame = s.frame;
        IN.doc = s.doc;
        IN.clips = s.clips;
        IN.menu = f;
        IN.stageCenter = center;
        IN.camera = CAM;
        IN.width = win.getWidth();
        IN.height = win.getHeight();
        IN.maxScale = 1f;
        IN.hover = 0;
        IN.parallaxX = 0;
        IN.parallaxY = 0;
        IN.partial = mc.getFrameTime();
        IN.wall = now / 1e9;
        g.flush();
        int tex = MenuScene.renderFrame(RENDERER, IN);
        if (tex == 0) return false;
        g.enableScissor(x, y, x + w, y + h);
        MenuScene.blit(g, tex, 0, 0, win.getGuiScaledWidth(), win.getGuiScaledHeight());
        g.disableScissor();
        if (RENDERER.stageProgress < 0.999f) g.fill(x, y + h - 2, x + (int) (w * RENDERER.stageProgress), y + h, 0xC0FFFFFF);
        return true;
    }

    /** Каркаси камер, світла, шляхи й стрілки гізмо — ще раз, поверх освітленого кадру (матриці світу). */
    static void overlay(SceneEditorScreen s, GuiGraphics g, int x, int y, int w, int h) {
        if (!EditorView.haveMatrices()) return;
        g.flush();
        Matrix4f oldProj = new Matrix4f(RenderSystem.getProjectionMatrix());
        VertexSorting oldSort = RenderSystem.getVertexSorting();
        PoseStack mv = RenderSystem.getModelViewStack();
        mv.pushPose();
        mv.setIdentity();
        RenderSystem.applyModelViewMatrix();
        RenderSystem.setProjectionMatrix(new Matrix4f(EditorView.projMatrix()), VertexSorting.DISTANCE_TO_ORIGIN);
        RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
        g.enableScissor(x, y, x + w, y + h);
        try {
            PoseStack ps = new PoseStack();
            ps.last().pose().set(EditorView.viewMatrix());
            ps.last().normal().set(new Matrix3f(EditorView.viewMatrix()));
            MultiBufferSource.BufferSource buffers = Minecraft.getInstance().renderBuffers().bufferSource();
            EditorOverlay.world(ps, buffers, EditorView.viewPos());
            buffers.endBatch();
        } finally {
            g.disableScissor();
            mv.popPose();
            RenderSystem.applyModelViewMatrix();
            RenderSystem.setProjectionMatrix(oldProj, oldSort);
            // глибина цих ліній не повинна ховати панелі GUI, що малюються далі
            RenderSystem.clear(GL11.GL_DEPTH_BUFFER_BIT, Minecraft.ON_OSX);
        }
    }
}
