package dev.shaurmalib.scene.mc.editor;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.mc.client.SceneAssets;
import dev.shaurmalib.scene.mc.client.SceneRender;
import dev.shaurmalib.scene.mc.client.SceneSkins;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Locale;
import java.util.UUID;

/**
 * «Модель гравця → редагована .bbmodel»: вбудована ванільна модель не є файлом, тож редагувати її на сторінках
 * «Модель»/«Малювання» не можна. Тут вона стає звичайним ассетом світу з тим самим ригом (head/torso/руки/ноги
 * з півотами {@code Rig.PLAYER} — кліпи й ключі пози діють як раніше) і другим шаром (капюшон, куртка, рукави,
 * штани). Скін актора вбудовується як текстура моделі; актор у слоті лишає мітку {@code player_skin} —
 * скін далі береться у гравця слота.
 */
final class PlayerModelCopy {

    private PlayerModelCopy() {}

    /** Чи можна запропонувати копію (вибрано актора з вбудованою моделлю гравця). */
    static boolean applicable(SceneEditorScreen s) {
        SceneObject o = s.selected();
        return o != null && !s.readOnly && (o.kind == SceneObject.Kind.ACTOR || o.kind == SceneObject.Kind.PROP)
            && o.modelType == SceneObject.ModelType.PLAYER;
    }

    static void convert(SceneEditorScreen s) {
        SceneObject o = s.selected();
        if (!applicable(s)) return;
        SceneFrame.Actor fa = s.frame.actor(o.id);
        SceneSkins.Skin skin = SceneSkins.resolve(o, fa == null ? null : fa.binding, s.doc);
        byte[] png = skinPng(skin.texture());
        boolean slim = skin.slim();
        String json = build(o.name, slim, png);
        byte[] data = json.getBytes(StandardCharsets.UTF_8);
        SceneDoc.Asset a = new SceneDoc.Asset();
        a.id = SceneDoc.newId();
        a.name = o.name.replaceAll("[\\\\/:*?\"<>|]", "_") + ".bbmodel";
        a.ext = "bbmodel";
        a.type = SceneDoc.Asset.Type.MODEL;
        a.size = data.length;
        try { a.sha256 = SceneAssets.store(data, "bbmodel"); }
        catch (Exception e) { s.toast("Не вдалося створити модель: " + e.getMessage()); return; }
        boolean keepSlotSkin = o.slot != null || png == null;
        s.edit("Модель гравця → .bbmodel", () -> {
            s.doc.assets.put(a.id, a);
            o.modelType = SceneObject.ModelType.ASSET;
            o.model = a.id;
            o.texture = null;
            if (keepSlotSkin) for (String b : BONES) o.boneLabels.put(b, SceneRender.SKIN_LABEL);
        });
        SceneAssets.upload(s.doc.id, a);
        s.toast(keepSlotSkin ? "Готово: модель можна правити. Скін — як і раніше, від гравця слота (мітка player_skin)"
            : "Готово: модель і скін можна правити («Модель» / «Малювання»)");
    }

    private static final String[] BONES = { "head", "torso", "right_arm", "left_arm", "right_leg", "left_leg" };

    /** PNG скіна з GPU (працює і для завантажених скінів, яких нема серед ресурсів). */
    private static byte[] skinPng(ResourceLocation rl) {
        try {
            var tm = Minecraft.getInstance().getTextureManager();
            int id = tm.getTexture(rl).getId();
            RenderSystem.bindTexture(id);
            int[] w = new int[1], h = new int[1];
            org.lwjgl.opengl.GL11.glGetTexLevelParameteriv(org.lwjgl.opengl.GL11.GL_TEXTURE_2D, 0, org.lwjgl.opengl.GL11.GL_TEXTURE_WIDTH, w);
            org.lwjgl.opengl.GL11.glGetTexLevelParameteriv(org.lwjgl.opengl.GL11.GL_TEXTURE_2D, 0, org.lwjgl.opengl.GL11.GL_TEXTURE_HEIGHT, h);
            if (w[0] != 64 || h[0] != 64) return null;
            try (NativeImage img = new NativeImage(64, 64, false)) {
                img.downloadTexture(0, false);
                return img.asByteArray();
            }
        } catch (Exception e) {
            return null;
        }
    }

    // ═════════════ .bbmodel ═════════════

    private static String build(String name, boolean slim, byte[] png) {
        int arm = slim ? 3 : 4;
        StringBuilder el = new StringBuilder(), out = new StringBuilder();
        // кістка: назва, півот, кубики {from, to, uv, inflate}
        Object[][] bones = {
            { "head", new double[] { 0, 24, 0 }, new double[][] { { -4, 24, -4, 4, 32, 4, 0, 0, 0 }, { -4, 24, -4, 4, 32, 4, 32, 0, 0.5 } } },
            { "torso", new double[] { 0, 24, 0 }, new double[][] { { -4, 12, -2, 4, 24, 2, 16, 16, 0 }, { -4, 12, -2, 4, 24, 2, 16, 32, 0.25 } } },
            { "right_arm", new double[] { 5, 22, 0 }, new double[][] { { 4, 12, -2, 4 + arm, 24, 2, 40, 16, 0 }, { 4, 12, -2, 4 + arm, 24, 2, 40, 32, 0.25 } } },
            { "left_arm", new double[] { -5, 22, 0 }, new double[][] { { -4 - arm, 12, -2, -4, 24, 2, 32, 48, 0 }, { -4 - arm, 12, -2, -4, 24, 2, 48, 48, 0.25 } } },
            { "right_leg", new double[] { 1.9, 12, 0 }, new double[][] { { -0.1, 0, -2, 3.9, 12, 2, 0, 16, 0 }, { -0.1, 0, -2, 3.9, 12, 2, 0, 32, 0.25 } } },
            { "left_leg", new double[] { -1.9, 12, 0 }, new double[][] { { -3.9, 0, -2, 0.1, 12, 2, 16, 48, 0 }, { -3.9, 0, -2, 0.1, 12, 2, 0, 48, 0.25 } } },
        };
        for (Object[] b : bones) {
            double[] piv = (double[]) b[1];
            StringBuilder kids = new StringBuilder();
            int n = 0;
            for (double[] c : (double[][]) b[2]) {
                String u = UUID.randomUUID().toString();
                if (el.length() > 0) el.append(',');
                el.append(String.format(Locale.ROOT,
                    "{\"name\":\"%s\",\"box_uv\":true,\"type\":\"cube\",\"uuid\":\"%s\",\"from\":[%s,%s,%s],\"to\":[%s,%s,%s],\"origin\":[%s,%s,%s],\"uv_offset\":[%d,%d]%s,\"faces\":%s}",
                    b[0] + (n == 0 ? "" : "_layer"), u, num(c[0]), num(c[1]), num(c[2]), num(c[3]), num(c[4]), num(c[5]),
                    num(piv[0]), num(piv[1]), num(piv[2]), (int) c[6], (int) c[7], c[8] != 0 ? ",\"inflate\":" + num(c[8]) : "",
                    faces((int) c[6], (int) c[7], c[3] - c[0], c[4] - c[1], c[5] - c[2])));
                if (n++ > 0) kids.append(',');
                kids.append('"').append(u).append('"');
            }
            if (out.length() > 0) out.append(',');
            out.append(String.format(Locale.ROOT,
                "{\"name\":\"%s\",\"origin\":[%s,%s,%s],\"rotation\":[0,0,0],\"uuid\":\"%s\",\"export\":true,\"isOpen\":true,\"children\":[%s]}",
                b[0], num(piv[0]), num(piv[1]), num(piv[2]), UUID.randomUUID(), kids));
        }
        String tex = png == null ? "" : String.format(Locale.ROOT,
            "{\"name\":\"skin.png\",\"uuid\":\"%s\",\"uv_width\":64,\"uv_height\":64,\"source\":\"data:image/png;base64,%s\"}",
            UUID.randomUUID(), Base64.getEncoder().encodeToString(png));
        return "{\"meta\":{\"format_version\":\"4.5\",\"model_format\":\"free\",\"box_uv\":true},\"name\":\"" + name.replace("\"", "'")
            + "\",\"resolution\":{\"width\":64,\"height\":64},\"elements\":[" + el + "],\"outliner\":[" + out + "],\"textures\":[" + tex + "]}";
    }

    /** Box UV граней (як рахує Blockbench) — щоб і в Blockbench, і в нашому читачі розкладка була однакова. */
    private static String faces(int u, int v, double w, double h, double d) {
        int W = (int) Math.round(w), H = (int) Math.round(h), D = (int) Math.round(d);
        int[][] f = {
            { u + D, v + D, u + D + W, v + D + H },                 // north
            { u, v + D, u + D, v + D + H },                         // east
            { u + D + W + D, v + D, u + D + W + D + W, v + D + H }, // south
            { u + D + W, v + D, u + D + W + D, v + D + H },         // west
            { u + D + W, v + D, u + D, v },                         // up
            { u + D + W, v, u + D + W + W, v + D },                 // down
        };
        String[] names = { "north", "east", "south", "west", "up", "down" };
        StringBuilder sb = new StringBuilder("{");
        for (int i = 0; i < 6; i++) {
            if (i > 0) sb.append(',');
            sb.append(String.format(Locale.ROOT, "\"%s\":{\"uv\":[%d,%d,%d,%d],\"texture\":0}", names[i], f[i][0], f[i][1], f[i][2], f[i][3]));
        }
        return sb.append('}').toString();
    }

    private static String num(double v) {
        return v == Math.rint(v) ? Long.toString((long) v) : String.format(Locale.ROOT, "%.4f", v).replaceAll("0+$", "");
    }
}
