package dev.shaurmalib.scene.mc.editor;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.eval.SceneFrame;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Vector4f;

/**
 * В'юпорт редактора як у Blender: орбіта навколо точки (СКМ), панорама (Shift+СКМ), наближення (колесо),
 * політ (ПКМ + WASD/QE, колесо — швидкість), види Numpad 1/3/7, вид з камери сцени (Numpad 0).
 * Камера редактора — не сутність: гравець стоїть, а чанки навколо далекої камери тримає сервер (VIEW).
 *
 * <p>Тут же проєкція світ→екран (для вибору кліком і підписів) за матрицями останнього кадру світу,
 * і малювання гізмо: каркаси камер, шляхи, осі вибраного, «пунктир» схованих акторів.
 */
public final class EditorView {

    double px, py, pz;          // точка орбіти
    double yaw = 30, pitch = 25, dist = 8;
    /** Політ: позиція ока задається прямо. */
    boolean flying;
    double flySpeed = 8;
    boolean cameraView;
    private final SceneFrame.Cam cam = new SceneFrame.Cam();
    private double sx, sy, sz, syaw, spitch, sdist;
    private boolean smoothInit;

    // матриці останнього кадру світу
    private static final Matrix4f VIEW = new Matrix4f(), PROJ = new Matrix4f();
    private static Vec3 viewPos = Vec3.ZERO;
    private static boolean haveMatrices;

    void reset(Vec3 eye, float eyeYaw) {
        yaw = eyeYaw + 160;
        pitch = 25;
        dist = 6;
        Vec3 f = Vec3.directionFromRotation(0, eyeYaw);
        px = eye.x + f.x * 3; py = eye.y - 0.5; pz = eye.z + f.z * 3;
        smoothInit = false;
    }

    /** Поза ока (орбіта з плавністю). */
    SceneFrame.Cam eye(float dt) {
        if (!smoothInit) { sx = px; sy = py; sz = pz; syaw = yaw; spitch = pitch; sdist = dist; smoothInit = true; }
        double k = 1 - Math.exp(-dt * 18);
        sx += (px - sx) * k; sy += (py - sy) * k; sz += (pz - sz) * k;
        syaw += Mth.wrapDegrees(yaw - syaw) * k;
        spitch += (pitch - spitch) * k;
        sdist += (dist - sdist) * k;
        Vec3 look = Vec3.directionFromRotation((float) spitch, (float) syaw);
        cam.x = sx - look.x * sdist;
        cam.y = sy - look.y * sdist;
        cam.z = sz - look.z * sdist;
        cam.yaw = (float) syaw;
        cam.pitch = (float) spitch;
        cam.roll = 0;
        cam.fov = 70;
        return cam;
    }

    void orbit(double dx, double dy) {
        yaw += dx * 0.4;
        pitch = Mth.clamp(pitch + dy * 0.4, -89.5, 89.5);
    }

    void pan(double dx, double dy) {
        double k = Math.max(0.6, dist) * 0.0022;
        Vec3 f = Vec3.directionFromRotation((float) pitch, (float) yaw);
        double ry = Math.toRadians(yaw);
        Vec3 r = new Vec3(-Math.cos(ry), 0, -Math.sin(ry));
        Vec3 u = r.cross(f).normalize();
        Vec3 d = r.scale(-dx * k).add(u.scale(dy * k));
        px += d.x; py += d.y; pz += d.z;
    }

    void zoom(double scroll) { dist = Mth.clamp(dist * (1 - scroll * 0.12), 0.3, 256); }

    /** Політ: рух ока (відносно погляду), точка орбіти їде разом. */
    void fly(double fwd, double right, double up, double dt) {
        Vec3 f = Vec3.directionFromRotation((float) pitch, (float) yaw);
        double ry = Math.toRadians(yaw);
        Vec3 r = new Vec3(-Math.cos(ry), 0, -Math.sin(ry));
        double s = flySpeed * dt;
        px += (f.x * fwd + r.x * right) * s;
        py += (f.y * fwd + up) * s;
        pz += (f.z * fwd + r.z * right) * s;
    }

    void look(double dx, double dy) {
        // у польоті обертаємо навколо ока: зсуваємо точку орбіти так, щоб око лишилось на місці
        SceneFrame.Cam e = eye(1);
        yaw += dx * 0.25;
        pitch = Mth.clamp(pitch + dy * 0.25, -89.5, 89.5);
        Vec3 look = Vec3.directionFromRotation((float) pitch, (float) yaw);
        px = e.x + look.x * dist; py = e.y + look.y * dist; pz = e.z + look.z * dist;
        sx = px; sy = py; sz = pz; syaw = yaw; spitch = pitch;
    }

    void snap(int view) {
        switch (view) {
            case 1 -> { yaw = 180; pitch = 0; }
            case 3 -> { yaw = 90; pitch = 0; }
            case 7 -> pitch = 89.5;
            case 9 -> yaw += 180;
        }
    }

    void focus(double x, double y, double z, double size) {
        px = x; py = y; pz = z;
        dist = Math.max(2, size * 2.5);
    }

    /** Поставити вид точно як камера (вихід з виду камери без стрибка). */
    void matchCamera(SceneFrame.Cam c) {
        Vec3 look = Vec3.directionFromRotation(c.pitch, c.yaw);
        dist = 4;
        px = c.x + look.x * dist; py = c.y + look.y * dist; pz = c.z + look.z * dist;
        yaw = c.yaw; pitch = c.pitch;
        smoothInit = false;
    }

    // ═════════════════════════ проєкція ═════════════════════════

    /** З кадру світу (RenderLevelStage): запам'ятати матриці для проєкції в GUI. */
    public static void captureMatrices(Matrix4f modelView, Matrix4f projection, Vec3 camera) {
        VIEW.set(modelView);
        PROJ.set(projection);
        viewPos = camera;
        haveMatrices = true;
    }

    /** Світ → координати GUI; null — за камерою. */
    static Matrix4f viewMatrix() { return VIEW; }
    static Matrix4f projMatrix() { return PROJ; }
    static Vec3 viewPos() { return viewPos; }
    static boolean haveMatrices() { return haveMatrices; }

    static double[] project(double x, double y, double z) {
        if (!haveMatrices) return null;
        Vector4f v = new Vector4f((float) (x - viewPos.x), (float) (y - viewPos.y), (float) (z - viewPos.z), 1f);
        VIEW.transform(v);
        PROJ.transform(v);
        if (v.w <= 0.01f) return null;
        double nx = v.x / v.w, ny = v.y / v.w;
        var win = Minecraft.getInstance().getWindow();
        return new double[] { (nx * 0.5 + 0.5) * win.getGuiScaledWidth(), (1 - (ny * 0.5 + 0.5)) * win.getGuiScaledHeight(), v.w };
    }

    /** Промінь з точки GUI у світ: {ox,oy,oz, dx,dy,dz}. */
    static double[] ray(double gx, double gy) {
        if (!haveMatrices) return null;
        var win = Minecraft.getInstance().getWindow();
        float nx = (float) (gx / win.getGuiScaledWidth() * 2 - 1), ny = (float) (1 - gy / win.getGuiScaledHeight() * 2);
        Matrix4f inv = new Matrix4f(PROJ).mul(VIEW).invert();
        Vector4f a = new Vector4f(nx, ny, -1, 1), b = new Vector4f(nx, ny, 1, 1);
        inv.transform(a);
        inv.transform(b);
        a.div(a.w);
        b.div(b.w);
        double dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z, len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        return new double[] { a.x + viewPos.x, a.y + viewPos.y, a.z + viewPos.z, dx / len, dy / len, dz / len };
    }

    // ═════════════════════════ гізмо у світі ═════════════════════════

    static void line(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, double x0, double y0, double z0, double x1, double y1, double z1, int argb) {
        float dx = (float) (x1 - x0), dy = (float) (y1 - y0), dz = (float) (z1 - z0);
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-5f) return;
        dx /= len; dy /= len; dz /= len;
        int a = argb >>> 24, r = argb >> 16 & 255, g = argb >> 8 & 255, b = argb & 255;
        vc.vertex(p.pose(), (float) (x0 - cam.x), (float) (y0 - cam.y), (float) (z0 - cam.z)).color(r, g, b, a).normal(p.normal(), dx, dy, dz).endVertex();
        vc.vertex(p.pose(), (float) (x1 - cam.x), (float) (y1 - cam.y), (float) (z1 - cam.z)).color(r, g, b, a).normal(p.normal(), dx, dy, dz).endVertex();
    }

    /** Каркас камери: піраміда погляду + «дах» (верх кадру), як у Blender. */
    static void cameraGizmo(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, SceneFrame.Cam c, int color, double size) {
        Vec3 f = Vec3.directionFromRotation(c.pitch, c.yaw);
        double ry = Math.toRadians(c.yaw);
        Vec3 right = new Vec3(-Math.cos(ry), 0, -Math.sin(ry));
        Vec3 up = right.cross(f).normalize();
        if (c.roll != 0) {
            double rr = Math.toRadians(c.roll);
            Vec3 r2 = right.scale(Math.cos(rr)).add(up.scale(Math.sin(rr)));
            up = up.scale(Math.cos(rr)).subtract(right.scale(Math.sin(rr)));
            right = r2;
        }
        double hh = Math.tan(Math.toRadians(c.fov) / 2) * size, hw = hh * 16 / 9.0;
        Vec3 o = new Vec3(c.x, c.y, c.z), ctr = o.add(f.scale(size));
        Vec3[] k = {
            ctr.add(right.scale(hw)).add(up.scale(hh)), ctr.add(right.scale(-hw)).add(up.scale(hh)),
            ctr.add(right.scale(-hw)).add(up.scale(-hh)), ctr.add(right.scale(hw)).add(up.scale(-hh)) };
        for (int i = 0; i < 4; i++) {
            line(vc, p, cam, o.x, o.y, o.z, k[i].x, k[i].y, k[i].z, color);
            Vec3 n = k[(i + 1) % 4];
            line(vc, p, cam, k[i].x, k[i].y, k[i].z, n.x, n.y, n.z, color);
        }
        Vec3 t0 = ctr.add(up.scale(hh * 1.15)).add(right.scale(hw * 0.5)), t1 = ctr.add(up.scale(hh * 1.15)).add(right.scale(-hw * 0.5));
        Vec3 t2 = ctr.add(up.scale(hh * 1.6));
        line(vc, p, cam, t0.x, t0.y, t0.z, t1.x, t1.y, t1.z, color);
        line(vc, p, cam, t1.x, t1.y, t1.z, t2.x, t2.y, t2.z, color);
        line(vc, p, cam, t2.x, t2.y, t2.z, t0.x, t0.y, t0.z, color);
    }

    /** Пунктирна рамка схованого актора («тут він є, але не видно»). */
    static void dashedBox(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, double x, double y, double z, double hw, double h, int color) {
        double[][] c = { { -hw, -hw }, { hw, -hw }, { hw, hw }, { -hw, hw } };
        for (int i = 0; i < 4; i++) {
            double[] a = c[i], b = c[(i + 1) % 4];
            dashed(vc, p, cam, x + a[0], y, z + a[1], x + b[0], y, z + b[1], color);
            dashed(vc, p, cam, x + a[0], y + h, z + a[1], x + b[0], y + h, z + b[1], color);
            dashed(vc, p, cam, x + a[0], y, z + a[1], x + a[0], y + h, z + a[1], color);
        }
    }

    static void dashed(VertexConsumer vc, PoseStack.Pose p, Vec3 cam, double x0, double y0, double z0, double x1, double y1, double z1, int color) {
        double len = Math.sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0) + (z1 - z0) * (z1 - z0));
        int n = Math.max(1, (int) (len / 0.2));
        for (int i = 0; i < n; i += 2) {
            double a = i / (double) n, b = Math.min(1, (i + 1) / (double) n);
            line(vc, p, cam, x0 + (x1 - x0) * a, y0 + (y1 - y0) * a, z0 + (z1 - z0) * a, x0 + (x1 - x0) * b, y0 + (y1 - y0) * b, z0 + (z1 - z0) * b, color);
        }
    }

    static VertexConsumer lines(MultiBufferSource buffers) { return buffers.getBuffer(RenderType.lines()); }

    static boolean isCamera(SceneObject o) { return o.kind == SceneObject.Kind.CAMERA; }
}
