package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.io.BBModelDoc;
import dev.shaurmalib.scene.mc.ui.Draw2D;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.Icons;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import dev.shaurmalib.scene.paint.Image;
import dev.shaurmalib.scene.paint.Paint;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Сторінка «Малювання» (режим «Малювати» Shaurma Modeling): ліворуч — інструменти, пензель і колір, у центрі —
 * розгортка текстури (UV) і 3D-модель; малювати можна і там, і там. Мазок — одна дія історії сцени.
 *
 * <p>Миша: ЛКМ — інструмент, Alt+ЛКМ — піпетка, ПКМ/СКМ — зсунути полотно (на моделі ПКМ — обертати), колесо — масштаб.
 * Клавіші: B пензель, E гумка, F заливка, I піпетка, U фігура, G градієнт, X — поміняти кольори, [ / ] — розмір пензля.
 */
final class PaintPage {

    private PaintPage() {}

    enum Tool {
        BRUSH("Пензель", Icon.BRUSH, "B"), ERASER("Гумка", Icon.ERASER, "E"), FILL("Заливка", Icon.FILL, "F"),
        PICKER("Піпетка", Icon.PICKER, "I"), SHAPE("Фігура", Icon.SHAPE, "U"), GRADIENT("Градієнт", Icon.GRADIENT, "G");
        final String title; final Icon icon; final String key;
        Tool(String t, Icon i, String k) { title = t; icon = i; key = k; }
    }

    static Tool tool = Tool.BRUSH;
    static final Paint.Brush BRUSH = new Paint.Brush();
    static Paint.ShapeType shapeType = Paint.ShapeType.RECTANGLE;
    static int color = 0xFFE5646A, color2 = 0xFF000000, tolerance = 0;
    static boolean fillGlobal, fillFace = true;
    static final List<Integer> RECENT = new ArrayList<>();
    static final ModelView.Cam CAM = new ModelView.Cam();
    private static float hue = -1, sat, val;

    // полотно
    private static double zoom = -1, panX, panY;
    private static String fittedFor;
    private static int cx0, cy0, cw, ch;

    // мазок
    private static boolean stroking, panning, orbiting, strokeOn3d;
    private static int panButton;
    private static Image strokeBase;
    private static double lastPx, lastPy, startPx, startPy, lastMx, lastMy;
    private static ModelView.Face lastFace;
    private static boolean strokeChanged;

    static final int LEFT_W = 132;

    // ═════════════ кадр ═════════════

    static void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        gui.g.fill(x, y, x + w, y + h, 0xFF10141F);
        if (!ModelSession.sync(s)) { ModelPage.placeholder(gui, x, y, w, h, ModelSession.problem); ModelPage.offerPlayerCopy(s, gui, x, y, w, h); return; }
        ModelPage.rebuildIfNeeded();
        int lw = Math.min(LEFT_W, w / 3);
        tools(s, gui, x, y, lw, h);
        int rest = w - lw;
        int canvasW = rest >= 360 ? rest * 55 / 100 : rest;
        canvas(s, gui, x + lw, y, canvasW, h);
        if (canvasW < rest) {
            int vx = x + lw + canvasW;
            gui.g.fill(vx, y, vx + 1, y + h, MenuSkin.OUTLINE);
            model3d(s, gui, vx + 1, y, rest - canvasW - 1, h);
        }
        if (stroking && !gui.isDown(0)) endStroke(s);
    }

    // ═════════════ ліва панель ═════════════

    private static void tools(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        gui.panel(x, y, w, h);
        int off = gui.scrollBegin("paint.tools", x, y, w, h, 470);
        int cy = y + 4 - off;
        int per = Math.max(1, (w - 8) / 20);
        Tool[] ts = Tool.values();
        for (int i = 0; i < ts.length; i++) {
            Tool t = ts[i];
            int bx = x + 4 + (i % per) * 20, by = cy + (i / per) * 20;
            if (gui.iconButton(bx, by, 18, t.icon, tool == t, Component.literal(t.title + " (" + t.key + ")"))) tool = t;
        }
        cy += ((ts.length + per - 1) / per) * 20 + 4;
        gui.text(tool.title, x + 5, cy, Theme.TEXT);
        cy += 12;
        if (tool == Tool.BRUSH || tool == Tool.ERASER || tool == Tool.SHAPE) {
            cy = num(gui, "Розмір", "paint.size", BRUSH.size, 1, x, cy, w, v -> BRUSH.size = (int) Math.max(1, Math.min(64, v)));
        }
        if (tool != Tool.PICKER) cy = num(gui, "Непрозорість %", "paint.opacity", Math.round(BRUSH.opacity * 100), 5, x, cy, w, v -> BRUSH.opacity = (float) Math.max(0, Math.min(100, v)) / 100f);
        if (tool == Tool.BRUSH || tool == Tool.ERASER) {
            cy = num(gui, "М'якість %", "paint.soft", Math.round(BRUSH.softness * 100), 5, x, cy, w, v -> BRUSH.softness = (float) Math.max(0, Math.min(100, v)) / 100f);
            if (gui.button(x + 4, cy, w - 8, 14, Component.literal(BRUSH.shape == Paint.Shape.SQUARE ? "Форма: квадрат" : "Форма: коло"), false, null))
                BRUSH.shape = BRUSH.shape == Paint.Shape.SQUARE ? Paint.Shape.CIRCLE : Paint.Shape.SQUARE;
            cy += 18;
        }
        if (tool == Tool.FILL) {
            cy = num(gui, "Допуск", "paint.tol", tolerance, 1, x, cy, w, v -> tolerance = (int) Math.max(0, Math.min(255, v)));
            if (gui.checkbox(x + 4, cy, w - 8, Component.literal("Усі такі кольори"), fillGlobal, Component.literal("Не лише суміжні пікселі"))) fillGlobal = !fillGlobal;
            cy += 15;
            if (gui.checkbox(x + 4, cy, w - 8, Component.literal("У межах грані"), fillFace, Component.literal("На моделі заливка не виходить за грань"))) fillFace = !fillFace;
            cy += 15;
        }
        if (tool == Tool.SHAPE) {
            Paint.ShapeType[] st = Paint.ShapeType.values();
            Icon[] icons = { Icon.RECT_FILLED, Icon.RECT_HOLLOW, Icon.ELLIPSE_FILLED, Icon.ELLIPSE_HOLLOW };
            String[] names = { "Прямокутник", "Рамка", "Еліпс", "Кільце" };
            for (int i = 0; i < st.length; i++)
                if (gui.iconButton(x + 4 + i * 20, cy, 18, icons[i], shapeType == st[i], Component.literal(names[i]))) shapeType = st[i];
            cy += 22;
        }
        if (tool != Tool.PICKER && tool != Tool.GRADIENT) {
            if (gui.checkbox(x + 4, cy, w - 8, Component.literal("Дзеркально по X"), BRUSH.mirrorX, null)) BRUSH.mirrorX = !BRUSH.mirrorX;
            cy += 15;
        }
        if (tool != Tool.PICKER && tool != Tool.ERASER) {
            if (gui.checkbox(x + 4, cy, w - 8, Component.literal("Блокувати альфу"), BRUSH.lockAlpha, Component.literal("Малювати лише по непрозорому"))) BRUSH.lockAlpha = !BRUSH.lockAlpha;
            cy += 15;
        }
        cy += 4;
        gui.g.fill(x + 4, cy, x + w - 4, cy + 1, MenuSkin.RULE);
        cy += 5;
        color(gui, x, cy, w - MenuSkin.SCROLL_W);
        gui.scrollEnd();
    }

    private static int num(Gui gui, String label, String id, double value, double step, int x, int y, int w, java.util.function.DoubleConsumer set) {
        int lw = Math.max(50, (w - 8) * 55 / 100);
        gui.textClip(label, x + 5, y + 3, lw - 4, MenuSkin.LABEL);
        Gui.Num n = gui.number(id, x + 4 + lw, y, w - 8 - lw, 13, value, step, Theme.ACCENT);
        if (n.any()) set.accept(n.value());
        return y + 17;
    }

    /** Колір як у Blockbench: основний/другий, HEX, квадрат S×V, смуга відтінку, останні кольори. */
    private static void color(Gui gui, int x, int y, int w) {
        float[] hsv = hsv(color);
        if (hue < 0 || hsvToRgb(hue, sat, val) != (color & 0xFFFFFF)) { hue = hsv[0]; sat = hsv[1]; val = hsv[2]; }
        int sw = 12;
        gui.g.fill(x + 12, y + 6, x + 12 + sw, y + 6 + sw, 0xFF000000);
        gui.g.fill(x + 13, y + 7, x + 11 + sw, y + 5 + sw, color2 | 0xFF000000);
        gui.g.fill(x + 4, y, x + 5 + sw, y + 1 + sw, 0xFFFFFFFF);
        gui.g.fill(x + 5, y + 1, x + 4 + sw, y + sw, color | 0xFF000000);
        if (!gui.hover(x + 4, y, sw + 1, sw + 1) && gui.clicked(x + 12, y + 6, sw, sw, 0)) swap();
        String typed = gui.textField("paint.hex", x + 30, y + 3, 52, 12, String.format(Locale.ROOT, "%06X", color & 0xFFFFFF), null);
        if (typed != null) {
            try { color = 0xFF000000 | Integer.parseInt(typed.replace("#", "").strip(), 16); hue = -1; } catch (NumberFormatException ignored) { }
        }
        if (gui.icon(x + 86, y + 3, 12, Icon.SWAP, false, Component.literal("Поміняти кольори (X)"))) swap();
        y += 22;
        int size = Math.max(40, w - 24);
        int px = x + 4;
        for (int i = 0; i < size; i++) gui.g.fillGradient(px + i, y, px + i + 1, y + size, 0xFF000000 | hsvToRgb(hue, i / (float) (size - 1), 1), 0xFF000000);
        int sx = px + (int) (sat * (size - 1)), sy = y + (int) ((1 - val) * (size - 1));
        gui.g.fill(sx - 2, sy - 2, sx + 3, sy + 3, 0xFFFFFFFF);
        gui.g.fill(sx - 1, sy - 1, sx + 2, sy + 2, 0xFF000000 | color);
        if (gui.press("paint.sv", px, y, size, size, 0) || (gui.isActive("paint.sv") && gui.isDown(0))) {
            sat = clamp01((gui.mx - px) / (float) (size - 1));
            val = 1 - clamp01((gui.my - y) / (float) (size - 1));
            color = 0xFF000000 | hsvToRgb(hue, sat, val);
        }
        int hx = px + size + 4;
        for (int j = 0; j < size; j++) gui.g.fill(hx, y + j, hx + 10, y + j + 1, 0xFF000000 | hsvToRgb(j / (float) size, 1, 1));
        int hy = y + (int) (hue * size);
        gui.g.fill(hx - 1, hy - 1, hx + 11, hy + 1, 0xFFFFFFFF);
        if (gui.press("paint.h", hx, y, 10, size, 0) || (gui.isActive("paint.h") && gui.isDown(0))) {
            hue = clamp01((gui.my - y) / (float) size);
            color = 0xFF000000 | hsvToRgb(hue, sat, val);
        }
        y += size + 4;
        int rx = x + 4;
        for (int i = 0; i < RECENT.size(); i++) {
            int cxp = rx + (i % 10) * 10, cyp = y + (i / 10) * 10;
            gui.g.fill(cxp, cyp, cxp + 9, cyp + 9, RECENT.get(i) | 0xFF000000);
            if (gui.clicked(cxp, cyp, 10, 10, 0)) { color = RECENT.get(i) | 0xFF000000; hue = -1; }
            if (gui.clicked(cxp, cyp, 10, 10, 1)) color2 = RECENT.get(i) | 0xFF000000;
        }
    }

    private static void swap() { int c = color; color = color2; color2 = c; hue = -1; }

    private static void remember(int c) {
        c |= 0xFF000000;
        RECENT.remove((Integer) c);
        RECENT.add(0, c);
        while (RECENT.size() > 20) RECENT.remove(RECENT.size() - 1);
    }

    // ═════════════ полотно (UV) ═════════════

    private static void canvas(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        Image img = ModelSession.image;
        ResourceLocation tex = ModelSession.texture();
        cx0 = x; cy0 = y; cw = w; ch = h;
        String key = ModelSession.assetId + ":" + img.width + "x" + img.height;
        if (zoom <= 0 || !key.equals(fittedFor)) { fit(img, w, h); fittedFor = key; }
        gui.g.fill(x, y, x + w, y + h, 0xFF1A1F2C);
        gui.g.enableScissor(x, y, x + w, y + h);
        double ox = x + panX, oy = y + panY;
        int tw = (int) Math.round(img.width * zoom), th = (int) Math.round(img.height * zoom);
        int ix = (int) Math.round(ox), iy = (int) Math.round(oy);
        // шахівниця під прозорим
        int cell = 8;
        for (int j = 0; j < th; j += cell)
            for (int i = 0; i < tw; i += cell)
                gui.g.fill(ix + i, iy + j, ix + Math.min(tw, i + cell), iy + Math.min(th, j + cell), ((i / cell + j / cell) & 1) == 0 ? 0xFF6A6A6A : 0xFF8A8A8A);
        if (tex != null) {
            gui.g.pose().pushPose();
            gui.g.pose().translate(ox, oy, 0);
            gui.g.pose().scale((float) zoom, (float) zoom, 1);
            gui.g.blit(tex, 0, 0, 0, 0, img.width, img.height, img.width, img.height);
            gui.g.pose().popPose();
        }
        if (zoom >= 6) {
            for (int i = 0; i <= img.width; i++) gui.g.fill((int) (ox + i * zoom), iy, (int) (ox + i * zoom) + 1, iy + th, 0x18FFFFFF);
            for (int j = 0; j <= img.height; j++) gui.g.fill(ix, (int) (oy + j * zoom), ix + tw, (int) (oy + j * zoom) + 1, 0x18FFFFFF);
        }
        Draw2D.rectOutline(gui.g, ix - 1, iy - 1, tw + 2, th + 2, 0xFF000000);
        uvOutlines(gui, ox, oy, img);
        boolean over = gui.hover(x, y, w, h);
        // курсор пензля
        if (over && !panning) {
            double fx = (gui.mx - ox) / zoom, fy = (gui.my - oy) / zoom;
            if (tool == Tool.BRUSH || tool == Tool.ERASER) {
                int sz = Math.max(1, BRUSH.size);
                int bx0 = (int) Math.floor(fx - sz / 2.0 + (sz % 2 == 1 ? 0.5 : 0)), by0 = (int) Math.floor(fy - sz / 2.0 + (sz % 2 == 1 ? 0.5 : 0));
                if (sz == 1) { bx0 = (int) Math.floor(fx); by0 = (int) Math.floor(fy); }
                Draw2D.rectOutline(gui.g, (int) (ox + bx0 * zoom), (int) (oy + by0 * zoom), (int) Math.ceil(sz * zoom), (int) Math.ceil(sz * zoom), 0xC0FFFFFF);
            }
            int pxi = (int) Math.floor(fx), pyi = (int) Math.floor(fy);
            if (img.inside(pxi, pyi)) {
                String info = pxi + ", " + pyi;
                gui.text(info, x + 4, y + h - 11, Theme.MUTED);
            }
        }
        gui.g.disableScissor();
        gui.text(img.width + "×" + img.height + (ModelSession.texAssetId != null ? " · окрема текстура" : " · текстура моделі"), x + 4, y + 4, Theme.MUTED);

        // ── миша ──
        int c = gui.pendingClick();
        if (c >= 0 && over && gui.clicked(x, y, w, h, c)) {
            lastMx = gui.mx; lastMy = gui.my;
            if (c == 0) {
                double fx = (gui.mx - ox) / zoom, fy = (gui.my - oy) / zoom;
                beginStroke(s, fx, fy, false, null);
            } else { panning = true; panButton = c; }
        }
        double sc = gui.pendingScroll();
        if (over && sc != 0) {
            double old = zoom;
            zoom = Math.max(0.25, Math.min(64, zoom * Math.pow(1.2, sc)));
            panX = (gui.mx - x) - (gui.mx - x - panX) * zoom / old;
            panY = (gui.my - y) - (gui.my - y - panY) * zoom / old;
            gui.consumeScroll();
        }
        if (panning) {
            if (!gui.isDown(panButton)) panning = false;
            else { panX += gui.mx - lastMx; panY += gui.my - lastMy; lastMx = gui.mx; lastMy = gui.my; }
        }
        if (stroking && !strokeOn3d && gui.isDown(0)) {
            double fx = (gui.mx - ox) / zoom, fy = (gui.my - oy) / zoom;
            continueStroke(fx, fy);
        }
    }

    private static void fit(Image img, int w, int h) {
        zoom = Math.max(0.25, Math.min((w - 20) / (double) img.width, (h - 30) / (double) img.height));
        if (zoom >= 1) zoom = Math.floor(zoom);
        panX = (w - img.width * zoom) / 2;
        panY = (h - img.height * zoom) / 2 + 6;
    }

    /** Обриси граней на розгортці: усі — ледь видно, вибрані кубики — акцентом. */
    private static void uvOutlines(Gui gui, double ox, double oy, Image img) {
        Set<String> sel = selectedCubes();
        double sx = img.width * zoom, sy = img.height * zoom;
        for (ModelView.Face f : ModelView.faces) {
            boolean on = f.uuid != null && sel.contains(f.uuid);
            double u0 = Math.min(f.uv[0], f.uv[4]), u1 = Math.max(f.uv[0], f.uv[4]), v0 = Math.min(f.uv[1], f.uv[5]), v1 = Math.max(f.uv[1], f.uv[5]);
            int x0 = (int) Math.round(ox + u0 * sx), y0 = (int) Math.round(oy + v0 * sy), x1 = (int) Math.round(ox + u1 * sx), y1 = (int) Math.round(oy + v1 * sy);
            if (x1 - x0 < 1 || y1 - y0 < 1) continue;
            Draw2D.rectOutline(gui.g, x0, y0, x1 - x0, y1 - y0, on ? 0xFF5EA0FF : 0x30FFFFFF);
        }
    }

    private static Set<String> selectedCubes() {
        Set<String> out = new HashSet<>();
        String sel = ModelSession.sel;
        BBModelDoc bb = ModelSession.bb;
        if (sel == null || bb == null) return out;
        if (bb.isGroup(sel)) out.addAll(bb.cubesIn(sel)); else out.add(sel);
        return out;
    }

    // ═════════════ 3D-модель ═════════════

    private static void model3d(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        ModelView.layout(CAM, x, y, w, h);
        ModelView.render(gui.g, ModelSession.texture());
        boolean over = gui.hover(x, y, w, h);
        ModelView.Hit hover = over && !orbiting ? ModelView.pick(gui.mx, gui.my) : null;
        Set<String> sel = selectedCubes();
        if (!sel.isEmpty()) ModelView.outline(gui.g, sel, 0x905EA0FF, 1f);
        if (hover != null && tool != Tool.PICKER) {
            // піксель під курсором — маленький квадрат
            double[] p = ModelView.project(hover.x(), hover.y(), hover.z());
            if (p != null) Draw2D.rectOutline(gui.g, (int) p[0] - 2, (int) p[1] - 2, 5, 5, 0xC0FFFFFF);
        }
        gui.text("ЛКМ — малювати · ПКМ — обертати · колесо — ближче", x + 4, y + 4, Theme.MUTED);

        int c = gui.pendingClick();
        if (c >= 0 && over && gui.clicked(x, y, w, h, c)) {
            lastMx = gui.mx; lastMy = gui.my;
            ModelView.Hit hit = c == 0 ? ModelView.pick(gui.mx, gui.my) : null;
            if (hit != null && tool != Tool.SHAPE && tool != Tool.GRADIENT) {
                Image img = ModelSession.image;
                beginStroke(s, hit.u() * img.width, hit.v() * img.height, true, hit.face());
            } else { orbiting = true; panButton = c; }
        }
        double sc = gui.pendingScroll();
        if (over && sc != 0) { ModelView.zoom(CAM, sc); gui.consumeScroll(); }
        if (orbiting) {
            if (!gui.isDown(panButton)) orbiting = false;
            else {
                double dx = gui.mx - lastMx, dy = gui.my - lastMy;
                if (panButton == 2 || Screen.hasShiftDown()) ModelView.pan(CAM, dx, dy); else ModelView.orbit(CAM, dx, dy);
                lastMx = gui.mx; lastMy = gui.my;
            }
        }
        if (stroking && strokeOn3d && gui.isDown(0) && over) {
            ModelView.Hit hit = ModelView.pick(gui.mx, gui.my);
            if (hit != null) {
                Image img = ModelSession.image;
                double px = hit.u() * img.width, py = hit.v() * img.height;
                if (hit.face() != lastFace) { lastPx = px; lastPy = py; lastFace = hit.face(); }   // інша грань — без лінії через розгортку
                continueStroke(px, py);
            }
        }
    }

    // ═════════════ мазок ═════════════

    private static void beginStroke(SceneEditorScreen s, double px, double py, boolean on3d, ModelView.Face face) {
        Image img = ModelSession.image;
        Tool t = Screen.hasAltDown() ? Tool.PICKER : tool;
        int pxi = (int) Math.floor(px), pyi = (int) Math.floor(py);
        if (t == Tool.PICKER) {
            if (img.inside(pxi, pyi)) { int c = img.get(pxi, pyi); if ((c >>> 24) != 0) { color = c | 0xFF000000; hue = -1; } }
            return;
        }
        strokeBase = img.copy();
        strokeChanged = false;
        if (t == Tool.FILL) {
            int[] bounds = null;
            if (on3d && fillFace && face != null) bounds = faceBounds(face, img);
            Paint.Dirty d = Paint.fill(img, pxi, pyi, color, tolerance, bounds, fillGlobal, BRUSH.opacity, BRUSH.blend, false, BRUSH.lockAlpha);
            if (!d.empty()) { ModelSession.pixelsChanged(); ModelSession.commitPaint(s, "заливка"); remember(color); }
            strokeBase = null;
            return;
        }
        stroking = true;
        strokeOn3d = on3d;
        lastFace = face;
        startPx = lastPx = px;
        startPy = lastPy = py;
        if (t == Tool.BRUSH || t == Tool.ERASER) {
            Paint.Dirty d = Paint.dab(img, px, py, color, BRUSH, t == Tool.ERASER);
            if (!d.empty()) { strokeChanged = true; ModelSession.pixelsChanged(); }
        }
    }

    private static void continueStroke(double px, double py) {
        Image img = ModelSession.image;
        switch (tool) {
            case BRUSH, ERASER -> {
                if (Math.abs(px - lastPx) < 0.01 && Math.abs(py - lastPy) < 0.01) return;
                Paint.Dirty d = Paint.line(img, lastPx, lastPy, px, py, color, BRUSH, tool == Tool.ERASER);
                lastPx = px; lastPy = py;
                if (!d.empty()) { strokeChanged = true; ModelSession.pixelsChanged(); }
            }
            case SHAPE, GRADIENT -> {
                if (Math.abs(px - lastPx) < 0.01 && Math.abs(py - lastPy) < 0.01 && strokeChanged) return;
                lastPx = px; lastPy = py;
                System.arraycopy(strokeBase.argb, 0, img.argb, 0, img.argb.length);
                int x0 = (int) Math.floor(startPx), y0 = (int) Math.floor(startPy), x1 = (int) Math.floor(px), y1 = (int) Math.floor(py);
                if (tool == Tool.SHAPE) {
                    Paint.shape(img, x0, y0, x1, y1, color, shapeType, BRUSH.size, BRUSH.opacity, BRUSH.blend, false, BRUSH.lockAlpha);
                    if (BRUSH.mirrorX) Paint.shape(img, img.width - 1 - x0, y0, img.width - 1 - x1, y1, color, shapeType, BRUSH.size, BRUSH.opacity, BRUSH.blend, false, BRUSH.lockAlpha);
                } else {
                    Paint.gradient(img, x0, y0, x1, y1, color, color2, null, BRUSH.opacity, BRUSH.blend, BRUSH.lockAlpha);
                }
                strokeChanged = true;
                ModelSession.pixelsChanged();
            }
            default -> { }
        }
    }

    private static void endStroke(SceneEditorScreen s) {
        stroking = false;
        if (strokeChanged) {
            ModelSession.commitPaint(s, tool.title.toLowerCase(Locale.ROOT));
            if (tool != Tool.ERASER) remember(color);
        }
        strokeBase = null;
        lastFace = null;
    }

    static boolean cancelStroke() {
        if (!stroking) return false;
        stroking = false;
        if (strokeBase != null) System.arraycopy(strokeBase.argb, 0, ModelSession.image.argb, 0, strokeBase.argb.length);
        strokeBase = null;
        ModelSession.pixelsChanged();
        ModelSession.clearLive();
        return true;
    }

    static boolean busy() { return stroking; }

    /** UV-прямокутник грані в пікселях {x0, y0, x1, y1} (x1, y1 не включно). */
    private static int[] faceBounds(ModelView.Face f, Image img) {
        double u0 = Math.min(f.uv[0], f.uv[4]), u1 = Math.max(f.uv[0], f.uv[4]), v0 = Math.min(f.uv[1], f.uv[5]), v1 = Math.max(f.uv[1], f.uv[5]);
        return new int[] { (int) Math.floor(u0 * img.width + 1e-6), (int) Math.floor(v0 * img.height + 1e-6), (int) Math.ceil(u1 * img.width - 1e-6), (int) Math.ceil(v1 * img.height - 1e-6) };
    }

    // ═════════════ клавіші ═════════════

    static boolean key(int key) {
        switch (key) {
            case GLFW.GLFW_KEY_B -> tool = Tool.BRUSH;
            case GLFW.GLFW_KEY_E -> tool = Tool.ERASER;
            case GLFW.GLFW_KEY_F -> tool = Tool.FILL;
            case GLFW.GLFW_KEY_I -> tool = Tool.PICKER;
            case GLFW.GLFW_KEY_U -> tool = Tool.SHAPE;
            case GLFW.GLFW_KEY_G -> tool = Tool.GRADIENT;
            case GLFW.GLFW_KEY_X -> swap();
            case GLFW.GLFW_KEY_LEFT_BRACKET -> BRUSH.size = Math.max(1, BRUSH.size - 1);
            case GLFW.GLFW_KEY_RIGHT_BRACKET -> BRUSH.size = Math.min(64, BRUSH.size + 1);
            case GLFW.GLFW_KEY_HOME -> zoom = -1;
            default -> { return false; }
        }
        return true;
    }

    // ═════════════ колір ═════════════

    static float[] hsv(int rgb) {
        float r = (rgb >> 16 & 255) / 255f, g = (rgb >> 8 & 255) / 255f, b = (rgb & 255) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        float h = 0;
        if (d > 0) {
            if (max == r) h = ((g - b) / d) % 6;
            else if (max == g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h /= 6;
            if (h < 0) h += 1;
        }
        return new float[] { h, max == 0 ? 0 : d / max, max };
    }

    static int hsvToRgb(float h, float s, float v) {
        int i = (int) Math.floor(h * 6) % 6;
        float f = h * 6 - (float) Math.floor(h * 6), p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        float r, g, b;
        switch (i) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return (Math.round(r * 255) << 16) | (Math.round(g * 255) << 8) | Math.round(b * 255);
    }

    private static float clamp01(float v) { return Math.max(0, Math.min(1, v)); }
}
