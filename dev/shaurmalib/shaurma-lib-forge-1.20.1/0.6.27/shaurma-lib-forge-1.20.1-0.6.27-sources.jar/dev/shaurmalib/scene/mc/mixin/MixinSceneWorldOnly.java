package dev.shaurmalib.scene.mc.mixin;

import dev.shaurmalib.scene.mc.client.SceneWorldFilter;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** «Лише світ»: жодна сутність не малюється (гравці, моби, предмети, рамки, стійки, снаряди) — з тінями й нікнеймами. */
@Mixin(EntityRenderDispatcher.class)
public abstract class MixinSceneWorldOnly {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private <E extends Entity> void shaurma$scene$worldOnly(E entity, Frustum frustum, double x, double y, double z, CallbackInfoReturnable<Boolean> cir) {
        if (SceneWorldFilter.hideEntities() || SceneWorldFilter.hideSelf(entity)) cir.setReturnValue(false);
    }
}
