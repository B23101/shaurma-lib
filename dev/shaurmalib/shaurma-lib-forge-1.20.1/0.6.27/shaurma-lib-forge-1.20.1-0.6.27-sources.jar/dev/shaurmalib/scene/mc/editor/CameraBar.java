package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.doc.Channels;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.eval.SceneFrame;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.network.chat.Component;

/**
 * Плаваюча панель камери у в'юпорті — на будь-якій сторінці (Монтаж, Ключі, Криві, Аудіо, Колір), щойно
 * вибрано камеру або дивишся крізь неї: вид з камери, «камера за видом», вселитися, ключ позиції, FOV,
 * точка шляху з поточного виду, редагування кривої в 3D. Камеру не треба шукати в правій панелі.
 */
final class CameraBar {

    private CameraBar() {}

    private static final int H = 16;

    /** Камера, якою керує панель (вибрана або та, що зараз у кадрі при виді з камери). */
    static SceneObject camera(SceneEditorScreen s) {
        SceneObject o = s.selected();
        if (o != null && o.isCamera()) return o;
        if (s.view.cameraView && s.frame.cameraId != null) return s.variant().object(s.frame.cameraId);
        return null;
    }

    /** Кнопка й поле FOV: ширші, якщо в'юпорт дозволяє (GUI ×4 — компактно, підпис FOV у підказці). */
    private static int fovW(SceneEditorScreen s) { return s.vw >= 7 * (H + 2) + 110 ? 84 : 40; }

    private static int width(SceneEditorScreen s) { return 7 * (H + 2) + fovW(s) + 6; }

    /** Нижній край панелі (щоб превʼю меню не налазило). */
    static int bottom(SceneEditorScreen s) { return camera(s) == null || s.previewing ? s.vy : s.vy + 6 + H + 6; }

    static boolean contains(SceneEditorScreen s, double mx, double my) {
        if (camera(s) == null || s.previewing) return false;
        int x = s.vx + 6, y = s.vy + 6;
        return mx >= x && my >= y && mx < x + width(s) && my < y + H + 4;
    }

    static void render(SceneEditorScreen s, Gui gui) {
        SceneObject c = camera(s);
        if (c == null || s.previewing) return;
        int x = s.vx + 6, y = s.vy + 6, w = width(s);
        gui.g.fill(x - 1, y - 1, x + w + 1, y + H + 5, 0xE0000000);
        gui.g.fill(x, y, x + w, y + H + 4, 0xF0141B2C);
        int bx = x + 2, by = y + 2;
        boolean edit = !s.readOnly;
        if (gui.iconButton(bx, by, H, Icon.FULLSCREEN, s.view.cameraView && s.possessed == null,
            Component.literal("Вид з камери «" + c.name + "» (Num 0)"))) {
            if (s.view.cameraView) s.leaveCameraView(); else { s.select(c.id); s.cameraView(true); }
        }
        bx += H + 2;
        if (gui.iconButton(bx, by, H, Icon.LOCK, s.lockCameraToView, Component.literal("Камера за видом\nНавігація в'юпорта рухає саму камеру (з автоключем — ключ у playhead)"), edit)) {
            s.lockCameraToView = !s.lockCameraToView;
            if (s.lockCameraToView) { s.select(c.id); s.cameraView(true); }
        }
        bx += H + 2;
        if (gui.iconButton(bx, by, H, Icon.DIRECTIONAL_MOVE, s.possessed != null, Component.literal("Вселитися в камеру (C)\nПКМ+миша — повертати, ПКМ+WASD/QE — летіти, колесо — наїзд"), edit)) {
            s.select(c.id);
            s.togglePossess();
        }
        bx += H + 2;
        if (gui.iconButton(bx, by, H, Icon.KEYFRAME, false, Component.literal("Ключ позиції, повороту й FOV у playhead (K)"), edit)) {
            s.select(c.id);
            s.keyAll();
        }
        bx += H + 2;
        if (gui.iconButton(bx, by, H, Icon.CAMERA, false, Component.literal("Камера = поточний вид редактора (Ctrl+Num 0)"), edit)) {
            s.select(c.id);
            s.cameraToView();
        }
        bx += H + 2;
        if (gui.iconButton(bx, by, H, Icon.PLUS, false, Component.literal("Точка шляху камери з поточного виду\n(шлях — сплайн, яким летить камера; тягни точки в 3D)"), edit)) {
            SceneFrame.Cam e = s.view.eye(1);
            s.edit("Точка шляху", () -> c.path.add(new SceneObject.PathPoint(e.x, e.y, e.z, e.yaw, e.pitch, 0, c.fov)));
            s.select(c.id);
        }
        bx += H + 2;
        if (gui.iconButton(bx, by, H, Icon.GRADIENT, s.showGizmos, Component.literal("Крива руху в 3D: точки-ключі й ручки Безьє\nТягни точку/ручку; Ctrl+клік по кривій — нова точка; Delete — прибрати"))) s.showGizmos = !s.showGizmos;
        bx += H + 4;
        int fw = fovW(s), lab = fw > 60 ? 22 : 0;
        if (lab > 0) Icons.draw(gui, bx, by + 4);
        Gui.Num n = gui.number("cambar.fov." + c.id, bx + lab, by + 1, fw - lab - 2, H - 2, s.value(c, Channels.FOV), 0.5, Theme.ACCENT);
        Properties.apply(s, "FOV", n, v -> s.setValue(c, Channels.FOV, Math.max(5, Math.min(150, v))));
        if (gui.hover(bx, by, fw, H)) gui.tip(Component.literal("FOV камери «" + c.name + "» (тягни або введи число)"));
    }

    /** Підпис «FOV» дрібними літерами. */
    private static final class Icons {
        static void draw(Gui gui, int x, int y) { gui.text("FOV", x, y, Theme.MUTED); }
    }
}
