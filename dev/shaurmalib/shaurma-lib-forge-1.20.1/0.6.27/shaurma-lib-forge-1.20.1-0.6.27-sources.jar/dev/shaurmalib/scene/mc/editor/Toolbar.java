package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;

/**
 * Панель інструментів під верхнім рядком — як у Shaurma Modeling: лише іконки по центру, групи через роздільник,
 * назва й клавіша — у підказці. Інструменти в'юпорта, створення, камера, швидкість польоту, перемикачі.
 */
final class Toolbar {

    private Toolbar() {}

    private record Item(Icon icon, String tip, Runnable run, BooleanSupplier on, BooleanSupplier enabled) {}

    private static List<Item> items(SceneEditorScreen s) {
        List<Item> l = new ArrayList<>();
        BooleanSupplier yes = () -> true, edit = () -> !s.readOnly;
        l.add(new Item(Icon.SELECT, "Вибір (1)\nКлік — об'єкт, ще клік — кістка; Ctrl — кілька; тягни — рамка",
            () -> ViewportTools.tool = ViewportTools.Tool.SELECT, () -> ViewportTools.tool == ViewportTools.Tool.SELECT, yes));
        l.add(new Item(Icon.MOVE, "Переміщення (2)\nТягни стрілку осі. Shift — точно, Ctrl — без сітки",
            () -> ViewportTools.tool = ViewportTools.Tool.MOVE, () -> ViewportTools.tool == ViewportTools.Tool.MOVE, yes));
        l.add(new Item(Icon.ROTATE, "Поворот (3)\nТягни кільце. Для кістки — поворот кістки (поза)",
            () -> ViewportTools.tool = ViewportTools.Tool.ROTATE, () -> ViewportTools.tool == ViewportTools.Tool.ROTATE, yes));
        l.add(new Item(Icon.RESIZE, "Масштаб (4)\nТягни кубик осі",
            () -> ViewportTools.tool = ViewportTools.Tool.SCALE, () -> ViewportTools.tool == ViewportTools.Tool.SCALE, yes));
        l.add(null);
        l.add(new Item(Icon.CAMERA, "Нова камера з поточного виду", s::addCamera, () -> false, edit));
        l.add(new Item(Icon.PLAYERS, "Новий актор-гравець (під центром в'юпорта)", () -> s.addActor(SceneObject.ModelType.PLAYER, null), () -> false, edit));
        l.add(new Item(Icon.PIVOT, "Нова точка (ціль погляду, батько, мітка)", s::addEmpty, () -> false, edit));
        l.add(new Item(Icon.LIGHT, "Нове світло для сцени меню\nЛКМ — лампа; Shift — прожектор; Ctrl — сонце з тінями",
            () -> s.addLight(net.minecraft.client.gui.screens.Screen.hasControlDown() ? SceneObject.LightType.SUN
                : net.minecraft.client.gui.screens.Screen.hasShiftDown() ? SceneObject.LightType.SPOT : SceneObject.LightType.POINT), () -> false, edit));
        l.add(new Item(Icon.IMPORT, "Імпорт файлу (Ctrl+I)\nМодель .bbmodel / .geo.json, текстура .png, звук .ogg/.mp3/.wav", () -> LeftPanel.importDialog(s), () -> false, edit));
        l.add(null);
        l.add(new Item(Icon.DIRECTIONAL_MOVE, "Вселитися в камеру (C)\nВи дивитесь крізь камеру: ПКМ+миша — повертати, ПКМ+WASD/QE — летіти, колесо — наїзд.\nКамера приймає позицію (з автоключем — ключ у playhead). Ще раз / Esc — вийти",
            s::togglePossess, () -> s.possessed != null, edit));
        l.add(new Item(Icon.FULLSCREEN, "Вид з камери монтажу (Num 0)\nЯк побачить гравець: смуги, переходи, титули",
            () -> s.cameraView(!s.view.cameraView), () -> s.view.cameraView && s.possessed == null, yes));
        l.add(new Item(Icon.BUTTON, "Превʼю віконця меню\nСцена так, як її побачить гравець у картці меню: світло, тіні, корекція, кадр",
            () -> s.menuPreview = !s.menuPreview, () -> s.showMenuPreview(), yes));
        l.add(new Item(Icon.STATE, "Записати рух актора (Ctrl+R)\nВи ходите — вибраний актор повторює", s::startRecording, () -> false,
            () -> !s.readOnly && s.selected() != null && s.selected().kind == SceneObject.Kind.ACTOR));
        l.add(null);
        l.add(new Item(Icon.KEYFRAME, "Автоключ\nЗміни трансформу пишуться ключем у playhead", () -> s.autoKey = !s.autoKey, () -> s.autoKey, yes));
        l.add(new Item(Icon.EYE, "Onion skin\nПрозорі копії пози в сусідніх ключах", () -> s.onion = !s.onion, () -> s.onion, yes));
        l.add(new Item(Icon.LIT, "Світло у в'юпорті (як Rendered у Blender)\nПрожектори, лампи, тіні, промені й сторінка «Колір» — прямо тут.\nВимкніть, якщо гальмує: тоді звичайний світ гри",
            () -> SceneEditorScreen.litView = !SceneEditorScreen.litView, () -> SceneEditorScreen.litView, yes));
        l.add(new Item(Icon.WORLD_GRID, "Каркаси камер, шляхи, траєкторії", () -> s.showGizmos = !s.showGizmos, () -> s.showGizmos, yes));
        l.add(new Item(Icon.STAR, "Точка редагування = вигляд\nРедактор відкриватиметься звідси. H — повернутись", s::setHomeHere, () -> s.doc.home != null, edit));
        return l;
    }

    static void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        MenuSkin.bar(gui.g, x, y, w, h, false);
        int bs = MenuSkin.BAR_BTN, by = y + 2;
        List<Item> list = items(s);
        int flyW = 62;
        int total = flyW + 12;
        boolean sep = false;
        for (Item it : list) { if (it == null) { sep = true; continue; } if (sep) { total += 6; sep = false; } total += bs + 2; }
        int bx = x + Math.max(2, (w - total) / 2);
        sep = false;
        int index = 0;
        for (Item it : list) {
            if (it == null) { sep = true; continue; }
            if (sep) { separator(gui, bx, y, h); bx += 6; sep = false; }
            if (gui.iconButton(bx, by, bs, it.icon(), it.on().getAsBoolean(), Component.literal(it.tip()), it.enabled().getAsBoolean())) it.run().run();
            bx += bs + 2;
            index++;
            if (it.icon() == Icon.FULLSCREEN) {        // швидкість польоту — поруч з камерою
                separator(gui, bx, y, h);
                bx += 6;
                dev.shaurmalib.scene.mc.ui.Icons.draw(gui.g, Icon.DIRECTIONAL_MOVE, bx, by + 2, 8, Theme.MUTED);
                Gui.Num n = gui.number("fly.speed", bx + 9, by, flyW - 10, bs, s.view.flySpeed, 0.5, Theme.ACCENT);
                if (n.any()) s.view.flySpeed = Math.max(0.5, Math.min(120, n.value()));
                if (gui.hover(bx, by, flyW, bs)) gui.tip(Component.literal("Швидкість польоту, блоків/с\nПКМ+WASD — летіти; колесо під час польоту — змінити"));
                bx += flyW + 2;
            }
        }
    }

    private static void separator(Gui gui, int bx, int y, int h) {
        gui.g.fill(bx + 1, y + 4, bx + 2, y + h - 4, MenuSkin.OUTLINE);
        gui.g.fill(bx + 2, y + 4, bx + 3, y + h - 4, MenuSkin.PANE_EDGE);
    }
}
