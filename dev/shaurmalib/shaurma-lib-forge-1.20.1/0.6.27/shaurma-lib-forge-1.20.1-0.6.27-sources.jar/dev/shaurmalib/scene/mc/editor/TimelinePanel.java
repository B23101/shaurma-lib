package dev.shaurmalib.scene.mc.editor;

import dev.shaurmalib.anim.math.Easing;
import dev.shaurmalib.scene.doc.Channels;
import dev.shaurmalib.scene.doc.Clip;
import dev.shaurmalib.scene.doc.KeyChannel;
import dev.shaurmalib.scene.doc.Marker;
import dev.shaurmalib.scene.doc.SceneDoc;
import dev.shaurmalib.scene.doc.SceneObject;
import dev.shaurmalib.scene.doc.Track;
import dev.shaurmalib.scene.doc.Transition;
import dev.shaurmalib.scene.edit.EditOps;
import dev.shaurmalib.scene.io.AudioPcm;
import dev.shaurmalib.scene.mc.client.GameSounds;
import dev.shaurmalib.scene.mc.client.SceneAssets;
import dev.shaurmalib.scene.mc.ui.Draw2D;
import dev.shaurmalib.scene.mc.ui.Gui;
import dev.shaurmalib.scene.mc.ui.Icon;
import dev.shaurmalib.scene.mc.ui.Icons;
import dev.shaurmalib.scene.mc.ui.MenuSkin;
import dev.shaurmalib.scene.mc.ui.Theme;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Нижня панель — монтаж і ключі:
 * <ul>
 *   <li><b>Кліпи</b> (як Kdenlive/Shotcut): треки камер/анімацій/звуку/оверлеїв/ефектів/часу; кліп тягнеться,
 *       краї — trim, S — розрізати в playhead, ПКМ — меню; хвиля звуку; межа джерела анімації з візуалізацією
 *       циклу/заморозки; переходи на межах; мітки на лінійці;</li>
 *   <li><b>Ключі</b> (Dope Sheet): канали вибраного об'єкта й кісток, вибір рамкою, перетягування, інтерполяція;</li>
 *   <li><b>Криві</b> (Graph Editor): криві каналів, ключі й ручки Безьє (Free/Aligned/Auto/Vector).</li>
 * </ul>
 */
final class TimelinePanel {

    private TimelinePanel() {}

    private static final int HEAD = 124, BAR = 18, RULER = 14, ROW = 18, KROW = 12;
    /** Звукова доріжка вища: у заголовку повзунок гучності, на кліпі видно хвилю, лінію гучності й fade. */
    private static final int AUDIO_ROW = 30;
    /** Де цього кадру намальовано рядок кожного треку {y, висота} — щоб знати, на яку доріжку кинули звук. */
    private static final Map<Track, int[]> ROWS = new HashMap<>();

    /** Сторінка «Аудіо» (як Fairlight у DaVinci): звукові доріжки великі, решта — тонкі сірі смужки без взаємодії. */
    static boolean audioFocus;

    private static int rowH(Track t) {
        if (audioFocus) return t.type == Track.Type.AUDIO ? 46 : 8;
        return t.type == Track.Type.AUDIO ? AUDIO_ROW : ROW;
    }

    /** Рядки минулого кадру — щоб під час перетягування знати доріжку під курсором (поточні ще малюються). */
    private static final Map<Track, int[]> PREV_ROWS = new HashMap<>();
    /** Кліп, який тягнуть, переїжджає на іншу доріжку (застосовується після обходу треків). */
    private static Track moveTo;
    /** Тягнуть під останню доріжку — при відпусканні створиться нова. */
    private static boolean moveToNew;
    private static double pps = 60, scroll;
    private static boolean fitted;

    // перетягування
    private enum Drag { NONE, TRACK_GAIN, CLIP_GAIN, FADE_L, FADE_R, CLIP_MOVE, CLIP_L, CLIP_R, CLIP_SLIP, CLIP_ROLL, TRANS, SCRUB, MARKER, KEYS, BOX, GKEY, GHANDLE_L, GHANDLE_R, SUMMARY, END }
    private static double panFrom, panScroll, sbGrab, sbSpan;
    private static Clip dNext;
    private static double dNStart, dNLen, dNIn;
    private static Drag drag = Drag.NONE;
    private static Clip dClip;
    private static Track dTrack;
    private static double dMouseT, dStart, dLen, dIn, dValue, dMy;
    private static Marker dMarker;
    private static double[] box;
    private static final Map<KeyChannel.Key, double[]> dOrig = new HashMap<>();
    private static KeyChannel.Key gKey;
    private static KeyChannel gChannel;
    private static double gMin, gMax;
    private static List<KeyChannel.Key> summaryKeys = List.of();
    private static List<KeyChannel.Key> clipboard = List.of();
    private static List<String> clipboardCh = List.of();

    static double tx(int x0, double t) { return x0 + (t - scroll) * pps; }

    static double xt(int x0, double x) { return scroll + (x - x0) / pps; }

    /** Курсор над таймлайном (підказка в рядку стану). */
    static boolean hovered;

    static void render(SceneEditorScreen s, Gui gui, int x, int y, int w, int h) {
        hovered = gui.hover(x, y, w, h);
        gui.panel(x, y, w, h);
        int laneX = x + HEAD, laneW = w - HEAD - 4;
        if (!fitted) { fit(s, laneW); fitted = true; }
        toolbar(s, gui, x, y, w, laneW);
        wheel(s, gui, x, y, w, h, laneX, laneW);
        navigate(s, gui, y, h, laneX, laneW);
        int ry = y + BAR;
        ruler(s, gui, laneX, ry, laneW);
        int cy = ry + RULER, ch = h - BAR - RULER - 2;
        gui.pushClip(x, cy, w, ch);
        gui.g.enableScissor(x, cy, x + w, cy + ch);
        switch (s.timelineMode) {
            case 0 -> clips(s, gui, x, cy, w, ch, laneX, laneW);
            case 1 -> dope(s, gui, x, cy, w, ch, laneX, laneW);
            default -> graph(s, gui, x, cy, w, ch, laneX, laneW);
        }
        // після кінця сцени — затемнено (видно, де вона закінчується)
        int ex = (int) tx(laneX, s.length());
        if (ex < laneX + laneW) gui.g.fill(Math.max(ex, laneX), cy, laneX + laneW, cy + ch, 0x66000000);
        if (ex >= laneX && ex <= laneX + laneW) gui.g.fill(ex, cy, ex + 1, cy + ch, 0x99F2B84B);
        // playhead
        int px = (int) tx(laneX, s.time);
        if (px >= laneX && px <= laneX + laneW) gui.g.fill(px, cy, px + 1, cy + ch, 0xFFE5646A);
        gui.g.disableScissor();
        gui.popClip();
        if (px >= laneX && px <= laneX + laneW) gui.g.fill(px - 3, ry, px + 4, ry + 4, 0xFFE5646A);
        hScrollbar(s, gui, y, h, laneX, laneW);
        if (!gui.isDown(0) && drag != Drag.NONE) endDrag(s);
        libraryDrag(s, gui, x, y, laneX, laneW, h);
    }

    /**
     * Кидок з бібліотеки: над доріжками — напрямна, «привид» кліпу на доріжці під курсором (або «+ нова доріжка»),
     * для переходу — підсвічений стик кліпів камери. Відпустили — кліп/перехід саме там.
     */
    private static void libraryDrag(SceneEditorScreen s, Gui gui, int x, int y, int laneX, int laneW, int h) {
        MediaLibrary.Item it = MediaLibrary.dragging();
        if (it == null) return;
        int top = y + BAR + RULER;
        boolean over = gui.mx >= x && gui.mx < laneX + laneW && gui.my >= top && gui.my < y + h;
        if (!over) return;
        if (s.timelineMode != 0) s.timelineMode = 0;
        double at = Math.max(0, snapT(s, xt(laneX, Math.max(laneX, gui.mx)), null));
        boolean release = !gui.isDown(0);
        gui.g.pose().pushPose();
        gui.g.pose().translate(0, 0, 200);
        try {
            if (it.trans != null) {
                // найближчий стик (початок кліпу) на треках камер
                Track bestT = null;
                Clip best = null;
                double bestD = 14 / pps;
                for (Map.Entry<Track, int[]> e : ROWS.entrySet()) {
                    if (e.getKey().type != Track.Type.CAMERA || e.getKey().locked) continue;
                    for (Clip c : e.getKey().clips) {
                        double d = Math.abs(c.start - xt(laneX, gui.mx));
                        if (d < bestD) { bestD = d; best = c; bestT = e.getKey(); }
                    }
                }
                if (best != null) {
                    int[] r = ROWS.get(bestT);
                    int bx = (int) tx(laneX, best.start), d = (int) Math.max(8, it.trans.defaultMs / 1000.0 * pps);
                    gui.g.fill(bx - d / 2, r[0], bx + d / 2, r[0] + r[1] - 1, 0x66FFFFFF);
                    gui.g.renderOutline(bx - d / 2, r[0], d, r[1] - 1, 0xFFFFFFFF);
                    if (release) {
                        Clip c = best;
                        Track tr = bestT;
                        s.edit("Перехід: " + MediaLibrary.transitionTitle(it.trans), () -> c.transition = Transition.of(it.trans));
                        s.selectClip(tr, c);
                    }
                } else {
                    gui.g.fill(gui.mx, top, gui.mx + 1, y + h, 0x88FFFFFF);
                    gui.tip(Component.literal("Переходи кидають на стик кліпів камери (жовта доріжка)"));
                    if (release) s.toast("Переходи кидають на стик кліпів камери");
                }
            } else if (it.type != null) {
                Track target = null;
                for (Map.Entry<Track, int[]> e : ROWS.entrySet()) {
                    int[] r = e.getValue();
                    if (gui.my >= r[0] && gui.my < r[0] + r[1] && SceneEditorScreen.compatible(e.getKey(), it)) target = e.getKey();
                }
                double len = it.len;
                if (it.type == Track.Type.AUDIO && GameSounds.isGame(it.ref)) { double d = GameSounds.duration(GameSounds.id(it.ref), 0); if (d > 0) len = d; }
                int gx0 = (int) tx(laneX, at), gx1 = (int) Math.max(gx0 + 4, tx(laneX, at + len));
                int col = it.color;
                gui.g.fill(gui.mx, top, gui.mx + 1, y + h, 0xFFFFE08A);
                int gy, gh;
                if (target != null) { int[] r = ROWS.get(target); gy = r[0] + 1; gh = r[1] - 3; }
                else { gy = Math.min(y + h - 20, lanesBottom + 2); gh = 16; }
                gui.g.fill(gx0, gy, gx1, gy + gh, Theme.withAlpha(col, 0x70));
                gui.g.renderOutline(gx0, gy, gx1 - gx0, gh, col);
                gui.textClip((target == null ? "+ нова доріжка · " : "") + it.title, gx0 + 3, gy + Math.max(1, gh / 2 - 4), Math.max(0, gx1 - gx0 - 6), 0xFFFFFFFF);
                if (release) s.dropItem(it, target, at);
            } else if (release) {
                MediaLibrary.addAtPlayhead(s, it);   // модель/текстура — як «+»
            }
        } finally {
            gui.g.pose().popPose();
        }
        if (release) MediaLibrary.consumed();
    }

    /** Нижній край останньої доріжки цього кадру — під ним «порожнє місце» для нової доріжки. */
    private static int lanesBottom;

    private static void fit(SceneEditorScreen s, int laneW) {
        pps = Math.max(4, laneW / (s.length() * 1.04));
        scroll = 0;
    }

    /**
     * Колесо: над лінійкою або з Ctrl/Alt — масштаб (під курсором); над доріжками — вліво/вправо;
     * Shift+колесо або колесо над назвами треків — угору/вниз по треках.
     */
    private static void wheel(SceneEditorScreen s, Gui gui, int x, int y, int w, int h, int laneX, int laneW) {
        boolean overRuler = gui.hover(laneX, y + BAR, laneW, RULER);
        boolean overLanes = gui.hover(laneX, y + BAR + RULER, laneW, h - BAR - RULER);
        if (!overRuler && !overLanes) return;
        double d = gui.pendingScroll();
        if (d == 0) return;
        if (overRuler || Screen.hasControlDown() || Screen.hasAltDown()) {
            double tAt = xt(laneX, gui.mx);
            pps = Math.max(2, Math.min(2000, pps * (d > 0 ? 1.2 : 1 / 1.2)));
            scroll = tAt - (gui.mx - laneX) / pps;
        } else if (Screen.hasShiftDown()) {
            return;                                   // вертикально — забере прокрутка треків
        } else scroll -= d * 50 / pps;
        gui.consumeScroll();
        clampScroll(s, laneW);
    }

    private static double span(SceneEditorScreen s) { return Math.max(1, s.length() * 1.1 + 1); }

    private static void clampScroll(SceneEditorScreen s, int laneW) {
        double view = laneW / pps;
        scroll = Math.max(-0.5, Math.min(scroll, Math.max(0, span(s) - view * 0.5)));
    }

    /** Середня кнопка — тягнути таймлайн; смуга прокрутки внизу — тягнути повзунок або клікнути поруч. */
    private static void navigate(SceneEditorScreen s, Gui gui, int y, int h, int laneX, int laneW) {
        if (gui.press("tl.pan", laneX, y + BAR, laneW, h - BAR, 2)) { panFrom = gui.mx; panScroll = scroll; }
        if (gui.isActive("tl.pan")) { scroll = panScroll - (gui.mx - panFrom) / pps; clampScroll(s, laneW); gui.cursor(Gui.CUR_HRESIZE); }
        int sbY = y + h - 7;
        double view = laneW / pps, sp = Math.max(span(s), scroll + view);
        int tw = (int) Math.max(24, Math.min(laneW, laneW * view / sp));
        int tx0 = laneX + (int) ((laneW - tw) * Math.max(0, Math.min(1, Math.max(0, scroll) / Math.max(0.001, sp - view))));
        if (gui.press("tl.hsb", laneX, sbY - 1, laneW, 7, 0)) {
            sbSpan = sp;
            sbGrab = gui.mx >= tx0 && gui.mx < tx0 + tw ? gui.mx - tx0 : tw / 2.0;
        }
        if (gui.isActive("tl.hsb")) {
            double f = (gui.mx - sbGrab - laneX) / Math.max(1.0, laneW - tw);
            scroll = Math.max(0, Math.min(1, f)) * Math.max(0, sbSpan - view);
            clampScroll(s, laneW);
        }
    }

    private static void hScrollbar(SceneEditorScreen s, Gui gui, int y, int h, int laneX, int laneW) {
        int sbY = y + h - 7;
        double view = laneW / pps, sp = Math.max(span(s), scroll + view);
        int tw = (int) Math.max(24, Math.min(laneW, laneW * view / sp));
        int tx0 = laneX + (int) ((laneW - tw) * Math.max(0, Math.min(1, Math.max(0, scroll) / Math.max(0.001, sp - view))));
        boolean hot = gui.hover(laneX, sbY - 1, laneW, 7) || gui.isActive("tl.hsb");
        gui.g.fill(laneX, sbY, laneX + laneW, sbY + 5, hot ? 0x90000000 : 0x50000000);
        gui.g.fill(tx0, sbY, tx0 + tw, sbY + 5, hot ? 0xFF8FA8D8 : 0xFF4A5A7A);
        if (hot) { gui.cursor(Gui.CUR_HAND); gui.tip(Component.literal("Тягни — рух по часу. Колесо над доріжками — вліво/вправо, над лінійкою — масштаб, середня кнопка — тягнути")); }
    }

    // ═════════════════════════ панель інструментів ═════════════════════════

    /**
     * Рядок над доріжками: зліва — правка треків (+ Трек, Вміст, Розрізати), ПО ЦЕНТРУ — транспорт і час
     * (як у будь-якій монтажці), справа — «Перегляд». Перемикачі Кліпи/Ключі/Криві тут більше не дублюються —
     * це сторінки внизу (Монтаж / Ключі / Криві).
     */
    private static void toolbar(SceneEditorScreen s, Gui gui, int x, int y, int w, int laneW) {
        MenuSkin.bar(gui.g, x, y, w, BAR, false);
        int by = y + 1, b = 16;
        int left = x + 4, right = x + w - 3;

        // ── справа: перегляд ──
        int pvW = gui.font.width("▶ Перегляд") + 10;
        int pvX = right - pvW;
        if (gui.button(pvX, by, pvW, b, Component.literal("▶ Перегляд"), false, Component.literal("P: уся сцена з камери на весь екран, як побачить гравець. Esc — назад"))) s.startPreview();
        right = pvX - 6;

        // ── центр: транспорт + час ──
        String tm = s.fmtTime(s.time) + " / " + s.fmtTime(s.length());
        int tw = gui.font.width(tm);
        int groupW = 4 * (b + 1) + 6 + tw;
        int leftW = gui.font.width("+ Трек") + 10 + 4 + gui.font.width("Вміст") + 10 + 4 + (s.selClip != null ? gui.font.width("Розрізати") + 10 + 4 : 0);
        int cx = x + (w - groupW) / 2;
        cx = Math.max(cx, left + leftW + 6);
        if (cx + groupW > right) { tm = s.fmtTime(s.time); tw = gui.font.width(tm); groupW = 4 * (b + 1) + 6 + tw; cx = Math.max(left + leftW + 6, Math.min(cx, right - groupW)); }
        if (gui.iconButton(cx, by, b, Icon.REWIND, false, Component.literal("На початок (Home)"))) s.seek(0);
        cx += b + 1;
        if (gui.iconButton(cx, by, b, s.playing ? Icon.PAUSE : Icon.PLAY, s.playing, Component.literal("Грати / пауза (Space)"))) s.playing = !s.playing;
        cx += b + 1;
        if (gui.iconButton(cx, by, b, Icon.SKIP_NEXT, false, Component.literal("До наступного ключа/кліпу (↑)"))) s.jumpKey(true);
        cx += b + 1;
        if (gui.iconButton(cx, by, b, Icon.LOOP, s.loopPlayback, Component.literal("Зациклити превʼю"))) s.loopPlayback = !s.loopPlayback;
        cx += b + 6;
        if (cx + tw <= right) {
            SceneDoc.Variant v = s.variant();
            boolean hot = gui.hover(cx - 2, by, tw + 4, b);
            if (hot) { gui.g.fill(cx - 2, by, cx + tw + 2, by + b, 0x30FFFFFF); gui.cursor(Gui.CUR_HAND); gui.tip(Component.literal("Довжина сцени" + (v.autoLength ? " (авто — за вмістом)" : "") + ": клік — меню.\nАбо тягни жовту риску на лінійці")); }
            gui.text(tm, cx, y + 5, v.autoLength ? 0xFF9DE3B0 : Theme.TEXT);
            if (hot && !s.readOnly && gui.clicked(cx - 2, by, tw + 4, b, 0)) {
                double end = Math.max(0.1, s.contentEnd(v));
                Popup.open("Довжина сцени", cx, by + b + 2, List.of(
                    Popup.item((v.autoLength ? "● " : "○ ") + "Авто: до кінця останнього кліпу/ключа", () -> s.edit("Довжина", () -> v.autoLength = !v.autoLength)),
                    Popup.item("Обрізати до вмісту (" + s.fmtTime(end) + ")", () -> s.edit("Довжина", () -> { v.length = end; v.autoLength = false; })),
                    Popup.item("Кінець = playhead (" + s.fmtTime(s.time) + ")", () -> s.edit("Довжина", () -> { v.length = Math.max(0.1, s.time); v.autoLength = false; })),
                    Popup.item("+5 с", () -> s.edit("Довжина", () -> { v.length += 5; v.autoLength = false; })),
                    Popup.item("+30 с", () -> s.edit("Довжина", () -> { v.length += 30; v.autoLength = false; }))));
            }
        }

        // ── зліва: треки ──
        int lx = left;
        int addW = gui.font.width("+ Трек") + 10;
        if (gui.button(lx, by, addW, b, Component.literal("+ Трек"), false, Component.literal("Новий трек: камери, анімація актора, звук, оверлей, ефект, час"), !s.readOnly)) {
            List<Popup.Item> items = new ArrayList<>();
            items.add(Popup.item("Камери (монтаж)", () -> s.addTrack(Track.Type.CAMERA, null)));
            SceneObject sel = s.selected();
            boolean actor = sel != null && (sel.kind == SceneObject.Kind.ACTOR || sel.kind == SceneObject.Kind.PROP);
            items.add(Popup.item("Анімація → " + (actor ? sel.name : "(виберіть актора)"), () -> s.addTrack(Track.Type.ANIMATION, sel.id), actor));
            items.add(Popup.item("Звук", () -> s.addTrack(Track.Type.AUDIO, null)));
            items.add(Popup.item("Оверлей", () -> s.addTrack(Track.Type.OVERLAY, null)));
            items.add(Popup.item("Ефект / шейдер", () -> s.addTrack(Track.Type.EFFECT, null)));
            items.add(Popup.item("Час (сповільнення)", () -> s.addTrack(Track.Type.TIME, null)));
            Popup.open("Новий трек", lx, by + b + 2, items);
        }
        lx += addW + 4;
        int fitW = gui.font.width("Вміст") + 10;
        if (gui.button(lx, by, fitW, b, Component.literal("Вміст"), false, Component.literal("Масштаб: уся сцена"))) fit(s, laneW);
        lx += fitW + 4;
        int cutW = gui.font.width("Розрізати") + 10;
        if (s.selClip != null && gui.button(lx, by, cutW, b, Component.literal("Розрізати"), false, Component.literal("S: розрізати вибраний кліп у playhead"))) s.splitClip();
    }

    // ═════════════════════════ лінійка ═════════════════════════

    private static void ruler(SceneEditorScreen s, Gui gui, int x0, int y, int w) {
        gui.g.fill(x0, y, x0 + w, y + RULER, 0xFF0B111E);
        double step = niceStep(60 / pps, s.fps());
        double t0 = Math.floor(scroll / step) * step;
        for (double t = t0; tx(x0, t) < x0 + w; t += step) {
            int px = (int) tx(x0, t);
            if (px < x0) continue;
            gui.g.fill(px, y + 8, px + 1, y + RULER, 0xFF3A4A6A);
            String lb = label(t, step);
            if (t >= -1e-6 && px + 2 + gui.font.width(lb) <= x0 + w) gui.g.drawString(gui.font, lb, px + 2, y + 2, 0xFF7C93C0, false);
        }
        SceneDoc.Variant v = s.variant();
        int ex = (int) tx(x0, v.length);
        if (ex < x0 + w) gui.g.fill(Math.max(ex, x0), y, x0 + w, y + RULER, 0x70000000);
        if (ex >= x0 && ex <= x0 + w) {
            boolean hot = drag == Drag.END || gui.hover(ex - 4, y, 9, RULER);
            gui.g.fill(ex - (hot ? 1 : 0), y, ex + (hot ? 3 : 2), y + RULER, hot ? 0xFFFFE08A : 0xFFF2B84B);
            if (hot) { gui.cursor(Gui.CUR_HRESIZE); gui.tip(Component.literal("Кінець сцени " + s.fmtTime(v.length) + " — тягни")); }
            if (!s.readOnly && gui.press("tl.end", ex - 4, y, 9, RULER, 0)) { drag = Drag.END; s.begin("Довжина сцени"); return; }
        }
        if (v.workOut > v.workIn) gui.g.fill((int) tx(x0, v.workIn), y + RULER - 3, (int) tx(x0, v.workOut), y + RULER, 0x884A9EFF);
        for (Marker m : v.markers) {
            int mx = (int) tx(x0, m.time);
            if (mx < x0 - 4 || mx > x0 + w) continue;
            int col = 0xFF000000 | m.color;
            Draw2D.triangle(gui.g, mx - 4, y, mx + 4, y, mx, y + 7, m == s.selMarker ? 0xFFFFFFFF : col);
            if (gui.hover(mx - 4, y, 9, RULER)) {
                gui.tip(Component.literal(m.name + (m.event ? " (подія)" : "")));
                if (gui.press("marker", mx - 4, y, 9, RULER, 0)) { s.selMarker = m; s.selClip = null; drag = Drag.MARKER; dMarker = m; s.begin("Рух мітки"); return; }
            }
        }
        if (gui.press("ruler", x0, y, w, RULER, 0)) { drag = Drag.SCRUB; s.playing = false; }
        if (gui.clicked(x0, y, w, RULER, 1)) {
            double t = Math.max(0, xt(x0, gui.mx));
            Popup.open(s.fmtTime(t), gui.mx, gui.my, List.of(
                Popup.item("+ Мітка тут (M)", () -> { s.seek(t); s.addMarker(); }),
                Popup.item("Робоча зона: початок", () -> s.edit("Робоча зона", () -> s.variant().workIn = t)),
                Popup.item("Робоча зона: кінець", () -> s.edit("Робоча зона", () -> s.variant().workOut = t)),
                Popup.item("Довжина сцени = тут", () -> s.edit("Довжина", () -> { s.variant().length = Math.max(0.1, t); s.variant().autoLength = false; })),
                Popup.item("Скинути робочу зону", () -> s.edit("Робоча зона", () -> { s.variant().workIn = 0; s.variant().workOut = 0; }))));
        }
        if (drag == Drag.SCRUB) s.seek(snapT(s, xt(x0, gui.mx), null));
        if (drag == Drag.MARKER && dMarker != null) dMarker.time = Math.max(0, snapT(s, xt(x0, gui.mx), null));
        if (drag == Drag.END) {
            List<Double> pts = EditOps.snapPoints(v, null, s.time, null);
            pts.remove(1);                                   // сама довжина — не магніт для себе
            double t = EditOps.frame(xt(x0, gui.mx), s.fps());
            if (s.snapping) t = EditOps.snap(t, pts, 8 / pps);
            v.length = Math.max(0.1, t);
            v.autoLength = false;
        }
    }

    private static String label(double t, double step) {
        int s = (int) Math.floor(t + 1e-6);
        if (step >= 1) return s / 60 > 0 ? (s / 60) + ":" + String.format("%02d", s % 60) : s + "s";
        return String.format(java.util.Locale.ROOT, "%.2f", t);
    }

    private static double niceStep(double raw, double fps) {
        double[] steps = { 1 / fps, 0.1, 0.25, 0.5, 1, 2, 5, 10, 15, 30, 60 };
        for (double s : steps) if (s >= raw) return s;
        return 120;
    }

    private static double snapT(SceneEditorScreen s, double t, Clip except) {
        if (!s.snapping || Screen.hasShiftDown()) return EditOps.frame(t, s.fps());
        return EditOps.snap(EditOps.frame(t, s.fps()), EditOps.snapPoints(s.variant(), except, s.time, s.selected()), 8 / pps);
    }

    // ═════════════════════════ кліпи ═════════════════════════

    private static void clips(SceneEditorScreen s, Gui gui, int x, int y, int w, int h, int laneX, int laneW) {
        SceneDoc.Variant v = s.variant();
        SceneObject sel = s.selected();
        PREV_ROWS.clear();
        PREV_ROWS.putAll(ROWS);
        ROWS.clear();
        int total = sel != null ? ROW : 0;
        for (Track tr : v.tracks) total += rowH(tr);
        int off = gui.scrollBegin("tl.clips", x, y, w, h, total + 24);
        int cy = y - off;
        if (sel != null) { summaryRow(s, gui, x, cy, laneX, laneW, sel); cy += ROW; }
        for (int i = v.tracks.size() - 1; i >= 0; i--) {   // вищий трек — зверху, як у монтажці
            Track t = v.tracks.get(i);
            trackRow(s, gui, x, cy, w, laneX, laneW, t, i);
            cy += rowH(t);
        }
        lanesBottom = cy;
        if (v.tracks.isEmpty()) gui.textClip("Порожньо: перетягніть сюди звук, текст, ефект з бібліотеки ліворуч", x + 8, cy + 6, w - 16, Theme.MUTED);
        if (drag == Drag.CLIP_MOVE && moveToNew && dTrack != null) {
            gui.g.fill(laneX, cy + 2, laneX + laneW, cy + 18, 0x334A9EFF);
            gui.textClip("+ нова доріжка", laneX + 6, cy + 6, laneW - 12, Theme.ACCENT);
        }
        gui.scrollEnd();
        // перенос кліпу між доріжками того ж типу (як у монтажці — тягни вгору/вниз)
        if (moveTo != null && dClip != null && dTrack != null && moveTo != dTrack) {
            dTrack.clips.remove(dClip);
            moveTo.clips.add(dClip);
            dTrack = moveTo;
            s.selectClip(moveTo, dClip);
        }
        moveTo = null;
        if (gui.pendingClick() == 0 && gui.hover(laneX, y, laneW, h)) { s.selClip = null; s.selTrack = null; s.selMarker = null; s.seek(snapT(s, xt(laneX, gui.mx), null)); gui.consumeClick(); }
    }

    /** Рядок «ключі вибраного об'єкта» (summary) у режимі кліпів: ромб = момент з ключами; тягни — зсуває ключі цього моменту. */
    private static void summaryRow(SceneEditorScreen s, Gui gui, int x, int y, int laneX, int laneW, SceneObject o) {
        gui.g.fill(x + 1, y, x + HEAD - 2, y + ROW - 1, 0xFF18233F);
        Icons.draw(gui.g, Icon.KEYFRAME, x + 4, y + 3, 12, 0xFFF2B84B);
        gui.textClip("Ключі: " + o.name + (s.selBone != null ? " · " + s.selBone : ""), x + 18, y + 5, HEAD - 22, Theme.TEXT);
        gui.g.fill(laneX, y, laneX + laneW, y + ROW - 1, 0x22FFFFFF);
        List<Double> times = new ArrayList<>();
        for (KeyChannel.Key k : EditOps.allKeys(o)) if (times.stream().noneMatch(t -> Math.abs(t - k.t) < 1e-4)) times.add(k.t);
        for (double t : times) {
            int kx = (int) tx(laneX, t);
            if (kx < laneX - 4 || kx > laneX + laneW + 4) continue;
            diamond(gui, kx, y + ROW / 2, 4, 0xFFF2B84B);
            if (gui.press("sum" + t, kx - 4, y, 9, ROW, 0)) {
                drag = Drag.SUMMARY;
                summaryKeys = new ArrayList<>();
                for (KeyChannel.Key k : EditOps.allKeys(o)) if (Math.abs(k.t - t) < 1e-4) summaryKeys.add(k);
                dOrig.clear();
                for (KeyChannel.Key k : summaryKeys) dOrig.put(k, new double[] { k.t });
                dMouseT = xt(laneX, gui.mx);
                s.begin("Рух ключів");
            }
        }
        if (drag == Drag.SUMMARY) {
            double dt = EditOps.frame(xt(laneX, gui.mx) - dMouseT, s.fps());
            for (KeyChannel.Key k : summaryKeys) k.t = Math.max(0, dOrig.get(k)[0] + dt);
        }
    }

    private static void trackRow(SceneEditorScreen s, Gui gui, int x, int y, int w, int laneX, int laneW, Track t, int index) {
        boolean selTrack = t == s.selTrack;
        int rh = rowH(t);
        if (audioFocus && t.type != Track.Type.AUDIO) {
            // сторінка «Аудіо»: не-звукові доріжки — сірі смужки, лише щоб бачити, де що відбувається
            gui.g.fill(x + 1, y, x + HEAD - 2, y + rh - 1, 0xFF1A1D24);
            gui.g.fill(laneX, y, laneX + laneW, y + rh - 1, 0xFF15171C);
            for (Clip c : t.clips) {
                int x0 = (int) tx(laneX, c.start), x1 = (int) tx(laneX, c.end());
                if (x1 >= laneX && x0 <= laneX + laneW) gui.g.fill(Math.max(laneX, x0), y + 1, Math.min(laneX + laneW, x1), y + rh - 2, 0xFF3A3F4A);
            }
            return;
        }
        ROWS.put(t, new int[] { y, rh });
        gui.g.fill(x + 1, y, x + HEAD - 2, y + rh - 1, selTrack ? Theme.PANEL_HI : Theme.PANEL);
        int col = SceneEditorScreen.clipColor(t.type);
        gui.g.fill(x + 1, y, x + 3, y + rh - 1, col);
        Icons.draw(gui.g, SceneEditorScreen.trackIcon(t.type), x + 5, y + 3, 12, col);
        String name = t.name;
        if (t.type == Track.Type.ANIMATION) { SceneObject a = s.variant().object(t.target); name = a == null ? "⚠ актор зник" : a.name; }
        gui.textClip(name, x + 19, y + 5, HEAD - 62, t.muted ? Theme.MUTED : Theme.TEXT);
        int bx = x + HEAD - 40;
        if (gui.icon(bx, y + 3, 12, t.muted ? Icon.VOLUME : Icon.EYE, !t.muted, Component.literal("Вимкнути трек (mute)"))) s.edit("Mute", () -> t.muted = !t.muted);
        if (gui.icon(bx + 12, y + 3, 12, Icon.STAR, t.solo, Component.literal("Solo: лише цей трек свого типу"))) s.edit("Solo", () -> t.solo = !t.solo);
        if (gui.icon(bx + 24, y + 3, 12, t.locked ? Icon.LOCK : Icon.UNLOCK, t.locked, Component.literal("Заблокувати кліпи"))) s.edit("Lock", () -> t.locked = !t.locked);
        if (gui.clicked(x, y, HEAD - 42, ROW, 1)) {
            List<Popup.Item> items = new ArrayList<>();
            items.add(Popup.item("Вгору", () -> s.edit("Порядок", () -> move(s.variant().tracks, t, 1)), index < s.variant().tracks.size() - 1));
            items.add(Popup.item("Вниз", () -> s.edit("Порядок", () -> move(s.variant().tracks, t, -1)), index > 0));
            items.add(Popup.item("Видалити трек", () -> s.edit("Видалити трек", () -> s.variant().tracks.remove(t))));
            Popup.open(name, gui.mx, gui.my, items);
        }
        if (gui.clicked(x, y, HEAD - 42, ROW, 0)) { s.selTrack = t; s.selClip = null; }
        if (t.type == Track.Type.AUDIO) trackVolume(s, gui, x + 19, y + rh - 13, HEAD - 24, t, col);

        gui.g.fill(laneX, y, laneX + laneW, y + rh - 1, index % 2 == 0 ? 0x0EFFFFFF : 0x06FFFFFF);
        for (Clip c : t.clips) clip(s, gui, laneX, laneW, y, rh, t, c, col);
    }

    /** Повзунок гучності треку 0–200 % (множник на всі кліпи треку). Подвійний клік — повернути 100 %. */
    private static void trackVolume(SceneEditorScreen s, Gui gui, int sx, int sy, int sw, Track t, int col) {
        boolean active = drag == Drag.TRACK_GAIN && dTrack == t;
        boolean hv = gui.hover(sx, sy, sw, 9);
        gui.g.fill(sx, sy, sx + sw, sy + 9, Theme.RAIL);
        int fill = (int) Math.round(sw * Math.max(0, Math.min(2, t.gain)) / 2.0);
        gui.g.fill(sx, sy, sx + fill, sy + 9, Theme.withAlpha(col, hv || active ? 0xCC : 0x88));
        gui.g.fill(sx + sw / 2, sy, sx + sw / 2 + 1, sy + 9, 0x88FFFFFF);
        gui.text(Math.round(t.gain * 100) + "%", sx + 3, sy + 1, Theme.TEXT);
        if (s.readOnly) return;
        if (hv) { gui.cursor(Gui.CUR_HRESIZE); gui.tip(Component.literal("Гучність треку: тягни · подвійний клік — 100%")); }
        if (gui.doubleClicked(sx, sy, sw, 9)) { s.edit("Гучність треку", () -> t.gain = 1); gui.consumeClick(); }
        else if (gui.press("tgain" + t.id, sx, sy, sw, 9, 0)) { drag = Drag.TRACK_GAIN; dTrack = t; s.begin("Гучність треку"); }
        if (active) t.gain = Math.round(Math.max(0, Math.min(2, (gui.mx - sx) / (double) sw * 2)) * 20) / 20.0;
    }

    private static void move(List<Track> l, Track t, int d) {
        int i = l.indexOf(t), j = i + d;
        if (j < 0 || j >= l.size()) return;
        l.remove(i);
        l.add(j, t);
    }

    private static void clip(SceneEditorScreen s, Gui gui, int laneX, int laneW, int y, int rh, Track t, Clip c, int col) {
        int x0 = (int) tx(laneX, c.start), x1 = (int) tx(laneX, c.end());
        if (x1 < laneX || x0 > laneX + laneW) return;
        boolean sel = c == s.selClip;
        int cy = y + 1, ch = rh - 3;
        int body = c.muted ? 0xFF2A3348 : (col & 0x00FFFFFF) | 0x66000000;
        gui.g.fill(x0, cy, x1, cy + ch, body);
        // джерело закінчилось раніше за кліп: цикл / заморозка / тиша
        if (c.sourceLength > 0 && (t.type == Track.Type.ANIMATION || t.type == Track.Type.AUDIO)) {
            double srcEnd = c.start + Math.max(0, c.sourceLength - c.in) / c.speed;
            if (srcEnd < c.end()) {
                int ex = (int) tx(laneX, srcEnd);
                gui.g.fill(ex, cy, ex + 1, cy + ch, 0xFFFFFFFF);
                switch (c.end) {
                    case LOOP -> {
                        double span = Math.max(0.05, (c.sourceLength - Math.min(c.in, c.sourceLength * 0.999)) / c.speed);
                        for (double tt = srcEnd + span; tt < c.end(); tt += span) { int lx = (int) tx(laneX, tt); gui.g.fill(lx, cy + 2, lx + 1, cy + ch - 2, 0xAAFFFFFF); }
                    }
                    case HOLD -> { for (int hx = ex + 3; hx < x1; hx += 5) gui.g.fill(hx, cy + ch - 4, hx + 2, cy + ch - 2, 0xAAFFFFFF); }
                    case STOP -> gui.g.fill(ex + 1, cy, x1, cy + ch, 0xAA000000);
                }
            }
        }
        if (t.type == Track.Type.AUDIO) wave(s, gui, laneX, c, x0, x1, cy, ch);
        // blend in/out
        if (c.blendIn > 0) Draw2D.triangle(gui.g, x0, cy + ch, (int) tx(laneX, c.start + c.blendIn), cy, x0, cy, 0x55000000);
        if (c.blendOut > 0) Draw2D.triangle(gui.g, x1, cy + ch, x1, cy, (int) tx(laneX, c.end() - c.blendOut), cy, 0x55000000);
        // перехід на вході
        if (c.transition != null && c.transition.type != Transition.Type.CUT) {
            int d = (int) (c.transition.duration * pps);
            int tx0 = c.transition.type == Transition.Type.BLEND ? x0 : x0 - d / 2;
            gui.g.fill(tx0, cy, tx0 + Math.max(2, d), cy + 4, 0xDDFFFFFF);
        }
        clipCurve(gui, laneX, c, x0, x1, cy, ch);
        if (t.type == Track.Type.AUDIO) audioOverlay(gui, laneX, c, x0, x1, cy, ch, sel);
        gui.g.renderOutline(x0, cy, Math.max(1, x1 - x0), ch, sel ? 0xFFFFFFFF : col);
        gui.textClip(clipLabel(s, t, c), x0 + 3, cy + 4, Math.max(0, x1 - x0 - 6), 0xFFFFFFFF);
        // перехід: тягни білу смугу — довжина переходу (як «мікс» між кліпами в Kdenlive)
        if (c.transition != null && c.transition.type != Transition.Type.CUT && !t.locked && !s.readOnly) {
            int d = (int) (c.transition.duration * pps);
            int tx0 = c.transition.type == Transition.Type.BLEND ? x0 : x0 - d / 2;
            if (gui.hover(tx0 - 2, cy - 1, Math.max(4, d) + 4, 6)) { gui.cursor(Gui.CUR_HRESIZE); gui.tip(Component.literal("Тягни — тривалість переходу")); }
            if (gui.press("trans" + c.id, tx0 - 2, cy - 1, Math.max(4, d) + 4, 6, 0)) {
                s.selectClip(t, c);
                drag = Drag.TRANS; dClip = c; dTrack = t;
                s.begin("Тривалість переходу");
            }
        }

        if (t.locked || s.readOnly) { if (gui.clicked(x0, cy, x1 - x0, ch, 0)) s.selectClip(t, c); return; }
        if (t.type == Track.Type.AUDIO && audioHandles(s, gui, laneX, t, c, x0, x1, cy, ch)) return;
        boolean edgeL = Math.abs(gui.mx - x0) <= 3, edgeR = Math.abs(gui.mx - x1) <= 3;
        if (gui.hover(x0 - 3, cy, x1 - x0 + 6, ch) && (edgeL || edgeR)) gui.cursor(Gui.CUR_HRESIZE);
        if (gui.press("clip" + c.id, x0 - 3, cy, x1 - x0 + 6, ch, 0)) {
            s.selectClip(t, c);
            drag = edgeL ? Drag.CLIP_L : edgeR ? Drag.CLIP_R : Drag.CLIP_MOVE;
            // Kdenlive: Alt+тягни тіло — slip (зсув вмісту без руху кліпу), Ctrl+тягни стик — roll (межа двох кліпів)
            if (drag == Drag.CLIP_MOVE && Screen.hasAltDown()) drag = Drag.CLIP_SLIP;
            dNext = null;
            if (drag == Drag.CLIP_R && Screen.hasControlDown()) {
                for (Clip o : t.clips) if (o != c && Math.abs(o.start - c.end()) < 1e-3) dNext = o;
                if (dNext != null) { drag = Drag.CLIP_ROLL; dNStart = dNext.start; dNLen = dNext.length; dNIn = dNext.in; }
            }
            dClip = c; dTrack = t;
            dMouseT = xt(laneX, gui.mx);
            dStart = c.start; dLen = c.length; dIn = c.in;
            s.begin(drag == Drag.CLIP_MOVE ? "Рух кліпу" : "Обрізати кліп");
        }
        if (gui.clicked(x0, cy, x1 - x0, ch, 1)) { s.selectClip(t, c); context(s, t, c, gui.mx, gui.my); }
        if (dClip == c && drag != Drag.NONE) {
            double mt = xt(laneX, gui.mx), d = mt - dMouseT;
            switch (drag) {
                case CLIP_MOVE -> {
                    moveToNew = false;
                    if (!Screen.hasAltDown()) {
                        int bottom = Integer.MIN_VALUE;
                        for (Map.Entry<Track, int[]> e : PREV_ROWS.entrySet()) {
                            int[] r = e.getValue();
                            bottom = Math.max(bottom, r[0] + r[1]);
                            Track o = e.getKey();
                            if (gui.my >= r[0] && gui.my < r[0] + r[1] && o != t && o.type == t.type && !o.locked
                                && (t.type != Track.Type.ANIMATION || java.util.Objects.equals(o.target, t.target))) moveTo = o;
                        }
                        if (bottom != Integer.MIN_VALUE && gui.my >= bottom + 2) moveToNew = true;
                    }
                    double ns = snapT(s, dStart + d, c);
                    double ne = snapT(s, dStart + d + dLen, c);
                    c.start = Math.max(0, Math.abs(ne - (dStart + d + dLen)) < Math.abs(ns - (dStart + d)) ? ne - dLen : ns);
                }
                case CLIP_L -> { c.start = dStart; c.length = dLen; c.in = dIn; EditOps.trimStart(c, Math.max(0, snapT(s, dStart + d, c))); }
                case CLIP_R -> {
                    EditOps.trimEnd(c, snapT(s, dStart + dLen + d, c));
                    // потягнули далі за кінець анімації/звуку — грає по колу (як idle), коротше — без змін
                    if ((t.type == Track.Type.ANIMATION || t.type == Track.Type.AUDIO) && c.sourceLength > 0
                        && (c.length * c.speed + c.in) > c.sourceLength + 1e-3 && c.end != Clip.End.LOOP) c.end = Clip.End.LOOP;
                }
                case CLIP_SLIP -> c.in = Math.max(0, dIn - d * c.speed);
                case CLIP_GAIN -> c.params.put("gain", Math.round(Math.max(0, Math.min(2, (cy + ch - 2 - gui.my) / (double) Math.max(1, ch - 4) * 2)) * 50) / 50.0);
                case FADE_L -> c.blendIn = Math.max(0, Math.min(c.length - c.blendOut, EditOps.frame(mt - c.start, s.fps())));
                case FADE_R -> c.blendOut = Math.max(0, Math.min(c.length - c.blendIn, EditOps.frame(c.end() - mt, s.fps())));
                case CLIP_ROLL -> {
                    double b = snapT(s, dStart + dLen + d, c);
                    b = Math.max(c.start + 0.05, Math.min(dNStart + dNLen - 0.05, b));
                    c.length = b - c.start;
                    dNext.start = b;
                    dNext.length = dNLen - (b - dNStart);
                    dNext.in = Math.max(0, dNIn + (b - dNStart) * dNext.speed);
                }
                case TRANS -> {
                    double m = Math.abs(xt(laneX, gui.mx) - c.start) * (c.transition.type == Transition.Type.BLEND ? 1 : 2);
                    c.transition.duration = Math.max(0.05, Math.min(c.length, EditOps.frame(m, s.fps())));
                }
                default -> { }
            }
        }
    }

    private static boolean gainKeyed(Clip c) {
        KeyChannel k = c.channels.get(Channels.GAIN);
        return k != null && !k.isEmpty();
    }

    private static int gainY(Clip c, int cy, int ch) {
        return cy + ch - 2 - (int) Math.round(Math.max(0, Math.min(2, c.param("gain", 1))) / 2.0 * Math.max(1, ch - 4));
    }

    /** Звук: лінія гучності (100 % посередині), трикутники fade in/out. Лише малює; тягнуть у {@link #audioHandles}. */
    private static void audioOverlay(Gui gui, int laneX, Clip c, int x0, int x1, int cy, int ch, boolean sel) {
        if (x1 - x0 < 12) return;
        if (!gainKeyed(c)) {
            int ly = gainY(c, cy, ch);
            gui.g.fill(x0 + 1, ly, x1 - 1, ly + 1, 0xFFFFE08A);
            if (sel) gui.textClip(Math.round(c.param("gain", 1) * 100) + "%", x0 + 4, Math.max(cy + 12, Math.min(cy + ch - 9, ly - 9)), 40, 0xFFFFE08A);
        }
        int fl = (int) tx(laneX, c.start + c.blendIn), fr = (int) tx(laneX, c.end() - c.blendOut);
        gui.g.fill(fl - 2, cy + 1, fl + 3, cy + 6, 0xFFFFFFFF);
        gui.g.fill(fr - 2, cy + 1, fr + 3, cy + 6, 0xFFFFFFFF);
    }

    /** Звук: тягни білий квадрат — fade in/out, жовту лінію — гучність кліпу. Повертає true, якщо щойно почалось перетягування. */
    private static boolean audioHandles(SceneEditorScreen s, Gui gui, int laneX, Track t, Clip c, int x0, int x1, int cy, int ch) {
        if (x1 - x0 < 12) return false;
        int fl = (int) tx(laneX, c.start + c.blendIn), fr = (int) tx(laneX, c.end() - c.blendOut);
        if (gui.hover(fl - 4, cy, 9, 8) || gui.hover(fr - 4, cy, 9, 8)) { gui.cursor(Gui.CUR_HRESIZE); gui.tip(Component.literal("Тягни — fade in/out (плавне наростання й згасання звуку)")); }
        if (gui.press("fadeL" + c.id, fl - 4, cy, 9, 8, 0)) { startAudioDrag(s, t, c, Drag.FADE_L, "Fade in"); return true; }
        if (gui.press("fadeR" + c.id, fr - 4, cy, 9, 8, 0)) { startAudioDrag(s, t, c, Drag.FADE_R, "Fade out"); return true; }
        if (!gainKeyed(c)) {
            int ly = gainY(c, cy, ch);
            if (gui.hover(x0 + 6, ly - 3, Math.max(1, x1 - x0 - 12), 7)) { gui.cursor(Gui.CUR_HRESIZE); gui.tip(Component.literal("Тягни вгору/вниз — гучність кліпу (100% посередині)")); }
            if (gui.press("cgain" + c.id, x0 + 6, ly - 3, Math.max(1, x1 - x0 - 12), 7, 0)) { startAudioDrag(s, t, c, Drag.CLIP_GAIN, "Гучність кліпу"); return true; }
        }
        return false;
    }

    private static void startAudioDrag(SceneEditorScreen s, Track t, Clip c, Drag d, String label) {
        s.selectClip(t, c);
        drag = d; dClip = c; dTrack = t;
        s.begin(label);
    }

    private static String clipLabel(SceneEditorScreen s, Track t, Clip c) {
        if (c.name != null) return c.name;
        return switch (t.type) {
            case CAMERA -> { SceneObject o = s.variant().object(c.ref); yield o == null ? "⚠ камера?" : o.name; }
            case AUDIO -> {
                if (GameSounds.isGame(c.ref)) yield "♪ " + GameSounds.pretty(GameSounds.id(c.ref));
                SceneDoc.Asset a = s.doc.assets.get(c.ref);
                yield a == null ? String.valueOf(c.ref) : a.name;
            }
            case OVERLAY -> {
                Object tx = c.params.get("text");
                var e = dev.shaurmalib.scene.mc.client.SceneOverlays.overlayEntry(c.ref);
                yield tx != null && !tx.toString().isEmpty() ? "T " + tx : e != null ? e.title() : String.valueOf(c.ref);
            }
            case EFFECT -> { var e = dev.shaurmalib.scene.mc.client.SceneOverlays.effectEntry(c.ref); yield e != null ? e.title() : String.valueOf(c.ref); }
            case TIME -> "×" + String.format(java.util.Locale.ROOT, "%.2f", c.param(Channels.SPEED, 0.5));
            default -> c.ref == null ? "—" : c.ref.replaceFirst("^[^:]+:", "");
        };
    }

    /** Крива параметра кліпу просто на кліпі (як ключі ефектів на кліпі в Kdenlive): гучність, прозорість, сила, швидкість. */
    private static void clipCurve(Gui gui, int laneX, Clip c, int x0, int x1, int cy, int ch) {
        KeyChannel k = null;
        for (String n : new String[] { Channels.GAIN, Channels.OPACITY, Channels.INTENSITY, Channels.SPEED, "scale", "x", "y" }) {
            KeyChannel kk = c.channels.get(n);
            if (kk != null && !kk.isEmpty()) { k = kk; break; }
        }
        if (k == null || x1 - x0 < 6) return;
        double lo = 0, hi = 1;
        for (KeyChannel.Key key : k.keys()) { lo = Math.min(lo, key.v); hi = Math.max(hi, key.v); }
        double range = Math.max(1e-6, hi - lo);
        double px = -1, py = 0;
        for (int x = x0; x <= x1; x += 2) {
            double v = k.sample(xt(laneX, x) - c.start);
            double y = cy + ch - 2 - (v - lo) / range * (ch - 4);
            if (px >= 0) Draw2D.line(gui.g, px, py, x, y, 1f, 0xFFFFE08A);
            px = x; py = y;
        }
        for (KeyChannel.Key key : k.keys()) {
            double x = tx(laneX, c.start + key.t);
            if (x < x0 || x > x1) continue;
            Draw2D.dot(gui.g, x, cy + ch - 2 - (key.v - lo) / range * (ch - 4), 2, 0xFFFFE08A);
        }
    }

    private static final Map<String, float[]> PEAKS = new HashMap<>();

    private static void wave(SceneEditorScreen s, Gui gui, int laneX, Clip c, int x0, int x1, int cy, int ch) {
        boolean game = GameSounds.isGame(c.ref);
        SceneDoc.Asset a = game ? null : s.doc.assets.get(c.ref);
        if (a == null && !game) return;
        String pkKey = game ? c.ref + "#" + (int) c.param("variant", 0) : a.sha256;
        float[] pk = PEAKS.get(pkKey);
        if (pk == null) {
            AudioPcm pcm = game ? GameSounds.pcm(GameSounds.id(c.ref), (int) c.param("variant", 0), false) : SceneAssets.audio(s.doc, c.ref);
            if (pcm == null) return;
            pk = pcm.peaks(Math.max(1, (int) (pcm.duration() * 100)));
            PEAKS.put(pkKey, pk);
            if (game && c.sourceLength <= 0) c.sourceLength = pcm.duration();
        }
        int mid = cy + ch / 2;
        for (int px = Math.max(x0, laneX); px < x1; px++) {
            double t = xt(laneX, px);
            double src = (t - c.start) * c.speed + c.in;
            if (c.end == Clip.End.LOOP && c.sourceLength > 0 && src > c.sourceLength) src = c.in + ((src - c.in) % Math.max(0.05, c.sourceLength - c.in));
            int i = (int) (src * 100);
            if (i < 0 || i >= pk.length) continue;
            int amp = Math.min(ch / 2 - 1, (int) (pk[i] * c.fadeWeight(t) * c.param("gain", 1) * (ch / 2 - 1)));
            gui.g.fill(px, mid - amp, px + 1, mid + amp + 1, 0xCCBFE0FF);
        }
    }

    private static void context(SceneEditorScreen s, Track t, Clip c, int mx, int my) {
        List<Popup.Item> items = new ArrayList<>();
        items.add(Popup.item("Розрізати в playhead (S)", s::splitClip, c.covers(s.time)));
        items.add(Popup.item("Дублювати (Ctrl+D)", s::duplicateSelection));
        items.add(Popup.item(c.muted ? "Увімкнути" : "Вимкнути", () -> s.edit("Mute", () -> c.muted = !c.muted)));
        if (t.type == Track.Type.ANIMATION || t.type == Track.Type.AUDIO) {
            items.add(Popup.item("Кінець: зупинити", () -> s.edit("Кінець", () -> c.end = Clip.End.STOP)));
            items.add(Popup.item("Кінець: зациклити", () -> s.edit("Кінець", () -> c.end = Clip.End.LOOP)));
            items.add(Popup.item("Кінець: заморозити", () -> s.edit("Кінець", () -> c.end = Clip.End.HOLD)));
            items.add(Popup.item("Довжина = джерело", () -> s.edit("Довжина", () -> c.length = Math.max(0.05, (c.sourceLength - c.in) / c.speed)), c.sourceLength > 0));
        }
        if (t.type == Track.Type.ANIMATION) items.add(Popup.item("Запекти в ключі пози (BBS)", () -> s.bakeClip(t, c)));
        if (t.type == Track.Type.CAMERA) {
            items.add(Popup.item(c.transition == null ? "Перехід: тягни з бібліотеки «Переходи»" : "Прибрати перехід (" + MediaLibrary.transitionTitle(c.transition.type) + ")",
                () -> s.edit("Перехід", () -> c.transition = null), c.transition != null));
            items.add(Popup.item("Дивитись крізь цю камеру", () -> { s.seek(c.start + 0.01); s.view.cameraView = true; }));
        }
        items.add(Popup.item("Видалити (Del)", () -> s.edit("Видалити кліп", () -> t.clips.remove(c))));
        items.add(Popup.item("Видалити зі зсувом (Shift+Del)", () -> s.edit("Ripple delete", () -> EditOps.rippleDelete(t, c))));
        Popup.open(clipLabel(s, t, c), mx, my, items);
    }

    // ═════════════════════════ Dope Sheet ═════════════════════════

    /** Канали, що показуються: трансформ/камера + кістки вибраного (або всі кістки з ключами). */
    static Map<String, KeyChannel> channels(SceneEditorScreen s, SceneObject o) {
        Map<String, KeyChannel> m = new LinkedHashMap<>();
        if (s.selBone == null) {
            for (Map.Entry<String, KeyChannel> e : o.channels.map().entrySet()) if (!e.getValue().isEmpty()) m.put(e.getKey(), e.getValue());
        }
        for (Map.Entry<String, Channels> b : o.bones.entrySet()) {
            if (s.selBone != null && !s.selBone.equals(b.getKey())) continue;
            for (Map.Entry<String, KeyChannel> e : b.getValue().map().entrySet()) if (!e.getValue().isEmpty()) m.put(b.getKey() + "." + e.getKey(), e.getValue());
        }
        return m;
    }

    private static void dope(SceneEditorScreen s, Gui gui, int x, int y, int w, int h, int laneX, int laneW) {
        SceneObject o = s.selected();
        if (o == null) { gui.textClip("Виберіть об'єкт — тут його ключі по каналах", x + 8, y + 6, w - 16, Theme.MUTED); return; }
        Map<String, KeyChannel> chs = channels(s, o);
        int off = gui.scrollBegin("tl.dope", x, y, w, h, (chs.size() + 1) * KROW + 20);
        int cy = y - off;
        gui.textClip("Сумарно: " + o.name, x + 6, cy + 2, HEAD - 10, 0xFFF2B84B);
        gui.g.fill(laneX, cy, laneX + laneW, cy + KROW - 1, 0x22FFFFFF);
        for (KeyChannel.Key k : EditOps.allKeys(o)) diamond(gui, (int) tx(laneX, k.t), cy + KROW / 2, 3, 0x88F2B84B);
        cy += KROW;
        List<double[]> positions = new ArrayList<>();
        List<KeyChannel.Key> keyList = new ArrayList<>();
        List<KeyChannel> keyCh = new ArrayList<>();
        int row = 0;
        for (Map.Entry<String, KeyChannel> e : chs.entrySet()) {
            gui.g.fill(laneX, cy, laneX + laneW, cy + KROW - 1, row++ % 2 == 0 ? 0x0EFFFFFF : 0x06FFFFFF);
            gui.textClip(e.getKey(), x + 10, cy + 2, HEAD - 14, channelColor(e.getKey()));
            for (KeyChannel.Key k : e.getValue().keys()) {
                int kx = (int) tx(laneX, k.t);
                diamondKey(gui, kx, cy + KROW / 2, k);
                positions.add(new double[] { kx, cy + KROW / 2.0 });
                keyList.add(k);
                keyCh.add(e.getValue());
            }
            cy += KROW;
        }
        gui.scrollEnd();
        keyInteraction(s, gui, laneX, y, laneW, h, o, positions, keyList, keyCh);
    }

    private static void keyInteraction(SceneEditorScreen s, Gui gui, int laneX, int y, int laneW, int h, SceneObject o,
                                       List<double[]> pos, List<KeyChannel.Key> keys, List<KeyChannel> chs) {
        int hit = -1;
        for (int i = 0; i < pos.size(); i++) {
            double[] p = pos.get(i);
            if (Math.abs(gui.mx - p[0]) <= 4 && Math.abs(gui.my - p[1]) <= 5) hit = i;
        }
        if (gui.pendingClick() == 1 && hit >= 0 && gui.hover(laneX, y, laneW, h)) {
            gui.consumeClick();
            KeyChannel.Key k = keys.get(hit);
            if (!k.selected) { EditOps.clearSelection(o); k.selected = true; }
            keyMenu(s, o, gui.mx, gui.my);
            return;
        }
        if (gui.pendingClick() == 0 && gui.hover(laneX, y, laneW, h)) {
            gui.consumeClick();
            boolean add = Screen.hasControlDown() || Screen.hasShiftDown();
            if (hit >= 0) {
                KeyChannel.Key k = keys.get(hit);
                if (!add && !k.selected) EditOps.clearSelection(o);
                k.selected = !add || !k.selected;
                if (gui.pendingDouble()) s.seek(k.t);
                drag = Drag.KEYS;
                dOrig.clear();
                for (KeyChannel.Key x : EditOps.allKeys(o)) if (x.selected) dOrig.put(x, new double[] { x.t });
                dMouseT = xt(laneX, gui.mx);
                s.begin("Рух ключів");
            } else {
                if (!add) EditOps.clearSelection(o);
                drag = Drag.BOX;
                box = new double[] { gui.mx, gui.my, gui.mx, gui.my };
            }
        }
        if (drag == Drag.KEYS) {
            double dt = EditOps.frame(xt(laneX, gui.mx) - dMouseT, s.fps());
            for (Map.Entry<KeyChannel.Key, double[]> e : dOrig.entrySet()) e.getKey().t = Math.max(0, e.getValue()[0] + dt);
        }
        if (drag == Drag.BOX && box != null) {
            box[2] = gui.mx;
            box[3] = gui.my;
            int bx0 = (int) Math.min(box[0], box[2]), by0 = (int) Math.min(box[1], box[3]), bx1 = (int) Math.max(box[0], box[2]), by1 = (int) Math.max(box[1], box[3]);
            gui.g.fill(bx0, by0, bx1, by1, 0x224A9EFF);
            gui.g.renderOutline(bx0, by0, Math.max(1, bx1 - bx0), Math.max(1, by1 - by0), 0xAA4A9EFF);
            for (int i = 0; i < pos.size(); i++) {
                double[] p = pos.get(i);
                if (p[0] >= bx0 && p[0] <= bx1 && p[1] >= by0 && p[1] <= by1) keys.get(i).selected = true;
            }
        }
        // копіювати / вставити
        if (gui.hover(laneX, y, laneW, h) && Screen.hasControlDown()) {
            long win = net.minecraft.client.Minecraft.getInstance().getWindow().getWindow();
            if (com.mojang.blaze3d.platform.InputConstants.isKeyDown(win, org.lwjgl.glfw.GLFW.GLFW_KEY_C)) copy(s, o);
        }
    }

    private static void copy(SceneEditorScreen s, SceneObject o) {
        List<KeyChannel.Key> ks = new ArrayList<>();
        List<String> cn = new ArrayList<>();
        for (Map.Entry<String, KeyChannel> e : channels(s, o).entrySet()) for (KeyChannel.Key k : e.getValue().keys()) if (k.selected) { ks.add(k.copy()); cn.add(e.getKey()); }
        if (ks.isEmpty()) return;
        clipboard = ks;
        clipboardCh = cn;
        s.status = "Скопійовано ключів: " + ks.size() + " (Ctrl+V у меню ключа — вставити)";
    }

    private static void paste(SceneEditorScreen s, SceneObject o) {
        if (clipboard.isEmpty()) return;
        double t0 = Double.MAX_VALUE;
        for (KeyChannel.Key k : clipboard) t0 = Math.min(t0, k.t);
        double base = t0;
        s.edit("Вставити ключі", () -> {
            for (int i = 0; i < clipboard.size(); i++) {
                String name = clipboardCh.get(i);
                KeyChannel ch;
                int dot = name.indexOf('.');
                ch = dot > 0 ? o.bone(name.substring(0, dot)).getOrCreate(name.substring(dot + 1)) : o.channels.getOrCreate(name);
                KeyChannel.Key k = clipboard.get(i).copy();
                k.t = s.time + (k.t - base);
                KeyChannel.Key old = ch.keyAt(k.t, 1e-4);
                if (old != null) ch.remove(old);
                ch.add(k);
            }
        });
    }

    private static void keyMenu(SceneEditorScreen s, SceneObject o, int mx, int my) {
        List<Popup.Item> items = new ArrayList<>();
        items.add(Popup.item("Інтерполяція: Безьє", () -> forSel(s, o, k -> k.interp = KeyChannel.Interp.BEZIER)));
        items.add(Popup.item("Інтерполяція: лінійна", () -> forSel(s, o, k -> k.interp = KeyChannel.Interp.LINEAR)));
        items.add(Popup.item("Інтерполяція: константа", () -> forSel(s, o, k -> k.interp = KeyChannel.Interp.CONSTANT)));
        items.add(Popup.item("Ручки: Auto Clamped", () -> forSel(s, o, k -> k.handle = KeyChannel.HandleMode.AUTO_CLAMPED)));
        items.add(Popup.item("Ручки: Auto", () -> forSel(s, o, k -> k.handle = KeyChannel.HandleMode.AUTO)));
        items.add(Popup.item("Ручки: Vector", () -> forSel(s, o, k -> k.handle = KeyChannel.HandleMode.VECTOR)));
        items.add(Popup.item("Ручки: Free", () -> forSel(s, o, k -> k.handle = KeyChannel.HandleMode.FREE)));
        items.add(Popup.item("Ручки: Aligned", () -> forSel(s, o, k -> k.handle = KeyChannel.HandleMode.ALIGNED)));
        Easing[] es = { null, Easing.EASE_IN_OUT_SINE, Easing.EASE_IN_OUT_CUBIC, Easing.EASE_OUT_CUBIC, Easing.EASE_IN_CUBIC, Easing.EASE_OUT_BACK, Easing.EASE_OUT_BOUNCE, Easing.EASE_OUT_ELASTIC };
        for (Easing e : es) items.add(Popup.item("Easing: " + (e == null ? "немає" : e.name().toLowerCase(java.util.Locale.ROOT)), () -> forSel(s, o, k -> k.easing = e)));
        items.add(Popup.item("Копіювати (Ctrl+C)", () -> copy(s, o)));
        items.add(Popup.item("Вставити в playhead", () -> paste(s, o), !clipboard.isEmpty()));
        items.add(Popup.item("Видалити (Del)", () -> s.edit("Видалити ключі", () -> EditOps.deleteSelectedKeys(o))));
        Popup.open("Ключі", mx, my, items);
    }

    private static void forSel(SceneEditorScreen s, SceneObject o, java.util.function.Consumer<KeyChannel.Key> f) {
        s.edit("Ключі", () -> {
            for (KeyChannel ch : channels(s, o).values()) {
                boolean any = false;
                for (KeyChannel.Key k : ch.keys()) if (k.selected) { f.accept(k); any = true; }
                if (any) ch.recalcHandles();
            }
        });
    }

    // ═════════════════════════ Graph Editor ═════════════════════════

    private static void graph(SceneEditorScreen s, Gui gui, int x, int y, int w, int h, int laneX, int laneW) {
        SceneObject o = s.selected();
        if (o == null) { gui.textClip("Виберіть об'єкт — тут криві його каналів", x + 8, y + 6, w - 16, Theme.MUTED); return; }
        Map<String, KeyChannel> all = channels(s, o);
        Map<String, KeyChannel> shown = new LinkedHashMap<>();
        for (Map.Entry<String, KeyChannel> e : all.entrySet()) for (KeyChannel.Key k : e.getValue().keys()) if (k.selected) { shown.put(e.getKey(), e.getValue()); break; }
        if (shown.isEmpty()) shown = all;
        // список каналів зліва
        int ly = y + 2;
        for (Map.Entry<String, KeyChannel> e : all.entrySet()) {
            boolean on = shown.containsKey(e.getKey());
            gui.textClip((on ? "● " : "○ ") + e.getKey(), x + 6, ly, HEAD - 10, on ? channelColor(e.getKey()) : Theme.MUTED);
            if (gui.clicked(x, ly - 1, HEAD, 11, 0)) { EditOps.clearSelection(o); for (KeyChannel.Key k : e.getValue().keys()) k.selected = true; }
            ly += 11;
        }
        if (shown.isEmpty()) { gui.textClip("Ключів немає: K — ключ у playhead", laneX + 8, y + 6, laneW, Theme.MUTED); return; }
        // діапазон значень
        double t0 = xt(laneX, laneX), t1 = xt(laneX, laneX + laneW);
        if (drag != Drag.GKEY && drag != Drag.GHANDLE_L && drag != Drag.GHANDLE_R) {
            gMin = Double.MAX_VALUE; gMax = -Double.MAX_VALUE;
            for (KeyChannel ch : shown.values()) {
                for (int i = 0; i <= 80; i++) { double v = ch.sample(t0 + (t1 - t0) * i / 80); gMin = Math.min(gMin, v); gMax = Math.max(gMax, v); }
                for (KeyChannel.Key k : ch.keys()) { gMin = Math.min(gMin, k.v); gMax = Math.max(gMax, k.v); }
            }
            double pad = Math.max(0.5, (gMax - gMin) * 0.12);
            gMin -= pad; gMax += pad;
        }
        int gy0 = y + 6, gh = h - 12;
        // сітка значень
        for (int i = 0; i <= 4; i++) {
            int yy = gy0 + gh * i / 4;
            gui.g.fill(laneX, yy, laneX + laneW, yy + 1, 0x14FFFFFF);
            double v = gMax - (gMax - gMin) * i / 4;
            gui.g.drawString(gui.font, String.format(java.util.Locale.ROOT, "%.2f", v), laneX + 2, yy + 1, 0x557C93C0, false);
        }
        double range = gMax - gMin;
        for (Map.Entry<String, KeyChannel> e : shown.entrySet()) {
            KeyChannel ch = e.getValue();
            int col = channelColor(e.getKey());
            double prevX = -1, prevY = 0;
            for (int px = laneX; px <= laneX + laneW; px += 2) {
                double v = ch.sample(xt(laneX, px));
                double py = gy0 + (gMax - v) / range * gh;
                if (prevX >= 0) Draw2D.line(gui.g, prevX, prevY, px, py, 1.2f, col);
                prevX = px; prevY = py;
            }
            for (KeyChannel.Key k : ch.keys()) {
                double kx = tx(laneX, k.t), ky = gy0 + (gMax - k.v) / range * gh;
                if (k.selected && k.interp == KeyChannel.Interp.BEZIER) {
                    double lx = tx(laneX, k.t + k.lt), lyy = gy0 + (gMax - (k.v + k.lv)) / range * gh;
                    double rx = tx(laneX, k.t + k.rt), ry = gy0 + (gMax - (k.v + k.rv)) / range * gh;
                    Draw2D.line(gui.g, lx, lyy, kx, ky, 1f, 0xAAFFFFFF);
                    Draw2D.line(gui.g, kx, ky, rx, ry, 1f, 0xAAFFFFFF);
                    Draw2D.dot(gui.g, lx, lyy, 2, 0xFFFFFFFF);
                    Draw2D.dot(gui.g, rx, ry, 2, 0xFFFFFFFF);
                    if (drag == Drag.NONE && gui.pendingClick() == 0) {
                        if (Math.hypot(gui.mx - lx, gui.my - lyy) < 4) startHandle(s, gui, k, ch, Drag.GHANDLE_L);
                        else if (Math.hypot(gui.mx - rx, gui.my - ry) < 4) startHandle(s, gui, k, ch, Drag.GHANDLE_R);
                    }
                }
                Draw2D.dot(gui.g, kx, ky, k.selected ? 3 : 2, k.selected ? 0xFFFFFFFF : col);
                if (drag == Drag.NONE && gui.pendingClick() == 0 && Math.hypot(gui.mx - kx, gui.my - ky) < 5) {
                    gui.consumeClick();
                    if (!Screen.hasShiftDown()) EditOps.clearSelection(o);
                    k.selected = true;
                    drag = Drag.GKEY;
                    gKey = k; gChannel = ch;
                    dMouseT = xt(laneX, gui.mx); dMy = gui.my; dStart = k.t; dValue = k.v;
                    s.begin("Рух ключа");
                }
                if (gui.pendingClick() == 1 && Math.hypot(gui.mx - kx, gui.my - ky) < 5) {
                    gui.consumeClick();
                    if (!k.selected) { EditOps.clearSelection(o); k.selected = true; }
                    keyMenu(s, o, gui.mx, gui.my);
                }
            }
        }
        double perPx = range / gh;
        if (drag == Drag.GKEY && gKey != null) {
            gKey.t = Math.max(0, EditOps.frame(dStart + xt(laneX, gui.mx) - dMouseT, s.fps()));
            gKey.v = dValue - (gui.my - dMy) * perPx * (Screen.hasShiftDown() ? 0.1 : 1);
            gChannel.sort();
        }
        if ((drag == Drag.GHANDLE_L || drag == Drag.GHANDLE_R) && gKey != null) {
            double ht = xt(laneX, gui.mx) - gKey.t, hv = (gMax - (gui.my - gy0) * perPx) - gKey.v;
            if (gKey.handle != KeyChannel.HandleMode.ALIGNED) gKey.handle = KeyChannel.HandleMode.FREE;
            if (drag == Drag.GHANDLE_L) { gKey.lt = Math.min(-1e-3, ht); gKey.lv = hv; }
            else { gKey.rt = Math.max(1e-3, ht); gKey.rv = hv; }
            if (gKey.handle == KeyChannel.HandleMode.ALIGNED) {
                if (drag == Drag.GHANDLE_L) { double l = Math.hypot(gKey.rt, gKey.rv), m = Math.hypot(gKey.lt, gKey.lv); if (m > 1e-9) { gKey.rt = -gKey.lt / m * l; gKey.rv = -gKey.lv / m * l; } }
                else { double l = Math.hypot(gKey.lt, gKey.lv), m = Math.hypot(gKey.rt, gKey.rv); if (m > 1e-9) { gKey.lt = -gKey.rt / m * l; gKey.lv = -gKey.rv / m * l; } }
            }
        }
        if (gui.pendingClick() == 0 && gui.hover(laneX, y, laneW, h)) { gui.consumeClick(); EditOps.clearSelection(o); }
    }

    private static void startHandle(SceneEditorScreen s, Gui gui, KeyChannel.Key k, KeyChannel ch, Drag d) {
        gui.consumeClick();
        drag = d;
        gKey = k;
        gChannel = ch;
        s.begin("Ручка кривої");
    }

    // ═════════════════════════ спільне ═════════════════════════

    private static void endDrag(SceneEditorScreen s) {
        if (drag == Drag.CLIP_MOVE && moveToNew && dClip != null && dTrack != null) {
            Track nt = new Track(SceneDoc.newId(), dTrack.name, dTrack.type);
            nt.target = dTrack.target;
            dTrack.clips.remove(dClip);
            nt.clips.add(dClip);
            s.variant().tracks.add(0, nt);                    // під усіма — там, куди тягнули
            dTrack = nt;
            s.selectClip(nt, dClip);
        }
        moveToNew = false;
        if (drag == Drag.CLIP_MOVE && dClip != null && dTrack != null) {
            if (!dTrack.type.overlap) EditOps.resolveOverlap(dTrack, dClip);
            dTrack.sort();
        }
        if ((drag == Drag.CLIP_MOVE || drag == Drag.CLIP_R) && dClip != null && dClip.end() > s.variant().length)
            s.variant().length = dClip.end();                // витягли за кінець — сцена довшає, як у монтажці
        if (drag == Drag.KEYS || drag == Drag.SUMMARY || drag == Drag.GKEY) {
            SceneObject o = s.selected();
            if (o != null) {
                for (KeyChannel c : o.channels.map().values()) c.sort();
                for (Channels b : o.bones.values()) for (KeyChannel c : b.map().values()) c.sort();
            }
        }
        if (gChannel != null) gChannel.recalcHandles();
        if (drag != Drag.SCRUB && drag != Drag.BOX) s.commit();
        drag = Drag.NONE;
        dClip = null;
        dTrack = null;
        dMarker = null;
        box = null;
        gKey = null;
        gChannel = null;
        dOrig.clear();
    }

    private static void diamond(Gui gui, int x, int y, int r, int col) {
        Draw2D.quad(gui.g, x, y - r, x + r, y, x, y + r, x - r, y, col);
    }

    /** Форма ключа = інтерполяція: ромб — Безьє, квадрат — константа, трикутник — лінійна. */
    private static void diamondKey(Gui gui, int x, int y, KeyChannel.Key k) {
        int col = k.selected ? 0xFFFFFFFF : 0xFFF2B84B;
        switch (k.interp) {
            case CONSTANT -> gui.g.fill(x - 3, y - 3, x + 4, y + 4, col);
            case LINEAR -> Draw2D.triangle(gui.g, x - 4, y + 3, x + 4, y + 3, x, y - 4, col);
            default -> diamond(gui, x, y, 4, col);
        }
        if (k.easing != null) gui.g.fill(x - 1, y + 4, x + 2, y + 5, 0xFF39C5BB);
    }

    static int channelColor(String ch) {
        String c = ch.contains(".") ? ch.substring(ch.indexOf('.') + 1) : ch;
        return switch (c) {
            case "x", "rx", "px", "sx" -> Theme.AXIS_X;
            case "y", "ry", "py", "sy" -> Theme.AXIS_Y;
            case "z", "rz", "pz", "sz" -> Theme.AXIS_Z;
            case "yaw" -> 0xFFE5A04A;
            case "pitch" -> 0xFF59D185;
            case "roll" -> 0xFFB07CFF;
            case "fov" -> 0xFFF2B84B;
            default -> 0xFF9DB1D6;
        };
    }
}
