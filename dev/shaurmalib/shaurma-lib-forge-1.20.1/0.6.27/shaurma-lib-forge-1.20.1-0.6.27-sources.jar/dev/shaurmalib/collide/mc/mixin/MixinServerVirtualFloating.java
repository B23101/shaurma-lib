package dev.shaurmalib.collide.mc.mixin;

import dev.shaurmalib.collide.mc.ColliderPhysics;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Антифлай сервера: хто стоїть на моделі — не «висить у повітрі» (інакше кік через 80 тіків). */
@Mixin(ServerGamePacketListenerImpl.class)
public abstract class MixinServerVirtualFloating {

    @Inject(method = "noBlocksAround", at = @At("HEAD"), cancellable = true)
    private void shaurma$virtualGround(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (ColliderPhysics.standsOnVirtual(entity)) cir.setReturnValue(false);
    }
}
