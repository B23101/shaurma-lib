package dev.shaurmalib.collide.mc;

import dev.shaurmalib.anim.clip.AnimationClip;
import dev.shaurmalib.collide.Box;
import dev.shaurmalib.collide.ColliderAssets;
import dev.shaurmalib.collide.ColliderBody;
import dev.shaurmalib.collide.ColliderWorld;
import dev.shaurmalib.collide.CollisionModel;
import dev.shaurmalib.collide.Placement;
import dev.shaurmalib.collide.ShapeSource;
import dev.shaurmalib.collide.Voxelizer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;

import java.util.Optional;

/**
 * <b>Віртуальні блокові колізії</b> — публічний API.
 * <p>
 * Тіло прив'язується до позиції блоку-власника, але не займає клітинок світу: його форма
 * (довільного розміру, з поворотами й анімацією) вливається у ванільну фізику руху сутностей.
 * Гравці й моби стоять, ходять, стрибають, присідають на краю, упираються в нього так само, як у
 * звичайні блоки; рухомі частини везуть і виштовхують; приціл і снаряди в нього влучають.
 * <p>
 * Форма — функція від тіку гри, тож <b>реєструвати тіло треба на обох сторонах</b> з однаковими
 * даними (найпростіше — з {@code BlockEntity.onLoad}, який викликається і на сервері, і на клієнті).
 * Пакетів модуль не шле.
 *
 * <pre>{@code
 * // у BlockEntity:
 * public void onLoad() {
 *     super.onLoad();
 *     VirtualColliders.attachModel(level, worldPosition, new ResourceLocation("mymod", "big_door"),
 *         getBlockState().getValue(FACING), VirtualInteraction.OWNER_BLOCK);
 * }
 * public void setRemoved()        { super.setRemoved();        VirtualColliders.detach(level, worldPosition); }
 * public void onChunkUnloaded()   { super.onChunkUnloaded();   VirtualColliders.detach(level, worldPosition); }
 * // відтворити анімацію разом з хітбоксами (startTick — однаковий на сервері й клієнті, синхронізуйте через NBT):
 * VirtualColliders.play(level, worldPosition, model, animations, "open", startTick, facing, null);
 * }</pre>
 */
public final class VirtualColliders {

    private VirtualColliders() {}

    /**
     * Тіла світу. Живуть у полі самого {@link Level} (міксин {@code MixinLevelColliders}) — без
     * глобальних мап і синхронізації: світ і його тіла завжди в одному потоці й зникають разом.
     */
    public static ColliderWorld of(Level level) {
        ColliderHolder h = (ColliderHolder) level;
        ColliderWorld w = h.shaurma$colliders();
        if (w == null) {
            w = new ColliderWorld();
            h.shaurma$setColliders(w);
        }
        return w;
    }

    /** Без створення: {@code null} — у світі немає жодного тіла (швидкий шлях для міксинів). */
    static ColliderWorld peek(Level level) {
        if (level == null) return null;
        ColliderWorld w = ((ColliderHolder) level).shaurma$colliders();
        return w == null || w.isEmpty() ? null : w;
    }

    /** Світ вивантажено — забути всі його тіла. */
    public static void forget(Level level) {
        ((ColliderHolder) level).shaurma$setColliders(null);
    }

    // ── прив'язка ─────────────────────────────────────────────────────────

    /** Довільна форма (світові координати), роздільність вокселів типова. */
    public static ColliderBody attach(Level level, BlockPos owner, ShapeSource shape, VirtualInteraction interaction) {
        return attach(level, owner, shape, Voxelizer.DEFAULT_RES, interaction);
    }

    public static ColliderBody attach(Level level, BlockPos owner, ShapeSource shape, double resolution,
                                      VirtualInteraction interaction) {
        return of(level).put(owner.asLong(), shape, resolution, interaction);
    }

    /**
     * Нерухома geo-модель {@code assets/<ns>/geo/<path>.geo.json}, поставлена як GeckoLib ставить
     * блок ({@code FACING}). Колізійні — кістки {@code collision*}/{@code hitbox*}/{@code collider*},
     * а якщо їх немає — уся модель.
     *
     * @return тіло або порожньо, якщо модель не знайдено (попередження — в лог)
     */
    public static Optional<ColliderBody> attachModel(Level level, BlockPos owner, ResourceLocation model, Direction facing,
                                                     VirtualInteraction interaction) {
        return ColliderAssets.model(model.getNamespace(), model.getPath()).map(m ->
            attach(level, owner, ShapeSource.animated(m, placement(owner, facing), null, 0), interaction));
    }

    /**
     * Відтворити кліп з {@code assets/<ns>/animations/<path>.animation.json} — хітбокси рухаються
     * разом з моделлю. Тіло має вже існувати ({@link #attachModel}); інакше створюється з
     * {@link VirtualInteraction#OWNER_BLOCK}.
     *
     * @param clip      назва кліпа ({@code "open"} або {@code "animation.chest.open"}); {@code null} — поза спокою
     * @param startTick {@code level.getGameTime()} на момент старту, однаковий на обох сторонах
     * @param loop      {@code null} — як у файлі (GeckoLib {@code thenPlay}); {@code LOOP} — {@code thenLoop}
     */
    public static boolean play(Level level, BlockPos owner, ResourceLocation model, ResourceLocation animations,
                               String clip, long startTick, Direction facing, AnimationClip.LoopMode loop) {
        Optional<CollisionModel> m = ColliderAssets.model(model.getNamespace(), model.getPath());
        if (m.isEmpty()) return false;
        AnimationClip c = clip == null ? null
            : ColliderAssets.clip(animations.getNamespace(), animations.getPath(), clip).orElse(null);
        ShapeSource src = ShapeSource.animated(m.get(), placement(owner, facing), c, startTick, loop);
        ColliderWorld w = of(level);
        if (w.get(owner.asLong()) == null) w.put(owner.asLong(), src, Voxelizer.DEFAULT_RES, VirtualInteraction.OWNER_BLOCK);
        else w.setSource(owner.asLong(), src);
        return c != null || clip == null;
    }

    public static void detach(Level level, BlockPos owner) {
        if (level == null) return;
        ColliderWorld w = ((ColliderHolder) level).shaurma$colliders();
        if (w != null) w.remove(owner.asLong());
    }

    public static ColliderBody get(Level level, BlockPos owner) {
        ColliderWorld w = level == null ? null : ((ColliderHolder) level).shaurma$colliders();
        return w == null ? null : w.get(owner.asLong());
    }

    /** Поворот моделі блоку точно як у {@code GeoBlockRenderer}. */
    public static Placement placement(BlockPos pos, Direction facing) {
        return Placement.block(pos.getX(), pos.getY(), pos.getZ(),
            Placement.facing(facing == null ? "north" : facing.getSerializedName()));
    }

    // ── запити (для інших модулів/модів) ─────────────────────────────────

    /** Чи перетинає коробка хоч одне віртуальне тіло. */
    public static boolean intersects(Level level, AABB box) {
        ColliderWorld w = peek(level);
        return w != null && w.intersects(box(box));
    }

    static Box box(AABB a) { return new Box(a.minX, a.minY, a.minZ, a.maxX, a.maxY, a.maxZ); }

    static AABB aabb(Box b) { return new AABB(b.minX(), b.minY(), b.minZ(), b.maxX(), b.maxY(), b.maxZ()); }
}
