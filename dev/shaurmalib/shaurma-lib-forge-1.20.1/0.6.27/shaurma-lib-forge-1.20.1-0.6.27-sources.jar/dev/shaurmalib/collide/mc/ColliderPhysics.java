package dev.shaurmalib.collide.mc;

import dev.shaurmalib.collide.Box;
import dev.shaurmalib.collide.Carry;
import dev.shaurmalib.collide.ColliderBody;
import dev.shaurmalib.collide.ColliderWorld;
import dev.shaurmalib.collide.Obb;
import dev.shaurmalib.collide.RayHit;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.List;

/**
 * Усе, що віртуальні колізії роблять усередині гри. Міксини й клей лоадера лише викликають ці
 * методи (кожен міксин — один рядок), тож логіку видно в одному місці.
 * <p>
 * Кожен хук починається з {@link VirtualColliders#peek}: у світі без тіл — одне читання поля і вихід.
 */
public final class ColliderPhysics {

    private ColliderPhysics() {}

    // ── рух сутностей ─────────────────────────────────────────────────────

    /**
     * Доповнює список «колізій сутностей» у {@code Entity.collide} вокселями тіл. Ваніла далі сама
     * робить усе: зупинку об стіну, приземлення, step-up на сходинку, ковзання вздовж стіни.
     *
     * @param query область, яку ваніла перевіряє за цей рух (уже з урахуванням step-up)
     */
    public static List<VoxelShape> withVirtual(Entity entity, AABB query, List<VoxelShape> vanilla) {
        ColliderWorld w = VirtualColliders.peek(entity.level());
        if (w == null || entity.noPhysics) return vanilla;
        Box q = VirtualColliders.box(query);
        List<ColliderBody> near = w.bodiesNear(q);
        if (near.isEmpty()) return vanilla;
        List<VoxelShape> out = new ArrayList<>(vanilla.size() + 8);
        out.addAll(vanilla); // ванільний список може бути незмінним — копіюємо
        for (ColliderBody b : near) {
            VoxelShape[] shapes = b.platformCache(ColliderPhysics::toShapes);
            b.collectIndices(q, i -> out.add(shapes[i]));
        }
        return out;
    }

    private static VoxelShape[] toShapes(List<Box> boxes) {
        VoxelShape[] s = new VoxelShape[boxes.size()];
        for (int i = 0; i < s.length; i++) s[i] = Shapes.create(VirtualColliders.aabb(boxes.get(i)));
        return s;
    }

    /** Чи коробка вільна від віртуальних тіл (для {@code noCollision}-перевірок ваніли). */
    public static boolean free(Level level, AABB box) {
        ColliderWorld w = VirtualColliders.peek(level);
        return w == null || !w.intersects(VirtualColliders.box(box));
    }

    /** {@code level.noCollision(entity, box)} + віртуальні тіла (край при присіданні, «чи є опора»). */
    public static boolean noCollision(Level level, Entity entity, AABB box) {
        return level.noCollision(entity, box) && free(level, box);
    }

    /**
     * Антифлай сервера ({@code noBlocksAround}) дивиться лише на блоки — гравця, що стоїть на моделі,
     * без цього кікнуло б за «політ» через 4 секунди.
     */
    public static boolean standsOnVirtual(Entity entity) {
        ColliderWorld w = VirtualColliders.peek(entity.level());
        if (w == null) return false;
        AABB a = entity.getBoundingBox().inflate(0.0625).expandTowards(0, -0.55, 0);
        return w.intersects(VirtualColliders.box(a));
    }

    // ── тік: перенесення і виштовхування ─────────────────────────────────

    public static void tick(Level level) {
        ColliderWorld w = VirtualColliders.peek(level);
        if (w == null) return;
        w.tick(level.getGameTime(), body -> carry(level, body));
    }

    private static void carry(Level level, ColliderBody body) {
        Box swept = body.sweptBounds();
        if (swept == null) return;
        AABB area = VirtualColliders.aabb(swept).inflate(0.5, 1.0, 0.5);
        double[] out = new double[4];
        for (Entity e : level.getEntities((Entity) null, area, ColliderPhysics::simulatedHere)) {
            if (!Carry.solve(body, VirtualColliders.box(e.getBoundingBox()), out)) continue;
            Vec3 want = new Vec3(out[0], out[1], out[2]);
            // звичайні блоки все ще тверді: зсув обрізає ванільна колізія без віртуальних тіл
            Vec3 allowed = Entity.collideBoundingBox(e, want, e.getBoundingBox(), level, List.of());
            if (allowed.lengthSqr() > 0) e.setPos(e.getX() + allowed.x, e.getY() + allowed.y, e.getZ() + allowed.z);
            Vec3 v = e.getDeltaMovement();
            double vx = v.x, vy = v.y, vz = v.z;
            if (out[3] > 0) {
                e.setOnGround(true);
                e.resetFallDistance();
                if (vy < 0) vy = 0;
            }
            // гасимо швидкість у бік, звідки штовхнули (як ванільна зупинка об стіну)
            if (want.x != 0 && Math.signum(vx) == -Math.signum(want.x)) vx = 0;
            if (want.z != 0 && Math.signum(vz) == -Math.signum(want.z)) vz = 0;
            if (want.y < 0 && vy > 0) vy = 0;
            e.setDeltaMovement(vx, vy, vz);
            e.hasImpulse = true;
        }
    }

    /**
     * Хто рухає сутність, той і везе її: клієнт — свого гравця (і його транспорт), сервер — усе
     * інше. Серверних гравців не чіпаємо: їхню позицію визначає клієнт, сервер лише перевіряє.
     */
    private static boolean simulatedHere(Entity e) {
        if (e.noPhysics || e.isPassenger() || e.isSpectator()) return false;
        if (e.level().isClientSide) return e.isControlledByLocalInstance();
        return !(e instanceof Player) && !(e.getControllingPassenger() instanceof Player);
    }

    // ── рейкаст ───────────────────────────────────────────────────────────

    /**
     * {@code level.clip(ctx)} + віртуальні тіла: повертає ближче з двох. Використовується для
     * прицілу ({@code Entity.pick}) і снарядів, тож стріли застрягають у моделі, а клік бачить її.
     */
    public static BlockHitResult clip(Level level, ClipContext ctx) {
        BlockHitResult vanilla = level.clip(ctx);
        ColliderWorld w = VirtualColliders.peek(level);
        if (w == null) return vanilla;
        Vec3 from = ctx.getFrom(), to = ctx.getTo();
        RayHit h = w.raycast(from.x, from.y, from.z, to.x, to.y, to.z);
        if (h == null) return vanilla;
        if (vanilla.getType() != HitResult.Type.MISS) {
            double dv = vanilla.getLocation().distanceToSqr(from);
            double dh = from.distanceToSqr(h.x(), h.y(), h.z());
            if (dv <= dh) return vanilla;
        }
        return VirtualBlockHit.of(h);
    }

    // ── взаємодія ─────────────────────────────────────────────────────────

    /** Тіло і частина, яким належить точка влучання (на сервері приходить звичайний BlockHitResult). */
    public record Target(ColliderBody body, int part) {}

    public static Target resolve(Level level, BlockHitResult hit) {
        ColliderWorld w = VirtualColliders.peek(level);
        if (w == null) return null;
        if (hit instanceof VirtualBlockHit v) {
            ColliderBody b = w.get(v.ownerKey());
            if (b != null) return new Target(b, v.part());
        }
        Vec3 p = hit.getLocation();
        // справжній блок у клітинці має пріоритет: це клік по ньому, а не по моделі
        BlockPos pos = hit.getBlockPos();
        if (!level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()) return null;
        Box q = new Box(p.x, p.y, p.z, p.x, p.y, p.z).inflate(0.01);
        for (ColliderBody b : w.bodiesNear(q)) {
            List<Obb> parts = b.parts();
            for (int i = 0; i < parts.size(); i++) {
                Obb o = parts.get(i);
                if (o != null && o.contains(p.x, p.y, p.z, 0.01)) return new Target(b, i);
            }
        }
        return null;
    }

    /**
     * ПКМ по моделі. {@code null} — це не віртуальна колізія, ваніла обробляє як завжди.
     * Інакше результат треба повернути замість ванільного (і скасувати подію лоадера).
     */
    public static InteractionResult use(Level level, Player player, InteractionHand hand, BlockHitResult hit) {
        Target t = resolve(level, hit);
        if (t == null) return null;
        BlockPos owner = BlockPos.of(t.body().key());
        Object a = t.body().attachment();
        VirtualInteraction action = a instanceof VirtualInteraction vi ? vi : VirtualInteraction.NONE;
        BlockHitResult onOwner = new BlockHitResult(hit.getLocation(), hit.getDirection(), owner, false);
        InteractionResult r = action.use(level, owner, player, hand, onOwner, t.body().partName(t.part()));
        return r == null ? InteractionResult.PASS : r;
    }

    /** Чи можна поставити блок: його форма не має врізатися у віртуальне тіло. */
    public static boolean blocksPlacement(Level level, BlockPos pos, BlockState state) {
        ColliderWorld w = VirtualColliders.peek(level);
        if (w == null) return false;
        VoxelShape shape = state.getCollisionShape(level, pos);
        if (shape.isEmpty()) return false;
        for (AABB a : shape.toAabbs()) {
            if (w.intersects(VirtualColliders.box(a.move(pos)).deflate())) return true;
        }
        return false;
    }
}
