package dev.shaurmalib.collide.mc;

import dev.shaurmalib.collide.ColliderWorld;

/** Поле з тілами, яке міксин додає до {@code Level}. */
public interface ColliderHolder {

    ColliderWorld shaurma$colliders();

    void shaurma$setColliders(ColliderWorld world);
}
