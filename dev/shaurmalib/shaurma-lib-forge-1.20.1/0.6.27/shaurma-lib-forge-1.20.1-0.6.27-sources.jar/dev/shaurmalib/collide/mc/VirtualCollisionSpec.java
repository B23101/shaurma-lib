package dev.shaurmalib.collide.mc;

import net.minecraft.resources.ResourceLocation;

/**
 * Що потрібно анімованому блоку для віртуальних колізій: ті самі geo- і animation-файли, що
 * малює GeckoLib, плюс дія на ПКМ по моделі.
 *
 * @param model       {@code ns:path} → {@code assets/ns/geo/path.geo.json}
 * @param animations  {@code ns:path} → {@code assets/ns/animations/path.animation.json}
 * @param interaction що робить клік по моделі (типово — як клік по блоку)
 */
public record VirtualCollisionSpec(ResourceLocation model, ResourceLocation animations, VirtualInteraction interaction) {

    public VirtualCollisionSpec {
        if (model == null) throw new IllegalArgumentException("model");
        if (animations == null) animations = model;
        if (interaction == null) interaction = VirtualInteraction.OWNER_BLOCK;
    }

    public static VirtualCollisionSpec of(ResourceLocation modelAndAnimations) {
        return new VirtualCollisionSpec(modelAndAnimations, modelAndAnimations, VirtualInteraction.OWNER_BLOCK);
    }
}
