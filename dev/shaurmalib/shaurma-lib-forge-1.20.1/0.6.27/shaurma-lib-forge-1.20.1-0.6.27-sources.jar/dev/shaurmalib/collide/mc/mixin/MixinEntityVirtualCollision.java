package dev.shaurmalib.collide.mc.mixin;

import dev.shaurmalib.collide.mc.ColliderPhysics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

/**
 * Віртуальні колізії в русі сутності:
 * <ul>
 *   <li>{@code collide} — вокселі тіл додаються до списку колізій, з яким працює ваніла
 *       (рух, приземлення, step-up, ковзання);</li>
 *   <li>{@code isFree}/{@code canEnterPose} — не можна встати/залізти туди, де модель;</li>
 *   <li>{@code pick} — приціл бачить модель.</li>
 * </ul>
 */
@Mixin(Entity.class)
public abstract class MixinEntityVirtualCollision {

    @Shadow public abstract AABB getBoundingBox();
    @Shadow public abstract Level level();
    @Shadow public abstract float maxUpStep();
    @Shadow protected abstract AABB getBoundingBoxForPose(Pose pose);

    @Unique
    private Vec3 shaurma$collideMotion = Vec3.ZERO;

    @Inject(method = "collide(Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3;", at = @At("HEAD"))
    private void shaurma$captureMotion(Vec3 motion, CallbackInfoReturnable<Vec3> cir) {
        shaurma$collideMotion = motion;
    }

    @ModifyVariable(method = "collide(Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3;",
        at = @At(value = "STORE", ordinal = 0), ordinal = 0)
    private List<VoxelShape> shaurma$addVirtual(List<VoxelShape> vanilla) {
        // область, яку ваніла перевіряє за цей рух, включно зі спробою step-up
        AABB q = getBoundingBox().expandTowards(shaurma$collideMotion)
            .expandTowards(0, Math.max(maxUpStep(), 1.25f), 0).inflate(1e-7);
        return ColliderPhysics.withVirtual((Entity) (Object) this, q, vanilla);
    }

    @Inject(method = "isFree(Lnet/minecraft/world/phys/AABB;)Z", at = @At("RETURN"), cancellable = true)
    private void shaurma$isFree(AABB box, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ() && !ColliderPhysics.free(level(), box)) cir.setReturnValue(false);
    }

    @Inject(method = "canEnterPose", at = @At("RETURN"), cancellable = true)
    private void shaurma$canEnterPose(Pose pose, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ() && !ColliderPhysics.free(level(), getBoundingBoxForPose(pose).deflate(1.0E-7D))) {
            cir.setReturnValue(false);
        }
    }

    @Redirect(method = "pick", at = @At(value = "INVOKE",
        target = "Lnet/minecraft/world/level/Level;clip(Lnet/minecraft/world/level/ClipContext;)Lnet/minecraft/world/phys/BlockHitResult;"))
    private BlockHitResult shaurma$pick(Level level, ClipContext ctx) {
        return ColliderPhysics.clip(level, ctx);
    }
}
