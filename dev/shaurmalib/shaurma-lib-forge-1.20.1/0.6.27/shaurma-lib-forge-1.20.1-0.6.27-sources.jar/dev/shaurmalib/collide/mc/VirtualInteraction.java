package dev.shaurmalib.collide.mc;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;

/**
 * Що робить ПКМ по віртуальній колізії. Викликається на обох сторонах (як {@code Block.use}).
 *
 * @see VirtualColliders#attach
 */
@FunctionalInterface
public interface VirtualInteraction {

    /**
     * @param hit  {@code getBlockPos()} — позиція власника, {@code getLocation()} — точна точка влучання
     * @param part назва кістки, в яку влучили (або {@code null}, якщо форма не з моделі)
     */
    InteractionResult use(Level level, BlockPos owner, Player player, InteractionHand hand, BlockHitResult hit, String part);

    /** Клік по моделі = клік по самому блоку-власнику ({@code BlockState.use}). Типова поведінка. */
    VirtualInteraction OWNER_BLOCK = (level, owner, player, hand, hit, part) ->
        level.getBlockState(owner).use(level, player, hand, hit);

    /** Тверда, але неінтерактивна поверхня. */
    VirtualInteraction NONE = (level, owner, player, hand, hit, part) -> InteractionResult.PASS;
}
