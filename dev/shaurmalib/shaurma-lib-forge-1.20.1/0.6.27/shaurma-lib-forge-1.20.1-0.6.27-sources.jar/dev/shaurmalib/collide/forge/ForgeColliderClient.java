package dev.shaurmalib.collide.forge;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.shaurmalib.collide.Obb;
import dev.shaurmalib.collide.mc.VirtualBlockHit;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.RenderHighlightEvent;
import net.minecraftforge.common.MinecraftForge;

/** Клієнт: обведення частини моделі під прицілом (точна повернута коробка, як контур блоку). */
final class ForgeColliderClient {

    private ForgeColliderClient() {}

    static void init() {
        MinecraftForge.EVENT_BUS.addListener((RenderHighlightEvent.Block e) -> {
            if (!(e.getTarget() instanceof VirtualBlockHit hit)) return;
            e.setCanceled(true);
            Vec3 cam = e.getCamera().getPosition();
            outline(e.getPoseStack(), e.getMultiBufferSource().getBuffer(RenderType.lines()), hit.shape(), cam);
        });
    }

    private static void outline(PoseStack ps, VertexConsumer vc, Obb o, Vec3 cam) {
        double[][] c = new double[8][3];
        double g = 0.002; // як ванільний контур — трохи більший за форму, щоб не мерехтів
        for (int i = 0; i < 8; i++) {
            o.fromLocal(((i & 1) == 0 ? -1 : 1) * (o.hx + g), ((i & 2) == 0 ? -1 : 1) * (o.hy + g),
                ((i & 4) == 0 ? -1 : 1) * (o.hz + g), c[i]);
        }
        PoseStack.Pose pose = ps.last();
        for (int a = 0; a < 8; a++) {
            for (int bit = 1; bit < 8; bit <<= 1) {
                int b = a | bit;
                if (b == a) continue;
                float x0 = (float) (c[a][0] - cam.x), y0 = (float) (c[a][1] - cam.y), z0 = (float) (c[a][2] - cam.z);
                float x1 = (float) (c[b][0] - cam.x), y1 = (float) (c[b][1] - cam.y), z1 = (float) (c[b][2] - cam.z);
                float nx = x1 - x0, ny = y1 - y0, nz = z1 - z0;
                float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                if (len < 1e-6f) continue;
                nx /= len; ny /= len; nz /= len;
                vc.vertex(pose.pose(), x0, y0, z0).color(0, 0, 0, 0.4f).normal(pose.normal(), nx, ny, nz).endVertex();
                vc.vertex(pose.pose(), x1, y1, z1).color(0, 0, 0, 0.4f).normal(pose.normal(), nx, ny, nz).endVertex();
            }
        }
    }
}
