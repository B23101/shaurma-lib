package dev.shaurmalib.collide.mc;

import dev.shaurmalib.collide.Obb;
import dev.shaurmalib.collide.RayHit;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Влучання прицілу/снаряда у віртуальну колізію. Для ваніли це звичайний {@link BlockHitResult}:
 * {@code getBlockPos()} — клітинка, в якій лежить точка влучання (трохи всередині форми), тому
 * серверна перевірка {@code handleUseItemOn} («точка не далі 1 блоку від клітинки») проходить
 * навіть для моделі в 5 блоків. Справжнього власника сервер знаходить сам за точкою
 * ({@link ColliderPhysics#resolve}).
 */
public final class VirtualBlockHit extends BlockHitResult {

    private final long ownerKey;
    private final int part;
    private final Obb shape;

    VirtualBlockHit(Vec3 location, Direction face, BlockPos cell, long ownerKey, int part, Obb shape) {
        super(location, face, cell, false);
        this.ownerKey = ownerKey;
        this.part = part;
        this.shape = shape;
    }

    static VirtualBlockHit of(RayHit h) {
        Vec3 loc = new Vec3(h.x(), h.y(), h.z());
        Direction face = switch (h.dominantAxis()) {
            case 0 -> h.dominantSign() > 0 ? Direction.EAST : Direction.WEST;
            case 1 -> h.dominantSign() > 0 ? Direction.UP : Direction.DOWN;
            default -> h.dominantSign() > 0 ? Direction.SOUTH : Direction.NORTH;
        };
        // клітинка трохи всередині форми — щоб точка точно належала їй
        BlockPos cell = BlockPos.containing(h.x() - h.nx() * 1e-3, h.y() - h.ny() * 1e-3, h.z() - h.nz() * 1e-3);
        return new VirtualBlockHit(loc, face, cell, h.body().key(), h.part(), h.body().parts().get(h.part()));
    }

    public BlockPos owner() { return BlockPos.of(ownerKey); }

    public long ownerKey() { return ownerKey; }

    public int part() { return part; }

    /** Точна форма частини, в яку влучили (для обведення). */
    public Obb shape() { return shape; }
}
