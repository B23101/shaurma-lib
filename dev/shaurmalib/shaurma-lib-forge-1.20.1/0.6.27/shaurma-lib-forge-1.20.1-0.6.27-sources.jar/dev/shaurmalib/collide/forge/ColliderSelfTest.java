package dev.shaurmalib.collide.forge;

import com.mojang.logging.LogUtils;
import dev.shaurmalib.collide.Box;
import dev.shaurmalib.collide.Obb;
import dev.shaurmalib.collide.ShapeSource;
import dev.shaurmalib.collide.mc.VirtualColliders;
import dev.shaurmalib.collide.mc.VirtualInteraction;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.List;

/**
 * Перевірка віртуальних колізій у справжньому сервері (міксини застосовані, ванільна фізика).
 * Вмикається лише змінною середовища {@code SHAURMA_COLLIDE_SELFTEST=1} (лише dev-сервер ігрових тестів):
 * <pre>SHAURMA_COLLIDE_SELFTEST=1 ./gradlew :lib-forge:runGameTestServer</pre>
 * Потрібен порожній шаблон {@code run/gameteststructures/collideempty.snbt} (структура 1×1×1 з повітря).
 */
public final class ColliderSelfTest {

    private static final Logger LOG = LogUtils.getLogger();
    private static final int Y = 250;

    private ColliderSelfTest() {}

    static void installIfRequested(net.minecraftforge.eventbus.api.IEventBus modBus) {
        if (!"1".equals(System.getenv("SHAURMA_COLLIDE_SELFTEST"))) return;
        modBus.addListener((net.minecraftforge.event.RegisterGameTestsEvent e) -> e.register(ColliderSelfTest.class));
        MinecraftForge.EVENT_BUS.addListener((ServerStartedEvent e) -> start(e.getServer()));
    }

    /** Ігровий тест чекає, поки самоперевірка відпрацює 100 тіків, і звітує її результат. */
    @net.minecraft.gametest.framework.GameTest(templateNamespace = "shaurma_lib", template = "collideempty", timeoutTicks = 600)
    @net.minecraftforge.gametest.PrefixGameTestTemplate(false)
    public static void virtualCollisions(net.minecraft.gametest.framework.GameTestHelper helper) {
        helper.succeedWhen(() -> {
            if (!finished) throw new net.minecraft.gametest.framework.GameTestAssertException("collide self-test is running");
            if (!fails.isEmpty()) throw new net.minecraft.gametest.framework.GameTestAssertException("collide FAILED: " + fails);
        });
    }

    private static ArmorStand onFloor, onLift, onRamp;
    private static ItemEntity item;
    private static long t0;
    private static volatile boolean finished;
    private static final List<String> fails = new ArrayList<>();

    private static void start(MinecraftServer server) {
        ServerLevel level = server.overworld();
        level.setChunkForced(0, 0, true);
        t0 = level.getGameTime();
        // 1) підлога 6×0.5×6
        VirtualColliders.attach(level, new BlockPos(0, Y, 0),
            ShapeSource.boxes(List.of(new Box(0, Y, 0, 6, Y + 0.5, 6))), VirtualInteraction.NONE);
        // 2) ліфт: піднімається на 0.05 за тік протягом 40 тіків
        long start = t0;
        VirtualColliders.attach(level, new BlockPos(8, Y, 0), new ShapeSource() {
            @Override public List<Obb> sample(long tick) {
                double lift = 0.05 * Math.max(0, Math.min(40, tick - start - 20));
                return List.of(Obb.of(new Box(8, Y + lift, 0, 11, Y + 0.5 + lift, 3)));
            }
            @Override public boolean movesAt(long tick) { return true; }
        }, VirtualInteraction.NONE);
        // 3) похилий пандус 20° (повернута OBB → вокселі-сходинки)
        double a = Math.toRadians(20), c = Math.cos(a), s = Math.sin(a);
        Obb ramp = Obb.of(new Box(-2, -0.125, -1.5, 2, 0.125, 1.5));
        ramp = ramp.transformed(dev.shaurmalib.collide.Placement.of(15, Y + 1, 1.5, new double[] { c, -s, 0, s, c, 0, 0, 0, 1 }));
        VirtualColliders.attach(level, new BlockPos(15, Y, 0), ShapeSource.fixed(List.of(ramp)), VirtualInteraction.NONE);

        onFloor = spawnStand(level, 3, Y + 3, 3);
        onLift = spawnStand(level, 9.5, Y + 1, 1.5);
        onRamp = spawnStand(level, 15, Y + 4, 1.5);
        item = new ItemEntity(level, 1.5, Y + 2, 1.5, new ItemStack(Items.DIAMOND));
        level.addFreshEntity(item);

        MinecraftForge.EVENT_BUS.addListener((TickEvent.ServerTickEvent e) -> {
            if (e.phase == TickEvent.Phase.END && level.getGameTime() - t0 == 100) finish(server, level);
        });
        LOG.info("[collide-selftest] started at tick {}", t0);
    }

    private static ArmorStand spawnStand(ServerLevel level, double x, double y, double z) {
        ArmorStand s = new ArmorStand(EntityType.ARMOR_STAND, level);
        s.moveTo(x, y, z, 0, 0);
        level.addFreshEntity(s);
        return s;
    }

    private static void check(boolean ok, String what) {
        LOG.info("[collide-selftest] {} {}", ok ? "PASS" : "FAIL", what);
        if (!ok) fails.add(what);
    }

    private static void finish(MinecraftServer server, ServerLevel level) {
        check(Math.abs(onFloor.getY() - (Y + 0.5)) < 1e-3 && onFloor.onGround(), "armor stand lands on virtual floor: y=" + onFloor.getY());
        check(Math.abs(item.getY() - (Y + 0.5)) < 0.05, "item rests on virtual floor: y=" + item.getY());
        check(Math.abs(onLift.getY() - (Y + 0.5 + 2.0)) < 0.06, "lift carried the stand up 2 blocks: y=" + onLift.getY());
        double rampTop = Y + 1 + 0.125 / Math.cos(Math.toRadians(20)); // верх дошки над центром
        check(Math.abs(onRamp.getY() - rampTop) < 0.2 && onRamp.getY() > Y + 0.5, "stand rests on tilted ramp: y=" + onRamp.getY());

        // приціл: Entity.pick (міксин) бачить підлогу
        ArmorStand eye = spawnStand(level, 3, Y + 4, 3);
        eye.setXRot(90);
        HitResult hit = eye.pick(10, 1, false);
        check(hit instanceof BlockHitResult b && hit.getType() == HitResult.Type.BLOCK && Math.abs(b.getLocation().y - (Y + 0.5)) < 1e-6,
            "pick hits virtual floor: " + hit.getLocation());
        check(VirtualColliders.intersects(level, new net.minecraft.world.phys.AABB(1, Y + 0.1, 1, 2, Y + 0.4, 2)), "API intersects");

        // ставити блок усередину моделі не можна
        check(dev.shaurmalib.collide.mc.ColliderPhysics.blocksPlacement(level, new BlockPos(2, Y, 2),
            net.minecraft.world.level.block.Blocks.STONE.defaultBlockState()), "placement inside model is blocked");

        LOG.info("[collide-selftest] {}", fails.isEmpty() ? "ALL PASSED" : "FAILED: " + fails);
        finished = true;
    }
}
