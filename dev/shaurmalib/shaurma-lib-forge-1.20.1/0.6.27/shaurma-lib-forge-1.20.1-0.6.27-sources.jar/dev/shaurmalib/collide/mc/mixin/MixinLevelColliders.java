package dev.shaurmalib.collide.mc.mixin;

import dev.shaurmalib.collide.ColliderWorld;
import dev.shaurmalib.collide.mc.ColliderHolder;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/** Тіла віртуальних колізій живуть у полі світу: без глобальних мап, зникають разом зі світом. */
@Mixin(Level.class)
public abstract class MixinLevelColliders implements ColliderHolder {

    @Unique
    private ColliderWorld shaurma$colliderWorld;

    @Override
    public ColliderWorld shaurma$colliders() { return shaurma$colliderWorld; }

    @Override
    public void shaurma$setColliders(ColliderWorld world) { shaurma$colliderWorld = world; }
}
