package dev.shaurmalib.collide.mc.mixin;

import dev.shaurmalib.collide.mc.ColliderPhysics;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Сніжки, яйця, вогняні кулі, перли ({@code ProjectileUtil.getHitResult}) зупиняються об модель.
 * Підміна саме {@code clip} важлива: від точки влучання ваніла обрізає пошук сутностей, тож
 * моба за моделлю снаряд не зачепить.
 */
@Mixin(ProjectileUtil.class)
public abstract class MixinProjectileUtilVirtual {

    @Redirect(method = "getHitResult(Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/entity/Entity;Ljava/util/function/Predicate;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/level/Level;)Lnet/minecraft/world/phys/HitResult;",
        at = @At(value = "INVOKE",
            target = "Lnet/minecraft/world/level/Level;clip(Lnet/minecraft/world/level/ClipContext;)Lnet/minecraft/world/phys/BlockHitResult;"))
    private static BlockHitResult shaurma$clip(Level level, ClipContext ctx) {
        return ColliderPhysics.clip(level, ctx);
    }
}
