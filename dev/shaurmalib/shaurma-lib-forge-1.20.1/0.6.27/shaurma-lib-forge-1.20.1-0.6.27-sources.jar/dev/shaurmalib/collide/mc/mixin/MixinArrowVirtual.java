package dev.shaurmalib.collide.mc.mixin;

import dev.shaurmalib.collide.mc.ColliderPhysics;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Стріли й тризуби мають власний рейкаст у {@code tick} — вони теж застрягають у моделі. */
@Mixin(AbstractArrow.class)
public abstract class MixinArrowVirtual {

    @Redirect(method = "tick", at = @At(value = "INVOKE",
        target = "Lnet/minecraft/world/level/Level;clip(Lnet/minecraft/world/level/ClipContext;)Lnet/minecraft/world/phys/BlockHitResult;"))
    private BlockHitResult shaurma$clip(Level level, ClipContext ctx) {
        return ColliderPhysics.clip(level, ctx);
    }
}
