package dev.shaurmalib.collide.mc.mixin;

import dev.shaurmalib.collide.mc.ColliderPhysics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Присідання на краю моделі не дає впасти — як на краю звичайного блоку. */
@Mixin(Player.class)
public abstract class MixinPlayerVirtualEdge {

    @Redirect(method = { "maybeBackOffFromEdge", "isAboveGround" }, at = @At(value = "INVOKE",
        target = "Lnet/minecraft/world/level/Level;noCollision(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/AABB;)Z"))
    private boolean shaurma$noCollision(Level level, Entity entity, AABB box) {
        return ColliderPhysics.noCollision(level, entity, box);
    }
}
