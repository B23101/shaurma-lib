package dev.shaurmalib.collide.forge;

import com.mojang.logging.LogUtils;
import dev.shaurmalib.collide.ColliderAssets;
import dev.shaurmalib.collide.mc.ColliderPhysics;
import dev.shaurmalib.collide.mc.VirtualColliders;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.forgespi.language.IModFileInfo;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

/**
 * Forge-клей віртуальних колізій: тік світу → перенесення, ПКМ → обробник тіла, заборона ставити
 * блок усередину моделі, читання geo/animation-файлів з jar-ів модів (на сервері теж).
 */
public final class ForgeColliderBootstrap {

    private static final Logger LOG = LogUtils.getLogger();

    private ForgeColliderBootstrap() {}

    public static void init(IEventBus modBus) {
        ColliderAssets.install(ForgeColliderBootstrap::read, w -> LOG.warn("[ShaurmaLib/collide] {}", w));

        MinecraftForge.EVENT_BUS.addListener((TickEvent.LevelTickEvent e) -> {
            if (e.phase == TickEvent.Phase.END) ColliderPhysics.tick(e.level);
        });
        MinecraftForge.EVENT_BUS.addListener((LevelEvent.Unload e) -> {
            if (e.getLevel() instanceof Level l) VirtualColliders.forget(l);
        });
        // ПКМ по моделі: на клієнті — щоб не передбачати постановку блоку в клітинку моделі,
        // на сервері — справжня дія. Пакет UseItemOn клієнт шле в будь-якому разі.
        MinecraftForge.EVENT_BUS.addListener(EventPriority.HIGH, (PlayerInteractEvent.RightClickBlock e) -> {
            InteractionResult r = ColliderPhysics.use(e.getLevel(), e.getEntity(), e.getHand(), e.getHitVec());
            if (r == null) return;
            e.setCanceled(true);
            e.setCancellationResult(r);
        });
        MinecraftForge.EVENT_BUS.addListener((BlockEvent.EntityPlaceEvent e) -> {
            if (e.getLevel() instanceof Level l && ColliderPhysics.blocksPlacement(l, e.getPos(), e.getPlacedBlock())) {
                e.setCanceled(true);
            }
        });
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ForgeColliderClient::init);
        ColliderSelfTest.installIfRequested(modBus);
    }

    /** {@code assets/<ns>/<path>}: спершу jar мода з id = ns, потім усі інші (ns ≠ modid). */
    private static Optional<String> read(String namespace, String path) {
        ModList mods = ModList.get();
        if (mods == null) return Optional.empty();
        IModFileInfo own = mods.getModFileById(namespace);
        if (own != null) {
            Optional<String> s = readFrom(own, namespace, path);
            if (s.isPresent()) return s;
        }
        for (IModFileInfo info : mods.getModFiles()) {
            if (info == own) continue;
            Optional<String> s = readFrom(info, namespace, path);
            if (s.isPresent()) return s;
        }
        return Optional.empty();
    }

    private static Optional<String> readFrom(IModFileInfo info, String namespace, String path) {
        try {
            Path p = info.getFile().findResource("assets", namespace, path);
            if (p == null || !Files.isRegularFile(p)) return Optional.empty();
            return Optional.of(Files.readString(p, StandardCharsets.UTF_8));
        } catch (IOException | RuntimeException ex) {
            return Optional.empty();
        }
    }
}
